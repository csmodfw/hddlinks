#!/usr/local/bin/Resource/www/cgi-bin/php
<?php
phpinfo();
?>

#!/usr/local/bin/Resource/www/cgi-bin/php
<?php
$file="/tmp/serialepenet.txt";
$exec="rm -f ".$file;
exec ($exec);
?>

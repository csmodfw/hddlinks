#!/usr/local/bin/Resource/www/cgi-bin/php
<?php
exec ($exec);
$exec="rm -f /tmp/opensub.txt";
exec ($exec);
?>

#!/usr/local/bin/Resource/www/cgi-bin/php
<?php
$exec="rm -f /tmp/moviesplanet.txt";
exec ($exec);
?>

<!DOCTYPE html>
<html><head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<link rel="stylesheet" type="text/css" href="../custom.css" />
      <meta charset="utf-8">
      <title>Sezoane</title>
</head>
<body>
<?php
function str_between($string, $start, $end){
	$string = " ".$string; $ini = strpos($string,$start);
	if ($ini == 0) return ""; $ini += strlen($start); $len = strpos($string,$end,$ini) - $ini;
	return substr($string,$ini,$len);
}
$query = $_GET["file"];
if($query) {
   $queryArr = explode(',', $query);
   $link = $queryArr[0];
   $pg_tit = urldecode($queryArr[1]);
}
echo  '<h2 style="color:#000000;background-color:deepskyblue;text-align:center">'.$pg_tit."</H2>";
$html = file_get_contents($link);
$t1=explode("<div id='serial_description'>",$html);
$t2=explode("src='",$t1[1]);
$t3=explode("'",$t2[1]);
$img="http://serialepenet.ro/".$t3[0];
$img=str_replace(" ","%20",$img);
$annotation=str_between($t1[1],"'serial_description_text'>","</span>");
$annotation=str_replace("</b>",":",$annotation);
$annotation = preg_replace("/(<\/?)(\w+)([^>]*>)/e","",$annotation);
$t=str_between($html,"<title>","</title>");
$t=explode("serial",$t);
$t=trim($t[0]);
if ($t <> "") {
$pg_tit = $t;
}
echo '
  <div class="content">
  <div>
    <ul>
';
$videos = explode("<div class='bloc_sezoane'>", $html);

unset($videos[0]);
$videos = array_values($videos);
foreach($videos as $video) {
   $t1=explode('href="',$video);
   $t2=explode('"',$t1[1]);
   $link="http://serialepenet.ro/".$t2[0];
   $t3=explode("class='serial_title'>",$video);
   $t4=explode("<",$t3[1]);
   $title=$t4[0];
   $s=$pg_tit."-".$title;
   $link = "serialepenet_s.php?file=".$link.",".urlencode($s);
   echo '<li><a href="'.$link.'"><font size="4">'.$title.'</font></a></li>';
}
?>
</ul>
<div style='clear:both;'></div>
<div id='serial_description'>
<div class='serial_thumb_left'>
<img src='<?php echo $img; ?>' /></div>
<span id='serial_description_text'><font size="4">
<?php echo $annotation; ?></font></span>
</div>
</div>
<br></body>
</html>
<br></body>
</html>

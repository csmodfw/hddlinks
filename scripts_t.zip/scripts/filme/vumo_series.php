<!DOCTYPE html>
<?php
error_reporting(0);
include ("../common.php");

$file = $_GET["file"];
//$file=str_replace("+","%20",$file);
$title = $_GET["title"];
$page = $_GET["page"];
?>
<html><head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate"/>
<meta http-equiv="Pragma" content="no-cache"/>
<meta http-equiv="Expires" content="0"/>
      <title><?php echo $title; ?></title>
<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.8.0/jquery.min.js"></script>
<script src="../jquery.nicescroll.min.js"></script>

<script type="text/javascript">
  $(document).ready(function() {
	$("html").niceScroll({styler:"fb",cursorcolor:"#000"});
  });
</script>
<link rel="stylesheet" type="text/css" href="../custom.css" />
</head>
<body>
<H2></H2>
<?php
function str_between($string, $start, $end){
	$string = " ".$string; $ini = strpos($string,$start);
	if ($ini == 0) return ""; $ini += strlen($start); $len = strpos($string,$end,$ini) - $ini;
	return substr($string,$ini,$len);
}
include ("../common.php");
$cookie=$base_cookie."vumo.dat";
$n=0;
echo '<h2 style="background-color:deepskyblue;color:black">'.$title.'</H2>';
echo '<table border="1px" width="100%">'."\n\r";
echo '<tr><TD colspan="4" align="right">';
if ($page > 1)
echo '<a href="vumo_series.php?page='.($page-1).'&file='.$file.'&title='.urlencode($title).'"><font size="4">&nbsp;&lt;&lt;&nbsp;</font></a> | <a href="vumo_series.php?page='.($page+1).'&file='.$file.'&title='.urlencode($title).'"><font size="4">&nbsp;&gt;&gt;&nbsp;</font></a></TD></TR>';
else
echo '<a href="vumo_series.php?page='.($page+1).'&file='.$file.'&title='.urlencode($title).'"><font size="4">&nbsp;&gt;&gt;&nbsp;</font></a></TD></TR>';

//$url="http://vumoo.li/videos/category/".str_replace(" ","%20",$file)."/?page=".$page."";
$requestLink = "http://vumoo.li/videos/category/trending-television/?page=".$page."";
//$url = file_get_contents("".$url."");
$cookie=$base_cookie."vumo.dat";
    if (!function_exists('json_last_error_msg')) {
        function json_last_error_msg() {
            static $ERRORS = array(
                JSON_ERROR_NONE => 'No error',
                JSON_ERROR_DEPTH => 'Maximum stack depth exceeded',
                JSON_ERROR_STATE_MISMATCH => 'State mismatch (invalid or malformed JSON)',
                JSON_ERROR_CTRL_CHAR => 'Control character error, possibly incorrectly encoded',
                JSON_ERROR_SYNTAX => 'Syntax error',
                JSON_ERROR_UTF8 => 'Malformed UTF-8 characters, possibly incorrectly encoded'
            );

            $error = json_last_error();
            return isset($ERRORS[$error]) ? $ERRORS[$error] : 'Unknown error';
        }
    }
require_once 'httpProxyClass.php';
require_once 'cloudflareClass.php';

$httpProxy   = new httpProxy();
$httpProxyUA = 'proxyFactory';
$requestPage = json_decode($httpProxy->performRequest($requestLink));

// if page is protected by cloudflare
if($requestPage->status->http_code == 503) {
	// Make this the same user agent you use for other cURL requests in your app
	cloudflare::useUserAgent($httpProxyUA);

	// attempt to get clearance cookie
	if($clearanceCookie = cloudflare::bypass($requestLink)) {
		// use clearance cookie to bypass page
		$requestPage = $httpProxy->performRequest($requestLink, 'GET', null, array(
			'cookies' => $clearanceCookie
		));
		// return real page content for site
		$requestPage = json_decode($requestPage);
		$tmp = $requestPage->content;
	} else {
		// could not fetch clearance cookie
		$tmp = 'Could not fetch CloudFlare clearance cookie (most likely due to excessive requests)';
	}
} else {
  $tmp = $requestPage->content;
}
//echo $l;
 $videos = explode('<article class="movie_item">', $tmp);
unset($videos[0]);
$videos = array_values($videos);
foreach($videos as $video) {

  $t1 = explode('<a href="/videos/play/', $video);
  $t2 = explode('"', $t1[1]);
  $link = $t2[0];

  $t1 = explode('data-title="', $video);
  $t2 = explode('"', $t1[1]);
  $title1 = $t2[0];

  //$title=trim(preg_replace("/- filme online subtitrate/i","",$title));
  $t1 = explode('background-image: url(', $video);
  $t2 = explode(');', $t1[1]);
  $image = $t2[0];
  if ($n==0) echo '<TR>';
  echo '<td align="center" width="25%"><a href="vumo_ep.php?file='.$link.'&title='.$title1.'&image='.$image.'" target="_blank"><img src="'.$image.'" width="200px" height="280px"><BR><font size="4">'.$title1.'</font></a></TD>';
  $n++;
  if ($n == 4) {
  echo '</tr>';
  $n=0;
  }
}
echo '<tr><TD colspan="4" align="right">';
if ($page > 1)
echo '<a href="vumo_series.php?page='.($page-1).'&file='.$file.'&title='.urlencode($title).'"><font size="4">&nbsp;&lt;&lt;&nbsp;</font></a> | <a href="vumo_series.php?page='.($page+1).'&file='.$file.'&title='.urlencode($title).'"><font size="4">&nbsp;&gt;&gt;&nbsp;</font></a></TD></TR>';
else
echo '<a href="vumo_series.php?page='.($page+1).'&file='.$file.'&title='.urlencode($title).'"><font size="4">&nbsp;&gt;&gt;&nbsp;</font></a></TD></TR>';
echo "</table>";
?>
<br></body>
</html>

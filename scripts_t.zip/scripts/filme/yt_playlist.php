<!DOCTYPE html>
<?php
include ("../common.php");
$query = $_GET["page"];
if($query) {
   $queryArr = explode(',', $query);
   $page = $queryArr[0];
   $search = $queryArr[1];
   $page_title=urldecode($queryArr[2]);
   $search=str_replace("|","&",$search);
}
$pageToken=$_GET["pageToken"];
$key="AIzaSyDhpkA0op8Cyb_Yu1yQa1_aPSr7YtMacYU";
if ($pageToken)
$l2="https://www.googleapis.com/youtube/v3/playlistItems?part=snippet&maxResults=25&pageToken=".$pageToken."&playlistId=".$search."&key=".$key;
else
$l2="https://www.googleapis.com/youtube/v3/playlistItems?part=snippet&maxResults=25&playlistId=".$search."&key=".$key;
  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $l2);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US; rv:1.9.1.2) Gecko/20090729 Firefox/3.5.2 GTB5');
  curl_setopt($ch, CURLOPT_FOLLOWLOCATION  ,1);
  curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
  $html = curl_exec($ch);
  curl_close($ch);
  //echo $html;
  $p=json_decode($html,1);
  //print_r ($p);
  $nextpage=$p["nextPageToken"];
  $prevPageToken=$p["prevPageToken"];
?>
<html><head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate"/>
<meta http-equiv="Pragma" content="no-cache"/>
<meta http-equiv="Expires" content="0"/>
      <title><?php echo $page_title; ?></title>
<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.8.0/jquery.min.js"></script>
<script src="../jquery.nicescroll.min.js"></script>

<script type="text/javascript">
  $(document).ready(function() {
	$("html").niceScroll({styler:"fb",cursorcolor:"#000"});
  });
</script>
<link rel="stylesheet" type="text/css" href="../custom.css" />
</head>
<body>
<H2></H2>
<?php
function str_between($string, $start, $end){
	$string = " ".$string; $ini = strpos($string,$start);
	if ($ini == 0) return ""; $ini += strlen($start); $len = strpos($string,$end,$ini) - $ini;
	return substr($string,$ini,$len);
}
$n=0;
echo '<h2 style="background-color:deepskyblue;color:black">'.$page_title.'</H2>';
echo '<table border="1px" width="100%">'."\n\r";
echo '<tr><TD colspan="5" align="right">';
if ($page > 1)
echo '<a href="yt_playlist.php?page='.($page-1).','.$search.','.urlencode($page_title).'&pageToken='.$prevPageToken.'"><font size="4">&nbsp;&lt;&lt;&nbsp;</font></a> | <a href="yt_playlist.php?page='.($page+1).','.$search.','.urlencode($page_title).'&pageToken='.$nextpage.'"><font size="4">&nbsp;&gt;&gt;&nbsp;</font></a></TD></TR>';
else
echo '<a href="yt_playlist.php?page='.($page+1).','.$search.','.urlencode($page_title).'&pageToken='.$nextpage.'"><font size="4">&nbsp;&gt;&gt;&nbsp;</font></a></TD></TR>';

//$p=25*($page-1)+1;
//$link="http://gdata.youtube.com/feeds/api/users/".$search."/uploads?start-index=".$p."&max-results=25&v=2";
//$link="http://gdata.youtube.com/feeds/api/playlists/".$search."?v=1&orderby=position&start-index=".$p."&max-results=25";


  //$c=count($p["items"]);
  //echo $c;
  //die();
$link=str_replace("&","&amp;",$link);
//$html = file_get_contents($link);
//$videos = explode('<entry', $html);
//unset($videos[0]);
//$videos = array_values($videos);
for ($k=0;$k<25;$k++) {
	//$id = str_between($video,"<id>http://gdata.youtube.com/feeds/api/videos/","</id>");
    $id=$p["items"][$k]["snippet"]["resourceId"]["videoId"];
	$title = $p["items"][$k]["snippet"]["title"];
	$image = $p["items"][$k]["snippet"]["thumbnails"]["default"]["url"];
	$link = "http://www.youtube.com/watch?v=".$id;
  if ($link <> "") {
  if ($n==0) echo '<TR>';
  echo '<td align="center" width="20%"><a href="link1.php?file='.urlencode($link).','.urlencode($title).'" target="_blank"><img src="'.$image.'" width="180px" height="106px"><BR><font size="4">'.$title.'</font></a></TD>';
  $n++;
  if ($n == 5) {
  echo '</tr>';
  $n=0;
  }
  }
}
echo '<tr><TD colspan="5" align="right">';
if ($page > 1)
echo '<a href="yt_playlist.php?page='.($page-1).','.$search.','.urlencode($page_title).'&pageToken='.$prevPageToken.'"><font size="4">&nbsp;&lt;&lt;&nbsp;</font></a> | <a href="yt_playlist.php?page='.($page+1).','.$search.','.urlencode($page_title).'&pageToken='.$nextpage.'"><font size="4">&nbsp;&gt;&gt;&nbsp;</font></a></TD></TR>';
else
echo '<a href="yt_playlist.php?page='.($page+1).','.$search.','.urlencode($page_title).'&pageToken='.$nextpage.'""><font size="4">&nbsp;&gt;&gt;&nbsp;</font></a></TD></TR>';
echo "</table>";
?>
<br></body>
</html>

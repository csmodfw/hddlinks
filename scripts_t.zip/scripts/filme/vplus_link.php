<?php
function str_between($string, $start, $end){ 
	$string = " ".$string; $ini = strpos($string,$start); 
	if ($ini == 0) return ""; $ini += strlen($start); $len = strpos($string,$end,$ini) - $ini; 
	return substr($string,$ini,$len); 
}
function jdecoder($json_str) {
     $cyr_chars = array (
         '\u0430' => 'а', '\u0410' => 'А',
         '\u0431' => 'б', '\u0411' => 'Б',
         '\u0432' => 'в', '\u0412' => 'В',
         '\u0433' => 'г', '\u0413' => 'Г',
         '\u0434' => 'д', '\u0414' => 'Д',
         '\u0435' => 'е', '\u0415' => 'Е',
         '\u0451' => 'ё', '\u0401' => 'Ё',
         '\u0436' => 'ж', '\u0416' => 'Ж',
         '\u0437' => 'з', '\u0417' => 'З',
         '\u0438' => 'и', '\u0418' => 'И',
         '\u0439' => 'й', '\u0419' => 'Й',
         '\u043a' => 'к', '\u041a' => 'К',
         '\u043b' => 'л', '\u041b' => 'Л',
         '\u043c' => 'м', '\u041c' => 'М',
         '\u043d' => 'н', '\u041d' => 'Н',
         '\u043e' => 'о', '\u041e' => 'О',
         '\u043f' => 'п', '\u041f' => 'П',
         '\u0440' => 'р', '\u0420' => 'Р',
         '\u0441' => 'с', '\u0421' => 'С',
         '\u0442' => 'т', '\u0422' => 'Т',
         '\u0443' => 'у', '\u0423' => 'У',
         '\u0444' => 'ф', '\u0424' => 'Ф',
         '\u0445' => 'х', '\u0425' => 'Х',
         '\u0446' => 'ц', '\u0426' => 'Ц',
         '\u0447' => 'ч', '\u0427' => 'Ч',
         '\u0448' => 'ш', '\u0428' => 'Ш',
         '\u0449' => 'щ', '\u0429' => 'Щ',
         '\u044a' => 'ъ', '\u042a' => 'Ъ',
         '\u044b' => 'ы', '\u042b' => 'Ы',
         '\u044c' => 'ь', '\u042c' => 'Ь',
         '\u044d' => 'э', '\u042d' => 'Э',
         '\u044e' => 'ю', '\u042e' => 'Ю',
         '\u044f' => 'я', '\u042f' => 'Я',
  
         '\r' => '',
         '\n' => '<br />',
         '\t' => ''
     );
  
     foreach ($cyr_chars as $key => $value) {
         $json_str = str_replace($key, $value, $json_str);
     }
     return $json_str;
 }
function sec2hms ($sec, $padHours = false)
  {
    $hms = "";
    $hours = intval(intval($sec) / 3600);
    $hms .= ($padHours)
          ? str_pad($hours, 2, "0", STR_PAD_LEFT). ":"
          : $hours. ":";
    $minutes = intval(($sec / 60) % 60);
    $hms .= str_pad($minutes, 2, "0", STR_PAD_LEFT). ":";
    $seconds = intval($sec % 60);
    $hms .= str_pad($seconds, 2, "0", STR_PAD_LEFT);
    $hms .= ",000";
    return $hms;
}
include ("../common.php");
if (file_exists($base_pass."player.txt")) {
$flash=trim(file_get_contents($base_pass."player.txt"));
} else {
$flash="direct";
}
$link = $_GET["file"];
$pg_tit=urldecode($_GET["title"]);
$cookie=$base_cookie."vplus.dat";
$t1=explode(",",$link);
$link = $t1[0];
$k=str_between($link,"watch/","/");
$l="http://vplus.ro/watch/".$k."/";
//*************************
  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $l);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US; rv:1.9.1.2) Gecko/20090729 Firefox/3.5.2 GTB5');
  curl_setopt($ch, CURLOPT_FOLLOWLOCATION  ,1);
  curl_setopt ($ch, CURLOPT_POST, 1);
  //curl_setopt ($ch, CURLOPT_POSTFIELDS, $post);
  curl_setopt($ch, CURLOPT_COOKIEFILE, $cookie);
  $page = curl_exec($ch);
  curl_close($ch);
//http://vplus.ro/watch/eey8skva/
//http://vplus.ro/watch/qw7x6zhg/
$l="http://www.vplay.ro/play/dinosaur.do";
$l="http://vplus.ro/play/player_config.do";
$l="http://vplus.ro/play/dinosaur.do";
$post="onLoad=%5Btype%20Function%5D&external=0&key=".$k;
$post="onLoad=%5Btype%20Function%5D&key=".$k;
$post="onLoad=%5Btype%20Function%5D&external=0&key=".$k;
//Referer: http://i.vplus.ro//f/embed.swf?v=2.5&key=eey8skva
  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $l);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US; rv:1.9.1.2) Gecko/20090729 Firefox/3.5.2 GTB5');
  curl_setopt($ch, CURLOPT_FOLLOWLOCATION  ,1);
  curl_setopt ($ch, CURLOPT_POST, 1);
  curl_setopt ($ch, CURLOPT_POSTFIELDS, $post);
  curl_setopt($ch,CURLOPT_REFERER,"http://i.vplus.ro//f/embed.swf?v=2.5&key=".$k);
  curl_setopt($ch, CURLOPT_COOKIEFILE, $cookie);
  curl_setopt($ch, CURLOPT_HEADER, true);
  $page = curl_exec($ch);
  curl_close($ch);
//echo $page;
$link1=str_between($page,"nqURL=","&");
  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $link1);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US; rv:1.9.1.2) Gecko/20090729 Firefox/3.5.2 GTB5');
  curl_setopt($ch, CURLOPT_FOLLOWLOCATION  ,1);
  curl_setopt($ch,CURLOPT_REFERER,"http://i.vplus.ro//f/embed.swf?v=2.5&key=".$k);
  curl_setopt($ch, CURLOPT_NOBODY, true);
  curl_setopt($ch, CURLOPT_HEADER, true);
  $page1 = curl_exec($ch);
  curl_close($ch);
  $t1=explode("Location:",$page1);
  $t2=explode("\n",$t1[1]);
  $movie=trim($t2[0]);
  //http://607.filespot.com/zx/zxfj66ivy3attzbejjwe8sew84ukdgdm.mp4?st=9wxmQftRLVxjgqtW6RkoPA&e=1398956272&r=M3V%2FehcDyjdStLrKcRPRjQEnRvBizBu0yNuzgHBvRcQ%3D
  $t1=substr(strrchr($movie, "/"), 1);
  $t2=explode("mp4",$t1);
  $movie_file=trim($t2[0])."mp4";
$subs = str_between($page,"[","]");
if (strpos($subs,'RO') !==false)
  $lang="RO";
else if (strpos($subs,'EN') !==false)
  $lang="EN";
else
  $lang="";
if ($lang <> "") {
$list = glob($base_sub."*.srt");
   foreach ($list as $l) {
    str_replace(" ","%20",$l);
    unlink($l);
}
$post="onLoad=%5Btype%20Function%5D&sc=undefined&lang=".$lang."&key=".$k;
$post="key=".$k;
$l="http://www.vplay.ro/play/subs.do";
$l="http://vplus.ro/play/subs.do";
  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $l);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US; rv:1.9.1.2) Gecko/20090729 Firefox/3.5.2 GTB5');
  curl_setopt($ch, CURLOPT_FOLLOWLOCATION  ,1);
  curl_setopt ($ch, CURLOPT_POST, 1);
  curl_setopt ($ch, CURLOPT_POSTFIELDS, $post);
  curl_setopt($ch, CURLOPT_COOKIEFILE, $cookie);
  $html = curl_exec($ch);
  curl_close($ch);
  //echo $html;
  //$h=json_decode($html,true);
  //var_dump($h);
  //$html=dec($html);
$html=str_replace("\\\\","\\",$html);
  $html=jdecoder($html);
  //echo $html;
  $html=str_replace("\\","",$html);
//die();
$n=1;
$ttxml = "";
$videos = explode('"s":"', $html);
unset($videos[0]);
$videos = array_values($videos);
foreach($videos as $video) {
 $t1=explode('"',$video);
 $line=$t1[0];
 //echo $line."<BR>";
 $line=str_replace("u0163","�",$line);
 $line=str_replace("u021B","�",$line);
 $line=str_replace("u00e2","�",$line);
 $line=str_replace("u0103","�",$line);
 $line=str_replace("u015f","�",$line);
 $line=str_replace("u0219","�",$line);
 $line=str_replace("u00ee","�",$line);

 $line=str_replace("u015e","�",$line);
 $line=str_replace("u0218","�",$line);
 $line=str_replace("u00ce","�",$line);
 $line=str_replace("u0162","�",$line);
 $line=str_replace("u021A","�",$line);
 $line=str_replace("u0102","�",$line);
 $line=str_replace("u00C2","�",$line);
 $line=str_replace("u00CE","�",$line);

 $line=str_replace("u00e3","�",$line);
 $line=str_replace("u00de","�",$line);
 $line=str_replace("u00c3","�",$line);
 $line=str_replace("u00c2","�",$line);
 $line=str_replace("u021b","�",$line);
 $line=str_replace("<br>","\r\n",$line);
 //$line = trim(preg_replace("/<(.*)>|(\{(.*)\})/e","",$line));
 $t1=explode('"f":',$video);
 $t2=explode(",",$t1[1]);
 $begin=sec2hms($t2[0]);
 $t1=explode('"t":',$video);
 $t2=explode('}',$t1[1]);
 $end=sec2hms($t2[0]);
 $ttxml .=$n."\r\n".$begin." --> ".$end."\r\n".$line."\r\n"."\r\n";
 $n++;
}
//echo $ttxml;
if ($n > 2) {
//$t1=explode("vod:",$link1);
//$movie_file=trim($t1[1]);
//$movie_file="ef4e252a731d58e01e89fa200444342e";
//http://filespot.com/vpl/s3m/w6u45f7x.vod:c0fe5b5f0c353ca36a3edf3dd78b15ba:53625ebc
//$srt_name= $movie_file.".srt";
$srt_name = substr($movie_file, 0, -3)."srt";
$new_file=$base_sub.$srt_name;
if ($flash != "direct") {
 if (function_exists("mb_convert_encoding")) {
	$h=mb_convert_encoding($ttxml, 'UTF-8');
    $h = str_replace("ª","Ş",$h);
    $h = str_replace("º","ş",$h);
    $h = str_replace("Þ","Ţ",$h);
    $h = str_replace("þ","ţ",$h);
	$h = str_replace("ã","ă",$h);
	$h = str_replace("Ã","Ă",$h);

    $h = str_replace("Å£","ţ",$h);
    $h = str_replace("Å¢","Ţ",$h);
    $h = str_replace("Å","ş",$h);
	$h = str_replace("Ă®","î",$h);
	$h = str_replace("Ă¢","â",$h);
	$h = str_replace("Ă","Î",$h);
	$h = str_replace("Ã","Â",$h);
	$h = str_replace("Ä","ă",$h);
} else {
    $h = str_replace("�","S",$ttxml);
    $h = str_replace("�","s",$h);
    $h = str_replace("�","T",$h);
    $h = str_replace("�","t",$h);
    $h=str_replace("�","a",$h);
	$h=str_replace("�","a",$h);
	$h=str_replace("�","i",$h);
	$h=str_replace("�","A",$h);
}
} else {
$h=$ttxml;
}
$fh = fopen($new_file, 'w');
fwrite($fh, $h);
fclose($fh);
}
}
if ($flash == "direct") {
header('Content-type: application/vnd.apple.mpegURL');
header('Content-Disposition: attachment; filename="'.$movie_file.'"');
header("Location: $movie");
} else {
echo '
<!doctype html>
<HTML>
<HEAD>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>'.$pg_tit.'</title>
<style type="text/css">
body {
margin: 0px auto;
overflow:hidden;
}
body {background-color:#000000;}
</style>
<script src="//code.jquery.com/jquery-1.11.0.min.js"></script>
'.$jwv.'

</HEAD>
<BODY>
<div id="container"></div>
<script type="text/javascript">
jwplayer("container").setup({
';
if (strpos($movie,"fastupload") !== false)
echo '"flashplayer": "http://superweb.rol.ro/video/player6/jwplayer.flash.swf",';
echo '
"playlist": [{
"sources": [{"file": "'.$movie.'"}],
"tracks": [{"file": "../subs/'.$srt_name.'", "default": true}]
}],
    captions: {
        color: "#FFFFFF",
        fontSize: 20,
        backgroundOpacity: 0
    },
"skin": '.$skin.',
"height": $(document).height(),
"width": $(document).width(),
"startparam": "start",
"fallback": false,
"wmode": "direct",
"stagevideo": true
});
</script>
</BODY>
</HTML>
';
}
?>

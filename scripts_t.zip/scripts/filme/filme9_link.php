<?php
function str_between($string, $start, $end){
	$string = " ".$string; $ini = strpos($string,$start);
	if ($ini == 0) return ""; $ini += strlen($start); $len = strpos($string,$end,$ini) - $ini;
	return substr($string,$ini,$len);
}
$query = $_GET["file"];
if($query) {
   $queryArr = explode(',', $query);
   $link = urldecode($queryArr[0]);
   $pg_tit = urldecode($queryArr[1]);
   $pg = preg_replace('/[^A-Za-z0-9_]/','_',$pg_tit);
}
include ("../common.php");
if (file_exists($base_pass."player.txt")) {
$flash=trim(file_get_contents($base_pass."player.txt"));
} else {
$flash="direct";
}
$f=$base_pass."html5.txt";
$html5 = "DA";
if (file_exists($f)) {
$h=file_get_contents($f);
$t1=explode("|",$h);
$html5=$t1[0];
}
if ((strpos($base_pass,":") === false) && ($html5 == "DA")) $flash="html5";
$html=file_get_contents($link);
$t1=explode('source src="',$html);
$t2=explode('"',$t1[1]);
$movie=$t2[0];
$t0=explode('captions"',$html);
$t1=explode('src="',$t0[1]);
$t2=explode('"',$t1[1]);
$srt=$t2[0];
//echo $movie;
$movie_file=substr(strrchr($movie, "/"), 1);
$srt_name = substr($movie_file, 0, -3)."srt";
$list = glob($base_sub."*.srt");
   foreach ($list as $l) {
    str_replace(" ","%20",$l);
    unlink($l);
}
//echo $srt;
if ($srt) {
$out="";
$n=0;
$line = file_get_contents($srt);
$line=urlencode($line);


if ($flash == "direct") {
$line=str_replace("%C3%83%C2%A2","�",$line);
$line=str_replace("%C3%84%C2%83","�",$line);
$line=str_replace("%C3%85%C2%A3","�",$line);
$line=str_replace("%C3%83%C2%AE","�",$line);
$line=str_replace("%C3%85%C2%A2","�",$line);
$line=str_replace("%C3%85%C2%9F","�",$line);
$line=str_replace("%C3%85%C2%9E","�",$line);
$line=str_replace("%C3%83%C2%8E","�",$line);
$line=str_replace("%C2%83%2C","�",$line);
$line=str_replace("%C3%8E","�",$line);
$line=str_replace("%C2%A2","�",$line);
$line=str_replace("%C4%83","�",$line);
$line=str_replace("%C4%82","�",$line);
$line=str_replace("%C5%9F","�",$line);
$line=str_replace("%C5%A3","�",$line);
$line=str_replace("%C3%AE","�",$line);
$line=str_replace("%C5%A2","�",$line);
$line=str_replace("%C5%9E","�",$line);
$line=str_replace("%C5%9F","�",$line);
$line=str_replace("%C3%AE","�",$line);
$line=str_replace("%C3%A2","�",$line);
$line=str_replace("%C3%A3","�",$line);
$line=str_replace("%C8%9A","�",$line);
$line=str_replace("%C8%9B","�",$line);
$line=str_replace("%C8%99","�",$line);
$line=str_replace("%C8%98","�",$line);
//$line=str_replace("%C8%98"
//echo $start."<BR>".$line."<BR>";
//$line=str_replace("%C3%83%C2%AE","�",$line);
$line=urldecode($line);

$line=str_replace("�","a",$line);
$line=str_replace("A*?","t",$line);
} else {
$line=str_replace("%C3%83%C2%A2","a",$line);
$line=str_replace("%C3%84%C2%83","a",$line);
$line=str_replace("%C3%85%C2%A3","t",$line);
$line=str_replace("%C3%83%C2%AE","i",$line);
$line=str_replace("%C3%85%C2%A2","S",$line);
$line=str_replace("%C3%85%C2%9F","s",$line);
$line=str_replace("%C3%85%C2%9E","S",$line);
$line=str_replace("%C3%83%C2%8E","i",$line);
$line=str_replace("%C2%83%2C","a",$line);
$line=str_replace("%C3%8E","I",$line);
$line=str_replace("%C2%A2","a",$line);
$line=str_replace("%C4%83","a",$line);
$line=str_replace("%C4%82","A",$line);
$line=str_replace("%C5%9F","s",$line);
$line=str_replace("%C5%A3","t",$line);
$line=str_replace("%C3%AE","i",$line);
$line=str_replace("%C5%A2","T",$line);
$line=str_replace("%C5%9E","S",$line);
$line=str_replace("%C5%9F","s",$line);
$line=str_replace("%C3%AE","i",$line);
$line=str_replace("%C3%A2","a",$line);
$line=str_replace("%C3%A3","a",$line);
$line=str_replace("%C8%9A","T",$line);
$line=str_replace("%C8%9B","t",$line);
$line=str_replace("%C8%99","s",$line);
$line=str_replace("%C8%98","S",$line);
$line=urldecode($line);
$line=str_replace("�","a",$line);
$line=str_replace("A*?","t",$line);
}
$line=urldecode($line);
$out=$line;
//$out=mb_convert_encoding($out, 'UTF-8');
$new_file = $base_sub.$srt_name;
$fh = fopen($new_file, 'w');
fwrite($fh, $out);
fclose($fh);
}

if ($flash == "direct") {
header('Content-type: application/vnd.apple.mpegURL');
header('Content-Disposition: attachment; filename="'.$movie_file.'"');
header("Location: $movie");
} else {
echo '
<!doctype html>
<HTML>
<HEAD>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>'.$pg_tit.'</title>
<style type="text/css">
body {
margin: 0px auto;
overflow:hidden;
}
body {background-color:#000000;}
</style>
<script src="//code.jquery.com/jquery-1.11.0.min.js"></script>
'.$jwv.'
</HEAD>
<BODY>
<div id="container"></div>
<script type="text/javascript">
jwplayer("container").setup({
';
if ((strpos($movie,"fastupload") !== false) && $flash != "html5" ) {
echo '"flashplayer": "http://superweb.rol.ro/video/player6/jwplayer.flash.swf",';
if (strpos($base_pass,":") !== false) echo '"primary": "flash",';
}

echo '
"playlist": [{
"sources": [{"file": "'.$movie.'", "type": "mp4"}],
"tracks": [{"file": "../subs/'.$srt_name.'", "default": true}]
}],
    captions: {
        color: "#FFFFFF",
        fontsize: 20,
        backgroundOpacity: 0
    },
"height": $(document).height(),
"width": $(document).width(),
"skin": '.$skin.',
"startparam": "start",
"fallback": false,
"wmode": "direct",
"stagevideo": true
});

</script>
</BODY>
</HTML>
';
}
?>

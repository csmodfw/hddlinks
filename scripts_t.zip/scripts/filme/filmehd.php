<!DOCTYPE html>
<?php
error_reporting(0);
include ("../common.php");
$query = $_GET["page"];
if($query) {
   $queryArr = explode(',', $query);
   $page = $queryArr[1];
   $search = $queryArr[0];
   $page_title=urldecode($queryArr[2]);
   $search=str_replace("|","&",$search);
}
if (!$page)
$page_title = "Cautare: ".$search;
if ($page) {
if ($search)
  $l = "https://filmehd.net/".$search."/page/".$page;
else
  $l= "https://filmehd.net/page/".$page;
} else {
$search=str_replace(" ","+",$search);
$l= "https://filmehd.net/?s=".$search;
//echo $html;
}
//echo $l;
  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $l);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 10.0; rv:55.0) Gecko/20100101 Firefox/55.0');
  curl_setopt($ch, CURLOPT_FOLLOWLOCATION  ,1);
  curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
  //curl_setopt($ch, CURLOPT_COOKIEJAR, $cookie);
  //curl_setopt($ch, CURLOPT_COOKIEFILE, $cookie);
  $html = curl_exec($ch);
  curl_close($ch);
?>
<html><head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
      <title><?php echo $page_title; ?></title>
<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.8.0/jquery.min.js"></script>
<script type="text/javascript">
function isValid(evt) {
    var charCode = (evt.which) ? evt.which : event.keyCode,
        self = evt.target;
        //self = document.activeElement;
        //self = evt.currentTarget;
    //console.log(self.value);
       //alert (charCode);
    if (charCode == "97" || charCode == "49") {
     //alert (self.id);
     id = "imdb_" + self.id;
     val_imdb=document.getElementById(id).value;
     msg="imdb.php?tip=movie&" + val_imdb;
     window.open(msg);
    }
    return true;
}
$(document).on('keyup', '.imdb', isValid);
//$(document).on('keydown', '.imdb', isValid);
</script>
<link rel="stylesheet" type="text/css" href="../custom.css" />
</head>
<body><div id="mainnav">
<H2></H2>
<?php
function str_between($string, $start, $end){
	$string = " ".$string; $ini = strpos($string,$start);
	if ($ini == 0) return ""; $ini += strlen($start); $len = strpos($string,$end,$ini) - $ini;
	return substr($string,$ini,$len);
}
if (file_exists($base_pass."tastatura.txt")) {
$tast=trim(file_get_contents($base_pass."tastatura.txt"));
} else {
$tast="NU";
}
$w=0;
$n=0;
$w=0;
echo '<H2>'.$page_title.'</H2>';

echo '<table border="1px" width="100%">'."\n\r";
if ($page) {
echo '<tr><TD colspan="4" align="right">';

if ($page > 1)
echo '<a href="filmehd.php?page='.$search.','.($page-1).','.urlencode($page_title).'"><font size="4">&nbsp;&lt;&lt;&nbsp;</font></a> | <a href="filmehd.php?page='.$search.','.($page+1).','.urlencode($page_title).'"><font size="4">&nbsp;&gt;&gt;&nbsp;</font></a></TD></TR>';
else
echo '<a href="filmehd.php?page='.$search.','.($page+1).','.urlencode($page_title).'"><font size="4">&nbsp;&gt;&gt;&nbsp;</font></a></TD></TR>';
}
$html=urlencode($html);
$x=urlencode('<div class="imgleft"');
//$videos = explode('d%3D%22post', $html);
$videos = explode($x,$html);
unset($videos[0]);
$videos = array_values($videos);

foreach($videos as $video) {
	$t1 = explode('href%3D%22', $video);
	$t2 = explode("%22", $t1[1]);
	$link = urldecode($t2[0]);
	$link = str_replace(' ','%20',$link);
	$link = str_replace('[','%5B',$link);
	$link = str_replace(']','%5D',$link);
	$t1 = explode('src%3D%22', $video);
	$t2 = explode('%22', $t1[1]);
	$image = urldecode($t2[0]);

	$t1 = explode('alt%3D%22', $video);
	$t2 = explode('%22', $t1[1]);
	$t2=urldecode($t2[0]);
	$t3 = explode("&#8211;",$t2);
	$title = str_replace("– Filme online gratis subtitrate in romana","",$t3[0]);
	$title = str_replace("– Filme online gratis subtitratate in romana","",$title);
	$title = str_replace("– Filme online gratis subititrate in romana","",$title);
	$title = trim($title);
	$title=preg_replace("/online|subtitrat(e*)|film(e*)|vezi(.*)(:)|gratis/si","",$title);
	$title=trim(str_replace("&nbsp;","",$title));

	$pos = strpos($image, '.jpg');
	if (($pos !== false) && ($title <> "") && strpos($link,"serial-tv") === false){
    //$link = 'filme_link.php?file='.$link.','.urlencode($title);
  if ($n==0) echo '<TR>';
   if ($tast == "NU")
    echo '<td align="center" width="25%"><a href="filme_link.php?file='.urlencode($link).','.urlencode($title).'" target="blank"><img src="'.$image.'" width="160px" height="200px"><BR><font size="4">'.$title.'</font></a></TD>';
  else {
  $val_imdb="title=".$title."&year=".$year."&imdb=";
  echo '<td align="center" width="25%"><a class ="imdb" id="myLink'.($w*1).'" href="filme_link.php?file='.urlencode($link).','.urlencode($title).'" target="blank"><input type="hidden" id="imdb_myLink'.($w*1).'" value="'.$val_imdb.'"><img src="'.$image.'" width="160px" height="200px"><BR><font size="4">'.$title.'</font></a></TD>';
  $w++;
  }
   $n++;
  if ($n == 4) {
  echo '</tr>';
  $n=0;
  }
}
}
if ($page) {
echo '<tr><TD colspan="4" align="right">';

if ($page > 1)
echo '<a href="filmehd.php?page='.$search.','.($page-1).','.urlencode($page_title).'"><font size="4">&nbsp;&lt;&lt;&nbsp;</font></a> | <a href="filmehd.php?page='.$search.','.($page+1).','.urlencode($page_title).'"><font size="4">&nbsp;&gt;&gt;&nbsp;</font></a></TD></TR>';
else
echo '<a href="filmehd.php?page='.$search.','.($page+1).','.urlencode($page_title).'"><font size="4">&nbsp;&gt;&gt;&nbsp;</font></a></TD></TR>';
}
echo "</table>";
?>
<br></div></body>
</html>

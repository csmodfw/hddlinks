<?php
include ("../common.php");
$cookie=$base_cookie."opensub.dat";
unlink($cookie);

echo "Am sters token. Regeneram....";
?>

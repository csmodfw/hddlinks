<!DOCTYPE html>
<html><head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate"/>
<meta http-equiv="Pragma" content="no-cache"/>
<meta http-equiv="Expires" content="0"/>
      <title>moviesplanet</title>
<script src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
<link rel="stylesheet" type="text/css" href="../custom.css" />
</head>
<body>
<H2></H2>
<?php
function str_between($string, $start, $end){
	$string = " ".$string; $ini = strpos($string,$start);
	if ($ini == 0) return ""; $ini += strlen($start); $len = strpos($string,$end,$ini) - $ini;
	return substr($string,$ini,$len);
}
include ("../common.php");
require_once 'httpProxyClass.php';
require_once 'cloudflareClass.php';

$httpProxy   = new httpProxy();
$httpProxyUA = 'proxyFactory';
$cookie=$base_cookie."moviesplanet.dat";
$pop=$base_pass."moviesplanet.txt";
    if (!function_exists('json_last_error_msg')) {
        function json_last_error_msg() {
            static $ERRORS = array(
                JSON_ERROR_NONE => 'No error',
                JSON_ERROR_DEPTH => 'Maximum stack depth exceeded',
                JSON_ERROR_STATE_MISMATCH => 'State mismatch (invalid or malformed JSON)',
                JSON_ERROR_CTRL_CHAR => 'Control character error, possibly incorrectly encoded',
                JSON_ERROR_SYNTAX => 'Syntax error',
                JSON_ERROR_UTF8 => 'Malformed UTF-8 characters, possibly incorrectly encoded'
            );

            $error = json_last_error();
            return isset($ERRORS[$error]) ? $ERRORS[$error] : 'Unknown error';
        }
    }
if (file_exists($pop) && !file_exists($cookie)) {

  $requestLink="https://www.moviesplanet.tv/";

$requestPage = json_decode($httpProxy->performRequest($requestLink));

// if page is protected by cloudflare
if($requestPage->status->http_code == 503) {
	// Make this the same user agent you use for other cURL requests in your app
	cloudflare::useUserAgent($httpProxyUA);

	// attempt to get clearance cookie
	if($clearanceCookie = cloudflare::bypass($requestLink)) {
		// use clearance cookie to bypass page
		$requestPage = $httpProxy->performRequest($requestLink, 'GET', null, array(
			'cookies' => $clearanceCookie
		));
		// return real page content for site
		$requestPage = json_decode($requestPage);
		$html = $requestPage->content;
	} else {
		// could not fetch clearance cookie
		$html = 'Could not fetch CloudFlare clearance cookie (most likely due to excessive requests)';
	}
}
  $handle = fopen($pop, "r");
  $c = fread($handle, filesize($pop));
  fclose($handle);
  $a=explode("|",$c);
  $a1=str_replace("?","@",$a[0]);
  $user=urlencode($a1);
  $user=str_replace("@","%40",$user);
  $pass=trim($a[1]);
  //https://www.moviesplanet.tv/login
  //https://www.moviesplanet.tv/login
  //returnpath=%2F&username=vb6rocod&password=113298
  $l="https://www.moviesplanet.is/index.php?menu=login";
  $l="https://www.moviesplanet.is/login";
  $requestLink="https://www.moviesplanet.tv/login";
  $post="&username=".$user."&password=".$pass;
  $post="username=".$user."&password=".$pass."&action=login";
  $post="returnpath=%2F&username=".$user."&password=".$pass;
  $head=array('Accept: text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8','Accept-Language: ro-ro,ro;q=0.8,en-us;q=0.6,en-gb;q=0.4,en;q=0.2','Accept-Encoding: gzip, deflate','Content-Type: application/x-www-form-urlencoded','Content-Length: '.strlen($post));
  $postf=array(
  'returnpath' => '%2F',
  'username' => $user,
  'password' => $pass
  );

  $l="https://www.moviesplanet.tv/login";
  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $l);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_USERAGENT, 'proxyFactory');
  //curl_setopt($ch, CURLOPT_FOLLOWLOCATION  ,1);
  curl_setopt ($ch, CURLOPT_REFERER, "https://www.moviesplanet.tv/");
  curl_setopt($ch,CURLOPT_HTTPHEADER,$head);
  curl_setopt ($ch, CURLOPT_POST, 1);
  //curl_setopt($ch, CURLOPT_HEADER,1);
  curl_setopt ($ch, CURLOPT_POSTFIELDS, $post);
  curl_setopt($ch, CURLOPT_COOKIE, $clearanceCookie);
  curl_setopt($ch, CURLOPT_COOKIEJAR, $cookie);
  //curl_setopt($ch, CURLOPT_COOKIEFILE, $cookie);
  curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
  $html = curl_exec($ch);
  curl_close($ch);
$f=file_get_contents($cookie);
$t1=explode("PHPSESSID",$f);
$t2=explode("\n",$t1[1]);
$p=trim($t2[0]);
$t1=explode("guid",$f);
$t2=explode("\n",$t1[1]);
$g=trim($t2[0]);
$clearanceCookie = $clearanceCookie."PHPSESSID=".$p.";guid=".$g.";";
//echo $clearanceCookie;
file_put_contents($cookie,$clearanceCookie);
  //echo $html;
}
  $requestLink="https://www.moviesplanet.tv/";
//$requestPage = json_decode($httpProxy->performRequest($requestLink));

// if page is protected by cloudflare
//if($requestPage->status->http_code == 503) {
	// Make this the same user agent you use for other cURL requests in your app
	cloudflare::useUserAgent($httpProxyUA);

	// attempt to get clearance cookie
	//if($clearanceCookie = cloudflare::bypass($requestLink)) {
		// use clearance cookie to bypass page
		$requestPage = $httpProxy->performRequest($requestLink, 'GET', null, array(
			'cookies' => $clearanceCookie
		));
		// return real page content for site
		$requestPage = json_decode($requestPage);
		$h = $requestPage->content;
	//} else {
		// could not fetch clearance cookie
	//	$h = 'Could not fetch CloudFlare clearance cookie (most likely due to excessive requests)';
	//}
//}
 // echo $h;
  //die();
echo '<table border="1px" width="100%">'."\n\r";
echo '<TR><td style="color:black;background-color:deepskyblue;text-align:center" colspan="4"><font size="4"><b>moviesplanet - filme (cont moviesplanet.is)</b></font></TD></TR>';
$link="moviesplanet.php?page=1&link=https://www.moviesplanet.tv/movies&title=Recente";
echo '<TR><TD style="text-align:center"><font size="4">'.'<a href="'.$link.'" target="_blank">Recente</a></font></TD>';

$n=1;
$h1=str_between($h,'GENRE MOVIES',"</ul");
$videos = explode('<li>', $h1);
unset($videos[0]);
$videos = array_values($videos);
foreach($videos as $video) {
  $t1=explode('<a href="',$video);
  $t2=explode('"',$t1[1]);
  $link=$t2[0];
  if (strpos($link,"http") === false) $link="https://www.moviesplanet.tv".$link;
  $t1=explode('">',$video);
  $t2=explode('</a>',$t1[1]);
  $title=$t2[0];
  $link="moviesplanet.php?page=1&link=".$link."&title=".$title;

	if ($n == 0) echo "<TR>"."\n\r";
	echo '<TD style="text-align:center"><font size="4">'.'<a href="'.$link.'" target="_blank">'.$title.'</a></font></TD>';
    $n++;
    if ($n > 3) {
     echo '</TR>'."\n\r";
     $n=0;
    }
}
 if ($n<4) echo "</TR>"."\n\r";
 echo '</table>';

?>

</BODY>
</HTML>

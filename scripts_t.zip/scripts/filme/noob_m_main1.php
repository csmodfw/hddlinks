<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
      <title>Noobroom</title>
<link rel="stylesheet" type="text/css" href="../custom.css" />
<script src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
<script type="text/javascript">
    function myFunc(url2) {
         msg = 'noob_m1.php?page=1&query=' + url2 + '&sub=' + document.getElementById('sub').value + '&alf=' + document.getElementById('alf').value;
         window.open(msg);
    }
</script>
<script type="text/javascript">
// create the XMLHttpRequest object, according browser
function get_XmlHttp() {
  // create the variable that will contain the instance of the XMLHttpRequest object (initially with null value)
  var xmlHttp = null;
  if(window.XMLHttpRequest) {		// for Forefox, IE7+, Opera, Safari, ...
    xmlHttp = new XMLHttpRequest();
  }
  else if(window.ActiveXObject) {	// for Internet Explorer 5 or 6
    xmlHttp = new ActiveXObject("Microsoft.XMLHTTP");
  }
  return xmlHttp;
}

// sends data to a php file, via POST, and displays the received answer
function ajaxrequest(title, link) {
  var request =  get_XmlHttp();		// call the function for the XMLHttpRequest instance

  // create pairs index=value with data that must be sent to server
  //var the_data = {mod:add,title:title, link:link}; //Array
  var the_data = 'sub='+ document.getElementById('sub').value +'&alf='+document.getElementById('alf').value;
  var php_file='noob_extra.php';
  request.open("POST", php_file, true);			// set the request

  // adds a header to tell the PHP script to recognize the data as is sent via POST
  request.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
  request.send(the_data);		// calls the send() method with datas as parameter

  // Check request status
  // If the response is received completely, will be transferred to the HTML tag with tagID
  request.onreadystatechange = function() {
    if (request.readyState == 4) {
      alert (request.responseText);
    }
  }
}
function ajaxrequest2() {
  var request =  get_XmlHttp();		// call the function for the XMLHttpRequest instance

  // create pairs index=value with data that must be sent to server
  //var the_data = {mod:add,title:title, link:link}; //Array
  var the_data = '';
  var php_file='noob_del_cookie.php';
  request.open("POST", php_file, true);			// set the request

  // adds a header to tell the PHP script to recognize the data as is sent via POST
  request.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
  request.send(the_data);		// calls the send() method with datas as parameter

  // Check request status
  // If the response is received completely, will be transferred to the HTML tag with tagID
  request.onreadystatechange = function() {
    if (request.readyState == 4) {
      alert (request.responseText);
      location.reload();
    }
  }
}
function ajaxrequest3() {
  var request =  get_XmlHttp();		// call the function for the XMLHttpRequest instance

  // create pairs index=value with data that must be sent to server
  //var the_data = {mod:add,title:title, link:link}; //Array
  var the_data = '';
  var php_file='noob_save_cookie.php';
  request.open("POST", php_file, true);			// set the request

  // adds a header to tell the PHP script to recognize the data as is sent via POST
  request.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
  request.send(the_data);		// calls the send() method with datas as parameter

  // Check request status
  // If the response is received completely, will be transferred to the HTML tag with tagID
  request.onreadystatechange = function() {
    if (request.readyState == 4) {
      alert (request.responseText);
      location.reload();
    }
  }
}
</script>
</head>
<body>

<?php
function str_between($string, $start, $end){
	$string = " ".$string; $ini = strpos($string,$start);
	if ($ini == 0) return ""; $ini += strlen($start); $len = strpos($string,$end,$ini) - $ini;
	return substr($string,$ini,$len);
}
include ("../common.php");
$cookie=$base_cookie."noob.dat";
$filename=$base_pass."amigo.txt";
$noob_log=$base_pass."noob_log.txt";
$noob_serv=$base_cookie."noob_serv.dat";
$ff=$base_cookie."n.dat";
$noob_extra=$base_fav."noob_extra.dat";
$post="";
echo '<BR><table border="0" width="100%" style="background-color: lightskyblue;color:black">
<TR>
<TD><font size="5"><b>Noobroom (flash)</b></font></td>
';
echo '
<TD align="right">
<a onclick="ajaxrequest2()" style="cursor:pointer;"><font size="5"><b>Logout</b></font></a></td>
</tr></table><BR>
';
if (!file_exists($noob_extra)) {
$sub="DA";
$alf="NU";
} else {
  $handle = fopen($noob_extra, "r");
  $c = fread($handle, filesize($noob_extra));
  fclose($handle);
  $a=explode("|",$c);
  $sub=trim($a[0]);
  $alf=trim($a[1]);
}
/*
if (!file_exists($ff)) {
$l="http://noobroom.com/";
$h=file_get_contents($l);
$t1=explode('value="',$h);
$n= count($t1);
$t2=explode('"',$t1[1]); // $t1[$n-1]
$noob=$t2[0];
if (!$noob) $noob="http://noobroom9.com";
  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $noob."/login.php");
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US; rv:1.9.1.2) Gecko/20090729 Firefox/3.5.2 GTB5');
  curl_setopt($ch, CURLOPT_FOLLOWLOCATION  ,1);
  curl_setopt($ch, CURLOPT_HEADER, true);
  curl_setopt($ch, CURLOPT_TIMEOUT, 30);
  $h = curl_exec($ch);
  curl_close($ch);
  if (strpos($h,"200 OK") !== false) $out=$noob;
if ($n > 2 && !$out) {
  $t2=explode('"',$t1[2]);
  $noob=$t2[0];
  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $noob."/login.php");
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US; rv:1.9.1.2) Gecko/20090729 Firefox/3.5.2 GTB5');
  curl_setopt($ch, CURLOPT_FOLLOWLOCATION  ,1);
  curl_setopt($ch, CURLOPT_HEADER, true);
  curl_setopt($ch, CURLOPT_TIMEOUT, 30);
  $h = curl_exec($ch);
  curl_close($ch);
  if (strpos($h,"200 OK") !== false) $out=$noob;
}
if ($out) {
$fh = fopen($ff, 'w');
fwrite($fh, $noob);
fclose($fh);
} else {
 die();
}
} else {
$noob=file_get_contents($ff);
}
*/
$noob="http://superchillin.com";
$fh = fopen($ff, 'w');
fwrite($fh, $noob);
fclose($fh);
/*
if (file_exists($cookie)) {
  unlink($cookie);
}
*/
if (file_exists($noob_log) && !file_exists($cookie)) {
  $handle = fopen($noob_log, "r");
  $c = fread($handle, filesize($noob_log));
  fclose($handle);
  $a=explode("|",$c);
  $a1=str_replace("?","@",$a[0]);
  $user=urlencode($a1);
  $user=str_replace("@","%40",$user);
  $pass=trim($a[1]);
  $post="email=".$user."&password=".$pass;
}
if (file_exists($filename) && !file_exists($cookie) && !file_exists($noob_log)) {
  $pass=file_get_contents($filename);
  $lp="http://hddlinks.p.ht/n_a.php?pass=".$pass;
  $lp="http://hddlinks.pht.ro/n_a.php?pass=".$pass;
  //$post1=file_get_contents($lp);
  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $lp);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US; rv:1.9.1.2) Gecko/20090729 Firefox/3.5.2 GTB5');
  curl_setopt($ch, CURLOPT_FOLLOWLOCATION  ,1);
  $post1 = curl_exec($ch);
  curl_close($ch);
  if ($post1) $post=$post1;
  //echo $post;
}
if ($post) {
  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $noob."/");
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 5.1; rv:22.0) Gecko/20100101 Firefox/22.0');
  curl_setopt($ch, CURLOPT_FOLLOWLOCATION  ,1);
  curl_setopt ($ch, CURLOPT_REFERER, $noob."/");
  curl_setopt($ch, CURLOPT_COOKIEJAR, $cookie);
  curl_setopt($ch, CURLOPT_COOKIEFILE, $cookie);
  $html = curl_exec($ch);
  curl_close($ch);

  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $noob."/login.php");
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 5.1; rv:22.0) Gecko/20100101 Firefox/22.0');
  curl_setopt($ch, CURLOPT_FOLLOWLOCATION  ,1);
  curl_setopt ($ch, CURLOPT_REFERER, $noob."/");
  curl_setopt($ch, CURLOPT_COOKIEJAR, $cookie);
  curl_setopt($ch, CURLOPT_COOKIEFILE, $cookie);
  $html = curl_exec($ch);
  curl_close($ch);
$post=$post."&recaptcha_challenge_field=03AHJ_VuuzO2g9g6IILiu2pyaterQVaBodP0EWtwOldqTajuz63nzeDsaRg_Cs617aTY_EFwWGEk2bScrak5VqgddT8mf7dDaAeq8FNQn3dyIIkeC0dZ68412_e0mDZAJCEw4MqZdXsEfZzskKSIiOIELzpZ_y6RaE4115uzZh6FLgC0PCEzdvDjGooksZbaBe4ZrTwBd4-EifnGifYL4ti-J8WSsLGj5gNnmeWRRfUIzxN1J_tYdorC9V_3IpZSavvdnozYWIC_-40UWWn6hYaLBF6Nt_VJvUw8HlUwyukVy78gUk1OrVss4&recaptcha_response_field=1002";

  $l=$noob."/login2.php";
  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $l);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 5.1; rv:22.0) Gecko/20100101 Firefox/22.0');
  curl_setopt($ch, CURLOPT_FOLLOWLOCATION  ,1);
  curl_setopt ($ch, CURLOPT_POST, 1);
  curl_setopt ($ch, CURLOPT_REFERER, $noob."/login.php");
  curl_setopt ($ch, CURLOPT_POSTFIELDS, $post);
  curl_setopt($ch, CURLOPT_COOKIEJAR, $cookie);
  curl_setopt($ch, CURLOPT_COOKIEFILE, $cookie);
  $html = curl_exec($ch);
  curl_close($ch);
}
  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $noob."/genre.php");
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US; rv:1.9.1.2) Gecko/20090729 Firefox/3.5.2 GTB5');
  curl_setopt($ch, CURLOPT_FOLLOWLOCATION  ,1);
  curl_setopt ($ch, CURLOPT_REFERER, $noob."/login.php");
  curl_setopt($ch, CURLOPT_COOKIEFILE, $cookie);
  $html = curl_exec($ch);
  curl_close($ch);
  $status = str_between($html,'premium.php">','</');
  $status = str_replace("<","&lt;",$status);
  /*
  $t1=explode('premium.php',$html);
  $t2=explode(">",$t1[1]);
  $t3=explode("<",$t2[1]);
  $status=$t3[0]; //Active
  */
  if (strpos($status,"day") === false)
    $premium="";
  else
    $premium="Premium: ".$status;

if (!file_exists($noob_serv)) {
  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $noob."/index.php");
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US; rv:1.9.1.2) Gecko/20090729 Firefox/3.5.2 GTB5');
  curl_setopt($ch, CURLOPT_FOLLOWLOCATION  ,1);
  curl_setopt ($ch, CURLOPT_REFERER, $noob."/login.php");
  curl_setopt($ch, CURLOPT_COOKIEFILE, $cookie);
  $h = curl_exec($ch);
  curl_close($ch);
  $h=str_between($h,"Select","</div");
  $out="";
  $videos = explode('href=', $h);
  unset($videos[0]);
  $videos = array_values($videos);
  foreach($videos as $video) {
    $t1=explode("s=",$video);
if (sizeof($t1) > 2) {
    $t2=explode("'",$t1[1]);
    $serv=$t2[0];
    $t1=explode(">",$video);
    $t2=explode("<",$t1[1]);
    $name_serv=$t2[0];
    $out=$out.$name_serv."\n".$serv."\n";
  }
}
$fh = fopen($noob_serv, 'w');
fwrite($fh, $out);
fclose($fh);
}
$n=0;

echo '<table border="1" width="100%">';
echo '<TR><TD style="background-color: lightskyblue;color:black" colspan="3" align="center"><font size="5"><b>FILME</b></font></TD></TR>';
echo '<TR><TD align="left"><font size="5">Doar filme subtitrate: <select name="sub" id="sub">';
if ($sub=="DA")
echo '<option value="DA" selected>DA</option><option value="NU">NU</option></select></TD>';
else
echo '<option value="DA">DA</option><option value="NU" selected>NU</option></select></TD>';
echo '<TD align="left"><font size="5">Sorteaza alfabetic: <select name="alf" id="alf">';
if ($alf=="DA")
echo '<option value="DA" selected>DA</option><option value="NU">NU</option></select></TD>';
else
echo '<option value="DA">DA</option><option value="NU" selected>NU</option></select></TD>';
echo '<TD><input type="submit" value="Memoreaza optiunile" onclick="ajaxrequest()";></TD></TR>';


 echo '<TR><TD><a href="noob_m_fav1.php" target="_blank"><font size="5"><b>Filme favorite</b></font></a></TD>';
 echo '<TD colspan="2"><form action="noob_search1.php" target="_blank"><font size="5"><b>Cauta film: <input type="text" id="src" name="src"><input type="submit" id="send" name="send" value="cauta"></b></font></form></TD></TR>';
$link=$noob."/latest.php";
$title="Latest";
if ($n == 0) echo "<TR>";
 echo '<TD><font size="5">'.'<a href="javascript:myFunc(\''.urlencode($link).'&limit=&title='.$title.'\');">'.$title.'</a></font>';
 echo '</TD>';
 $n++;
 if ($n > 2) {
 echo '</TR>';
 $n=0;
 }
$link=$noob."/latest.php";
$title="Latest (250)";
if ($n == 0) echo "<TR>";
 echo '<TD><font size="5">'.'<a href="javascript:myFunc(\''.urlencode($link).'&limit=250&title='.$title.'\');">'.$title.'</a></font>';
 echo '</TD>';
 $n++;
 if ($n > 2) {
 echo '</TR>';
 $n=0;
 }
 $title="Alfabetic";
 $link=$noob."/azlist.php";
if ($n == 0) echo "<TR>";
 echo '<TD><font size="5">'.'<a href="javascript:myFunc(\''.urlencode($link).'&limit=&title='.$title.'\');">'.$title.'</a></font>';
 echo '</TD>';
 $n++;
 if ($n > 2) {
 echo '</TR>';
 $n=0;
 }
 $title="Top Rating";
$link=$noob."/rating.php";
if ($n == 0) echo "<TR>";
 echo '<TD><font size="5">'.'<a href="javascript:myFunc(\''.urlencode($link).'&limit=&title='.$title.'\');">'.$title.'</a></font>';
 echo '</TD>';
 $n++;
 if ($n > 2) {
 echo '</TR>';
 $n=0;
 }
  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $noob."/genre.php");
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US; rv:1.9.1.2) Gecko/20090729 Firefox/3.5.2 GTB5');
  curl_setopt ($ch, CURLOPT_REFERER, $noob."/login.php");
  curl_setopt($ch, CURLOPT_COOKIEFILE, $cookie);
  $html = curl_exec($ch);
  curl_close($ch);
$len= strlen("00000000000000000000100000");
$videos = explode('checkbox" name="', $html);
unset($videos[0]);
$n1=1;
$videos = array_values($videos);
foreach($videos as $video) {
    $l="";
    for ($k=1;$k<$len+1;$k++) {
      if ($k==$n1)
        $l.="1";
      else
        $l.="0";
    }
    $n1++;
    $link=$noob."/genre.php?b=".$l;

    $t3 = explode('>', $video);
    $t4 = explode('<', $t3[1]);
    $title = $t4[0];
if ($n == 0) echo "<TR>";
 echo '<TD><font size="5">'.'<a href="javascript:myFunc(\''.urlencode($link).'&limit=&title='.$title.'\');">'.$title.'</a></font>';
 echo '</TD>';
 $n++;
 if ($n > 2) {
 echo '</TR>';
 $n=0;
 }
}
 if ($n < 3) {
 echo '</TR>';
 $n=0;
 }
?>
</table>
</body>
</html>

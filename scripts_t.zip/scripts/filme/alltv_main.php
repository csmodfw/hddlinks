<?php
echo '
<form action="alltv.php" target="_blank">
<font size="4">Cauta un videoclip: </font><input type="text" size="40" name="search" id="search">
<input type="hidden" id="page" name="page" value="1">
<input type="submit" value="cauta"></form>
';
?>

<?php
function s_dec($s) { 
$sA = str_split($s); 
$sA = ); 
$sA = _splice($sA,3); 
$sA = _reverse($sA,13); 
$sA = _splice($sA,2); 
$sA = implode($sA); 
return $sA;
};
?>

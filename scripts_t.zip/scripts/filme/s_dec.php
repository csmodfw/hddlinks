<?php
function s_dec($s) { 
$sA = str_split($s); 
$sA = _splice($sA,2); 
$sA = _slice($sA,13); 
$sA = _splice($sA,1); 
$sA = ); 
$sA = _splice($sA,1); 
$sA = _slice($sA,69); 
$sA = ); 
$sA = implode($sA); 
return $sA;
};
?>

<?php
function s_dec($s) { 
$sA = str_split($s); 
$sA = _splice($sA,1); 
$sA = _reverse($sA,3); 
$sA = _length];a[b]=c}};Ty.prototype.Pa=function($sA,35); 
$sA = _reverse($sA,59); 
$sA = _splice($sA,1); 
$sA = _reverse($sA,43); 
$sA = _length];a[b]=c}};Ty.prototype.Pa=function($sA,36); 
$sA = _splice($sA,3); 
$sA = implode($sA); 
return $sA;
};
?>

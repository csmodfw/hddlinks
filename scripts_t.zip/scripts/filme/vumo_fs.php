<!doctype html>
<?php
include ("../common.php");
error_reporting(0);
//query=8612&tv=0&title=The+Intervention+(2016)&serv=30&hd=NU
$tit=$_GET["title"];
$image=$_GET["image"];
$link=$_GET["file"];
if (strpos($tit,"|") === false) {
//$pg_tit=urldecode(str_replace("\\","",$pg_tit));
$link="http://vumoo.at/videos/play/".$link;
$tip="movie";
} else {
   $t1=explode("|",$link);
   $id1=$t1[0];
   $id_t=$t1[1];
   $t1=explode("|",$tit);
   $tit=$t1[0];
   $tit2=$t1[1];
   $title= $t1[0]." ".$t1[1];
   $serial=$t1[0];
  preg_match("/(\d+)x(\d+)/",$t1[1],$m);
  //print_r ($m);
  $sezon=$m[1];
  $episod=$m[2];
  if ($id1) $openload="https://openload.co/embed/".$id1;
  if ($id_t) $google="https://docs.google.com/uc?id=".$id_t."&export=download";
  $tip="series";
}

function str_between($string, $start, $end){
	$string = " ".$string; $ini = strpos($string,$start);
	if ($ini == 0) return ""; $ini += strlen($start); $len = strpos($string,$end,$ini) - $ini;
	return substr($string,$ini,$len);
}
function get_value($q, $string) {
   $t1=explode($q,$string);
   return str_between($t1[1],"<string>","</string>");
}
   function generateResponse($request)
    {
        $context  = stream_context_create(
            array(
                'http' => array(
                    'method'  => "POST",
                    'header'  => "Content-Type: text/xml",
                    'content' => $request
                )
            )
        );
        $response     = file_get_contents("http://api.opensubtitles.org/xml-rpc", false, $context);
        return $response;
    }
if ($tip=="movie") {
$cookie=$base_cookie."vumo.dat";
$curlOptions = array(
    CURLOPT_SSL_VERIFYPEER => false,
    CURLOPT_RETURNTRANSFER => 1,
    CURLOPT_FOLLOWLOCATION => 1,
    CURLOPT_COOKIEFILE => ''.$cookie.'',
    CURLOPT_COOKIEJAR => ''.$cookie.'',
    CURLOPT_USERAGENT => "Mozilla/5.0 (Windows NT 6.1; WOW64; rv:43.0) Gecko/20100101 Firefox/43.0",
    CURLOPT_CONNECTTIMEOUT => 30,
    CURLOPT_TIMEOUT => 30,
);
$ch = curl_init();
foreach ($curlOptions as $k => $v)
    curl_setopt($ch, $k, $v);
usleep(rand(4000000, 6000000));
curl_setopt($ch, CURLOPT_URL, $_POST['result']);
curl_setopt($ch, CURLOPT_URL, "".$link."");
$tmp = curl_exec($ch);
//echo $tmp;
//die();
$t1=explode('openloadLink = "',$tmp);
$t2=explode('"',$t1[1]);
$openload=str_replace("\\","",$t2[0]);

$t1=explode('googleLink = "',$tmp);
$t2=explode('"',$t1[1]);
$google=str_replace("\\","",$t2[0]);
}
$f=$base_cookie."opensub.dat";
if (file_exists($f)) {
$token=file_get_contents($f);
} else {
$request="<?xml version=\"1.0\" encoding=\"iso-8859-1\"?>
<methodCall>
<methodName>LogIn</methodName>
<params>
 <param>
  <value>
   <string></string>
  </value>
 </param>
 <param>
  <value>
   <string></string>
  </value>
 </param>
 <param>
  <value>
   <string>en</string>
  </value>
 </param>
 <param>
  <value>
   <string>hd4all</string>
  </value>
 </param>
</params>
</methodCall>";
$response = generateResponse($request);
$token=get_value("token",$response);
file_put_contents($f,$token);
}
?>
<html>



   <head>

      <meta charset="utf-8">
      <title><?php echo $tit." ".$tit2; ?></title>
	  <link rel="stylesheet" type="text/css" href="../custom.css" />
     <script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.8.0/jquery.min.js"></script>
     <script src="../jquery.nicescroll.min.js"></script>
      <script type="text/javascript" src="../jquery.fancybox.js?v=2.1.5"></script>
      <script type="text/javascript" src="func.js"></script>
      <link rel="stylesheet" type="text/css" href="../jquery.fancybox.css?v=2.1.5" media="screen" />
<script type="text/javascript">
    function myFunc() {
         msg = 'vumo_fs_link.php?image=' + '<?php echo $image; ?>' + '&title=' + '<?php echo str_replace("'","\'",$tit); ?>' + '&serv='  + document.getElementById('server').value + '&sub=' + document.getElementById('menu').value;
         window.open(msg);
    }
function ajaxrequest2() {
  var request =  get_XmlHttp();		// call the function for the XMLHttpRequest instance

  // create pairs index=value with data that must be sent to server
  //var the_data = {mod:add,title:title, link:link}; //Array
  var the_data = '';
  var php_file='fs_del_cookie.php';
  request.open("POST", php_file, true);			// set the request

  // adds a header to tell the PHP script to recognize the data as is sent via POST
  request.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
  request.send(the_data);		// calls the send() method with datas as parameter

  // Check request status
  // If the response is received completely, will be transferred to the HTML tag with tagID
  request.onreadystatechange = function() {
    if (request.readyState == 4) {
      alert (request.responseText);
      location.reload();
    }
  }
}
</script>
<script type="text/javascript">
// create the XMLHttpRequest object, according browser
function get_XmlHttp() {
  // create the variable that will contain the instance of the XMLHttpRequest object (initially with null value)
  var xmlHttp = null;
  if(window.XMLHttpRequest) {		// for Forefox, IE7+, Opera, Safari, ...
    xmlHttp = new XMLHttpRequest();
  }
  else if(window.ActiveXObject) {	// for Internet Explorer 5 or 6
    xmlHttp = new ActiveXObject("Microsoft.XMLHTTP");
  }
  return xmlHttp;
}
</script>
<script type="text/javascript">
$(document).ready(function() {
	$(".various").fancybox({
		maxWidth	: 800,
		maxHeight	: 600,
		fitToView	: false,
		width		: '70%',
		height		: '70%',
		autoSize	: false,
		closeClick	: false,
		openEffect	: 'none',
		closeEffect	: 'none'
	});
	$('.fancybox').fancybox();
	$("html").niceScroll({styler:"fb",cursorcolor:"#000"});
});
</script>
  </head>
   <body>

	<div class="balloon"></div>
<?php
//echo '<h2 style="background-color:deepskyblue;color:black;">'.$tit.' '.$tit2.'</H2>';
echo '<table border="0" width="100%" style="background-color: lightskyblue;color:black">
<TR>
<TD><font size="5"><b>'.$tit.' '.$tit2.'</b></font></td>

<TD align="right">
<a onclick="ajaxrequest2()" style="cursor:pointer;"><font size="5"><b>Apasa aici daca lista e goala!</b></font></a></td>
</tr></table><BR>
';
if ($tip=="movie") {
$request="<?xml version=\"1.0\" encoding=\"iso-8859-1\"?>
<methodCall>
<methodName>SearchSubtitles</methodName>
<params>
 <param>
  <value>
   <string>".$token."</string>
  </value>
 </param>
 <param>
  <value>
   <array>
    <data>
     <value>
      <struct>
       <member>
        <name>query</name>
        <value>
         <string>".$tit."</string>
        </value>
       </member>
       <member>
        <name>sublanguageid</name>
        <value>
         <string>rum,eng</string>
        </value>
       </member>
      </struct>
     </value>
    </data>
   </array>
  </value>
 </param>
 <param>
  <value>
   <struct>
    <member>
     <name>limit</name>
     <value>
      <int>100</int>
     </value>
    </member>
   </struct>
  </value>
 </param>
</params>
</methodCall>";
//echo $request;
$response = generateResponse($request);
//echo $response;
$videos=explode("MatchedBy",$response);
unset($videos[0]);
$videos = array_values($videos);
$arrsub = array();
foreach($videos as $video) {
 $MovieKind = get_value("MovieKind",$video);
 $SubFormat = get_value("SubFormat",$video);
 if ($MovieKind == "movie" && $SubFormat == "srt") {
   $SubFileName =get_value("SubFileName",$video);
   $id1 = get_value("IDSubtitleFile",$video);
   $SubLanguageID = get_value("SubLanguageID",$video);
   //if ($SubLanguageID == "rum") break;
   $id2=get_value("IDSubtitleFile",$video);
   array_push($arrsub ,array($SubFileName,$SubLanguageID, $id2));
 }
}
} else {
$request="<?xml version=\"1.0\" encoding=\"iso-8859-1\"?>
<methodCall>
<methodName>SearchSubtitles</methodName>
<params>
 <param>
  <value>
   <string>".$token."</string>
  </value>
 </param>
 <param>
  <value>
   <array>
    <data>
     <value>
      <struct>
       <member>
        <name>query</name>
        <value>
         <string>".$tit."</string>
        </value>
       </member>
       <member>
        <name>season</name>
        <value>
         <int>".$sezon."</int>
        </value>
       </member>
       <member>
        <name>episode</name>
        <value>
         <int>".$episod."</int>
        </value>
       </member>
       <member>
        <name>sublanguageid</name>
        <value>
         <string>rum,eng</string>
        </value>
       </member>
      </struct>
     </value>
    </data>
   </array>
  </value>
 </param>
 <param>
  <value>
   <struct>
    <member>
     <name>limit</name>
     <value>
      <int>100</int>
     </value>
    </member>
   </struct>
  </value>
 </param>
</params>
</methodCall>";
//echo $request;
$response = generateResponse($request);
//echo $response;
$videos=explode("MatchedBy",$response);
unset($videos[0]);
$videos = array_values($videos);
$arrsub = array();
foreach($videos as $video) {
 //echo $video;
 $MovieKind = get_value("MovieKind",$video);
 $SubFormat = get_value("SubFormat",$video);
 //echo $MovieKind." ".$SubFormat."<BR>";
 if ($MovieKind == "episode" && $SubFormat == "srt") {
   $SubFileName =get_value("SubFileName",$video);
   $id1 = get_value("IDSubtitleFile",$video);
   $SubLanguageID = get_value("SubLanguageID",$video);
   //if ($SubLanguageID == "rum") break;
   $id2=get_value("IDSubtitleFile",$video);
   array_push($arrsub ,array($SubFileName,$SubLanguageID, $id2));
 }
}
}
//print_r ($arrsub);
$nn=count($arrsub);
echo '<p><b>Alegeti un server: </b><select name="server" id="server">';
if ($openload) echo '<option value="'.urlencode($openload).'">Openload</option>';
if ($google) echo '<option value="'.urlencode($google).'">Google</option>';
echo '</select>';
echo '<p><b>  Alegeti o subtitrare: </b><select name="menu" id="menu">';
echo '<option value="">fara subtitrare</option>';
for ($k=0;$k<$nn;$k++) {
  echo '<option value="'.$arrsub[$k][2].'">'.$arrsub[$k][1]." - ".$arrsub[$k][0].'</option>';
}
echo '</select>';
echo '<input type="submit" value="Vizioneaza!" onclick="myFunc()";>
</p>';
echo '<br></body>
</html>';

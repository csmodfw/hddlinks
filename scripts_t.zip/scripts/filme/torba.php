<!DOCTYPE html>
<?php
include ("../common.php");

if (isset($_GET['search'])) {
 $search=$_GET["search"];
 $tit=$search;
 $page=1;
 $s=str_replace(" ","+",$search);
 $link1="http://torba.se/search?title=".$s."&order=recent&_pjax=%23films-pjax-container&page=".$page."&per-page=";
} else {
$page = $_GET["page"];
$tit= $_GET["title"];
if (array_key_exists("link",$_GET)) {
$link=$_GET["link"];
$tip=$link;
}
$link1="http://torba.se/search?order=recent&genre=".$link."&_pjax=%23films-pjax-container&page=".$page."&per-page=";
$search="";
}
?>
<html><head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate"/>
<meta http-equiv="Pragma" content="no-cache"/>
<meta http-equiv="Expires" content="0"/>
      <title><?php echo $tit; ?></title>
<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.8.0/jquery.min.js"></script>
<script src="../jquery.nicescroll.min.js"></script>
<script type="text/javascript" src="../jquery.fancybox.js?v=2.1.5"></script>
<link rel="stylesheet" type="text/css" href="../jquery.fancybox.css?v=2.1.5" media="screen" />

<script type="text/javascript">
  $(document).ready(function() {
	$("html").niceScroll({styler:"fb",cursorcolor:"#000"});
  });
</script>
<link rel="stylesheet" type="text/css" href="../custom.css" />
<script type="text/javascript">
$(document).ready(function() {
	$(".various").fancybox({
		maxWidth	: 800,
		maxHeight	: 600,
		fitToView	: false,
		width		: '70%',
		height		: '70%',
		autoSize	: false,
		closeClick	: false,
		openEffect	: 'none',
		closeEffect	: 'none'
	});
	$('.fancybox').fancybox();
	$("html").niceScroll({styler:"fb",cursorcolor:"#000"});
});
</script>
</head>
<body>
<H2></H2>
<?php
function str_between($string, $start, $end){
	$string = " ".$string; $ini = strpos($string,$start);
	if ($ini == 0) return ""; $ini += strlen($start); $len = strpos($string,$end,$ini) - $ini;
	return substr($string,$ini,$len);
}
$l22="http://uphero.xpresso.eu/torba/m/glob.php";
$html22=file_get_contents($l22);
$videos = explode(",", $html22);
//echo $html22;
unset($videos[0]);
$videos = array_values($videos);

foreach($videos as $video) {
  $t1=explode('.',$video);
  $id_srt=trim($t1[0]);
  //echo $id_srt;
  $srt[$id_srt]="exista";
}
$noob_sub=$base_cookie."noob_sub.dat";
if (!file_exists($noob_sub)) {
  $sub="http://uphero.xpresso.eu/srt/list.php";
  $html=file_get_contents($sub);
  //$html=preg_replace("/ \(Awards Screener\)| \(High Bitrate Test\)| \(HDRip\)|/i","",$html);
  $fh = fopen($noob_sub, 'w');
  fwrite($fh, $html);
  fclose($fh);
}
$n=0;
echo '<h2 style="background-color:deepskyblue;color:black">'.$tit.'</H2>';
echo '<table border="1px" width="100%">'."\n\r";
echo '<tr><TD colspan="4" align="right">';
if (!$search) {
if ($page > 1)
echo '<a href="torba.php?page='.($page-1)."&link=".$tip."&title=".$tit.'"><font size="4">&nbsp;&lt;&lt;&nbsp;</font></a> | <a href="torba.php?page='.($page+1)."&link=".$tip."&title=".$tit.'"><font size="4">&nbsp;&gt;&gt;&nbsp;</font></a></TD></TR>';
else
echo '<a href="torba.php?page='.($page+1)."&link=".$tip."&title=".$tit.'"><font size="4">&nbsp;&gt;&gt;&nbsp;</font></a></TD></TR>';
}
//$link="http://123movies.to/movie/filter/movie/latest/".$link."/all/all/all/".$page."";
//$link="http://123movies.to/movie/filter/movie/latest/".$link."/all/all/all/all/".$page."";
//if ($page > 1) $link=$link."/".$page;
//http://torba.se/search?title=star+war&order=recent

  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $link1);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 5.1; rv:31.0) Gecko/20100101 Firefox/31.0');
  curl_setopt($ch, CURLOPT_FOLLOWLOCATION  ,1);
  //curl_setopt($ch, CURLOPT_COOKIEJAR, $cookie);
  //curl_setopt($ch, CURLOPT_COOKIEFILE, $cookie);
  $html = curl_exec($ch);
  curl_close($ch);
  //echo $html;
  //$html=str_between($html,'<ul class="list">','<ul class="paging">');
$h=file_get_contents($noob_sub);
$videos = explode('<div class="films-item-image">', $html);
unset($videos[0]);
$videos = array_values($videos);
foreach($videos as $video) {
    //if ($n == 0) echo "<TR>"."\n\r";
	$t1 = explode('<a href="', $video);
    $t2 = explode('"', $t1[1]);
    $link = $t2[0];

	$t1 = explode('<div class="films-item-title"><span>', $video);
    $t2 = explode('</span></div>', $t1[1]);
    $title11=$t2[0];
	$t1 = explode('<div class="films-item-year"><span>', $video);
    $t2 = explode('</span></div>', $t1[1]);
    $year=$t2[0];
    $title=$title11." (".$year.")";
	$t1 = explode('<img src="', $video);
    $t2 = explode('"', $t1[1]);
    $image = $t2[0];
    if (strpos($image,"poster") === false) $image="/css/images/film-empty.jpg";

    $id=substr(strrchr($link, "/"), 1);
	$image=str_replace('/css/',"http://torba.se/css/",$image);
    $id_t="";
    if (!array_key_exists($id, $srt)) {
     $tt="".$title11."\|".$year."";
     $tt=str_replace("/","\/'",$tt);
     $s="/\|".$tt."\|\d+\|\d+/i";

     //echo $s;
     if (preg_match($s,$h,$m)) {
       $t1=explode("|",$m[0]);
       if ($t1[4]== 1) {
         $title1=$title;
         $id_t=$t1[3];
       } else
         $title1=$title." *";
     } else
       $title1=$title." *";
  } else
    $title1=$title;
  if ($n==0) echo '<TR>';
  echo '<td align="center" width="25%"><a href="torba_link.php?file='.$link.'&title='.$title.'&year='.$year.'&id='.$id.'&id_t='.$id_t.'&image='.$image.'" target="_blank"><img src="'.$image.'" width="160px" height="224px"><BR><font size="4">'.$title1.'</font></a></TD>';
  $n++;
  if ($n == 4) {
  echo '</tr>';
  $n=0;
  }
}
echo '<tr><TD colspan="4" align="right">';
if (!$search) {
if ($page > 1)
echo '<a href="torba.php?page='.($page-1)."&link=".$tip."&title=".$tit.'"><font size="4">&nbsp;&lt;&lt;&nbsp;</font></a> | <a href="torba.php?page='.($page+1)."&link=".$tip."&title=".$tit.'"><font size="4">&nbsp;&gt;&gt;&nbsp;</font></a></TD></TR>';
else
echo '<a href="torba.php?page='.($page+1)."&link=".$tip."&title=".$tit.'"><font size="4">&nbsp;&gt;&gt;&nbsp;</font></a></TD></TR>';
}
echo "</table>";
?>
<br></body>
</html>

<?php
function str_between($string, $start, $end){
	$string = " ".$string; $ini = strpos($string,$start);
	if ($ini == 0) return ""; $ini += strlen($start); $len = strpos($string,$end,$ini) - $ini;
	return substr($string,$ini,$len);
}
include ("../common.php");
if (file_exists($base_pass."player.txt")) {
$flash=trim(file_get_contents($base_pass."player.txt"));
} else {
$flash="direct";
}
$f=$base_pass."html5.txt";
$html5 = "DA";
if (file_exists($f)) {
$h=file_get_contents($f);
$t1=explode("|",$h);
$html5=$t1[0];
}
if ((strpos($base_pass,":") === false) && ($html5 == "DA")) $flash="html5";
$id = $_GET["id"];
$id_t=$_GET["id_t"];
$title=$_GET["title"];
$image=$_GET["image"];

$list = glob($base_sub."*.srt");
   foreach ($list as $l) {
    str_replace(" ","%20",$l);
    unlink($l);
}

$lm="http://123movies.to/movie/loadepisodes/".$id;
//echo $lm;
$ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $lm);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 5.1; rv:14.0) Gecko/20100101 Firefox/14.0.1');
  $html=curl_exec($ch);
  curl_close($ch);
  //echo $html;
//http://123movies.to/movie/loadepisodes/7861
$videos = explode('<div id="', $html);  //de urmarit - se schimba des
unset($videos[0]);
$videos = array_values($videos);
foreach($videos as $video) {
  $server=trim(str_between($video,'<strong>','</strong>'));
  $calitate=str_between($video,'<a title="','"');
  $server=$server." ".$calitate;
  $id_l=str_between($video,'episode-id="','"');
  $l="http://123movies.to/movie/load_episode/".$id_l;
  $h=file_get_contents($l);
  //echo $h;
  $mm=str_between($h,'file="','"');
  if (strpos($mm,"http://123movies.to") === false) {
    //echo $mm."*";
   if ($mm) $mmm[$server]=$mm;
  }
}
//print_r ($mmm);
$k=count($mmm);
if ($k>1) {
echo '
<html><head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">

      <meta charset="utf-8">
      <title>Alege varianta</title>
   	  <link rel="stylesheet" type="text/css" href="../custom.css" />
     <script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.8.0/jquery.min.js"></script>
     <script src="../jquery.nicescroll.min.js"></script>
      <script type="text/javascript" src="../jquery.fancybox.js?v=2.1.5"></script>
      <link rel="stylesheet" type="text/css" href="../jquery.fancybox.css?v=2.1.5" media="screen" />


<script type="text/javascript">
$(document).ready(function() {
	$(".various").fancybox({
		maxWidth	: 800,
		maxHeight	: 600,
		fitToView	: false,
		width		: "70%",
		height		: "70%",
		autoSize	: false,
		closeClick	: false,
		openEffect	: "none",
		closeEffect	: "none"
	});
	$(".fancybox").fancybox();
	$("html").niceScroll({styler:"fb",cursorcolor:"#000"});
});
</script>
</head>
<body>';
echo '<h2 style="background-color:deepskyblue;color:black">'.$title."</H2>";
echo "<H2>Alegeti una din variantele de mai jos</H2>";
foreach($mmm as $key=>$value) {
  echo '<a href="movietv_link1.php?file='.urlencode($value).'&title='.urlencode($title).'&id='.$id.'&id_t='.$id_t.'&image='.$image.'" target="_blank"><font size="6">'.$key.'</font></a><BR>';
}
} else {
//http://123movies.to/movie/load_episode/106779
foreach($mmm as $key=>$value) {
$link=$value;
}
if (strpos($link,"blogspot") !== false) {
$link=str_replace('=m22',"=m18",$link);
$linkhd=str_replace('=m18',"=m22",$link);
  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $linkhd);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 5.1; rv:22.0) Gecko/20100101 Firefox/22.0');
  curl_setopt($ch, CURLOPT_FOLLOWLOCATION  ,1);
  curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
  curl_setopt($ch, CURLOPT_HEADER,1);
  curl_setopt($ch, CURLOPT_NOBODY,1);
  $html = curl_exec($ch);
  curl_close($ch);
  if (strpos($html,"404 Not Found") !== false) {
  $linkhd=$link;
  }
$movie_name="videoplayback.mp4";
$srt_name="videoplayback.srt";
} elseif (strpos($link,"123movies") !== false) {
$srt_name = substr(strrchr($linkhd, "/"), 1);
  $movie_name = substr(strrchr($link, "/"), 1);
  $srt_name=str_replace("mp4","srt",$movie_name);
  $linkhd=$link;
}
if ($id_t=="")
   $sub="http://uphero.xpresso.eu/123movies/m/".$id.".srt";
else
   $sub="http://uphero.xpresso.eu/srt/m/".$id_t.".srt";

   $ch = curl_init();
   curl_setopt($ch, CURLOPT_URL, $sub);
   curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
   curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 5.1; rv:14.0) Gecko/20100101 Firefox/14.0.1');
   curl_setopt($ch, CURLOPT_FOLLOWLOCATION  ,1);
   $h=curl_exec($ch);
   curl_close($ch);

if ( ($h) && strpos($h,"302 Found") == false && strpos(strtolower($h),"doctype html") == false )  {
 if (function_exists("mb_convert_encoding")) {
    $map = array(
        chr(0x8A) => chr(0xA9),
        chr(0x8C) => chr(0xA6),
        chr(0x8D) => chr(0xAB),
        chr(0x8E) => chr(0xAE),
        chr(0x8F) => chr(0xAC),
        chr(0x9C) => chr(0xB6),
        chr(0x9D) => chr(0xBB),
        chr(0xA1) => chr(0xB7),
        chr(0xA5) => chr(0xA1),
        chr(0xBC) => chr(0xA5),
        chr(0x9F) => chr(0xBC),
        chr(0xB9) => chr(0xB1),
        chr(0x9A) => chr(0xB9),
        chr(0xBE) => chr(0xB5),
        chr(0x9E) => chr(0xBE),
        chr(0x80) => '&euro;',
        chr(0x82) => '&sbquo;',
        chr(0x84) => '&bdquo;',
        chr(0x85) => '&hellip;',
        chr(0x86) => '&dagger;',
        chr(0x87) => '&Dagger;',
        chr(0x89) => '&permil;',
        chr(0x8B) => '&lsaquo;',
        chr(0x91) => '&lsquo;',
        chr(0x92) => '&rsquo;',
        chr(0x93) => '&ldquo;',
        chr(0x94) => '&rdquo;',
        chr(0x95) => '&bull;',
        chr(0x96) => '&ndash;',
        chr(0x97) => '&mdash;',
        chr(0x99) => '&trade;',
        chr(0x9B) => '&rsquo;',
        chr(0xA6) => '&brvbar;',
        chr(0xA9) => '&copy;',
        chr(0xAB) => '&laquo;',
        chr(0xAE) => '&reg;',
        chr(0xB1) => '&plusmn;',
        chr(0xB5) => '&micro;',
        chr(0xB6) => '&para;',
        chr(0xB7) => '&middot;',
        chr(0xBB) => '&raquo;',
    );
	$h = html_entity_decode(mb_convert_encoding(strtr($h, $map), 'UTF-8', 'ISO-8859-2'), ENT_QUOTES, 'UTF-8');

	$h = str_replace("\xC3\x84\xE2\x80\x9A","\xC4\x82",$h);
	$h = str_replace("\xC3\x84\xC2\x83","\xC4\x83",$h);
    $h = str_replace("\xC4\x82\xC5\xBD","\xC3\x8E",$h);
    $h = str_replace("\xC4\x82\xC2\xAE","\xC3\xAE",$h);
    $h = str_replace("\xC4\xB9\xCB\x98","\xC5\xA2",$h);
    $h = str_replace("\xC4\xB9\xC5\x81","\xC5\xA3",$h);
    $h = str_replace("\xC4\x82\xE2\x80\X9A","\xC3\x82",$h);
    $h = str_replace("\xC4\x82\xCB\x98","\xC3\xA2",$h);
    $h = str_replace("\xC4\xB9\xC5\xBE","\xC5\x9E",$h);
    $h = str_replace("\xC4\xB9\xC5\xBA","\xC5\x9F",$h);
    $h = str_replace("\xC4\x8C\xC5\xA1","\xC5\xA2",$h);
    $h = str_replace("\xC4\x8C\xE2\x80\x99","\xC5\xA3",$h);
    $h = str_replace("\xC4\x8C\xC2\x98","\xC5\x9E",$h);
    $h = str_replace("\xC4\x8C\xE2\x84\xA2","\xC5\x9F",$h);

} else {
    $h = str_replace("�","S",$h);
    $h = str_replace("�","s",$h);
    $h = str_replace("�","T",$h);
    $h = str_replace("�","t",$h);
    $h=str_replace("�","a",$h);
	$h=str_replace("�","a",$h);
	$h=str_replace("�","i",$h);
	$h=str_replace("�","A",$h);
}

   $new_file = $base_sub.$srt_name;
   $fh = fopen($new_file, 'w');
   fwrite($fh, $h, strlen($h));
   fclose($fh);

}

  /*
  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $link);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 5.1; rv:22.0) Gecko/20100101 Firefox/22.0');
  curl_setopt($ch, CURLOPT_FOLLOWLOCATION  ,1);
  curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
  curl_setopt($ch, CURLOPT_HEADER,1);
  curl_setopt($ch, CURLOPT_NOBODY,1);
  $html = curl_exec($ch);
  curl_close($ch);
  */

if ($flash=="direct") {

header('Content-type: application/vnd.apple.mpegURL');
//header('Cookie: '.$cookie1);
//header('Referer: http://movietv.to/');
header('Content-Disposition: attachment; filename="'.$movie_name.'"');
header("Location: $linkhd");
} else {
echo '
<!doctype html>
<HTML>
<HEAD>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>'.$title.'</title>
<style type="text/css">
body {
margin: 0px auto;
overflow:hidden;
}
body {background-color:#000000;}
</style>
<script src="//code.jquery.com/jquery-1.11.0.min.js"></script>
'.$jwv.'

</HEAD>
<BODY>
<div id="container"></div>
<script type="text/javascript">
jwplayer("container").setup({
"playlist": [{
"image": "'.$image.'",
"sources": [{"file": "'.$linkhd.'", "type": "mp4", "label": "HD"}, {"file": "'.$link.'", "type": "mp4", "label": "SD"}],
"tracks": [{"file": "../subs/'.$srt_name.'", "default": true}]
}],
    captions: {
        color: "#FFFFFF",
        fontSize: 20,
        backgroundOpacity: 0
    },
"height": $(document).height(),
"width": $(document).width(),
"skin": '.$skin.',
"startparam": "start",
"fallback": false,
"wmode": "direct",
"stagevideo": true
});
';
if ($flash=="html5" || $flash=="direct") {
echo '
jwplayer("container").onReady(function(event){
if (jwplayer().getRenderingMode() == "flash") {
//jwplayer().stop();
jwplayer().remove();
}
});
';
}
echo'
</script>
</BODY>
</HTML>
';
}
}
?>

<!DOCTYPE html>
<?php
include ("../common.php");
$pageToken="";
$nextpage="";
$nextPageToken="";
$prevPageToken="";
$page = $_GET["page"];
$search=$_GET["search"];
$page_title="Cautare: ".$search;
if (array_key_exists("pageToken",$_GET)) $pageToken=$_GET["pageToken"];
$key="AIzaSyDhpkA0op8Cyb_Yu1yQa1_aPSr7YtMacYU";
if ($pageToken)
$l2="https://www.googleapis.com/youtube/v3/search?part=snippet&maxResults=25&pageToken=".$pageToken."&q=".urlencode($search)."&key=".$key;
else
$l2="https://www.googleapis.com/youtube/v3/search?part=snippet&maxResults=25&q=".urlencode($search)."&key=".$key;
  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $l2);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US; rv:1.9.1.2) Gecko/20090729 Firefox/3.5.2 GTB5');
  curl_setopt($ch, CURLOPT_FOLLOWLOCATION  ,1);
  curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
  $html = curl_exec($ch);
  curl_close($ch);
  //echo $html;
  $p=json_decode($html,1);
  //print_r ($p);
  if (array_key_exists("nextPageToken",$p)) $nextpage=$p["nextPageToken"];
  if (array_key_exists("prevPageToken",$p)) $prevPageToken=$p["prevPageToken"];

?>
<html><head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate"/>
<meta http-equiv="Pragma" content="no-cache"/>
<meta http-equiv="Expires" content="0"/>
      <title><?php echo $page_title; ?></title>
<script src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
<link rel="stylesheet" type="text/css" href="../custom.css" />
<script type="text/javascript">
// create the XMLHttpRequest object, according browser
function get_XmlHttp() {
  // create the variable that will contain the instance of the XMLHttpRequest object (initially with null value)
  var xmlHttp = null;
  if(window.XMLHttpRequest) {		// for Forefox, IE7+, Opera, Safari, ...
    xmlHttp = new XMLHttpRequest();
  }
  else if(window.ActiveXObject) {	// for Internet Explorer 5 or 6
    xmlHttp = new ActiveXObject("Microsoft.XMLHTTP");
  }
  return xmlHttp;
}

// sends data to a php file, via POST, and displays the received answer
function ajaxrequest(tip, user,id) {
  var request =  get_XmlHttp();		// call the function for the XMLHttpRequest instance

  // create pairs index=value with data that must be sent to server
  //var the_data = {mod:del,title:title, link:link}; //Array
  var the_data = 'tip=' + tip + '&user='+ user + '&id='+id;
  var php_file='youtube_add1.php';
  request.open("POST", php_file, true);			// set the request

  // adds a header to tell the PHP script to recognize the data as is sent via POST
  request.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
  request.send(the_data);		// calls the send() method with datas as parameter

  // Check request status
  // If the response is received completely, will be transferred to the HTML tag with tagID
  request.onreadystatechange = function() {
    if (request.readyState == 4) {
      alert (request.responseText);
      //location.reload();
    }
  }
}
</script>
</head>
<body>
<H2></H2>
<?php
function str_between($string, $start, $end){
	$string = " ".$string; $ini = strpos($string,$start);
	if ($ini == 0) return ""; $ini += strlen($start); $len = strpos($string,$end,$ini) - $ini;
	return substr($string,$ini,$len);
}
$n=0;
echo '<h2 style="background-color:deepskyblue;color:black">'.$page_title.'</H2>';
echo '<table border="1px" width="100%">'."\n\r";
echo '<tr><TD colspan="5" align="right">';
if ($page > 1)
echo '<a href="youtube_search.php?page='.($page-1).'&search='.$search.'&pg='.urlencode($page_title).'&pagetoken='.$prevPageToken.'"><font size="4">&nbsp;&lt;&lt;&nbsp;</font></a> | <a href="youtube_search.php?page='.($page+1).'&search='.$search.'&pg='.urlencode($page_title).'&pageToken='.$nextpage.'"><font size="4">&nbsp;&gt;&gt;&nbsp;</font></a></TD></TR>';
else
echo '<a href="youtube_search.php?page='.($page+1).'&search='.$search.'&pg='.urlencode($page_title).'&pageToken='.$nextpage.'"><font size="4">&nbsp;&gt;&gt;&nbsp;</font></a></TD></TR>';

//$p=25*($page-1)+1;
//$link="http://gdata.youtube.com/feeds/api/users/".$search."/uploads?start-index=".$p."&max-results=25&v=2";
//$link="http://gdata.youtube.com/feeds/api/videos?orderby=relevance&vq=".urlencode($search)."&start-index=".$p."&max-results=25";

for ($k=0;$k<min(sizeof($p["items"]),25);$k++) {
	//$id = str_between($video,"<id>http://gdata.youtube.com/feeds/api/videos/","</id>");
  $link = "";
  $tip="";
  	$title = $p["items"][$k]["snippet"]["title"];
	$image = $p["items"][$k]["snippet"]["thumbnails"]["default"]["url"];
  if (array_key_exists("videoId",$p["items"][$k]["id"])) {
    $id=$p["items"][$k]["id"]["videoId"];
	$link = "link1.php?file=".urlencode("http://www.youtube.com/watch?v=".$id);
  }
  if (array_key_exists("playlistId",$p["items"][$k]["id"])) {
    $id=$p["items"][$k]["id"]["playlistId"];
	$link = "yt_playlist.php?page=1,".$id;
	$title="(playlist) ".$title;
	$tip="playlist";
  }
  if (array_key_exists("channelId",$p["items"][$k]["id"])) {
    $id=$p["items"][$k]["snippet"]["channelTitle"];
    if ($id) $title="(user) ".$title;
    if (!$id) {
      $id=$p["items"][$k]["snippet"]["channelId"];
      $title="(channel) ".$title;
    }
	$link = "youtube_user.php?page=1,".$id;
	$tip="user";
  }

	//$link = "http://www.youtube.com/watch?v=".$id;
  if ($link <> "") {
  if ($n==0) echo '<TR>';
  if (!$tip)
  echo '<td align="center" width="20%"><a href="'.$link.','.urlencode($title).'" target="_blank"><img src="'.$image.'" width="180px" height="106px"><BR><font size="4">'.$title.'</font></a></TD>';
  else
  echo '<td align="center" width="20%"><a href="'.$link.','.urlencode($title).'" target="_blank"><img src="'.$image.'" width="180px" height="106px"><BR><font size="4">'.$title.'</font></a> <a onclick="ajaxrequest('."'".$tip."', '".urlencode($title)."','".$id."');".'"'." style='cursor:pointer;'>".'<font size="4">(FAV)</font></a></TD>';
  $n++;
  if ($n == 5) {
  echo '</tr>';
  $n=0;
  }
  }
}
echo '<tr><TD colspan="5" align="right">';
if ($page > 1)
echo '<a href="youtube_search.php?page='.($page-1).'&search='.$search.'&pg='.urlencode($page_title).'&pagetoken='.$prevPageToken.'"><font size="4">&nbsp;&lt;&lt;&nbsp;</font></a> | <a href="youtube_search.php?page='.($page+1).'&search='.$search.'&pg='.urlencode($page_title).'&pageToken='.$nextpage.'"><font size="4">&nbsp;&gt;&gt;&nbsp;</font></a></TD></TR>';
else
echo '<a href="youtube_search.php?page='.($page+1).'&search='.$search.'&pg='.urlencode($page_title).'&pageToken='.$nextpage.'"><font size="4">&nbsp;&gt;&gt;&nbsp;</font></a></TD></TR>';
echo "</table>";
//http://r16---sn-4g57kndk.googlevideo.com/videoplayback?source=youtube&mv=m&mt=1431415130&ms=au&mm=31&id=o-ALBCX9HVtU6pEVsVU1PV8pI1cDU1G5CLYGIIhnv159ld&ip=85.186.229.96&initcwndbps=2192500&ipbits=0&upn=iK_bPS8ROs8&pl=24&itag=22&ratebypass=yes&sver=3&key=yt5&mime=video%2Fmp4&sparams=dur%2Cid%2Cinitcwndbps%2Cip%2Cipbits%2Citag%2Cmime%2Cmm%2Cms%2Cmv%2Cnh%2Cpl%2Cratebypass%2Csource%2Cupn%2Cexpire&expire=1431436796&fexp=907263%2C934954%2C936106%2C9408142%2C9408289%2C945137%2C948124%2C952612%2C952637%2C952642&nh=IgpwcjAxLmZyYTAzKgkxMjcuMC4wLjE&dur=234.057&signature=4372D4CDC39F69503225AA257B35F3D43EED1617E.191D7CBF22E60FD34C8A8052E3818DF9FAD24
//http://r16---sn-4g57kndk.googlevideo.com/videoplayback?source=youtube&mv=m&mt=1431415130&ms=au&mm=31&id=o-ALBCX9HVtU6pEVsVU1PV8pI1cDU1G5CLYGIIhnv159ld&ip=85.186.229.96&initcwndbps=2192500&ipbits=0&upn=iK_bPS8ROs8&pl=24&itag=22&ratebypass=yes&sver=3&key=yt5&mime=video%2Fmp4&sparams=dur%2Cid%2Cinitcwndbps%2Cip%2Cipbits%2Citag%2Cmime%2Cmm%2Cms%2Cmv%2Cnh%2Cpl%2Cratebypass%2Csource%2Cupn%2Cexpire&expire=1431436796&fexp=907263%2C934954%2C936106%2C9408142%2C9408289%2C945137%2C948124%2C952612%2C952637%2C952642&nh=IgpwcjAxLmZyYTAzKgkxMjcuMC4wLjE&dur=234.057&signature=4372D4CDC39F69503225AA257B35F3D43EED1617E.191D7CBF22E60FD34C8A8052E3818DF9FAD24
//https://r16---sn-4g57kndk.googlevideo.com/videoplayback?itag=22&key=yt5&source=youtube&ratebypass=yes&mv=m&mt=1431415048&fexp=907263%2C908211%2C930817%2C934964%2C9405191%2C9406015%2C9406813%2C9407470%2C9407610%2C9407664%2C9408142%2C9408705%2C9409038%2C9409261%2C9412493%2C9412903%2C946008%2C948124%2C952612%2C952637%2C952642&ms=au&nh=IgpwcjAyLmZyYTAzKgkxMjcuMC4wLjE&pl=24&mm=31&requiressl=yes&dur=234.057&id=o-AOfBVC0bxdjEZ-MESCMiV9uOi42WW-n5Y-QdjDqHQ_gH&mime=video%2Fmp4&sparams=dur%2Cid%2Cinitcwndbps%2Cip%2Cipbits%2Citag%2Cmime%2Cmm%2Cms%2Cmv%2Cnh%2Cpl%2Cratebypass%2Crequiressl%2Csource%2Cupn%2Cexpire&expire=1431436721&ipbits=0&upn=7kRxe3Iu6NM&sver=3&ip=85.186.229.96&initcwndbps=2237500&signature=3DA292156086FD5614B16D1942D135CD7D05FD0D.07E8D037A461A949ABD98E4B8832D079CEBDA9A1&cmbypass=yes
?>
<br></body>
</html>

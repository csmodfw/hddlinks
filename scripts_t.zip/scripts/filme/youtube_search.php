<!DOCTYPE html>
<?php
include ("../common.php");
$page = $_GET["page"];
$search=$_GET["search"];
$page_title="Cautare: ".$search;
$pageToken=$_GET["pageToken"];
$key="AIzaSyDhpkA0op8Cyb_Yu1yQa1_aPSr7YtMacYU";
if ($pageToken)
$l2="https://www.googleapis.com/youtube/v3/search?part=snippet&maxResults=25&pageToken=".$pageToken."&q=".$search."&key=".$key;
else
$l2="https://www.googleapis.com/youtube/v3/search?part=snippet&maxResults=25&q=".$search."&key=".$key;
  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $l2);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US; rv:1.9.1.2) Gecko/20090729 Firefox/3.5.2 GTB5');
  curl_setopt($ch, CURLOPT_FOLLOWLOCATION  ,1);
  curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
  $html = curl_exec($ch);
  curl_close($ch);
  //echo $html;
  $p=json_decode($html,1);
  //print_r ($p);
  $nextpage=$p["nextPageToken"];
  $prevPageToken=$p["prevPageToken"];

?>
<html><head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate"/>
<meta http-equiv="Pragma" content="no-cache"/>
<meta http-equiv="Expires" content="0"/>
      <title><?php echo $page_title; ?></title>
<script src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
<link rel="stylesheet" type="text/css" href="../custom.css" />
</head>
<body>
<H2></H2>
<?php
function str_between($string, $start, $end){
	$string = " ".$string; $ini = strpos($string,$start);
	if ($ini == 0) return ""; $ini += strlen($start); $len = strpos($string,$end,$ini) - $ini;
	return substr($string,$ini,$len);
}
$n=0;
echo '<h2 style="background-color:deepskyblue;color:black">'.$page_title.'</H2>';
echo '<table border="1px" width="100%">'."\n\r";
echo '<tr><TD colspan="5" align="right">';
if ($page > 1)
echo '<a href="youtube_search.php?page='.($page-1).'&search='.$search.'&pg='.urlencode($page_title).'&pagetoken='.$prevPageToken.'"><font size="4">&nbsp;&lt;&lt;&nbsp;</font></a> | <a href="youtube_search.php?page='.($page+1).'&search='.$search.'&pg='.urlencode($page_title).'&pageToken='.$nextpage.'"><font size="4">&nbsp;&gt;&gt;&nbsp;</font></a></TD></TR>';
else
echo '<a href="youtube_search.php?page='.($page+1).'&search='.$search.'&pg='.urlencode($page_title).'&pageToken='.$nextpage.'"><font size="4">&nbsp;&gt;&gt;&nbsp;</font></a></TD></TR>';

//$p=25*($page-1)+1;
//$link="http://gdata.youtube.com/feeds/api/users/".$search."/uploads?start-index=".$p."&max-results=25&v=2";
//$link="http://gdata.youtube.com/feeds/api/videos?orderby=relevance&vq=".urlencode($search)."&start-index=".$p."&max-results=25";
for ($k=0;$k<25;$k++) {
	//$id = str_between($video,"<id>http://gdata.youtube.com/feeds/api/videos/","</id>");
    $id=$p["items"][$k]["id"]["videoId"];
	$title = $p["items"][$k]["snippet"]["title"];
	$image = $p["items"][$k]["snippet"]["thumbnails"]["default"]["url"];
	$link = "http://www.youtube.com/watch?v=".$id;
	//$link = "http://www.youtube.com/watch?v=".$id;
  if ($link <> "") {
  if ($n==0) echo '<TR>';
  echo '<td align="center" width="20%"><a href="link1.php?file='.urlencode($link).','.urlencode($title).'" target="_blank"><img src="'.$image.'" width="180px" height="106px"><BR><font size="4">'.$title.'</font></a></TD>';
  $n++;
  if ($n == 5) {
  echo '</tr>';
  $n=0;
  }
  }
}
echo '<tr><TD colspan="5" align="right">';
if ($page > 1)
echo '<a href="youtube_search.php?page='.($page-1).'&search='.$search.'&pg='.urlencode($page_title).'&pagetoken='.$prevPageToken.'"><font size="4">&nbsp;&lt;&lt;&nbsp;</font></a> | <a href="youtube_search.php?page='.($page+1).'&search='.$search.'&pg='.urlencode($page_title).'&pageToken='.$nextpage.'"><font size="4">&nbsp;&gt;&gt;&nbsp;</font></a></TD></TR>';
else
echo '<a href="youtube_search.php?page='.($page+1).'&search='.$search.'&pg='.urlencode($page_title).'&pageToken='.$nextpage.'"><font size="4">&nbsp;&gt;&gt;&nbsp;</font></a></TD></TR>';
echo "</table>";
//http://r16---sn-4g57kndk.googlevideo.com/videoplayback?source=youtube&mv=m&mt=1431415130&ms=au&mm=31&id=o-ALBCX9HVtU6pEVsVU1PV8pI1cDU1G5CLYGIIhnv159ld&ip=85.186.229.96&initcwndbps=2192500&ipbits=0&upn=iK_bPS8ROs8&pl=24&itag=22&ratebypass=yes&sver=3&key=yt5&mime=video%2Fmp4&sparams=dur%2Cid%2Cinitcwndbps%2Cip%2Cipbits%2Citag%2Cmime%2Cmm%2Cms%2Cmv%2Cnh%2Cpl%2Cratebypass%2Csource%2Cupn%2Cexpire&expire=1431436796&fexp=907263%2C934954%2C936106%2C9408142%2C9408289%2C945137%2C948124%2C952612%2C952637%2C952642&nh=IgpwcjAxLmZyYTAzKgkxMjcuMC4wLjE&dur=234.057&signature=4372D4CDC39F69503225AA257B35F3D43EED1617E.191D7CBF22E60FD34C8A8052E3818DF9FAD24
//http://r16---sn-4g57kndk.googlevideo.com/videoplayback?source=youtube&mv=m&mt=1431415130&ms=au&mm=31&id=o-ALBCX9HVtU6pEVsVU1PV8pI1cDU1G5CLYGIIhnv159ld&ip=85.186.229.96&initcwndbps=2192500&ipbits=0&upn=iK_bPS8ROs8&pl=24&itag=22&ratebypass=yes&sver=3&key=yt5&mime=video%2Fmp4&sparams=dur%2Cid%2Cinitcwndbps%2Cip%2Cipbits%2Citag%2Cmime%2Cmm%2Cms%2Cmv%2Cnh%2Cpl%2Cratebypass%2Csource%2Cupn%2Cexpire&expire=1431436796&fexp=907263%2C934954%2C936106%2C9408142%2C9408289%2C945137%2C948124%2C952612%2C952637%2C952642&nh=IgpwcjAxLmZyYTAzKgkxMjcuMC4wLjE&dur=234.057&signature=4372D4CDC39F69503225AA257B35F3D43EED1617E.191D7CBF22E60FD34C8A8052E3818DF9FAD24
//https://r16---sn-4g57kndk.googlevideo.com/videoplayback?itag=22&key=yt5&source=youtube&ratebypass=yes&mv=m&mt=1431415048&fexp=907263%2C908211%2C930817%2C934964%2C9405191%2C9406015%2C9406813%2C9407470%2C9407610%2C9407664%2C9408142%2C9408705%2C9409038%2C9409261%2C9412493%2C9412903%2C946008%2C948124%2C952612%2C952637%2C952642&ms=au&nh=IgpwcjAyLmZyYTAzKgkxMjcuMC4wLjE&pl=24&mm=31&requiressl=yes&dur=234.057&id=o-AOfBVC0bxdjEZ-MESCMiV9uOi42WW-n5Y-QdjDqHQ_gH&mime=video%2Fmp4&sparams=dur%2Cid%2Cinitcwndbps%2Cip%2Cipbits%2Citag%2Cmime%2Cmm%2Cms%2Cmv%2Cnh%2Cpl%2Cratebypass%2Crequiressl%2Csource%2Cupn%2Cexpire&expire=1431436721&ipbits=0&upn=7kRxe3Iu6NM&sver=3&ip=85.186.229.96&initcwndbps=2237500&signature=3DA292156086FD5614B16D1942D135CD7D05FD0D.07E8D037A461A949ABD98E4B8832D079CEBDA9A1&cmbypass=yes
?>
<br></body>
</html>

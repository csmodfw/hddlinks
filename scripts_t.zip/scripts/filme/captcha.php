<!DOCTYPE html>
<html>
<head>
	<title>Captcha</title>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
      <link rel="stylesheet" type="text/css" href="../custom.css" />
      <script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.8.0/jquery.min.js"></script>
<script type="text/javascript">
// create the XMLHttpRequest object, according browser
function get_XmlHttp() {
  // create the variable that will contain the instance of the XMLHttpRequest object (initially with null value)
  var xmlHttp = null;
  if(window.XMLHttpRequest) {		// for Forefox, IE7+, Opera, Safari, ...
    xmlHttp = new XMLHttpRequest();
  }
  else if(window.ActiveXObject) {	// for Internet Explorer 5 or 6
    xmlHttp = new ActiveXObject("Microsoft.XMLHTTP");
  }
  return xmlHttp;
}

// sends data to a php file, via POST, and displays the received answer
function ajaxrequest(link) {
  var request =  get_XmlHttp();		// call the function for the XMLHttpRequest instance

  // create pairs index=value with data that must be sent to server
  //var the_data = {mod:add,title:title, link:link}; //Array
  var the_data = 'link='+ document.getElementById('opt').value;
  var php_file='captcha_w.php';
  request.open("POST", php_file, true);			// set the request

  // adds a header to tell the PHP script to recognize the data as is sent via POST
  request.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
  request.send(the_data);		// calls the send() method with datas as parameter

  // Check request status
  // If the response is received completely, will be transferred to the HTML tag with tagID
  request.onreadystatechange = function() {
    if (request.readyState == 4) {
      alert (request.responseText);
    }
  }
}
</script>
</head>
<body>
<?php
function str_between($string, $start, $end){
	$string = " ".$string; $ini = strpos($string,$start);
	if ($ini == 0) return ""; $ini += strlen($start); $len = strpos($string,$end,$ini) - $ini;
	return substr($string,$ini,$len);
}
include ("../common.php");
$filelink = urldecode($_GET["file"]);
$new_file = $base_cookie."ticket.dat";
if (file_exists($new_file)) unlink($new_file);
if (strpos($filelink,"openload") !== false) {
   $filelink=str_replace("openload.co/f/","openload.co/embed/",$filelink);
   preg_match('/openload\.co\/(v\/|watch\?v=|embed\/)([\w\-]+)/', $filelink, $match);
   $file = $match[2];
   $key="UebmYlZN";
   $login="de2a2a3fe31fdb89";
   $ticket="https://api.openload.co/1/file/dlticket?file=".$file."&login=".$login."&key=".$key;
      $ch = curl_init();
      curl_setopt($ch, CURLOPT_URL, $ticket);
      curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
      curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 5.1; rv:22.0) Gecko/20100101 Firefox/22.0');
      curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
      $ret = curl_exec($ch);
      curl_close($ch);
      //echo $ret;
  $t=str_between($ret,'ticket":"','"');
  $a=str_between($ret,'captcha_url":"','"');
  $a=str_replace("\/","/",$a);
  if ($a) {
      /*
      $ch = curl_init();
      $fp = fopen('captcha.png', 'w+');
      curl_setopt($ch, CURLOPT_URL, $ticket);
      curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
      curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 5.1; rv:22.0) Gecko/20100101 Firefox/22.0');
      curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
      curl_setopt($ch, CURLOPT_FILE, $fp);
      $ret = curl_exec($ch);
      curl_close($ch);
      fclose($fp);
      */
      $new_file = $base_cookie."ticket.dat";
      $fh = fopen($new_file, 'w');
      fwrite($fh, $t);
      fclose($fh);
  } else {
   $a="http://itxdesign.com/wp-content/uploads/2015/02/NoCAPTCHAreCAPTCHA.png";
  }
}
//$a="https://openload.co/dlcaptcha/INeu9bfld_Y.png";
echo '<h2 style="background-color:deepskyblue;color:black;text-align:left;">Solve captcha</h2>';
echo '<img src="'.$a.'" width="320px" height="140px"><BR>';
echo 'Enter captcha:<input type="text" name="opt" id="opt">';
echo '<input type="submit" value="Memoreaza" onclick="ajaxrequest()";>';
?>

<!DOCTYPE html>
<html><head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate"/>
<meta http-equiv="Pragma" content="no-cache"/>
<meta http-equiv="Expires" content="0"/>
      <title>Seteaza GoogleCaptcha</title>
<link rel="stylesheet" type="text/css" href="../custom.css" />
<script src="//code.jquery.com/jquery-2.0.2.js"></script>
<style>
html { height: 100%;}
.balloon { position: absolute; width: 214px; height: 317px; background: #000; border: 1px solid #fff; z-index: 10; display: none; }
</style>
<BODY>

<BR><BR>
<div id="mainnav">
<table id="data" border="1" align="center" width="90%">
<TR>
<td style="color:black;background-color:#0a6996;color:#64c8ff;text-align:center" colspan="4"><b><font size="4">Setare GoogleCaptcha</font></b></TD>
</TR>

</table>
<table align="center" width="90%">
<TR><TD><font size="4">Setare GoogleCaptcha  - varianta firefox</font></TD></TR>
<TR><TD>De pe PC vizitati http://www.filmeserialeonline.org/</TD></TR>
<TR><TD>Alegeti un film/serial si navigati pana apare "afiseaza surse" si verificare "nu sunt robot".</TD></TR>
<TR><TD>Dupa ce sunt afisate sursele, din meniul firefox "Unelte" --> "Dezvoltator web" -->"Inspector de stocare".</TD></TR>
<TR><TD>Selectati "cookie" ---> GoogleCaptcha. Din panelul data click pe GoogleCaptcha si Ctrl+c (copiere).</TD></TR>
<TR><TD>OPTIUNEA 1</TD></TR>
<TR><TD>Cu notepad creati un fisier filmeseriale.txt, deschideti fisierul si faceti Ctrl+V. PASTRATI doar ce e intre ghilimele!</TD></TR>
<TR><TD>Deschideti media playerul, iar de pe PC accesati file managerul (http://ip-mp:8080/scripts/fm.php). Mergeti in folderul "Parole" si faceti upload la fisierul filmeseriale.txt.</TD></TR>
<TR><TD>OPTIUNEA 2</TD></TR>
<TR><TD>Deschideti media playerul, de pe PC navigati la http://ip-mp:8080/scripts/imdex.php. Accesati "Setari", cautati "Setare GoogleCaptcha" si faceti paste (Ctrl+v). Pastrati doar partea dintre ghilimele!!!1. Apasati memoreaza.</TD></TR>
<TR><TD><img src="filmeseriale.jpg"></TD></TR>
</TABLE>
</div>
</BODY>
</HTML>

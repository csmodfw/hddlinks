<!DOCTYPE html>
<html><head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<link rel="stylesheet" type="text/css" href="../custom.css" />
      <meta charset="utf-8">
      <title>seriale</title>
<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.8.0/jquery.min.js"></script>
<script src="../jquery.nicescroll.min.js"></script>

<script type="text/javascript">
  $(document).ready(function() {
	$("html").niceScroll({styler:"fb",cursorcolor:"#000"});
  });
</script>
</head>
<body><h4></h4>
<?php
include ("../common.php");
function str_between($string, $start, $end){
	$string = " ".$string; $ini = strpos($string,$start);
	if ($ini == 0) return ""; $ini += strlen($start); $len = strpos($string,$end,$ini) - $ini;
	return substr($string,$ini,$len);
}
//file=watch-suits-87279&title=Suits&image=http://poster.vumoo.net/300/87279.jpg
$l = $_GET["file"];
$tit=$_GET["title"];
$image=$_GET["image"];
$n=0;
echo '<table border="1" width="100%">'."\n\r";
echo '<TR><td style="color:#000000;background-color:deepskyblue;text-align:center" colspan="3" align="center"><font size="4">'.$tit.'</font></TD></TR>';
$requestLink="http://vumoo.li/videos/play/".$l;
$cookie=$base_cookie."vumo.dat";
    if (!function_exists('json_last_error_msg')) {
        function json_last_error_msg() {
            static $ERRORS = array(
                JSON_ERROR_NONE => 'No error',
                JSON_ERROR_DEPTH => 'Maximum stack depth exceeded',
                JSON_ERROR_STATE_MISMATCH => 'State mismatch (invalid or malformed JSON)',
                JSON_ERROR_CTRL_CHAR => 'Control character error, possibly incorrectly encoded',
                JSON_ERROR_SYNTAX => 'Syntax error',
                JSON_ERROR_UTF8 => 'Malformed UTF-8 characters, possibly incorrectly encoded'
            );

            $error = json_last_error();
            return isset($ERRORS[$error]) ? $ERRORS[$error] : 'Unknown error';
        }
    }
require_once 'httpProxyClass.php';
require_once 'cloudflareClass.php';

$httpProxy   = new httpProxy();
$httpProxyUA = 'proxyFactory';

$requestPage = json_decode($httpProxy->performRequest($requestLink));

// if page is protected by cloudflare
if($requestPage->status->http_code == 503) {
	// Make this the same user agent you use for other cURL requests in your app
	cloudflare::useUserAgent($httpProxyUA);

	// attempt to get clearance cookie
	if($clearanceCookie = cloudflare::bypass($requestLink)) {
		// use clearance cookie to bypass page
		$requestPage = $httpProxy->performRequest($requestLink, 'GET', null, array(
			'cookies' => $clearanceCookie
		));
		// return real page content for site
		$requestPage = json_decode($requestPage);
		$html = $requestPage->content;
	} else {
		// could not fetch clearance cookie
		$html = 'Could not fetch CloudFlare clearance cookie (most likely due to excessive requests)';
	}
} else {
  $html = $requestPage->content;
}
  $link1="";
 $videos = explode('<li id=season', $html);
 $series_title=$tit;
unset($videos[0]);
$videos = array_values($videos);
foreach($videos as $video) {
  $ep_tit=str_between($video,'<h2>','</h2>');
  $t1=explode('>',$video);
  preg_match("/(\d+)-(\d+)/",$t1[0],$m);
  //print_r ($m);
  $season=$m[1];
  $episod=$m[2];
  $t1=explode('data-click="',$video);
  $k=count($t1);
  $link_openload="";
  $link_google="";
  $id1="";
  $id_t="";
  for ($i=0;$i<$k;$i++) {
    $t2=explode('"',$t1[$i]);
    $l=trim($t2[0]);
    if (strpos($l,"openload") !== false) {
      $l1=explode("embed/",$l);
      $id1=trim($l1[1]);
    }
    if (strpos($l,"id=") !== false && !$link_google) $id_t=str_between($l,"id=","&");
  }
  $link=$id1."|".$id_t;
   $title1=$series_title."|".$season."x".$episod." - ".$ep_tit;
   $title=$season."x".$episod." - ".$ep_tit;


      //$link = 'filme_link.php?file='.urlencode($link).",".urlencode($title);
      $link='vumo_fs.php?file='.$link.'&title='.$title1.'&image='.$image;
      //echo '<td align="center" width="25%"><a href="vumo_fs.php?file='.$link.'&title='.$title1.'&image='.$image.'" target="_blank"><img src="'.$image.'" width="200px" height="280px"><BR><font size="4">'.$title1.'</font></a></TD>';
      //$link="fs.php?link=".$link."&title=".urlencode($tit)."&tip=series&tit=".$title;
//}
      if ($n == 0) echo "<TR>"."\n\r";
   if ($title) {
		echo '<TD><font size="4">'.'<a href="'.$link.'" target="_blank">'.$title.'</a></font>';
		echo '</TD>'."\n\r";
        $n++;
        if ($n > 2) {
         echo '</TR>'."\n\r";
         $n=0;
        }
	}
}
echo '</table>';
?>
<br></body>
</html>

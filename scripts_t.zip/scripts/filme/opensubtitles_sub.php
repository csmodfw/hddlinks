<?php
$sub=$_POST["id"];
$srt_name="sub_extern.srt";
include ("../common.php");
function str_between($string, $start, $end){
	$string = " ".$string; $ini = strpos($string,$start);
	if ($ini == 0) return ""; $ini += strlen($start); $len = strpos($string,$end,$ini) - $ini;
	return substr($string,$ini,$len);
}
function get_value($q, $string) {
   $t1=explode($q,$string);
   return str_between($t1[1],"<string>","</string>");
}
   function generateResponse($request)
    {
        $context  = stream_context_create(
            array(
                'http' => array(
                    'method'  => "POST",
                    'header'  => "Content-Type: text/xml",
                    'content' => $request
                )
            )
        );
        $response     = file_get_contents("http://api.opensubtitles.org/xml-rpc", false, $context);
        return $response;
    }
if ($sub) {
  $token=file_get_contents($base_cookie."opensub.dat");
$request="<?xml version=\"1.0\" encoding=\"iso-8859-1\"?>
<methodCall>
<methodName>DownloadSubtitles</methodName>
<params>
 <param>
  <value>
   <string>".$token."</string>
  </value>
 </param>
 <param>
  <value>
   <array>
    <data>
     <value>
      <string>".$sub."</string>
     </value>
    </data>
   </array>
  </value>
 </param>
</params>
</methodCall>";
$response = generateResponse($request);
//echo $response;
$t1=explode("data",$response);
$data=str_between($t1[3],"<string>","</string>");
//echo $data;
$a1=base64_decode($data);
$f=$base_cookie."opensub.gz";
file_put_contents($f,$a1);
$h = gzdecode(base64_decode($data));
}
if ( ($h) && strpos($h,"302 Found") == false && strpos(strtolower($h),"doctype html") == false )  {
 if (function_exists("mb_convert_encoding")) {
    $map = array(
        chr(0x8A) => chr(0xA9),
        chr(0x8C) => chr(0xA6),
        chr(0x8D) => chr(0xAB),
        chr(0x8E) => chr(0xAE),
        chr(0x8F) => chr(0xAC),
        chr(0x9C) => chr(0xB6),
        chr(0x9D) => chr(0xBB),
        chr(0xA1) => chr(0xB7),
        chr(0xA5) => chr(0xA1),
        chr(0xBC) => chr(0xA5),
        chr(0x9F) => chr(0xBC),
        chr(0xB9) => chr(0xB1),
        chr(0x9A) => chr(0xB9),
        chr(0xBE) => chr(0xB5),
        chr(0x9E) => chr(0xBE),
        chr(0x80) => '&euro;',
        chr(0x82) => '&sbquo;',
        chr(0x84) => '&bdquo;',
        chr(0x85) => '&hellip;',
        chr(0x86) => '&dagger;',
        chr(0x87) => '&Dagger;',
        chr(0x89) => '&permil;',
        chr(0x8B) => '&lsaquo;',
        chr(0x91) => '&lsquo;',
        chr(0x92) => '&rsquo;',
        chr(0x93) => '&ldquo;',
        chr(0x94) => '&rdquo;',
        chr(0x95) => '&bull;',
        chr(0x96) => '&ndash;',
        chr(0x97) => '&mdash;',
        chr(0x99) => '&trade;',
        chr(0x9B) => '&rsquo;',
        chr(0xA6) => '&brvbar;',
        chr(0xA9) => '&copy;',
        chr(0xAB) => '&laquo;',
        chr(0xAE) => '&reg;',
        chr(0xB1) => '&plusmn;',
        chr(0xB5) => '&micro;',
        chr(0xB6) => '&para;',
        chr(0xB7) => '&middot;',
        chr(0xBB) => '&raquo;',
    );
	$h = html_entity_decode(mb_convert_encoding(strtr($h, $map), 'UTF-8', 'ISO-8859-2'), ENT_QUOTES, 'UTF-8');

	$h = str_replace("\xC3\x84\xE2\x80\x9A","\xC4\x82",$h);
	$h = str_replace("\xC3\x84\xC2\x83","\xC4\x83",$h);
    $h = str_replace("\xC4\x82\xC5\xBD","\xC3\x8E",$h);
    $h = str_replace("\xC4\x82\xC2\xAE","\xC3\xAE",$h);
    $h = str_replace("\xC4\xB9\xCB\x98","\xC5\xA2",$h);
    $h = str_replace("\xC4\xB9\xC5\x81","\xC5\xA3",$h);
    $h = str_replace("\xC4\x82\xE2\x80\X9A","\xC3\x82",$h);
    $h = str_replace("\xC4\x82\xCB\x98","\xC3\xA2",$h);
    $h = str_replace("\xC4\xB9\xC5\xBE","\xC5\x9E",$h);
    $h = str_replace("\xC4\xB9\xC5\xBA","\xC5\x9F",$h);
    $h = str_replace("\xC4\x8C\xC5\xA1","\xC5\xA2",$h);
    $h = str_replace("\xC4\x8C\xE2\x80\x99","\xC5\xA3",$h);
    $h = str_replace("\xC4\x8C\xC2\x98","\xC5\x9E",$h);
    $h = str_replace("\xC4\x8C\xE2\x84\xA2","\xC5\x9F",$h);
	$h = str_replace("\xC3\xA2\xE2\x84\xA2\xC5\x9E","\xE2\x99\xAA",$h);

} else {
    $h = str_replace("ª","S",$h);
    $h = str_replace("º","s",$h);
    $h = str_replace("Þ","T",$h);
    $h = str_replace("þ","t",$h);
    $h=str_replace("ã","a",$h);
	$h=str_replace("â","a",$h);
	$h=str_replace("î","i",$h);
	$h=str_replace("Ã","A",$h);
}

   $new_file = $base_sub.$srt_name;
   $fh = fopen($new_file, 'w');
   fwrite($fh, $h, strlen($h));
   fclose($fh);
   echo 'Am salvat subtitrarea';
} else {
   echo 'Nu am putut salva subtitrarea!';
}
?>

<?php
include ("../common.php");
function str_between($string, $start, $end){
	$string = " ".$string; $ini = strpos($string,$start);
	if ($ini == 0) return ""; $ini += strlen($start); $len = strpos($string,$end,$ini) - $ini;
	return substr($string,$ini,$len);
}
if (file_exists($base_pass."player.txt")) {
$flash=trim(file_get_contents($base_pass."player.txt"));
} else {
$flash="direct";
}
$query = $_GET["file"];
$queryArr = explode(',', $query);
$link = urldecode($queryArr[0]);
$tit = urldecode($queryArr[1]);
$html = urldecode(file_get_contents($link));
//echo $html;
$videos = explode('section caption="', $html);

unset($videos[0]);
$videos = array_values($videos);
//$videos = array_reverse($videos);
foreach($videos as $video) {
//echo $video;
    $t3=explode('Site/redirect/?to=',$video);
//if ( sizeof($t3)>1 ) {
    $t4=explode('"',$t3[1]);
    $link=urldecode($t4[0]);
    if (!$link) {
    $t3=explode('superweb?superweb=',$video);
    $t4=explode('"',$t3[1]);
    $link=urldecode($t4[0]);
    }
    $title = str_between($link,"http://","/");
    if (preg_match("/roshare|rosharing|vk\.com|fastupload|superweb/",$link))
      $l[$link]=$title;
//}
}
if (count($l)==1) {
$dir_actual = "http".(($_SERVER['SERVER_PORT']==443) ? "s://" : "://") . $_SERVER['HTTP_HOST'] . $_SERVER['SCRIPT_NAME'];
$dir_actual = str_replace("serialetv.php","",$dir_actual);
$movie=file_get_contents($dir_actual."link.php?file=".key($l));
$movie_file=substr(strrchr($movie, "/"), 1);
if ($flash == "direct") {
header('Content-type: application/vnd.apple.mpegURL');
header('Content-Disposition: attachment; filename="'.$movie_file.'"');
header("Location: $movie");
} else {
if (strpos($movie,"fastupload") !== false)
  $startparam="ec_seek";
else
  $startparam="start";
echo '
<!doctype html>
<HTML>
<HEAD>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<style type="text/css">
body {
margin: 0px auto;
overflow:hidden;
}
body {background-color:#000000;}
</style>
<script src="//code.jquery.com/jquery-1.11.0.min.js"></script>
'.$jwv.'
</HEAD>
<BODY>
<div id="container"></div>
<script type="text/javascript">
jwplayer("container").setup({
';
if (strpos($movie,"fastupload") !== false) {
echo '"flashplayer": "http://superweb.rol.ro/video/player6/jwplayer.flash.swf",';
if (strpos($base_pass,":") !== false) echo '"primary": "flash",';
}
if (strpos($movie,"videomega.tv") !== false) {
echo '"flashplayer": "http://videomega.tv/player/jwplayer.flash.swf",';
if (strpos($base_pass,":") !== false) echo '"primary": "flash",';
}
if (strpos($movie,"roshare") !== false) {
echo '"flashplayer": "http://roshare.info/jh5/jwplayer.flash.swf",';
if (strpos($base_pass,":") !== false) echo '"primary": "flash",';
}
echo '
"playlist": [{
"sources": [{"file": "'.$movie.'", "type": "mp4"}],
"tracks": [{"file": "../subs/subtitrare.srt", "default": true}]
}],
    captions: {
        color: "#FFFFFF",
        back:false,
        fontsize: 20,
        backgroundOpacity: 0
    },
"height": $(document).height(),
"width": $(document).width(),
"skin": '.$skin.',
"startparam": "'.$startparam.'",
"fallback": false,
"wmode": "direct",
"stagevideo": true
});
</script>
</BODY>
</HTML>
';
}
} else {
echo '
<html><head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">

      <meta charset="utf-8">
      <title>Alege varianta</title>
   	  <link rel="stylesheet" type="text/css" href="../custom.css" />
</head>
<body>';
echo '<h2 style="background-color:deepskyblue;color:black">'.$tit."</H2>";
echo "<H2>Alegeti una din variantele de mai jos</H2>";
foreach($l as $key => $value) {
 echo '<a href="link1.php?file='.urlencode($key).'" target="_blank"><font size="6">'.$value.'</font></a><BR>';
}
echo '<br></body>
</html>';
}
?>

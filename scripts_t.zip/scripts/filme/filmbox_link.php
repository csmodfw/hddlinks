<?php
include ("../common.php");
function str_between($string, $start, $end){
	$string = " ".$string; $ini = strpos($string,$start);
	if ($ini == 0) return ""; $ini += strlen($start); $len = strpos($string,$end,$ini) - $ini;
	return substr($string,$ini,$len);
}
if (file_exists($base_pass."player.txt")) {
$flash=trim(file_get_contents($base_pass."player.txt"));
} else {
$flash="direct";
}
$id = $_GET["file"];
$title = $_GET["title"];
$year = $_GET["year"];
$image = $_GET["image"];
$id1= $_GET["out"];
//$file="http://panel.erstream.com/api/er/Get?cid=".$id."&format=8&customerid=16&action=redirect&id=".$id."";
//$out="http://panel.erstream.com/api/er/Get?cid=9i4db_D8V0yWBIlMjulvMg&format=1&customerid=16&action=redirect";
$file="http://panel.erstream.com/api/er/Get?cid=".$id."&format=4&customerid=16&action=redirect&id=".$id."";
//echo $file;
//$file="http://panel.erstream.com/api/er/Get?cid=OiXmiRHMF06BAU_iRprvwA&format=4&customerid=16&action=redirect";
//$r=get_headers($file);
  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $file);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  //curl_setopt($ch,CURLOPT_REFERER,"http://www.filmon.com/");
  curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Linux; U; Android 2.1-update1; ru-ru; GT-I9000 Build/ECLAIR) AppleWebKit/530.17 (KHTML, like Gecko) Version/4.0 Mobile Safari/530.17');
  //curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 5.1; rv:14.0) Gecko/20100101 Firefox/14.0.1');
  curl_setopt($ch, CURLOPT_FOLLOWLOCATION  ,0);
  //curl_setopt($ch, CURLOPT_NOBODY  ,1);
  curl_setopt($ch, CURLOPT_HEADER  ,1);
  $r=curl_exec($ch);
  curl_close($ch);
  //echo $out;
  //die();
  //http://filmbox.ercdn.com/O/Oi/OiXmiRHMF06BAU_iRprvwA.mp4
  //O/Oi/OiXmiRHMF06BAU_iRprvwA.high.smil
  //http://w-bk1.ercdn.net/filmbox/_definst_/smil:5/5k/5k5W1jkQjEKFRVuQwILflw.high.smil/manifest.f4m
$out=trim(str_between($r,"Location:","mp4"))."mp4";
//$h=file_get_contents($file);
//echo $h;
//die();
/*
//pentru mp4
$file="http://panel.erstream.com/api/er/Get?cid=".$id."&format=4&customerid=16&action=redirect&id=".$id."";
$r=get_headers($file);
$out=trim(str_between($r[4],"Location:","mp4"))."mp4";
//
*/

$title = preg_replace('~[^\\pL\d.]+~u', ' ', $title);
  //$link=str_between($h,'<id>','</id>');
  //$out="http://w-bk1.ercdn.net/filmbox/_definst_/smil:".$link."/".$movie_file;
//$out="http://spi-live.ercdn.net/spi/docuboxhd_0_3/playlist.m3u8";
//http://w-bk1.ercdn.net/filmbox/_definst_/smil:9/9i/9i4db_D8V0yWBIlMjulvMg.low.smil/playlist.m3u8
if (file_exists($base_pass."mpc.txt")) {
$file="http://panel.erstream.com/api/er/Get?cid=".$id."&format=8&customerid=16&action=redirect&id=".$id."";
$h=file_get_contents($file);
  $link=str_between($h,'<id>','</id>');
  $out="http://w-bk1.ercdn.net:1935/filmbox/_definst_/smil:".$link."/manifest.m3u8";
//if(file_exists($base_sub.$srt_name)) echo "OK";
//die();
  $mpc=trim(file_get_contents($base_pass."mpc.txt"));
  $c='"'.$mpc.'" /fullscreen "'.$out.'"';
  pclose(popen($c,"r"));
  echo '<script type="text/javascript">window.close();</script>';
  die();
}
if ($flash == "direct") {
/*$file="http://panel.erstream.com/api/er/Get?cid=".$id."&format=4&customerid=16&action=redirect&id=".$id."";
$r=get_headers($file);
$out=trim(str_between($r[4],"Location:","mp4"))."mp4";
$movie_file=$title.".mp4";
*/
$file="http://panel.erstream.com/api/er/Get?cid=".$id."&format=8&customerid=16&action=redirect&id=".$id."";
$h=file_get_contents($file);
  $link=str_between($h,'<id>','</id>');
  $out="http://w-bk1.ercdn.net:1935/filmbox/_definst_/smil:".$link."/manifest.m3u8";
header('Content-type: application/vnd.apple.mpegURL');
header('Content-Disposition: attachment; filename="playlist.m3u8"');
header("Location: $out");
} else {
$file="http://panel.erstream.com/api/er/Get?cid=".$id."&format=8&customerid=16&action=redirect&id=".$id."";
$h=file_get_contents($file);
  $link=str_between($h,'<id>','</id>');
  $out="http://w-bk1.ercdn.net:1935/filmbox/_definst_/smil:".$link."/manifest.m3u8";
$t1=$_SERVER["PHP_SELF"];
if(!isset($_GET['screen_check'])) {
 echo "<script language='JavaScript'>
 <!--
 document.location=\"$t1?screen_check=done&file=$id&title=$title&year=$year&image=$image&out=$out&Width=\"+window.innerWidth+\"&Height=\"+window.innerHeight;
 //-->
 </script>";
 die();
} else {
	if(isset($_GET['Width']) && isset($_GET['Height'])) {
		$Width=$_GET['Width']-4;
		$Height=$_GET['Height']-4;
	}
}
echo '
<!doctype html>
<HTML>
<HEAD>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>'.$title.'</title>
<style type="text/css">
body {
margin: 0px auto;
overflow:hidden;
}
body {background-color:#000000;}
</style>
<script src="//code.jquery.com/jquery-1.11.0.min.js"></script>
'.$jwv.'

</HEAD>
<BODY>
<div id="container"></div>
<script type="text/javascript">
jwplayer("container").setup({
"playlist": [{
"sources": [{"file": "'.$out.'", "type": "m3u8"}],
}],
    captions: {
        color: "#FFFFFF",
        fontSize: 20,
        backgroundOpacity: 0
    },
"height": $(document).height(),
"width": $(document).width(),
"skin": '.$skin.',
"stretching":"exactfit",
"androidhls": true,
"startparam": "start",
"autostart": true,
"fallback": false,
"wmode": "direct",
"stagevideo": true
});
</script>
</BODY>
</HTML>
';
}
?>
</BODY>
</HTML>


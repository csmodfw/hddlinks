<!DOCTYPE html>
<html>
<head>
	<title>IMDB</title>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
      <link rel="stylesheet" type="text/css" href="../custom.css" />
</head>
<body>
<!--
	<p>
		<a href="javascript:parent.jQuery.fancybox.close();">Close</a>
	</p>
-->
<?php
function str_between($string, $start, $end){
	$string = " ".$string; $ini = strpos($string,$start);
	if ($ini == 0) return ""; $ini += strlen($start); $len = strpos($string,$end,$ini) - $ini;
	return substr($string,$ini,$len);
}
$id = $_GET["id"];
include ("../common.php");
//$tit = urldecode($_GET["title"]);
$noob=file_get_contents($base_cookie."n.dat");
$cookie=$base_cookie."noob.dat";
$noob_serv=$base_cookie."noob_serv.dat";
  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $noob."/func.js");
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US; rv:1.9.1.2) Gecko/20090729 Firefox/3.5.2 GTB5');
  //curl_setopt($ch, CURLOPT_FOLLOWLOCATION  ,1);
  curl_setopt($ch,CURLOPT_REFERER,$noob);
  curl_setopt($ch, CURLOPT_COOKIEFILE, $cookie);
  $h = curl_exec($ch);
  curl_close($ch);
$t1=explode('src="',$h);
$t2=explode("'",$t1[1]);
$baseimg=$t2[0];
$image=$baseimg.$id.".jpg";
$l=$noob."/?".$id;
  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $l);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US; rv:1.9.1.2) Gecko/20090729 Firefox/3.5.2 GTB5');
  curl_setopt($ch, CURLOPT_FOLLOWLOCATION  ,1);
  //curl_setopt($ch, CURLOPT_COOKIEJAR, $cookie);
  curl_setopt($ch, CURLOPT_COOKIEFILE, $cookie);
  $html = curl_exec($ch);
  curl_close($ch);
$t1=explode("?imdb.com",$html);
$img="";
if ( sizeof($t1)>1 ) {
$t2=explode('"',$t1[1]);
if ($t2[0])
  $link="http://imdb.com".$t2[0];
}
else
  $link="http://imdb.com".str_between($html,'http://imdb.com','"');
$html=file_get_contents($link);
$t1=explode('id="img_primary">',$html);
if (sizeof($t1) > 1) {
  $t2=explode('src="',$t1[1]);
  $t3=explode('"',$t2[1]);
  $img=$t3[0];
}
if (!$img) {
$t1=explode('div class="poster">',$html);
$t2=explode('src="',$t1[1]);
$t3=explode('"',$t2[1]);
$img=$t3[0];
}
$t1=explode('class="title_wrapper">',$html);
$t2=explode('>',$t1[1]);
$t3=explode('<',$t2[1]);
$year=str_between($html,'span class="nobr">','</span');
$year=str_replace("(","",$year);
$year=str_replace(")","",$year);
$year=trim(preg_replace("/(<\/?)(\w+)([^>]*>)/e","",$year));
$year="<b>Year:</b> ".$year;
$tit=trim($t3[0]);

$imdb="<b>IMDB:</b> ".trim(str_between($html,'span itemprop="ratingValue">','<'));
$a1=explode('div class="titleBar">',$html);
//$gen1=str_between($html,'div class="titleBar">','</div>');
$gen1=$a1[1];
$t1=explode('itemprop="duration"',$gen1);
$t2=explode('>',$t1[1]);
$t3=explode('<',$t2[1]);
$durata="<b>Duration:</b> ".trim($t3[0]);

//$gen = trim(preg_replace("/<(.*)>|(\{(.*)\})/e","",$gen));
$videos = explode('href="/genre', $gen1);
unset($videos[0]);
$videos = array_values($videos);
$gen="";
foreach($videos as $video) {
  $t1=explode('itemprop="genre">',$video);
  if (sizeof($t1) > 1){
  $t2=explode("<",$t1[1]);
  $a=trim($t2[0]);
  if ($a) $gen .=trim($a)." | ";
  }
}
$gen=substr($gen, 0, -2);
$gen = trim(preg_replace("/(<\/?)(\w+)([^>]*>)/e","",$gen));
$gen=str_replace("&nbsp;","",$gen);
$gen=str_replace("\n","",$gen);
$gen=str_replace("\t","",$gen);
$gen=str_replace("  ","",$gen);
$gen="<b>Genre:</b> ".$gen;
$videos=explode('itemprop="actor"',$html);
unset($videos[0]);
$videos = array_values($videos);
$cast="";
foreach($videos as $video) {
 $t=explode('itemprop="name">',$video);
 $t1=explode("<",$t[1]);
 $cast=$cast.$t1[0]." | ";
}
$cast="<b>Cast</b>: ".$cast;
$cast=substr($cast, 0, -2);
//$gen="Gen: ".$gen;
//echo $gen;
$desc=trim(str_between($html,'itemprop="description">',"<"));
$desc = trim(preg_replace("/(<\/?)(\w+)([^>]*>)/e","",$desc));
echo '<table><tr>';
echo '<TD><img src="'.$image.'"></TD><h2 style="background-color:deepskyblue;color:black;text-align:left;">'.$tit.'</h2>';
echo '<TD  style="vertical-align:top;">'.$year.'<BR>'.$imdb.'<BR>'.$gen.'<BR>'.$durata.'<BR>'.$cast.'<BR><br>'.$desc.'</TD>';
?>
</TR>
</TABLE>
</body>
</html>

<!DOCTYPE html>
<?php
include ("../common.php");
$page = $_GET["page"];
$tit= urldecode($_GET["title"]);
$link=urldecode($_GET["link"]);
?>
<html><head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate"/>
<meta http-equiv="Pragma" content="no-cache"/>
<meta http-equiv="Expires" content="0"/>
      <title><?php echo $tit; ?></title>
<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.8.0/jquery.min.js"></script>
<script type="text/javascript" src="../jquery.fancybox.js?v=2.1.5"></script>
<link rel="stylesheet" type="text/css" href="../jquery.fancybox.css?v=2.1.5" media="screen" />
<script src="../jquery.nicescroll.min.js"></script>

<script type="text/javascript">
  $(document).ready(function() {
	$("html").niceScroll({styler:"fb",cursorcolor:"#000"});
  });
</script>
<script type="text/javascript">
$(document).ready(function() {
	$(".various").fancybox({
		maxWidth	: 800,
		maxHeight	: 600,
		fitToView	: false,
		width		: '70%',
		height		: '70%',
		autoSize	: false,
		closeClick	: false,
		openEffect	: 'none',
		closeEffect	: 'none'
	});
	$('.fancybox').fancybox();
	$("html").niceScroll({styler:"fb",cursorcolor:"#000"});
});
</script>
<link rel="stylesheet" type="text/css" href="../custom.css" />
</head>
<body>
<H2></H2>
<?php
function str_between($string, $start, $end){
	$string = " ".$string; $ini = strpos($string,$start);
	if ($ini == 0) return ""; $ini += strlen($start); $len = strpos($string,$end,$ini) - $ini;
	return substr($string,$ini,$len);
}


//print_r ($srt);
//die();
$cookie=$base_cookie."moviesplanet.dat";
//http://www.moviesplanet.is/movies/date/2
//$l="http://movietv.to/index/loadmovies";
$l=$link."/date/".$page."";
  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $l);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 5.1; rv:31.0) Gecko/20100101 Firefox/31.0');
  curl_setopt($ch, CURLOPT_FOLLOWLOCATION  ,1);
  curl_setopt ($ch, CURLOPT_REFERER, "http://www.moviesplanet.is/");
  curl_setopt($ch, CURLOPT_COOKIEJAR, $cookie);
  curl_setopt($ch, CURLOPT_COOKIEFILE, $cookie);
  //curl_setopt($ch, CURLOPT_HEADER,1);
  $html = curl_exec($ch);
  curl_close($ch);


echo '<h2 style="background-color:deepskyblue;color:black">'.$tit.'</H2>';
echo '<table border="1px" width="100%">'."\n\r";
echo '<tr><TD colspan="4" align="right">';
if ($page > 1)
echo '<a href="moviesplanet.php?page='.($page-1).'&link='.$link.'&title='.urlencode($tit).'"><font size="4">&nbsp;&lt;&lt;&nbsp;</font></a> | <a href="moviesplanet.php?page='.($page+1).'&link='.$link.'&title='.urlencode($tit).'"><font size="4">&nbsp;&gt;&gt;&nbsp;</font></a></TD></TR>';
else
echo '<a href="moviesplanet.php?page='.($page+1).'&link='.$link.'&title='.urlencode($tit).'"><font size="4">&nbsp;&gt;&gt;&nbsp;</font></a></TD></TR>';
//$h=file_get_contents($noob_sub);
//echo $html;
$videos = explode('<div class="ml-item"', $html);
unset($videos[0]);
$videos = array_values($videos);
$n=0;
foreach($videos as $video) {
  $title1=str_between($video,'class="mli-info"><h2>','</h2');
  if (!$title1) {
    $t1=explode('id="title"',$video);
    $t2=explode('title="',$t1[1]);
    $t3=explode('"',$t2[1]);
    $title1=$t3[0];
  }
  $image=str_between($video,'thumb.php?src=','&');;
  $link1= str_between($video,'href="','"');
  if (!$title1) {
    $t1=explode("show/",$link1);
    $title1=$t1[1];
  }
  if ($n==0) echo '<TR>';
  echo '<td align="center" width="25%"><a href="moviesplanet_link.php?file='.$link1.'&title='.$title1.'&image='.$image.'" target="_blank"><img src="'.$image.'" width="160px" height="224px"><BR><font size="4">'.$title1.'</font></a>|<a class="various fancybox.ajax" href="info.php?file='.urlencode($title1).'&image='.$image.'&title='.urlencode($title1).'"><b> INFO</b></a></TD>';
  $n++;
  if ($n == 4) {
  echo '</tr>';
  $n=0;
  }
}
echo '<tr><TD colspan="4" align="right">';
if ($page > 1)
echo '<a href="moviesplanet.php?page='.($page-1).'&link='.$link.'&title='.urlencode($tit).'"><font size="4">&nbsp;&lt;&lt;&nbsp;</font></a> | <a href="moviesplanet.php?page='.($page+1).'&link='.$link.'&title='.urlencode($tit).'"><font size="4">&nbsp;&gt;&gt;&nbsp;</font></a></TD></TR>';
else
echo '<a href="moviesplanet.php?page='.($page+1).'&link='.$link.'&title='.urlencode($tit).'"><font size="4">&nbsp;&gt;&gt;&nbsp;</font></a></TD></TR>';
echo "</table>";
?>
<br>

</body>
</html>

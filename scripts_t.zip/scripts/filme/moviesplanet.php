<!DOCTYPE html>
<?php
include ("../common.php");
$page = $_GET["page"];
$tit= urldecode($_GET["title"]);
$link=urldecode($_GET["link"]);
require_once 'httpProxyClass.php';
require_once 'cloudflareClass.php';

$httpProxy   = new httpProxy();
$httpProxyUA = 'proxyFactory';
?>
<html><head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate"/>
<meta http-equiv="Pragma" content="no-cache"/>
<meta http-equiv="Expires" content="0"/>
      <title><?php echo $tit; ?></title>
<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.8.0/jquery.min.js"></script>
<script type="text/javascript" src="../jquery.fancybox.js?v=2.1.5"></script>
<link rel="stylesheet" type="text/css" href="../jquery.fancybox.css?v=2.1.5" media="screen" />
<script src="../jquery.nicescroll.min.js"></script>

<script type="text/javascript">
  $(document).ready(function() {
	$("html").niceScroll({styler:"fb",cursorcolor:"#000"});
  });
</script>
<script type="text/javascript">
$(document).ready(function() {
	$(".various").fancybox({
		maxWidth	: 800,
		maxHeight	: 600,
		fitToView	: false,
		width		: '70%',
		height		: '70%',
		autoSize	: false,
		closeClick	: false,
		openEffect	: 'none',
		closeEffect	: 'none'
	});
	$('.fancybox').fancybox();
	$("html").niceScroll({styler:"fb",cursorcolor:"#000"});
});
</script>
<link rel="stylesheet" type="text/css" href="../custom.css" />
</head>
<body>
<H2></H2>
<?php
function str_between($string, $start, $end){
	$string = " ".$string; $ini = strpos($string,$start);
	if ($ini == 0) return ""; $ini += strlen($start); $len = strpos($string,$end,$ini) - $ini;
	return substr($string,$ini,$len);
}
    if (!function_exists('json_last_error_msg')) {
        function json_last_error_msg() {
            static $ERRORS = array(
                JSON_ERROR_NONE => 'No error',
                JSON_ERROR_DEPTH => 'Maximum stack depth exceeded',
                JSON_ERROR_STATE_MISMATCH => 'State mismatch (invalid or malformed JSON)',
                JSON_ERROR_CTRL_CHAR => 'Control character error, possibly incorrectly encoded',
                JSON_ERROR_SYNTAX => 'Syntax error',
                JSON_ERROR_UTF8 => 'Malformed UTF-8 characters, possibly incorrectly encoded'
            );

            $error = json_last_error();
            return isset($ERRORS[$error]) ? $ERRORS[$error] : 'Unknown error';
        }
    }

//print_r ($srt);
//die();
$cookie=$base_cookie."moviesplanet.dat";
//http://www.moviesplanet.is/movies/date/2
//$l="http://movietv.to/index/loadmovies";
$requestLink=$link."/date/".$page."";
$clearanceCookie = file_get_contents($cookie);
//echo $clearanceCookie;
//die();
	//cloudflare::useUserAgent($httpProxyUA);

	// attempt to get clearance cookie
	//if($clearanceCookie = cloudflare::bypass($requestLink)) {
		// use clearance cookie to bypass page
		$requestPage = $httpProxy->performRequest($requestLink, 'GET', null, array(
			'cookies' => $clearanceCookie
		));
		// return real page content for site
		$requestPage = json_decode($requestPage);
		$html = $requestPage->content;

//echo $html;
echo '<h2 style="background-color:deepskyblue;color:black">'.$tit.'</H2>';
echo '<table border="1px" width="100%">'."\n\r";
echo '<tr><TD colspan="4" align="right">';
if ($page > 1)
echo '<a href="moviesplanet.php?page='.($page-1).'&link='.$link.'&title='.urlencode($tit).'"><font size="4">&nbsp;&lt;&lt;&nbsp;</font></a> | <a href="moviesplanet.php?page='.($page+1).'&link='.$link.'&title='.urlencode($tit).'"><font size="4">&nbsp;&gt;&gt;&nbsp;</font></a></TD></TR>';
else
echo '<a href="moviesplanet.php?page='.($page+1).'&link='.$link.'&title='.urlencode($tit).'"><font size="4">&nbsp;&gt;&gt;&nbsp;</font></a></TD></TR>';
//$h=file_get_contents($noob_sub);
//echo $html;
$videos = explode('<div class="ml-item"', $html);
unset($videos[0]);
$videos = array_values($videos);
$n=0;
foreach($videos as $video) {
  $title1=str_between($video,'class="mli-info"><h2>','</h2');
  if (!$title1) {
    $t1=explode('id="title"',$video);
    $t2=explode('title="',$t1[1]);
    $t3=explode('"',$t2[1]);
    $title1=$t3[0];
  }
  $image=str_between($video,'thumb.php?src=','&');
  $image="r_m.php?file=".$image;
  $link1= str_between($video,'href="','"');
  if (!$title1) {
    $t1=explode("show/",$link1);
    $title1=$t1[1];
  }
  if ($n==0) echo '<TR>';
  echo '<td align="center" width="25%"><a href="moviesplanet_link.php?file='.$link1.'&title='.$title1.'&image='.$image.'" target="_blank"><img src="'.$image.'" width="160px" height="224px"><BR><font size="4">'.$title1.'</font></a>|<a class="various fancybox.ajax" href="info.php?file='.urlencode($title1).'&image='.$image.'&title='.urlencode($title1).'"><b> INFO</b></a></TD>';
  $n++;
  if ($n == 4) {
  echo '</tr>';
  $n=0;
  }
}
echo '<tr><TD colspan="4" align="right">';
if ($page > 1)
echo '<a href="moviesplanet.php?page='.($page-1).'&link='.$link.'&title='.urlencode($tit).'"><font size="4">&nbsp;&lt;&lt;&nbsp;</font></a> | <a href="moviesplanet.php?page='.($page+1).'&link='.$link.'&title='.urlencode($tit).'"><font size="4">&nbsp;&gt;&gt;&nbsp;</font></a></TD></TR>';
else
echo '<a href="moviesplanet.php?page='.($page+1).'&link='.$link.'&title='.urlencode($tit).'"><font size="4">&nbsp;&gt;&gt;&nbsp;</font></a></TD></TR>';
echo "</table>";
?>
<br>

</body>
</html>

<!DOCTYPE html>
<html><head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<link rel="stylesheet" type="text/css" href="../custom.css" />
     <script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.8.0/jquery.min.js"></script>
     <script src="../jquery.nicescroll.min.js"></script>
<script type="text/javascript">
  $(document).ready(function() {
	$("html").niceScroll({styler:"fb",cursorcolor:"#000"});
  });
</script>
      <meta charset="utf-8">
      <title>Episoade</title>
</head>
<body><h4></h4>
<?php
function str_between($string, $start, $end){
	$string = " ".$string; $ini = strpos($string,$start);
	if ($ini == 0) return ""; $ini += strlen($start); $len = strpos($string,$end,$ini) - $ini;
	return substr($string,$ini,$len);
}

$query = $_GET["file"];
if($query) {
   $queryArr = explode(',', $query);
   $link = $queryArr[0];
   $pg_tit = urldecode($queryArr[1]);
}
echo '<table border="1" width="100%">'."\n\r";
echo '<TR><TD align="center" colspan="5"><font size="4">'.$pg_tit.'</font></TD></TR>';
$n=0;
$html = file_get_contents($link);
$videos = explode("<div class='bloc_episoade'>", $html);

unset($videos[0]);
$videos = array_values($videos);
foreach($videos as $video) {
   $t1=explode('href="',$video);
   $t2=explode('"',$t1[1]);
   $link="http://serialepenet.ro".$t2[0];
   $t3=explode("class='serial_title'>",$video);
   $t4=explode("<",$t3[1]);
   $title=$t4[0];
   $t1=explode('src="',$video);
   $t2=explode('"',$t1[1]);
   $image=$t2[0];
   $s=$pg_tit."-".$title;
   $link = "serialepenet_l.php?file=".$link.",".urlencode($s);
   if ($n == 0) echo "<TR>"."\n\r";
echo '
<TD align="center"><a href="'.$link.'" target="_blank"><img style="width:170px; height:91px;" src="'.$image.'" />'.$title.'</a></TD>
';
   $n++;
   if ($n > 4) {
   echo '</TR>'."\n\r";
   $n=0;
   }
}
 if ($n < 5) {
 echo '</TR>';
 $n=0;
 }
?>
</TABLE>
<br></body>
</html>

<!DOCTYPE html>
<html>
<head>
	<title>IMDB</title>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
      <link rel="stylesheet" type="text/css" href="../custom.css" />
</head>
<body>
<!--
	<p>
		<a href="javascript:parent.jQuery.fancybox.close();">Close</a>
	</p>
-->
<?php
function str_between($string, $start, $end){
	$string = " ".$string; $ini = strpos($string,$start);
	if ($ini == 0) return ""; $ini += strlen($start); $len = strpos($string,$end,$ini) - $ini;
	return substr($string,$ini,$len);
}
$id = $_GET["file"];
$img=$_GET["image"];
$tit=urldecode($_GET["title"]);
include ("../common.php");
$link="http://123movies.to/movie/loadinfo/".$id;
$html=file_get_contents($link);
//echo $html;

$t1=explode('class="jt-info">',$html);
$t3=explode('<',$t1[1]);
$year="<b>Year:</b> ".$t3[0];


$imdb=trim(str_between($html,'jt-imdb">','<'));
$gen1=str_between($html,'Genre:','</div>');
$t1=explode('class="jt-info">',$html);
$t3=explode('<',$t1[2]);
$durata="<b>Duration:</b> ".trim($t3[0]);

//$gen = trim(preg_replace("/<(.*)>|(\{(.*)\})/e","",$gen));
$videos = explode('title="', $gen1);
unset($videos[0]);
$videos = array_values($videos);
$gen="";
foreach($videos as $video) {
  $t2=explode('"',$video);
  $gen .=trim($t2[0])." | ";
}
$gen = trim(preg_replace("/(<\/?)(\w+)([^>]*>)/e","",$gen));
$gen=str_replace("&nbsp;","",$gen);
$gen=str_replace("\n","",$gen);
$gen=str_replace("\t","",$gen);
$gen=str_replace("  ","",$gen);
$gen="<b>Genre:</b> ".$gen;
$gen=substr($gen, 0, -2);
$actor=str_between($html,'Actor:','</div>');
$videos=explode('title="',$actor);
unset($videos[0]);
$videos = array_values($videos);
$cast="";
foreach($videos as $video) {
 $t1=explode('"',$video);
 $cast=$cast.$t1[0]." | ";
}
$cast="<b>Cast</b>: ".$cast;
$cast=substr($cast, 0, -2);
//$gen="Gen: ".$gen;
//echo $gen;
$desc=trim(str_between($html,'class="f-desc">',"</p>"));
$desc = trim(preg_replace("/(<\/?)(\w+)([^>]*>)/e","",$desc));
echo '<table><tr>';
echo '<TD><img src="'.$img.'" width="160px" height="224px"></TD><h2 style="background-color:deepskyblue;color:black;text-align:left;">'.$tit.'</h2>';
echo '<TD  style="vertical-align:top;">'.$year.'<BR>'.$imdb.'<BR>'.$gen.'<BR>'.$durata.'<BR>'.$cast.'<BR><br>'.$desc.'</TD>';
?>
</TR>
</TABLE>
</body>
</html>

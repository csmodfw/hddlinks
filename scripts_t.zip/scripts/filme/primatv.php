<!DOCTYPE html>
<html><head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate"/>
<meta http-equiv="Pragma" content="no-cache"/>
<meta http-equiv="Expires" content="0"/>
      <title>Prima TV - Seriale</title>
<script src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
<link rel="stylesheet" type="text/css" href="../custom.css" />
</head>
<body>
<H2></H2>
<?php
function str_between($string, $start, $end){
	$string = " ".$string; $ini = strpos($string,$start);
	if ($ini == 0) return ""; $ini += strlen($start); $len = strpos($string,$end,$ini) - $ini;
	return substr($string,$ini,$len);
}
echo '<table border="1px" width="100%">'."\n\r";
echo '<TR><td style="color:black;background-color:deepskyblue;text-align:center" colspan="4"><font size="4"><b>Prima TV - Seriale</b></font></TD></TR>';

?>
<TR>
<TD width="25%"><a href="traznitii.php" target="_blank"><font size="4">Traznitii</font></TD>
<TD width="25%"><a href="primatv_s.php?id=62-sezonul-1&title=La+TV" target="_blank"><font size="4">La TV</font></TD>
<TD width="25%"><a href="primatv_s.php?id=20-3&title=nimeni+nu-i+perfect" target="_blank"><font size="4">nimeni nu-i perfect</font></TD>
<TD width="25%"><a href="primatv_s.php?id=59-sezon-7&title=iubiri+secrete" target="_blank"><font size="4">iubiri secrete</font></TD>
</TR>
</TABLE>
<BODY>
</HTML>

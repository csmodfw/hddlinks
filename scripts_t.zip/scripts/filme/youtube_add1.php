<?php
include ("../common.php");
$filename=$base_fav."youtube.txt";
$user=urldecode($_POST["user"]);
$id=$_POST["id"];
$tip=$_POST["tip"];
if ($tip) {
if (file_exists($filename)) {
 $h=file_get_contents($filename);
 if (strpos($h,$id) ===false) $h=$h.$user."\n".$id."\n".$tip."\n";
} else {
   $h=$user."\n".$id."\n".$tip."\n";
}
$fh = fopen($filename, 'w');
fwrite($fh, $h);
fclose($fh);
}
echo "Am adaugat: ".$user;
?>

<?php
function get_between($string,$start,$end){
	$string = " ".$string;
	$ini = strpos($string, $start);
	if($ini==0) return "";
	$ini += strlen($start);
	$len = strpos($string, $end, $ini) - $ini;
	return substr($string, $ini, $len);
}
function curl($url, $post="") {
	//debug
	$print = "<curl> ".$url;
	if($post){
		$print .= " | ".implode(", ", $post);
	}
	//echo colorize($print, "debug");
	$ch = curl_init($url);
	curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US; rv:1.8.1.11) Gecko/20071127 Firefox/2.0.0.11');
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	curl_setopt($ch, CURLOPT_URL, $url);
	if($post){
		curl_setopt($ch,CURLOPT_POST, 1);
		curl_setopt($ch,CURLOPT_POSTFIELDS, $post);
	}
	curl_setopt ($ch, CURLOPT_COOKIEJAR, "D:/EasyPHP/data/localweb/mobile/cookie/vumo.dat");
	curl_setopt ($ch, CURLOPT_COOKIEFILE, "D:/EasyPHP/data/localweb/mobile/cookie/vumo.dat");
	curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
	$result = curl_exec($ch);
	$statusCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
	curl_close($ch);
	return $result;
}
$config['general']['siteUrl'] = "http://vumoo.at/";
$res =  curl("http://vumoo.at/");
//Cloudflare Bypass
if(strstr($res, "DDoS protection by CloudFlare")){
	//echo colorize("CloudFlare detected...", "warning");
	//Get the math calc
	$math_calc = get_between($res, "a.value = ", ";");
	if($math_calc){
		//Resolve the math calc
		$math_result = (int)eval("return ($math_calc);");
		if(is_numeric($math_result)){
			//echo colorize("Math resolved: (".$math_calc." = ".$math_result.")", "success");
			$math_result += 8; //Domain lenght (just-dice.com)
			//Send the CloudFlare's form
			$getData = "cdn-cgi/l/chk_jschl";
			$getData .= "?jschl_vc=".get_between($res, 'name="jschl_vc" value="', '"');
			$getData .= "&jschl_answer=".$math_result;
			$res = curl($config['general']['siteUrl'].$getData.$getData);
			//Cloudflare Bypassed?
			if(strstr($res, "DDoS protection by CloudFlare")){
				echo "CloudFlare not bypassed...";
				exit;
			}else{
				echo $res;
			}
		}
	}
}
?>

<?php
error_reporting(0);
function str_between($string, $start, $end){
	$string = " ".$string; $ini = strpos($string,$start);
	if ($ini == 0) return ""; $ini += strlen($start); $len = strpos($string,$end,$ini) - $ini;
	return substr($string,$ini,$len);
}
   function generateResponse($request)
    {
        $context  = stream_context_create(
            array(
                'http' => array(
                    'method'  => "POST",
                    'header'  => "Content-Type: text/xml",
                    'content' => $request
                )
            )
        );
        $response     = file_get_contents("http://api.opensubtitles.org/xml-rpc", false, $context);
        return $response;
    }
include ("../common.php");
if (file_exists($base_pass."player.txt")) {
$flash=trim(file_get_contents($base_pass."player.txt"));
} else {
$flash="direct";
}
if (file_exists($base_pass."mx.txt")) {
$mx=trim(file_get_contents($base_pass."mx.txt"));
} else {
$mx="ad";
}
$noob=file_get_contents($base_cookie."n.dat");
$cookie=$base_cookie."noob.dat";
$id = $_GET["query"];
$serv = $_GET["serv"];
$hd_o = $_GET["hd"];
$title = $_GET["title"];
$subtracks = "";
$premium = "";
if ($hd_o=="NU")
 $hd=0;
else
 $hd=1;
$tv= $_GET["tv"];
if (!$tv) {
 $l=$noob."/?".$id;
 $imgid=$id;
 $tv="0";
} else {
 $l=$noob."/?".$id."&tv=1";
 $imgid="ep".$id;
}
$sub=$_GET["sub"];
  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $l);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US; rv:1.9.1.2) Gecko/20090729 Firefox/3.5.2 GTB5');
  curl_setopt($ch, CURLOPT_FOLLOWLOCATION  ,1);
  curl_setopt($ch, CURLOPT_COOKIEJAR, $cookie);
  curl_setopt($ch, CURLOPT_COOKIEFILE, $cookie);
  $html = curl_exec($ch);
  curl_close($ch);
  //http://noobroom7.com/fork.php?type=flv&auth=0&loc=15&hd=0&tv=0&file=1633&start=0
  if ($hd==1) {
  if (!preg_match("/Watch in 1080p/i",$html))
    $hd=0;
  }
  if (preg_match("/Inactive/i",$html)) {
    $hd=0;
	$premium="Inactiv";
  }
  $auth=str_between($html,"auth=","&");
   if ($tv=="0") {
     if ($hd==0)
     $movie= $noob."/".$serv."/".$auth."/".$id.".mp4";
     else
     $movie= $noob."/".$serv."/".$auth."/".$id."_hd.mp4";
   } else {
     if ($hd==0)
     $movie= $noob."/".$serv."/".$auth."/episode_".$id.".mp4";
     else
     $movie= $noob."/".$serv."/".$auth."/episode_".$id."_hd.mp4";
   }
if ($hd==0) {
  $movie_SD_mp4=$movie;
  $movie_HD_mp4="";
} else {
  $movie_SD_mp4=str_replace("_hd","",$movie);
  $movie_HD_mp4=$movie;
}
//$movie=$noob."/fork.php?type=flv&auth=".$auth."&loc=".$serv."&hd=".$hd."&tv=".$tv."&file=".$id;
if ($hd==0)
$movie_file=$id.".mp4";
else
$movie_file=$id."_hd.mp4";
$h=file_get_contents($cookie);
$t1=explode("0	noob",$h);
$t2=explode("\n",$t1[1]);
$n=$t2[0];
$t1=explode("0	auth",$h);
$t2=explode("\n",$t1[1]);
$a=$t2[0];
$cookie_ref="lvca_unique_user=1; place=1; noob=".$n." auth=".$a;
if (!$sub) {
  if ($tv=="0")
    $file="http://uphero.xpresso.eu/srt/m/".$id.".srt";
  else
    $file="http://uphero.xpresso.eu/srt/s/".$id.".srt";
  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $file);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US; rv:1.9.1.2) Gecko/20090729 Firefox/3.5.2 GTB5');
  curl_setopt($ch, CURLOPT_FOLLOWLOCATION  ,1);
  //curl_setopt($ch, CURLOPT_HEADER, true);
  curl_setopt($ch, CURLOPT_TIMEOUT, 30);
  $h = curl_exec($ch);
  curl_close($ch);
  if (strpos($h,"-->") === false || strpos($h,"302 Found") !== false) {
  if ($tv=="0")
    $file="http://uphero.xpresso.eu/srt/en/".$id.".srt";
  else
    $file="";
  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $file);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US; rv:1.9.1.2) Gecko/20090729 Firefox/3.5.2 GTB5');
  curl_setopt($ch, CURLOPT_FOLLOWLOCATION  ,1);
  curl_setopt($ch, CURLOPT_TIMEOUT, 30);
  $h = curl_exec($ch);
  curl_close($ch);
  }
} else {
  $token=file_get_contents($base_cookie."opensub.dat");
$request="<?xml version=\"1.0\" encoding=\"iso-8859-1\"?>
<methodCall>
<methodName>DownloadSubtitles</methodName>
<params>
 <param>
  <value>
   <string>".$token."</string>
  </value>
 </param>
 <param>
  <value>
   <array>
    <data>
     <value>
      <string>".$sub."</string>
     </value>
    </data>
   </array>
  </value>
 </param>
</params>
</methodCall>";
$response = generateResponse($request);
//echo $response;
$t1=explode("data",$response);
$data=str_between($t1[3],"<string>","</string>");
//echo $data;
$a1=base64_decode($data);
$f=$base_cookie."opensub.gz";
file_put_contents($f,$a1);
$h = gzdecode(base64_decode($data));
}
if ($tv=="0") {
  if ($hd==0)
  $srt_name=$id.".srt";
  else
  $srt_name=$id."_hd.srt";
} else {
  if ($hd==0)
  $srt_name="episode_".$id.".srt";
  else
  $srt_name="episode_".$id."_hd.srt";
  /*
  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $movie);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US; rv:1.9.1.2) Gecko/20090729 Firefox/3.5.2 GTB5');
  curl_setopt($ch, CURLOPT_FOLLOWLOCATION  ,1);
  curl_setopt($ch, CURLOPT_HEADER, true);
  curl_setopt($ch, CURLOPT_NOBODY, true);
  curl_setopt($ch, CURLOPT_TIMEOUT, 30);
  $h = curl_exec($ch);
  curl_close($ch);
  $srt_name=str_between($h,'filename="','"');
  $srt_name=str_replace(".mp4",".srt",$srt_name);
  */
}
/*
   $ch = curl_init();
   curl_setopt($ch, CURLOPT_URL, $file);
   curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
   curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 5.1; rv:14.0) Gecko/20100101 Firefox/14.0.1');
   curl_setopt($ch, CURLOPT_FOLLOWLOCATION  ,1);
   $h=curl_exec($ch);
   curl_close($ch);
*/
$list = glob($base_sub."*.srt");
   foreach ($list as $l) {
    str_replace(" ","%20",$l);
    unlink($l);
}
if ( ($h) && strpos($h,"302 Found") == false && strpos(strtolower($h),"doctype html") == false )  {
 if (function_exists("mb_convert_encoding")) {
    $map = array(
        chr(0x8A) => chr(0xA9),
        chr(0x8C) => chr(0xA6),
        chr(0x8D) => chr(0xAB),
        chr(0x8E) => chr(0xAE),
        chr(0x8F) => chr(0xAC),
        chr(0x9C) => chr(0xB6),
        chr(0x9D) => chr(0xBB),
        chr(0xA1) => chr(0xB7),
        chr(0xA5) => chr(0xA1),
        chr(0xBC) => chr(0xA5),
        chr(0x9F) => chr(0xBC),
        chr(0xB9) => chr(0xB1),
        chr(0x9A) => chr(0xB9),
        chr(0xBE) => chr(0xB5),
        chr(0x9E) => chr(0xBE),
        chr(0x80) => '&euro;',
        chr(0x82) => '&sbquo;',
        chr(0x84) => '&bdquo;',
        chr(0x85) => '&hellip;',
        chr(0x86) => '&dagger;',
        chr(0x87) => '&Dagger;',
        chr(0x89) => '&permil;',
        chr(0x8B) => '&lsaquo;',
        chr(0x91) => '&lsquo;',
        chr(0x92) => '&rsquo;',
        chr(0x93) => '&ldquo;',
        chr(0x94) => '&rdquo;',
        chr(0x95) => '&bull;',
        chr(0x96) => '&ndash;',
        chr(0x97) => '&mdash;',
        chr(0x99) => '&trade;',
        chr(0x9B) => '&rsquo;',
        chr(0xA6) => '&brvbar;',
        chr(0xA9) => '&copy;',
        chr(0xAB) => '&laquo;',
        chr(0xAE) => '&reg;',
        chr(0xB1) => '&plusmn;',
        chr(0xB5) => '&micro;',
        chr(0xB6) => '&para;',
        chr(0xB7) => '&middot;',
        chr(0xBB) => '&raquo;',
    );
	$h = html_entity_decode(mb_convert_encoding(strtr($h, $map), 'UTF-8', 'ISO-8859-2'), ENT_QUOTES, 'UTF-8');

	$h = str_replace("\xC3\x84\xE2\x80\x9A","\xC4\x82",$h);
	$h = str_replace("\xC3\x84\xC2\x83","\xC4\x83",$h);
    $h = str_replace("\xC4\x82\xC5\xBD","\xC3\x8E",$h);
    $h = str_replace("\xC4\x82\xC2\xAE","\xC3\xAE",$h);
    $h = str_replace("\xC4\xB9\xCB\x98","\xC5\xA2",$h);
    $h = str_replace("\xC4\xB9\xC5\x81","\xC5\xA3",$h);
    $h = str_replace("\xC4\x82\xE2\x80\X9A","\xC3\x82",$h);
    $h = str_replace("\xC4\x82\xCB\x98","\xC3\xA2",$h);
    $h = str_replace("\xC4\xB9\xC5\xBE","\xC5\x9E",$h);
    $h = str_replace("\xC4\xB9\xC5\xBA","\xC5\x9F",$h);
    $h = str_replace("\xC4\x8C\xC5\xA1","\xC5\xA2",$h);
    $h = str_replace("\xC4\x8C\xE2\x80\x99","\xC5\xA3",$h);
    $h = str_replace("\xC4\x8C\xC2\x98","\xC5\x9E",$h);
    $h = str_replace("\xC4\x8C\xE2\x84\xA2","\xC5\x9F",$h);
	$h = str_replace("\xC3\xA2\xE2\x84\xA2\xC5\x9E","\xE2\x99\xAA",$h);

} else {
    $h = str_replace("�","S",$h);
    $h = str_replace("�","s",$h);
    $h = str_replace("�","T",$h);
    $h = str_replace("�","t",$h);
    $h=str_replace("�","a",$h);
	$h=str_replace("�","a",$h);
	$h=str_replace("�","i",$h);
	$h=str_replace("�","A",$h);
}

   $new_file = $base_sub.$srt_name;
   $fh = fopen($new_file, 'w');
   fwrite($fh, $h, strlen($h));
   fclose($fh);

    $subtracks='"tracks": [{"file": "../subs/'.$srt_name.'", "default": true}]';

}
$user_agent     =   $_SERVER['HTTP_USER_AGENT'];
if (preg_match("/android|ipad/i",$user_agent) && preg_match("/chrome|firefox|mobile/i",$user_agent)) $flash="chrome";
if ($flash == "direct") {
header('Content-type: application/vnd.apple.mpegURL');
header('Referer: '.$noob.'/index.php');
//header('Referer: http://p.jwpcdn.com/6/10/jwplayer.flash.swf');
header('Cookie: '.$cookie_ref);
header('Content-Disposition: attachment; filename="'.$movie_file.'"');
header("Location: $movie");
}
elseif ($flash == "chrome") {
$c="intent:".$movie."#Intent;package=com.mxtech.videoplayer.".$mx.";S.title=".urlencode($title).";end";
header("Location: $c");
} else {
  $l=$noob."/fork.php?type=flv&auth=".$auth."&loc=".$serv."&hd=".$hd."&tv=".$tv;
  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $l);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  //curl_setopt($ch, CURLOPT_FOLLOWLOCATION  ,1);
  curl_setopt($ch, CURLOPT_HEADER, 1);
  //curl_setopt($ch, CURLOPT_NOBODY, 1);
  curl_setopt($ch, CURLOPT_COOKIEFILE, $cookie);
  curl_setopt($ch, CURLOPT_REFERER,$noob."/player.swf");
  curl_setopt($ch, CURLOPT_HTTPHEADER, array("Accept: text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8","Accept-Language: ro-ro,ro;q=0.8,en-us;q=0.6,en-gb;q=0.4,en;q=0.2","Accept-Encoding: gzip, deflate"));
  curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 5.1; rv:14.0) Gecko/20100101 Firefox/14.0.1');
  $html = curl_exec($ch);
  //echo $html;
  curl_close($ch);
  if (strpos($html,"index.php") === false) {
  $link=trim(str_between($html,"http://","/"));
  $link="http://".$link;
  $type="flv";
  $movie1=$link."/".$id.".php?file=".$id."&start=0&hd=".$hd."&auth=".$auth."&type=".$type."&tv=".$tv."&loc=".$serv."&dl=";
  } else {
  $link=trim(str_between($html,"Location:","/index.php"));
  $type="flv";
  $movie1=$link."/index.php?file=".$id."&start=0&hd=".$hd."&auth=".$auth."&type=".$type."&tv=".$tv."&loc=".$serv;
  }
if ($hd==0) {
  $movie_SD_flv=$movie1;
  $movie_HD_flv="";
} else {
  $movie_SD_flv=str_replace("hd=1","hd=0",$movie1);
  $movie_HD_flv=$movie1;
}
if ($hd=="0")
	if ($premium == "Inactiv")
		$source='{"default": "true", "file": "'.$movie_SD_flv.'", "type": "flv", "label": "SD Flash"}';
	else 
		$source='{"default": "true", "file": "'.$movie_SD_flv.'", "type": "flv", "label": "SD Flash"},{"file": "'.$movie_SD_mp4.'", "type": "mp4", "label": "SD MP4"}';
else
	if ($premium == "Inactiv")
		$source='{"file": "'.$movie_SD_flv.'", "type": "flv", "label": "SD Flash"},{"default": "true", "file": "'.$movie_HD_flv.'", "type": "flv", "label": "HD Flash"}';
	else 
		$source='{"file": "'.$movie_SD_flv.'", "type": "flv", "label": "SD Flash"},{"default": "true", "file": "'.$movie_HD_flv.'", "type": "flv", "label": "HD Flash"},{"file": "'.$movie_SD_mp4.'", "type": "mp4", "label": "SD MP4"},{"default": "true", "file": "'.$movie_HD_mp4.'", "type": "mp4", "label": "HD MP4"}';

$sources='"sources": ['.$source.'],';
echo '
<!doctype html>
<HTML>
<HEAD>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>'.$title.'</title>
<style type="text/css">
body {
margin: 0px auto;
overflow:hidden;
}
body {background-color:#000000;}
</style>
<script src="//code.jquery.com/jquery-1.11.0.min.js"></script>
'.$jwv.'

</HEAD>
<BODY>
<div id="container"></div>
<script type="text/javascript">
jwplayer("container").setup({
"playlist": [{
"image": "'.$noob.'/2img/'.$imgid.'.jpg",
'.$sources.'
'.$subtracks.'
}],
    captions: {
        color: "#FFFFFF",
        fontSize: 20,
        backgroundOpacity: 0
    },
"height": $(document).height(),
"width": $(document).width(),
"skin": '.$skin.',
"title": "'.$title.'",
"abouttext": "'.$title.'",
"aboutlink": "imdb.php?id='.$id.'",
"androidhls": true,
"startparam": "start",
"fallback": false,
"wmode": "direct",
"stagevideo": true
});
</script>
</BODY>
</HTML>
';
}
?>

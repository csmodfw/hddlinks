<!DOCTYPE html>
<html><head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<link rel="stylesheet" type="text/css" href="../custom.css" />

      <meta charset="utf-8">
      <title>Favorite</title>
     <script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.8.0/jquery.min.js"></script>
     <script src="../jquery.nicescroll.min.js"></script>
      <script type="text/javascript" src="func.js"></script>
      <script type="text/javascript" src="../jquery.fancybox.js?v=2.1.5"></script>
      <link rel="stylesheet" type="text/css" href="../jquery.fancybox.css?v=2.1.5" media="screen" />


<script type="text/javascript">
// create the XMLHttpRequest object, according browser
function get_XmlHttp() {
  // create the variable that will contain the instance of the XMLHttpRequest object (initially with null value)
  var xmlHttp = null;
  if(window.XMLHttpRequest) {		// for Forefox, IE7+, Opera, Safari, ...
    xmlHttp = new XMLHttpRequest();
  }
  else if(window.ActiveXObject) {	// for Internet Explorer 5 or 6
    xmlHttp = new ActiveXObject("Microsoft.XMLHTTP");
  }
  return xmlHttp;
}

// sends data to a php file, via POST, and displays the received answer
function ajaxrequest(title, link) {
  var request =  get_XmlHttp();		// call the function for the XMLHttpRequest instance

  // create pairs index=value with data that must be sent to server
  //var the_data = {mod:del,title:title, link:link}; //Array
  var the_data = 'mod=del&title='+ title +'&link='+link;
  var php_file='noob_s_add.php';
  request.open("POST", php_file, true);			// set the request

  // adds a header to tell the PHP script to recognize the data as is sent via POST
  request.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
  request.send(the_data);		// calls the send() method with datas as parameter

  // Check request status
  // If the response is received completely, will be transferred to the HTML tag with tagID
  request.onreadystatechange = function() {
    if (request.readyState == 4) {
      alert (request.responseText);
      location.reload();
    }
  }
}
</script>
<script type="text/javascript">
$(document).ready(function() {
	$(".various").fancybox({
		maxWidth	: 800,
		maxHeight	: 600,
		fitToView	: false,
		width		: '70%',
		height		: '70%',
		autoSize	: false,
		closeClick	: false,
		openEffect	: 'none',
		closeEffect	: 'none'
	});
	$('.fancybox').fancybox();
	$("html").niceScroll({styler:"fb",cursorcolor:"#000"});
});
</script>
</head>
   <body>

	<div class="balloon"></div>
<?php
function str_between($string, $start, $end){
	$string = " ".$string; $ini = strpos($string,$start);
	if ($ini == 0) return ""; $ini += strlen($start); $len = strpos($string,$end,$ini) - $ini;
	return substr($string,$ini,$len);
}
include ("../common.php");
$filename=$base_fav."noob_s.txt";
$noob=file_get_contents($base_cookie."n.dat");
$f=$base_pass."airfun.txt";
if (file_exists($f)) {
$h=file_get_contents($f);
$t1=explode("|",$h);
$air=$t1[0];
} else {
$air="NU";
}
if (file_exists($filename)) {
echo '<table align="center" border="1" width="100%">'."\n\r";
echo '<TR><TD style="background-color:deepskyblue;color:black;" colspan="6" align="center"><font size="4"><b>SERIALE FAVORITE</b></font></TD></TR>';
$n=0;

  $h=file($filename);
  //print_r ($h);
  $m=count($h);
  for ($k=0;$k<$m;$k=$k+2) {
   if ($n == 0) echo "<TR>"."\n\r";
   $title=trim($h[$k]);
   $link1=trim($h[$k+1]);
   $arr[]=array($title, $link1);
  }
if( !empty( $arr ) ) {
asort($arr);
foreach ($arr as $key => $val) {
  $link1=$arr[$key][1];
  $title=$arr[$key][0];
  $img=str_replace("episodes.php?","2img/sh",$noob.$link1).".jpg";

   $link="noob_s1.php?query=".urlencode($noob.$link1)."&title=".urlencode($title);
   //echo '<TD><font size="4">'.'<a href="'.$link.'" target="_blank">'.$title.'</a></font></TD>';
   //echo '<td style="text-align:right;width:5px"><a onclick="ajaxrequest('."'".$title."', '".$link1."')".'"'." style='cursor:pointer;'>".'<font size="4">DEL</font></a></TD>'."\n\r";
   if ($n == 0) echo "<TR>"."\n\r";
   if ($air=="DA") {
   echo '
   <TD><font size="4"><a class="tippable" id="'.$img.'" href="'.$link.'" target="_blank">'.$title.'</font></a></TD?
   ';
   echo '<td style="text-align:right;width:5px"><a class="fancybox" href="'.$img.'" title=""><b>PIC</b></a>|<a onclick="ajaxrequest('."'".$title."', '".$link1."')".'"'." style='cursor:pointer;'>".'<font size="4">DEL</font></a></TD>'."\n\r";
   $k = 2;
   } elseif ($air=="NU") {
   echo '
   <TD><font size="4"><a href="'.$link.'" target="_blank">'.$title.'</font></a></TD?
   ';
   echo '<td style="text-align:right;width:5px"><a class="fancybox" href="'.$img.'" title=""><b>PIC</b></a>|<a onclick="ajaxrequest('."'".$title."', '".$link1."')".'"'." style='cursor:pointer;'>".'<font size="4">DEL</font></a></TD>'."\n\r";
   $k = 2;
   } else {
   echo '
   <TD align="center" width="20%"><a href="'.$link.'" target="_blank"><img src="'.$img.'" width="160px" height="224px"><BR><font size="4">'.$title.'</font></a><BR><a onclick="ajaxrequest('."'".$title."', '".$link1."')".'"'." style='cursor:pointer;'>".'<font size="4">DEL</font></a></TD>
   ';
   $k = 5;
   }
   //echo '</TD>'."\n\r";
    $n++;
    if ($n == $k) {
     echo '</TR>'."\n\r";
     $n=0;
    }
}
}
echo '</table>';
}
?>
<br></body>
</html>

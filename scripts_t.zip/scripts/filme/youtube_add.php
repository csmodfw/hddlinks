<?php
$user=$_POST["user"];
$id=$_POST["id"];
$tip=$_POST["tip"];
include ("../common.php");
$out="";
$filename=$base_fav."youtube.txt";
  $h=file($filename);
  //print_r($h);
  $n=count($h);
  for ($k=0;$k<$n;$k=$k+3) {
   if ($id <> trim($h[$k+1])) $out=$out.trim($h[$k])."\n".trim($h[$k+1])."\n".trim($h[$k+2])."\n";
  }
$fh = fopen($filename, 'w');
fwrite($fh, $out);
fclose($fh);
echo "Am sters: ".$user;
?>

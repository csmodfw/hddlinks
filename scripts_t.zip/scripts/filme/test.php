<?php
function str_between($string, $start, $end){
	$string = " ".$string; $ini = strpos($string,$start);
	if ($ini == 0) return ""; $ini += strlen($start); $len = strpos($string,$end,$ini) - $ini;
	return substr($string,$ini,$len);
}
include ("../common.php");
$noob=file_get_contents($base_cookie."n.dat");
$cookie=$base_cookie."noob.dat";
$hd=0;
$tv=0;
$serv=24;
$auth="ZmQxOGI0NDA5Njc4NmU4OGFmNGIzZDdjNWU4MDU5ODFlYmE0NDBhMg%3D%3D";
for ($k=1;$k<11;$k++) {
  $l=$noob."/fork.php?type=flv&auth=".$auth."&loc=".$serv."&hd=".$hd."&tv=".$tv;
  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $l);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  //curl_setopt($ch, CURLOPT_FOLLOWLOCATION  ,1);
  curl_setopt($ch, CURLOPT_HEADER, 1);
  //curl_setopt($ch, CURLOPT_NOBODY, 1);
  curl_setopt($ch, CURLOPT_COOKIEFILE, $cookie);
  curl_setopt($ch, CURLOPT_REFERER,$noob."/player.swf");
  curl_setopt($ch, CURLOPT_HTTPHEADER, array("Accept: text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8","Accept-Language: ro-ro,ro;q=0.8,en-us;q=0.6,en-gb;q=0.4,en;q=0.2","Accept-Encoding: gzip, deflate"));
  curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 5.1; rv:14.0) Gecko/20100101 Firefox/14.0.1');
  $html = curl_exec($ch);
  curl_close($ch);
  $s=str_between($html,'http://','/');
  echo $s."<BR>";
}
// dallas 173.192.81.175
// frankfurt 159.122.70.11
//echo $html;
?>

<!DOCTYPE html>
<?php
include ("../common.php");
$page = $_GET["page"];
$tit= urldecode($_GET["title"]);
$link=urldecode($_GET["link"]);
$token=$_GET["token"];
$tip=$_GET["tip"];
if ($tip=="search" || $tip=="actor") $tit="Cauta:".$link;
$link=str_replace(" ","+",$link);
?>
<html><head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate"/>
<meta http-equiv="Pragma" content="no-cache"/>
<meta http-equiv="Expires" content="0"/>
      <title><?php echo $tit; ?></title>
<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.8.0/jquery.min.js"></script>
<script src="../jquery.nicescroll.min.js"></script>

<script type="text/javascript">
  $(document).ready(function() {
	$("html").niceScroll({styler:"fb",cursorcolor:"#000"});
  });
</script>
<link rel="stylesheet" type="text/css" href="../custom.css" />
</head>
<body>
<H2></H2>
<?php
function str_between($string, $start, $end){
	$string = " ".$string; $ini = strpos($string,$start);
	if ($ini == 0) return ""; $ini += strlen($start); $len = strpos($string,$end,$ini) - $ini;
	return substr($string,$ini,$len);
}

$l22="http://uphero.xpresso.eu/movietv/m/glob.php";
$html22=file_get_contents($l22);
$videos = explode(",", $html22);
//echo $html22;
unset($videos[0]);
$videos = array_values($videos);

foreach($videos as $video) {
  $t1=explode('.',$video);
  $id_srt=trim($t1[0]);
  //echo $id_srt;
  $srt[$id_srt]="exista";
}
//print_r ($srt);
//die();
$noob_sub=$base_cookie."noob_sub.dat";
if (!file_exists($noob_sub)) {
  $sub="http://uphero.xpresso.eu/srt/list.php";
  $html=file_get_contents($sub);
  //$html=preg_replace("/ \(Awards Screener\)| \(High Bitrate Test\)| \(HDRip\)|/i","",$html);
  $fh = fopen($noob_sub, 'w');
  fwrite($fh, $html);
  fclose($fh);
}
$cookie=$base_cookie."movietv.dat";
if ($tip=="genres")
$post="loadmovies=showData&page=".$page."&abc=All&genres=".$link."&sortby=Recent&quality=All&type=movie&q=&token=".$token;
elseif ($tip=="release")
$post="loadmovies=showData&page=".$page."&abc=All&genres=&sortby=".$link."&quality=All&type=movie&q=&token=".$token;
elseif ($tip=="search")
$post="loadmovies=showData&page=".$page."&abc=All&genres=&sortby=Recent&quality=All&type=movie&q=".$link."&token=".$token;
$n=0;
//$l="http://movietv.to/titles1/paginate?_token=KCaCdzkIfE2xDhGqSsnHRtndTa7RsMWpck6ej5FU&perPage=20&page=1&order=created_atDesc&genres%5B%5D=action&type=movie";
$l="http://movietv.to/index/loadmovies";
//echo $l;
//echo $post;
$h1=file_get_contents($cookie);
$t1=explode("__cfduid",$h1);
$t2=explode("\n",$t1[1]);
$cfduid=trim($t2[0]);
$t1=explode("PHPSESSID",$h1);
$t2=explode("\n",$t1[1]);
$phpsessid=trim($t2[0]);
$announcement="";
$t1=explode("announcement",$h1);
if ( sizeof($t1)>1 ) {
  $t2=explode("\n",$t1[1]);
  $announcement=trim($t2[0]);
}
//$post="loadmovies=showData&page=1&abc=All&genres=&sortby=Recent&quality=All&type=movie&q=&token=41ae81322d584a9a0abd37fdc7381f69";
$head=array('Accept: */*','Accept-Language: ro-ro,ro;q=0.8,en-us;q=0.6,en-gb;q=0.4,en;q=0.2','Accept-Encoding: deflate','Content-Type: application/x-www-form-urlencoded; charset=UTF-8','X-Requested-With: XMLHttpRequest','Content-Length: '.strlen($post),'Cookie: __cfduid='.$cfduid.'; announcement='.$announcement.'; notice=true; _gat=1; PHPSESSID='.$phpsessid.'');

//$post="loadmovies=showData&page=1&abc=All&genres=&sortby=Recent&quality=All&type=movie&q=&token=7a782c9902aabbce5924af61d724bd22";
//$l="http://movietv.to/titles/paginate?_token=qmsTyuUNZpPt9YXlYvdYI2Oj8zFTMiaMXPDZ5DtS&perPage=16&page=1&order=&type=movie";
  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $l);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 5.1; rv:31.0) Gecko/20100101 Firefox/31.0');
  curl_setopt($ch, CURLOPT_FOLLOWLOCATION  ,1);
  curl_setopt($ch,CURLOPT_HTTPHEADER,$head);
  curl_setopt($ch, CURLOPT_POST, 1);
  //curl_setopt($ch, CURLOPT_HEADER,1);
  //curl_setopt($ch, CURLOPT_NOBODY,0);
  curl_setopt ($ch, CURLOPT_POSTFIELDS, $post);
  //curl_setopt($ch, CURLOPT_COOKIEJAR, $cookie);
  //curl_setopt($ch, CURLOPT_COOKIEFILE, $cookie);
  curl_setopt ($ch, CURLOPT_REFERER, "http://movietv.to/");
  $html = curl_exec($ch);
  curl_close($ch);


echo '<h2 style="background-color:deepskyblue;color:black">'.$tit.'</H2>';
echo '<table border="1px" width="100%">'."\n\r";
echo '<tr><TD colspan="4" align="right">';
if ($page > 1)
echo '<a href="movietv1.php?page='.($page-1)."&tip=".$tip."&link=".urlencode($link)."&title=".urlencode($tit)."&token=".$token.'"><font size="4">&nbsp;&lt;&lt;&nbsp;</font></a> | <a href="movietv1.php?page='.($page+1)."&tip=".$tip."&link=".urlencode($link)."&title=".urlencode($tit)."&token=".$token.'"><font size="4">&nbsp;&gt;&gt;&nbsp;</font></a></TD></TR>';
else
echo '<a href="movietv1.php?page='.($page+1)."&tip=".$tip."&link=".urlencode($link)."&title=".urlencode($tit)."&token=".$token.'"><font size="4">&nbsp;&gt;&gt;&nbsp;</font></a></TD></TR>';
$h=file_get_contents($noob_sub);
$videos = explode('<div class="item"', $html);
unset($videos[0]);
$videos = array_values($videos);
foreach($videos as $video) {
  $title11=str_between($video,'movie-title">','<');
  $image=str_between($video,'src="','"');;
  $link1= str_between($video,'href="','"');
  $id1= str_between($video,"addWatchlist('","'");
  $year=str_between($video,'movie-date">','<');
  $title=$title11." (".$year.") ";
  $id_t="";
  if (!array_key_exists($id1, $srt)) {
     $tt="".$title11."\|".$year."";
     $tt=str_replace("/","\/'",$tt);
     $s="/\|".$tt."\|\d+\|\d+/i";
     if (preg_match($s,$h,$m)) {
       $t1=explode("|",$m[0]);
       if ($t1[4]== 1) {
         $title1=$title;
         $id_t=$t1[3];
       } else
         $title1=$title." *";
     } else
       $title1=$title." *";
  } else
    $title1=$title;
  if ($n==0) echo '<TR>';
  echo '<td align="center" width="25%"><a href="movietv1_link.php?file='.urlencode($link1).'&id='.$id1.'&id_t='.$id_t.'&title='.urlencode(str_replace("'","\'",$title)).'&image='.$image.'" target="_blank"><img src="'.$image.'" width="160px" height="224px"><BR><font size="4">'.$title1.'</font></a></TD>';
  $n++;
  if ($n == 4) {
  echo '</tr>';
  $n=0;
  }
}
echo '<tr><TD colspan="4" align="right">';
if ($page > 1)
echo '<a href="movietv1.php?page='.($page-1)."&tip=".$tip."&link=".urlencode($link)."&title=".urlencode($tit)."&token=".$token.'"><font size="4">&nbsp;&lt;&lt;&nbsp;</font></a> | <a href="movietv1.php?page='.($page+1)."&tip=".$tip."&link=".urlencode($link)."&title=".urlencode($tit)."&token=".$token.'"><font size="4">&nbsp;&gt;&gt;&nbsp;</font></a></TD></TR>';
else
echo '<a href="movietv1.php?page='.($page+1)."&tip=".$tip."&link=".urlencode($link)."&title=".urlencode($tit)."&token=".$token.'"><font size="4">&nbsp;&gt;&gt;&nbsp;</font></a></TD></TR>';
echo "</table>";
?>
<br>

</body>
</html>

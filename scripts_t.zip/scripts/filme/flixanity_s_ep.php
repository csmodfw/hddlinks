<!DOCTYPE html>
<?php
$tit=$_GET["title"];
$image=$_GET["image"];
$link=$_GET["file"];
$tip=$_GET["tip"];
?>
<html><head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<link rel="stylesheet" type="text/css" href="../custom.css" />
      <meta charset="utf-8">
      <title><?php echo $tit; ?></title>
<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.8.0/jquery.min.js"></script>
<script src="../jquery.nicescroll.min.js"></script>

<script type="text/javascript">
  $(document).ready(function() {
	$("html").niceScroll({styler:"fb",cursorcolor:"#000"});
  });
</script>
</head>
<body><h4></h4>
<?php
error_reporting(0);
function str_between($string, $start, $end){
	$string = " ".$string; $ini = strpos($string,$start);
	if ($ini == 0) return ""; $ini += strlen($start); $len = strpos($string,$end,$ini) - $ini;
	return substr($string,$ini,$len);
}
echo '<table border="1" width="100%">'."\n\r";
echo '<TR><td style="color:#000000;background-color:deepskyblue;text-align:center" colspan="3" align="center"><font size="4">'.$tit.'</font></TD></TR>';
///flixanity_s_ep.php?tip=serie&file=http://flixanity.watch/the-walking-dead&title=The Walking Dead&image=http://flixanity.watch/thumbs/show_85a60e7d66f57fb9d75de9eefe36c42c.jpg
$requestLink=$link;
//$cookie="/tmp/vumoo.txt";
//$cookie="D:/";
  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $requestLink);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 5.1; rv:31.0) Gecko/20100101 Firefox/31.0');
  curl_setopt($ch, CURLOPT_FOLLOWLOCATION  ,1);
  curl_setopt ($ch, CURLOPT_REFERER, "https://flixanity.watch");
  curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
  $html = curl_exec($ch);
  curl_close($ch);
  $s=str_between($html,"Seasons:","</p");
  $t=explode('href="',$s);
  $c=count($t);
  //$t2=array();
  //print_r ($t);
  $t1=explode('"',$t[$c-1]);
  $min=substr($t1[0], -1, 1);
  $t1=explode('"',$t[1]);
  $max=substr($t1[0], -1, 1);
if ($min<$max) {
$n=0;
for ($i=$c;$i>0;$i--) {
  $t2=explode('"',$t[$i]);
  //echo $t2[0];
  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $t2[0]);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 5.1; rv:31.0) Gecko/20100101 Firefox/31.0');
  curl_setopt($ch, CURLOPT_FOLLOWLOCATION  ,1);
  curl_setopt ($ch, CURLOPT_REFERER, "https://flixanity.watch");
  curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
  $h = curl_exec($ch);
  curl_close($ch);
 $videos = explode('class="episode-title"', $h);
unset($videos[0]);
$videos = array_values($videos);
foreach($videos as $video) {
  $link1="";
  $ep_tit=str_between($video,'title="','"');
  //$ep_tit=str_replace(",","^",$ep_tit);
  $t1=explode('href="',$video);
  $t2=explode('"',$t1[2]);
  $link1=$t2[0];

  preg_match("/S(\d+)\s*E(\d+)/",$ep_tit,$m);
  //print_r ($m);
  $season=$m[1];
  $episod=$m[2];
  $link='flixanity_fs.php?tip=serie&file='.$link1.'&title='.$tit.'|'.$ep_tit.'&image='.$image;
      if ($n == 0) echo "<TR>"."\n\r";
		echo '<TD><font size="4">'.'<a href="'.$link.'" target="_blank">'.$ep_tit.'</a></font>';
		echo '</TD>'."\n\r";
        $n++;
        if ($n > 2) {
         echo '</TR>'."\n\r";
         $n=0;
        }
}  

}
} else {
$n=0;
for ($i=1;$i<$c;$i++) {
  $t2=explode('"',$t[$i]);
  //echo $t2[0];
  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $t2[0]);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 5.1; rv:31.0) Gecko/20100101 Firefox/31.0');
  curl_setopt($ch, CURLOPT_FOLLOWLOCATION  ,1);
  curl_setopt ($ch, CURLOPT_REFERER, "https://flixanity.watch");
  curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
  $h = curl_exec($ch);
  curl_close($ch);
 $videos = explode('class="episode-title"', $h);
unset($videos[0]);
$videos = array_values($videos);
foreach($videos as $video) {
  $link1="";
  $ep_tit=str_between($video,'title="','"');
  //$ep_tit=str_replace(",","^",$ep_tit);
  $t1=explode('href="',$video);
  $t2=explode('"',$t1[2]);
  $link1=$t2[0];

  preg_match("/S(\d+)\s*E(\d+)/",$ep_tit,$m);
  //print_r ($m);
  $season=$m[1];
  $episod=$m[2];
  $link='flixanity_fs.php?tip=serie&file='.$link1.'&title='.$tit.'|'.$ep_tit.'&image='.$image;
      if ($n == 0) echo "<TR>"."\n\r";
		echo '<TD><font size="4">'.'<a href="'.$link.'" target="_blank">'.$ep_tit.'</a></font>';
		echo '</TD>'."\n\r";
        $n++;
        if ($n > 2) {
         echo '</TR>'."\n\r";
         $n=0;
        }
}

}
}
echo '</table>';
?>
<br></body>
</html>

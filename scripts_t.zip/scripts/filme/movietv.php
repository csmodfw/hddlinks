<!DOCTYPE html>
<?php
include ("../common.php");
$page = $_GET["page"];
$tit= $_GET["title"];
$link=$_GET["link"];
//$search=$_GET["search"];
if (isset($_GET['search'])) {
 $search=$_GET["search"];
 $tit=$search;
 $link="http://123movies.to/movie/search/".$search."/";
 $page=1;
}
$tip=$link;
?>
<html><head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate"/>
<meta http-equiv="Pragma" content="no-cache"/>
<meta http-equiv="Expires" content="0"/>
      <title><?php echo $tit; ?></title>
<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.8.0/jquery.min.js"></script>
<script src="../jquery.nicescroll.min.js"></script>
<script type="text/javascript" src="../jquery.fancybox.js?v=2.1.5"></script>
<link rel="stylesheet" type="text/css" href="../jquery.fancybox.css?v=2.1.5" media="screen" />

<script type="text/javascript">
  $(document).ready(function() {
	$("html").niceScroll({styler:"fb",cursorcolor:"#000"});
  });
</script>
<link rel="stylesheet" type="text/css" href="../custom.css" />
<script type="text/javascript">
$(document).ready(function() {
	$(".various").fancybox({
		maxWidth	: 800,
		maxHeight	: 600,
		fitToView	: false,
		width		: '70%',
		height		: '70%',
		autoSize	: false,
		closeClick	: false,
		openEffect	: 'none',
		closeEffect	: 'none'
	});
	$('.fancybox').fancybox();
	$("html").niceScroll({styler:"fb",cursorcolor:"#000"});
});
</script>
</head>
<body>
<H2></H2>
<?php
function str_between($string, $start, $end){
	$string = " ".$string; $ini = strpos($string,$start);
	if ($ini == 0) return ""; $ini += strlen($start); $len = strpos($string,$end,$ini) - $ini;
	return substr($string,$ini,$len);
}
$l22="http://uphero.xpresso.eu/123movies/m/glob.php";
$html22=file_get_contents($l22);
$videos = explode(",", $html22);
//echo $html22;
unset($videos[0]);
$videos = array_values($videos);

foreach($videos as $video) {
  $t1=explode('.',$video);
  $id_srt=trim($t1[0]);
  //echo $id_srt;
  $srt[$id_srt]="exista";
}
$noob_sub=$base_cookie."noob_sub.dat";
if (!file_exists($noob_sub)) {
  $sub="http://uphero.xpresso.eu/srt/list.php";
  $html=file_get_contents($sub);
  //$html=preg_replace("/ \(Awards Screener\)| \(High Bitrate Test\)| \(HDRip\)|/i","",$html);
  $fh = fopen($noob_sub, 'w');
  fwrite($fh, $html);
  fclose($fh);
}
$n=0;
echo '<h2 style="background-color:deepskyblue;color:black">'.$tit.'</H2>';
echo '<table border="1px" width="100%">'."\n\r";
echo '<tr><TD colspan="4" align="right">';
if ($page > 1)
echo '<a href="movietv.php?page='.($page-1)."&link=".$tip."&title=".$tit.'"><font size="4">&nbsp;&lt;&lt;&nbsp;</font></a> | <a href="movietv.php?page='.($page+1)."&link=".$tip."&title=".$tit.'"><font size="4">&nbsp;&gt;&gt;&nbsp;</font></a></TD></TR>';
else
echo '<a href="movietv.php?page='.($page+1)."&link=".$tip."&title=".$tit.'"><font size="4">&nbsp;&gt;&gt;&nbsp;</font></a></TD></TR>';

//$link="http://123movies.to/movie/filter/movie/latest/".$link."/all/all/all/".$page."";
//$link="http://123movies.to/movie/filter/movie/latest/".$link."/all/all/all/all/".$page."";
if ($page > 1) $link=$link."/".$page;
//$link="http://123movies.to/movie/search/element";
  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $link);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 5.1; rv:31.0) Gecko/20100101 Firefox/31.0');
  curl_setopt($ch, CURLOPT_FOLLOWLOCATION  ,1);
  //curl_setopt($ch, CURLOPT_COOKIEJAR, $cookie);
  //curl_setopt($ch, CURLOPT_COOKIEFILE, $cookie);
  $html = curl_exec($ch);
  curl_close($ch);
  //echo $html;
  //$html=str_between($html,'<ul class="list">','<ul class="paging">');
$h=file_get_contents($noob_sub);
$videos = explode('<div class="ml-item">', $html);
unset($videos[0]);
$videos = array_values($videos);
foreach($videos as $video) {
    //if ($n == 0) echo "<TR>"."\n\r";
	$t1 = explode('data-url="http://123movies.to/movie/loadinfo/', $video);
    $t2 = explode('"', $t1[1]);
    $id = $t2[0];

	$t1 = explode('title="', $video);
    $t2 = explode('"', $t1[1]);
    $title=trim($t2[0]);
    
    $title2=str_between($video,'class="mli-eps">','</span');
    //$title2 = preg_replace("/(<\/?)(\w+)([^>]*>)/e","",$title2);
    /*
    $title2 = preg_replace_callback("/(<\/?)(\w+)([^>]*>)/",
	function ($m) {
        return "";
    },$title2);
    */
    $title2=str_replace("<i>","",$title2);
    $title2=str_replace("</i>","",$title2);
    if ($title2) $title=$title." - ".$title2;
	$t1 = explode('<img data-original="', $video);
    $t2 = explode('"', $t1[1]);
    $image = $t2[0];
    $id_t="";
  if (!array_key_exists($id, $srt)) {
     $tt=str_replace("/","\/",$title);
     $tt=str_replace("?","\?'",$title);
     $s="/\|".$tt."\|\d+\|\d+\|\d+/";
     if (preg_match($s,$h,$m)) {
       $t1=explode("|",$m[0]);
       if ($t1[4]== 1) {
         $title1=$title;
         $id_t=$t1[3];
       } else
         $title1=$title." *";
     } else
       $title1=$title." *";
  } else
    $title1=$title;
  if ($n==0) echo '<TR>';
  echo '<td align="center" width="25%"><a href="movietv_link.php?id='.$id.'&id_t='.$id_t.'&title='.$title.'&image='.$image.'" target="_blank"><img src="'.$image.'" width="160px" height="224px"><BR><font size="4">'.$title1.'</font></a>|<a class="various fancybox.ajax" href="imdb1.php?file='.$id.'&image='.$image.'&title='.urlencode($title).'"><b> INFO</b></a></TD>';
  $n++;
  if ($n == 4) {
  echo '</tr>';
  $n=0;
  }
}
echo '<tr><TD colspan="4" align="right">';
if ($page > 1)
echo '<a href="movietv.php?page='.($page-1)."&link=".$tip."&title=".$tit.'"><font size="4">&nbsp;&lt;&lt;&nbsp;</font></a> | <a href="movietv.php?page='.($page+1)."&link=".$tip."&title=".$tit.'"><font size="4">&nbsp;&gt;&gt;&nbsp;</font></a></TD></TR>';
else
echo '<a href="movietv.php?page='.($page+1)."&link=".$tip."&title=".$tit.'"><font size="4">&nbsp;&gt;&gt;&nbsp;</font></a></TD></TR>';
echo "</table>";
?>
<br></body>
</html>

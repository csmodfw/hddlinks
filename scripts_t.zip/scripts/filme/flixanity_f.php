<!DOCTYPE html>
<?php
error_reporting(0);
include ("../common.php");

$title = $_GET["title"];
$page = $_GET["page"];
$file=$_GET["file"];
$tip=$file;
if ($tip=="search")
  $page_title="Cautare: ".urldecode($title);
else
  $page_title=urldecode($title);
?>
<html><head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate"/>
<meta http-equiv="Pragma" content="no-cache"/>
<meta http-equiv="Expires" content="0"/>
      <title><?php echo $page_title; ?></title>
<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.8.0/jquery.min.js"></script>
<script src="../jquery.nicescroll.min.js"></script>

<script type="text/javascript">
  $(document).ready(function() {
	$("html").niceScroll({styler:"fb",cursorcolor:"#000"});
  });
</script>
<link rel="stylesheet" type="text/css" href="../custom.css" />
</head>
<body>
<H2></H2>
<?php
function str_between($string, $start, $end){
	$string = " ".$string; $ini = strpos($string,$start);
	if ($ini == 0) return ""; $ini += strlen($start); $len = strpos($string,$end,$ini) - $ini;
	return substr($string,$ini,$len);
}
include ("../common.php");

$n=0;
echo '<h2 style="background-color:deepskyblue;color:black">'.$page_title.'</H2>';
echo '<table border="1px" width="100%">'."\n\r";
if ($tip=="release") {
echo "<TR>";
if ($page > 1) {
echo '<tr><TD colspan="4" align="right">';
echo '<a href="flixanity_f.php?page='.($page-1).'&file='.$file.'&title='.urlencode($title).'"><font size="4">&nbsp;&lt;&lt;&nbsp;</font></a> | <a href="flixanity_f.php?page='.($page+1).'&file='.$file.'&title='.urlencode($title).'"><font size="4">&nbsp;&gt;&gt;&nbsp;</font></a></TD></TR>';
}else {
echo '<TD>';
//title=star&page=1&file=search
echo '<form action="flixanity_f.php" target="_blank">Cautare film:';
echo '<input type="text" id="title" name="title"><input type="hidden" id="page" name="page" value="1"><input type="hidden" id="file" name="file" value="search"><input type="submit" value="send"></form></TD>';
echo '<TD colspan="3" align="right"><a href="flixanity_f.php?page='.($page+1).'&file='.$file.'&title='.urlencode($title).'"><font size="4">&nbsp;&gt;&gt;&nbsp;</font></a></TD></TR>';
}
}
$v1="0A6ru35yevokjaqbb8";
$s1="52b1b99472b9ce7f990647349ed08f75";
if ($tip=="search")
   $requestLink="https://api.flixanity.watch/api/v1/".$v1;
else
   $requestLink = "https://flixanity.watch/movies/date/".$page."";
/*
https://api.flixanity.watch/api/v1/0A6ru35yevokjaqbb8
q=suits&limit=100&timestamp=1488790946255&verifiedCheck=eCNBuxFGpRmFlWjUJjmjguCJI&set=IzQRciTAgnxYXLCGTapGBQPVy&rt=rPAOhkSTcEzSyJwHWwzwthPWVVmDEpvGNtakLKYPTGncTODCIl&sl=52b1b99472b9ce7f990647349ed08f75

*/
if ($tip=="release") {
  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $requestLink);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 5.1; rv:31.0) Gecko/20100101 Firefox/31.0');
  curl_setopt($ch, CURLOPT_FOLLOWLOCATION  ,1);
  curl_setopt ($ch, CURLOPT_REFERER, "https://flixanity.watch");
  curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
  $html = curl_exec($ch);
  curl_close($ch);
} else {
$tok="";
$post="q=star+trek&limit=100&timestamp=&verifiedCheck=eCNBuxFGpRmFlWjUJjmjguCJI&set=&rt=&sl=";
$post="q=".str_replace(" ","+",$title)."&limit=100&timestamp=&verifiedCheck=".$tok."&set=&sl=".$s1;
//echo $post;
//q=star&limit=100�tamp=&verifiedCheck=&set=&sl=52b1b99472b9ce7f990647349ed08f75
  $head=array('Accept: text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8','Accept-Language: ro-ro,ro;q=0.8,en-us;q=0.6,en-gb;q=0.4,en;q=0.2','Accept-Encoding: deflate','Content-Type: application/x-www-form-urlencoded','Content-Length: '.strlen($post));
  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $requestLink);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 5.1; rv:31.0) Gecko/20100101 Firefox/31.0');
  curl_setopt($ch, CURLOPT_FOLLOWLOCATION  ,1);
  curl_setopt($ch,CURLOPT_HTTPHEADER,$head);
  curl_setopt ($ch, CURLOPT_REFERER, "https://flixanity.watch");
  curl_setopt ($ch, CURLOPT_POST, 1);
  curl_setopt ($ch, CURLOPT_POSTFIELDS, $post);
  curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
  $html = curl_exec($ch);
  curl_close($ch);
  //echo $html;
  $r=json_decode($html,1);
  //print_r ($r);
  //die();
}
//echo $l;
if ($tip=="release") {
 $videos = explode('class="flipBox">', $html);
unset($videos[0]);
$videos = array_values($videos);
foreach($videos as $video) {

  $t1 = explode('href="', $video);
  $t2 = explode('"', $t1[1]);
  $link1 = $t2[0];

  $t1 = explode('alt="', $video);
  $t2 = explode('"', $t1[1]);
  $title11 = $t2[0];
  $id1=$link1;
  //$title=trim(preg_replace("/- filme online subtitrate/i","",$title));
  $t1 = explode('php?src=', $video);
  $t2 = explode('&', $t1[1]);
  $image = $t2[0];
  $image="r.php?file=".$image;
  $image1=$image;
  //$year=trim(str_between($video,'movie-date">','<'));
  //$title=$title11; //." (".$year.")";
  //$id_t=$id1;
  $season="";
  $episod="";
  if ($n==0) echo '<TR>';
  echo '<td align="center" width="25%"><a href="flixanity_fs.php?tip=movie&file='.$link1.'&title='.$title11.'&image='.$image.'" target="_blank"><img src="'.$image.'" width="200px" height="280px"><BR><font size="4">'.$title11.'</font></a></TD>';
  $n++;
  if ($n == 4) {
  echo '</tr>';
  $n=0;
  }
}
} else {
for ($k=0;$k<count($r);$k++) {
  $season="";
  $episod="";
  $link1="https://flixanity.watch".$r[$k]["permalink"];
  $title11=$r[$k]["title"];
  $image="https://flixanity.watch".$r[$k]["image"];
  $image="r.php?file=".$image;
  $image1=$image;
  if (strpos($link1,"/movie/") !==false) {
  if ($n==0) echo '<TR>';
  echo '<td align="center" width="25%"><a href="flixanity_fs.php?tip=movie&file='.$link1.'&title='.$title11.'&image='.$image.'" target="_blank"><img src="'.$image.'" width="200px" height="280px"><BR><font size="4">'.$title11.'</font></a></TD>';
  $n++;
  }
  if ($n == 4) {
  echo '</tr>';
  $n=0;
  }
}
}
if ($tip=="release") {
echo '<tr><TD colspan="4" align="right">';
if ($page > 1)
echo '<a href="flixanity_f.php?page='.($page-1).'&file='.$file.'&title='.urlencode($title).'"><font size="4">&nbsp;&lt;&lt;&nbsp;</font></a> | <a href="flixanity_f.php?page='.($page+1).'&file='.$file.'&title='.urlencode($title).'"><font size="4">&nbsp;&gt;&gt;&nbsp;</font></a></TD></TR>';
else
echo '<a href="flixanity_f.php?page='.($page+1).'&file='.$file.'&title='.urlencode($title).'"><font size="4">&nbsp;&gt;&gt;&nbsp;</font></a></TD></TR>';
}
echo "</table>";
?>
<br></body>
</html>

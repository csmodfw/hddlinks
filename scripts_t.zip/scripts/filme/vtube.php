<!DOCTYPE html>
<?php
include ("../common.php");

$page_title="vtube";
$cookie=$base_cookie."vtube.dat";
$data="";
$page=1;
$l="http://www.vtube.ro/wp-admin/admin-ajax.php";
$post="action=go_portfolio_ajax_load_portfolio&portfolio_id=seriale&current_page=".$page."&current_id=&loaded_ids=".$data."&taxonomy=&term_slug=&post_per_page=500";
//$post="action=go_portfolio_ajax_load_portfolio&portfolio_id=seriale&current_page=4&current_id=&loaded_ids=24247%2C24186%2C25610%2C23870%2C23479%2C21415%2C18506%2C17845%2C17840%2C17856%2C17646%2C17881%2C17849%2C16845%2C16822%2C27368%2C27345%2C27319%2C27115%2C26696%2C26525%2C26434%2C26170%2C25630%2C25587%2C25546%2C25544%2C25476%2C25130%2C25078%2C29028%2C29021%2C29026%2C29023%2C28932%2C28903%2C28851%2C28837%2C28204%2C28050%2C27989%2C27842%2C27540%2C27402%2C27395&taxonomy=&term_slug=&post_per_page=100";
     $ch = curl_init();
     curl_setopt($ch, CURLOPT_URL, $l);
     curl_setopt ($ch, CURLOPT_POST, 1);
     curl_setopt ($ch, CURLOPT_POSTFIELDS, $post);
     curl_setopt ($ch, CURL_REFERER,"http://www.vtube.ro/seriale/");
     curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
     curl_setopt($ch, CURLOPT_FOLLOWLOCATION  ,1);
     $html = curl_exec($ch);
     curl_close($ch);
//echo $h;
//die();
?>
<html><head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate"/>
<meta http-equiv="Pragma" content="no-cache"/>
<meta http-equiv="Expires" content="0"/>
      <title><?php echo $page_title; ?></title>
<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.8.0/jquery.min.js"></script>
<script src="../jquery.nicescroll.min.js"></script>
<script type="text/javascript">
// create the XMLHttpRequest object, according browser
function get_XmlHttp() {
  // create the variable that will contain the instance of the XMLHttpRequest object (initially with null value)
  var xmlHttp = null;
  if(window.XMLHttpRequest) {		// for Forefox, IE7+, Opera, Safari, ...
    xmlHttp = new XMLHttpRequest();
  }
  else if(window.ActiveXObject) {	// for Internet Explorer 5 or 6
    xmlHttp = new ActiveXObject("Microsoft.XMLHTTP");
  }
  return xmlHttp;
}

// sends data to a php file, via POST, and displays the received answer
function ajaxrequest(title, link) {
  var request =  get_XmlHttp();		// call the function for the XMLHttpRequest instance

  // create pairs index=value with data that must be sent to server
  //var the_data = {mod:add,title:title, link:link}; //Array
  var the_data = 'mod=add&title='+ title +'&link='+link;
  var php_file='vtube_add.php';
  request.open("POST", php_file, true);			// set the request

  // adds a header to tell the PHP script to recognize the data as is sent via POST
  request.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
  request.send(the_data);		// calls the send() method with datas as parameter

  // Check request status
  // If the response is received completely, will be transferred to the HTML tag with tagID
  request.onreadystatechange = function() {
    if (request.readyState == 4) {
      alert (request.responseText);
    }
  }
}
</script>
<script type="text/javascript">
  $(document).ready(function() {
	$("html").niceScroll({styler:"fb",cursorcolor:"#000"});
  });
</script>
<link rel="stylesheet" type="text/css" href="../custom.css" />
</head>
<body>
<H2></H2>
<?php
function str_between($string, $start, $end){
	$string = " ".$string; $ini = strpos($string,$start);
	if ($ini == 0) return ""; $ini += strlen($start); $len = strpos($string,$end,$ini) - $ini;
	return substr($string,$ini,$len);
}
$n=0;
echo '<h2 style="background-color:deepskyblue;color:black">'.$page_title.'</H2>';
echo '<table border="1px" width="100%">'."\n\r";
echo '<TR><TD><font size="4">'.'<a href="vtube_fav.php" target="_blank"><b>Favorite</b></a></font></TD>
<TD colspan="3"></td>
</TR>';


$videos = explode('<div class="gw-gopf-post-overlay">', $html);

unset($videos[0]);
$videos = array_values($videos);

foreach($videos as $video) {
	$t1 = explode('href="', $video);
	$t2 = explode('"', $t1[1]);
	$link = $t2[0];

	$t3 = explode('>', $t1[1]);
	$t4 = explode('<', $t3[1]);
	$title=$t4[0];
	
	$t1 = explode('src="', $video);
	$t2 = explode('"', $t1[1]);
	$image = $t2[0];



	if ($title <> ""){
    //$link = 'filme_link.php?file='.$link.','.urlencode($title);
  if ($n==0) echo '<TR>';
  echo '<td align="center" width="25%"><a href="vtube_ep.php?file='.urlencode($link).','.urlencode($title).'" target="_blank"><img src="'.$image.'" width="200px" height="95px"><BR><font size="4">'.$title.'</font></a>';
  echo ' <a onclick="ajaxrequest('."'".$title."', '".$link."')".'"'." style='cursor:pointer;'>".'<font size="4"> (FAV)</font></a></TD>'."\n\r";
  $n++;
  if ($n == 4) {
  echo '</tr>';
  $n=0;
  }
}
}
echo "</table>";
?>
<br></body>
</html>

<!DOCTYPE html>
<html><head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<link rel="stylesheet" type="text/css" href="../custom.css" />
      <meta charset="utf-8">
      <title>seriale</title>
<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.8.0/jquery.min.js"></script>
<script src="../jquery.nicescroll.min.js"></script>

<script type="text/javascript">
  $(document).ready(function() {
	$("html").niceScroll({styler:"fb",cursorcolor:"#000"});
  });
</script>
</head>
<body><h4></h4>
<?php
include ("../common.php");
function str_between($string, $start, $end){
	$string = " ".$string; $ini = strpos($string,$start);
	if ($ini == 0) return ""; $ini += strlen($start); $len = strpos($string,$end,$ini) - $ini;
	return substr($string,$ini,$len);
}
//file=watch-suits-87279&title=Suits&image=http://poster.vumoo.net/300/87279.jpg
$l = $_GET["file"];
$tit=$_GET["title"];
echo '<table border="1" width="100%">'."\n\r";
echo '<TR><td style="color:#000000;background-color:deepskyblue;text-align:center" colspan="3" align="center"><font size="4">'.$tit.'</font></TD></TR>';
$requestLink="http://vumoo.at/videos/play/".$l;
$cookie=$base_cookie."vumo.dat";
//$cookie="D:/";
  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $requestLink);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 5.1; rv:31.0) Gecko/20100101 Firefox/31.0');
  curl_setopt($ch, CURLOPT_FOLLOWLOCATION  ,1);
  curl_setopt ($ch, CURLOPT_REFERER, "http://vumoo.at/");
  curl_setopt($ch, CURLOPT_COOKIEJAR, $cookie);
  curl_setopt($ch, CURLOPT_COOKIEFILE, $cookie);
  //curl_setopt($ch, CURLOPT_HEADER,1);
  $html = curl_exec($ch);
  curl_close($ch);
  $link1="";
 $videos = explode('<li id=season', $html);
unset($videos[0]);
$videos = array_values($videos);
foreach($videos as $video) {
  $ep_tit=str_between($video,'<h2>','</h2>');
  $t1=explode('>',$video);
  preg_match("/(\d+)-(\d+)/",$t1[0],$m);
  //print_r ($m);
  $season=$m[1];
  $episod=$m[2];
  $t1=explode('data-click="',$video);
  $k=count($t1);
  $link_openload="";
  $link_google="";
  for ($i=0;$i<$k;$i++) {
    $t2=explode('"',$t1[$i]);
    $l=trim($t2[0]);
    if (strpos($l,"openload") !== false) {
      $l1=explode("embed/",$l);
      $id1=trim($l1[1]);
    }
    if (strpos($l,"id=") !== false && !$link_google) $id_t=str_between($l,"id=","&");
  }
   $title1=$series_title."|".$season."x".$episod." - ".$ep_tit;
   $title=$season."x".$episod." - ".$ep_tit;


      $link = 'filme_link.php?file='.urlencode($link).",".urlencode($title);
      //$link="fs.php?link=".$link."&title=".urlencode($tit)."&tip=series&tit=".$title;
}  
      if ($n == 0) echo "<TR>"."\n\r";
   if ($title) {
		echo '<TD><font size="4">'.'<a href="'.$link.'" target="_blank">'.$title.'</a></font>';
		echo '</TD>'."\n\r";
        $n++;
        if ($n > 2) {
         echo '</TR>'."\n\r";
         $n=0;
        }
	}
}
echo '</table>';
?>
<br></body>
</html>

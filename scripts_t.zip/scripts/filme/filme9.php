<!DOCTYPE html>

<?php
function str_between($string, $start, $end){
	$string = " ".$string; $ini = strpos($string,$start);
	if ($ini == 0) return ""; $ini += strlen($start); $len = strpos($string,$end,$ini) - $ini;
	return substr($string,$ini,$len);
}
$query = $_GET["file"];
if($query) {
   $queryArr = explode(',', $query);
   $link = urldecode($queryArr[0]);
   $tit = urldecode($queryArr[1]);
}
?>
<html><head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<link rel="stylesheet" type="text/css" href="../custom.css" />
      <meta charset="utf-8">
      <title><?php echo $tit; ?></title>
<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.8.0/jquery.min.js"></script>
<script src="../jquery.nicescroll.min.js"></script>

<script type="text/javascript">
  $(document).ready(function() {
	$("html").niceScroll({styler:"fb",cursorcolor:"#000"});
  });
</script>
</head>
<body><h4></h4>
<?php
echo '<table border="1" width="100%">'."\n\r";
echo '<TR><td style="color:#000000;background-color:deepskyblue;text-align:center" colspan="5" align="center"><font size="4">'.$tit.'</font></TD></TR>';
$html = file_get_contents($link);
$h=str_between($html,'class="episoade">','</ul');
$videos = explode('<li', $h);
unset($videos[0]);
$videos = array_values($videos);
$n=0;
foreach($videos as $video) {
    $t1 = explode('href="', $video);
if ( sizeof($t1)>1 ) {
    $t2 = explode('"', $t1[1]);
    $link = $t2[0];
    $t3 = explode(">",$video);
    $t4 = explode("<",$t3[3]);
    $title = trim($t4[0]);

      $link = 'filme9_link.php?file='.urlencode($link).",".urlencode($title);
}  
      if ($n == 0) echo "<TR>"."\n\r";

		echo '<TD><font size="4">'.'<a href="'.$link.'" target="_blank">'.$title.'</a></font>';
		echo '</TD>'."\n\r";
        $n++;
        if ($n > 4) {
         echo '</TR>'."\n\r";
         $n=0;
        }

}
echo '</table>';
$h1='<br><div class="thumb_serial">'.str_between($html,'<div class="thumb_serial">','<iframe');
echo $h1;
?>
<br></body>
</html>

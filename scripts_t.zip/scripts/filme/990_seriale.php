<!DOCTYPE html>
<html><head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<link rel="stylesheet" type="text/css" href="../custom.css" />
      <meta charset="utf-8">
      <title>seriale</title>
<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.8.0/jquery.min.js"></script>
<script src="../jquery.nicescroll.min.js"></script>

<script type="text/javascript">
  $(document).ready(function() {
	$("html").niceScroll({styler:"fb",cursorcolor:"#000"});
  });
</script>
</head>
<body><h4></h4>
<?php
function str_between($string, $start, $end){
	$string = " ".$string; $ini = strpos($string,$start);
	if ($ini == 0) return ""; $ini += strlen($start); $len = strpos($string,$end,$ini) - $ini;
	return substr($string,$ini,$len);
}
$query = $_GET["file"];
if($query) {
   $queryArr = explode(',', $query);
   $link = $queryArr[0];
   $tit = urldecode($queryArr[1]);
}
echo '<table border="1" width="100%">'."\n\r";
echo '<TR><td style="color:#000000;background-color:deepskyblue;text-align:center" colspan="3" align="center"><font size="4">'.$tit.'</font></TD></TR>';
$html = file_get_contents($link);
$videos = explode("div style='position:relative; float:left; border:0px solid #000;'", $html);
unset($videos[0]);
$videos = array_values($videos);
$n=0;
$title2="";
foreach($videos as $video) {
    $t1 = explode("a href='", $video);
if ( sizeof($t1)>1 ) {
    $t2 = explode("'", $t1[1]);
    $link = $t2[0];
    $t3 = explode(">",$t1[1]);
    $t4 = explode("<",$t3[1]);
    $title1 = trim($t4[0]);
    $link = str_replace("seriale2","player-serial",$link);
    $t1=explode("-",$link);
    $link=$t1[0]."-".$t1[1]."-".$t1[2]."-".$t1[3]."-sfast.html";
    $t1=explode("<div",$video);
    $t2=explode(">",$t1[1]);
    $t3=explode("<",$t2[1]);
    $title2=trim(str_replace(",","",$t3[0]));

    //$link="player-seriale-redirect-serial.php?id=".$id."@idul=".$idul."@v=1";

      $link = "http://www.990.ro/".$link;
      $link=str_replace(",","%2C",$link);
      $title=$title2." - ".$title1;
      $link = 'filme_link.php?file='.urlencode($link).",".urlencode($title);
}  
      if ($n == 0) echo "<TR>"."\n\r";
   if ($title2) {
		echo '<TD><font size="4">'.'<a href="'.$link.'" target="_blank">'.$title.'</a></font>';
		echo '</TD>'."\n\r";
        $n++;
        if ($n > 2) {
         echo '</TR>'."\n\r";
         $n=0;
        }
	}
}
echo '</table>';
?>
<br></body>
</html>

<?php
include ("../common.php");
error_reporting(0);
if (file_exists($base_pass."player.txt")) {
$flash=trim(file_get_contents($base_pass."player.txt"));
} else {
$flash="direct";
}
$f=$base_pass."html5.txt";
$html5 = "DA";
if (file_exists($f)) {
$h=file_get_contents($f);
$t1=explode("|",$h);
$html5=$t1[0];
}
if ((strpos($base_pass,":") === false) && ($html5 == "DA")) $flash="html5";
function decode_entities($text) {
    $text= html_entity_decode($text,ENT_QUOTES,"ISO-8859-1"); #NOTE: UTF-8 does not work!
    $text= preg_replace('/&#(\d+);/me',"chr(\\1)",$text); #decimal notation
    $text= preg_replace('/&#x([a-f0-9]+);/mei',"chr(0x\\1)",$text);  #hex notation
    return $text;
}
function unpack_DivXBrowserPlugin($n_func,$html_cod,$sub=false) {
  $f=explode("return p}",$html_cod);
  $e=explode("'.split",$f[$n_func]);
  $ls=$e[0];
  //echo $ls;
  $a=explode(";",$ls);
  //print_r($a); //for debug only
  $a1=explode("'",$a[count($a)-1]); //char list for replace
  $b1=explode(",",$a1[1]);
  $base_enc=$b1[1];
  //echo $base_enc;
  $w=explode("|",$a1[2]);
  //print_r ($w);
  $ch="0123456789abcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyz";
  $ch="abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
  $ch="0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
  $fl="";
  for ($i=0;$i<count($a)-1;$i++) {
    $fl=$fl.$a[$i];
  }
  $r="";
  $x=strlen($fl);
  for ($i=0;$i<strlen($fl);$i++) {
    if (!preg_match('/[A-Za-z0-9]/',$fl[$i])) { //nu e alfanumeric
       $r=$r.$fl[$i];
    } elseif (($i<$x) && (preg_match('/[A-Za-z0-9]/',$fl[$i])) && (preg_match('/[A-Za-z0-9]/',$fl[$i+1]))) {
       $pos=strpos($ch,$fl[$i+1]);
       $pos=$base_enc*$fl[$i] + $pos;
       if ($w[$pos] <> "")
         $r=$r.$w[$pos];
       else
         $r=$r.$fl[$i].$fl[$i+1];
     } elseif (($i>0) && (preg_match('/[A-Za-z0-9]/',$fl[$i])) && (preg_match('/[A-Za-z0-9]/',$fl[$i-1]))) {
       // nothing
     } else {
       $pos=strpos($ch,$fl[$i]);
        if ($w[$pos] <> "")
          $r=$r.$w[$pos];
        else
          $r=$r.$fl[$i];
     }
  }
  $r=str_replace("\\","",$r);
  //echo $r;
  $ret_val=str_between($r,'param name="src"value="','"');
  if ($ret_val == "")
    $ret_val = str_between($r,"file','","'");
  if ($ret_val == "")
    $ret_val = str_between($r,"playlist=","&");  //nosvideo
  if ($ret_val == "")
    $ret_val=str_between($r,'file:"','"');
  if ($sub==true) {
    $srt=str_between($r,"captions.file','","'");
    $srt = str_replace(" ","%20",$srt);
    $ret_val=$ret_val.",".$srt;
  }
  return $ret_val;
}
//if (file_exists("D:\\Adobe"))
  $filelink = $_GET["file"];
  $link_f =  array();
  $type = "mp4";
  //$filelink=str_replace(",","%2C",$filelink);
  //echo $filelink;
//else
//  $filelink=$_ENV["QUERY_STRING"];
//$filelink = $_GET["file"];
//$filelink="http://www.seriale.filmesubtitrate.info/2011/08/against-wall-sezon-1-ep-1-pilot-serial.html";
$t1=explode(",",$filelink);
$filelink = urldecode($t1[0]);
$filelink = str_replace("*",",",$filelink);
$filelink = str_replace("@","&",$filelink); //seriale.subtitrate.info
$filelink=str_replace("www.seriale.filmesubtitrate.info","www.fsplay.net",$filelink);
$filelink=str_replace("www.filmesubtitrate.info","www.fsplay.net",$filelink);
if (sizeof($t1)>1) $pg = urldecode($t1[1]);
if (!$pg) $pg = "play now...";
//echo $filelink;
function str_between($string, $start, $end){
	$string = " ".$string; $ini = strpos($string,$start);
	if ($ini == 0) return ""; $ini += strlen($start); $len = strpos($string,$end,$ini) - $ini;
	return substr($string,$ini,$len);
}


/**####################################**/
/** Here we start.......**/
$last_link = "";
//if (strpos($filelink,"onlinemoca") === false) {
if (strpos($filelink,"voxfilmeonline1") !== false) {
//echo $filelink;
  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $filelink);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US; rv:1.9.1.2) Gecko/20090729 Firefox/3.5.2 GTB5');
  curl_setopt($ch, CURLOPT_FOLLOWLOCATION  ,1);
  //curl_setopt($ch, CURLOPT_COOKIEFILE, $cookie);
  $html = curl_exec($ch);
  curl_close($ch);
  $a=str_between($html,'"filmcontent">','</script');
  //echo $a;
  $t1=explode("'",$a);
  $k=count($t1);
  $html="";
  //print_r ($t1);
  for ($p=1;$p<$k;$p++) {
   if (strlen($t1[$p]) > 20) $html=$html." ".base64_decode($t1[$p]);
  }
//echo $html;
//die();
}
elseif (strpos($filelink,"filmeonlinesubtitrate") !== false) {

  $post="pageviewnr=1";
  $ch = curl_init($filelink);
  curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US; rv:1.9.1.2) Gecko/20090729 Firefox/3.5.2 GTB5');
  curl_setopt($ch,CURLOPT_REFERER,$filelink);
  //curl_setopt ($ch, CURLOPT_POST, 1);
  //curl_setopt ($ch, CURLOPT_POSTFIELDS, $post);
  //curl_setopt($ch, CURLOPT_FOLLOWLOCATION  ,1);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER  ,1);  // RETURN THE CONTENTS OF THE CALL
  curl_setopt($ch, CURLOPT_HEADER, true);
  $html = curl_exec($ch);
  curl_close ($ch);
  //$l = str_between($html,"Link: <",">;");
  //echo $l;
  //Link: <http://www.filmeonlinesubtitrate.tv/?p=5382>; rel=shortlink
  //$AgetHeaders = @get_headers($filelink);
  //echo $AgetHeaders;
} elseif (strpos($filelink,"990.ro") !== false) {
//echo $filelink;
    $link1 = str_replace("download","",$filelink);
    if (strpos($filelink,"seriale") !== false) {
    //$link1 = str_replace("seriale2","player-serial",$link1);
      $ch = curl_init($link1);
      curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US; rv:1.9.1.2) Gecko/20090729 Firefox/3.5.2 GTB5');
      curl_setopt($ch,CURLOPT_REFERER,$filelink);
      //curl_setopt($ch, CURLOPT_FOLLOWLOCATION  ,1);
      curl_setopt($ch, CURLOPT_RETURNTRANSFER  ,1);  // RETURN THE CONTENTS OF THE CALL
      $html11 = curl_exec($ch);
      curl_close ($ch);
      $t1=explode("player-serial",$html11);
      $t2=explode("'",$t1[1]);
      $link1="http://www.990.ro/player-serial".$t2[0];
//echo $link1;
//http://www.990.ro/player-serial-224607-28309-sfast-26051.html
//http://www.990.ro/player-serial-224607-28309-sfast.html
//http://www.990.ro/player-serial-41594-29941-smastervidcom-169126.html
//http://www.990.ro/player-serial-41594-29941-smastervidcom-169126.html
  }
  //echo $link1;
  $link1=str_replace(urldecode("%0D"),"",$link1);
  $ch = curl_init($link1);
  curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US; rv:1.9.1.2) Gecko/20090729 Firefox/3.5.2 GTB5');
  curl_setopt($ch,CURLOPT_REFERER,$filelink);
  //curl_setopt($ch, CURLOPT_FOLLOWLOCATION  ,1);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER  ,1);  // RETURN THE CONTENTS OF THE CALL
  $html = curl_exec($ch);
  curl_close ($ch);
  //echo $html;
  if (strpos($html,"mastervid") !== false) {
    $t1=explode("mastervid.com/watch",$html);
    $t2=explode("'",$t1[1]);
    $link1="http://mastervid.com/watch".$t2[0];
    //echo $link1;
    $ch = curl_init($link1);
    curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US; rv:1.9.1.2) Gecko/20090729 Firefox/3.5.2 GTB5');
    curl_setopt($ch,CURLOPT_REFERER,$filelink);
    //curl_setopt($ch, CURLOPT_FOLLOWLOCATION  ,1);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER  ,1);  // RETURN THE CONTENTS OF THE CALL
    $html = curl_exec($ch);
    curl_close ($ch);
    //$html=$html." ".$html22;
    //echo $html;
  } //else {
  $link1=str_replace(urldecode("%0D"),"",$link1);
  $filelink=$link1;
  //}
//echo $html;
//die();
  //echo $filelink;
//} elseif (strpos($filelink,"filmedivix") !== false) {
//  $html=file_get_contents($filelink);
//  $filelink="http://filmedivix.com/filmeonline/".str_between($html,"filmedivix.com/filmeonline/",'"');
//  $html = file_get_contents($filelink);
} elseif (strpos($filelink,"http://filmehd.net") !== false) {
  $html1=file_get_contents($filelink);
  $i1=str_between($html1,"js_content.php","'");
  $filelink="http://filmehd.net/js_content.php".$i1;
  $html=file_get_contents($filelink);
  //echo $html;
  $f=explode("return p}",$html);
  $e=explode("'.split",$f[1]);
  $ls=$e[0];
  //echo $ls;
  $t1=explode("||",$ls);
  if ($t1[2])
  $t2=$t1[2];
  else
  $t2=$t1[1];

  if (strpos($t2,"ok") !== false) {
  //echo $t2;
  preg_match_all("/\d+/",$t2,$m);
  //print_r ($m);
  if (strlen($m[0][2])< 14)
  $id=$m[0][2];
  else
  $id=$m[0][3];
  //echo $id;
  $html=' "http://ok.ru/videoembed/'.$id.'" '.$html;
  }
  //echo $t2;
  //$t2=$ls;
  /*
  if (strpos($t2,"ok") !== false) {
  //echo $t2;
  preg_match_all("/\d+/",$t2,$m);
  //print_r ($m);
  if (strlen($m[0][2])< 14)
  $id=$m[0][2];
  else
  $id=$m[0][3];
  //echo $id;
  $html=' "http://ok.ru/videoembed/'.$id.'" '.$html; //.' "http://ok.ru/videoembed1/'.$id.'" ';
  //echo $html;
  }
  */
  //die();
  //$l2=unpack_DivXBrowserPlugin(1,$html,false);
  //echo $l2;
  //die();
} elseif (strpos($filelink,"fsplay.net") !== false) {
  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $filelink);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch,CURLOPT_REFERER,"http://www.fsplay.net");
  curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 5.1; rv:14.0) Gecko/20100101 Firefox/14.0.1');
  curl_setopt($ch, CURLOPT_FOLLOWLOCATION  ,1);
  $html=curl_exec($ch);
  curl_close($ch);
  $html= decode_entities($html);
  //echo $html;
} elseif (strpos($filelink,"topvideohd.com") !== false) {
  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $filelink);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch,CURLOPT_REFERER,"http://www.topvideohd.com/");
  curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 5.1; rv:14.0) Gecko/20100101 Firefox/14.0.1');
  //curl_setopt($ch, CURLOPT_FOLLOWLOCATION  ,1);
  $html=curl_exec($ch);
  curl_close($ch);
  $html= decode_entities($html);
  //echo $html;
} else {
//echo $filelink;
$filelink=str_replace(" ","%20",$filelink);
  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $filelink);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  //curl_setopt($ch,CURLOPT_REFERER,"http://www.topvideohd.com/");
  curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 5.1; rv:14.0) Gecko/20100101 Firefox/14.0.1');
  curl_setopt($ch, CURLOPT_FOLLOWLOCATION  ,1);
  curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
  $html=curl_exec($ch);
  curl_close($ch);
  if (strpos($filelink,"vezi-online.net") !== false) {
    //$h1=str_between($html,'class="player">','</div');
    $h1=explode('class="player">',$html);
    $t1=explode("document.write(unescape('",$h1[1]);
    $t2=explode("'",$t1[1]);
    if ($t2[0]) $html=urldecode($t2[0]);
  }
}
//echo $html;
//http://api.vk.com/method/video.getEmbed?oid=-73370064&video_id=168863156&embed_hash=6f4b9a671f2954bd&callback=responseWork
//168863156
$mysrt=str_between($html,"captions.file=","&");
if(!$mysrt)
 $mysrt=str_between($html,'captions-2": { file: "','"');
$mysrt = str_replace(" ","%20",$mysrt);
if (strpos($mysrt,"http") === false && $mysrt) {
  $t=explode("/",$filelink);
  $mysrt="http://".$t[2].$mysrt;
}
//echo $html;
//echo $mysrt;
/**################ All links ################**/
//echo $html;
//die();
$html=str_replace("https","http",$html);
if(preg_match_all("/(\/\/.*?)(\"|\')+/i",$html,$matches)) {
$links=$matches[1];
//print_r ($links);
}
$s="/adf\.ly|vidxden\.c|divxden\.c|vidbux\.c|movreel\.c|videoweed\.(c|e)|novamov\.(c|e)|vk\.com";
$s=$s."|movshare\.net|youtube\.com|youtube-nocookie\.com|flvz\.com|rapidmov\.net|putlocker\.com|mixturevideo\.com|played\.to|";
$s=$s."peteava\.ro\/embed|peteava\.ro\/id|content\.peteava\.ro|divxstage\.net|divxstage\.eu";
$s=$s."|vimeo\.com|googleplayer\.swf|filebox\.ro\/get_video|vkontakte\.ru|megavideo\.com|videobam\.com";
$s=$s."|fastupload|video\.rol\.ro|zetshare\.net\/embed|ufliq\.com|stagero\.eu|ovfile\.com|videofox\.net";
$s=$s."|trilulilu|proplayer\/playlist-controller.php|viki\.com|modovideo\.com|roshare\.info|ishared\.eu|";
$s=$s."filebox\.com|glumbouploads\.com|uploadc\.com|sharefiles4u\.com|zixshare\.com|uploadboost\.com";
$s=$s."|nowvideo\.eu|nowvideo\.co|vreer\.com|180upload\.com|dailymotion\.com|nosvideo\.com|vidbull\.com|purevid\.com|videobam\.com|streamcloud\.eu|donevideo\.com|upafile\.com|docs\.google|mail\.ru|superweb\.rol|moviki\.ru|entervideos\.com/i";
$s="/fastupload|superweb|vkontakte\.ru|vk\.com|mail\.ru|kodik\.biz|videomega\.tv|playreplay\.net|ok\.ru|moviki\.ru|realvid\.net|streamin\.to|vidbull\.com|roshare|rosharing|up2stream\.com|openload\.co|allvid\.ch|mastervid\.com|thevideo\.me|goo\.gl|youjizz\.com|flashservice\.xvideos\.com|xhamster\.com|slutload\.com|rapidvideo\.com|megavideo\.pro|hqq\.tv/";
//|roshare|rosharing
for ($i=0;$i<count($links);$i++) {
  if (strpos($links[$i],"http") !== false) {
    $t1=explode("http:",$links[$i]);
   if (sizeof ($t1) > 1 ) {
    $p=count($t1);
    $cur_link="http:".$t1[$p-1];
	}
  } else {
  $cur_link="http:".$links[$i];
  }
  if (strpos($links[$i],"goo.gl") !== false) {
  $l="https:".$links[$i];
  //echo $l;
  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $l);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 5.1; rv:22.0) Gecko/20100101 Firefox/22.0');
  curl_setopt($ch, CURLOPT_FOLLOWLOCATION  ,1);
  curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
  curl_setopt($ch, CURLOPT_HEADER,1);
  curl_setopt($ch, CURLOPT_NOBODY,1);
  $h2 = curl_exec($ch);
  curl_close($ch);
  //echo $h2;
  $t1=explode("Location:",$h2);
  $t2=explode("\n",$t1[1]);
  $cur_link=trim($t2[0]);

  }
  //echo $cur_link;
  $t1=explode(" ",$cur_link);     //vezi-online
  $cur_link=$t1[0];
  $t1=explode("&stretching",$cur_link);    //vezi-online
  $cur_link=$t1[0];
  if (strpos($cur_link,"entervideos.com/vidembed") !==false) {
  $t1=explode("&",$cur_link);    //
  $cur_link=$t1[0];
  }
  $cur_link=str_replace(urldecode("%0D"),"",$cur_link);
  //echo $cur_link."<BR>";
  if (preg_match($s,$cur_link)) {
    if ($cur_link <> $last_link) {
     $t1=explode("proxy.link=",$cur_link); //vezi-filme
   if (sizeof ($t1) > 1 ) {
     if ($t1[1]) {
       $t2=explode("&",$t1[1]);
       $cur_link=trim($t2[0]);
     }
   }
      if (!preg_match("/top\.mail\.ru|facebook|twitter|player\.swf|img\.youtube|youtube\.com\/user|radioarad|\.jpg|\.png|\.gif|jq\/(js|css)|fsplay\.net\?s|changejplayer\.js|validateemb\.php/i",$cur_link)) {
        $t1=explode("proxy.link=",$cur_link); //filmeonline.org
      if (sizeof ($t1) > 1 ) {
        if ($t1[1] <> "") {
        $cur_link=$t1[1];
        }
      }
        if (strpos($cur_link,"captions.file") !== false) {  //http://vezi-online.net
        $a=explode("&captions.file",$cur_link);
        $mysrt=str_between($cur_link,"captions.file=","&");
        if (strpos($mysrt,"http") === false && $mysrt) {
         $t=explode("/",$filelink);
         $mysrt="http://".$t[2].$mysrt;
        }
        $cur_link=$a[0];
        }

        if (strpos($cur_link,"adf.ly") !==false) { //onlinemoca
           $a1=explode($cur_link,$html);
           $a2=explode('server/',$a1[1]);
           $a3=explode('.',$a2[1]);
           $server=$a3[0];
        } else {
          $server = str_between($cur_link,"http://","/");
          //echo "aasasasas";
          if (!$server) $server = str_between($cur_link,"https://","/");
        }
        if (!$server) $server = str_between($cur_link,"https://","/");
        $last_link=$cur_link;
        if (strpos($cur_link,"google") !==false) {
          $t1=explode("docid=",$cur_link);
          $t2=explode("&",$t1[1]);
          $docid=$t2[0];
          $mysrt_google="http://video.google.com/videotranscript?frame=c&docid=".$docid."&hl=ro&type=track&name=ro&lang=ro";
        }
        if (strpos($cur_link,"viki.com") !==false) {
          preg_match('/(viki\.com\/player\/medias\/)([\w\-]+)/', $cur_link, $match);
          $viki_id = $match[2];
        }
        $link_f[]=$cur_link;
      }
    }
  //echo $cur_link;
  }
}
/**################ special links ##############**/

/**################ flash... mediafile,file.....############**/

//http://www.filmesubtitrate.info/2010/06/10-things-i-hate-about-you-sez1-ep1.html
//http://www.seriale.filmesubtitrate.info/2010/06/10-things-i-hate-about-you-sez1-ep1.html
//www.seriale.filmesubtitrate.info
if (strpos($filelink,"fsplay.net") !== false) {
///playerfs/plmfilmesub.php?lk=a8u25iq4cach
///playerfs/plmnowvideo.php?lk=2rzm75lkxawps
//peteava - http://www.seriale.filmesubtitrate.info/playerfs/peteava.php?lk=503993
//videoweed - http://www.seriale.filmesubtitrate.info/playerfs/plmweed.php?lk=gdubcouik7ogu&km=A.Seriale/Alcatraz%20S01E01
//novamov - http://www.seriale.filmesubtitrate.info/playerfs/plmnova.php?lk=f6uol0yy3s2sp&km=A.Seriale/Alcatraz%20S01E01
//vidbux - http://www.seriale.filmesubtitrate.info/playerfs/plmvidb.php?lk=e2tjkd08bok4&km=A.Seriale/Alcatraz%20S01E01
//vidxden - http://www.seriale.filmesubtitrate.info/playerfs/plmvidx.php?lk=1798z8fap6g3/Touch_S01E01.flv.html
///playerfs/plmvk.php?lk=106177506&id=163445800&hash=7fa53905d105372e&hd=1
$title = "";
$f = "/usr/local/bin/home_menu";
$videos = explode('player5', $html);
unset($videos[0]);
$videos = array_values($videos);
foreach($videos as $video) {
 $t1=explode('"',$video);
 $link="http://www.fsplay.net/player5".$t1[0];

 if (strpos($link,"plmfilmesub") !== false) $title="roshare";
 if (strpos($link,"peteava") !== false) $title="peteava";
 if (strpos($link,"plmweed") !== false) $title="videoweed";
 if (strpos($link,"plmnova") !== false) $title="novamov";
 if (strpos($link,"plmvidb") !== false) $title="vidbux";
 if (strpos($link,"plmvidx") !== false) $title="vidxden";
 if (strpos($link,"plmnowvideo") !== false) $title="nowvideo";
 if (strpos($link,"plmvk") !== false) $title="vk";
 //$link="link.php?file=".urlencode($link);
 if ($title <> "") {
     $link_f[]=$link;
     //echo '<font size="4"><a href="'.$link.'" target="_blank">'.$title.'</a></font>'."<BR>";
 }
}
}
$link_f=array_unique($link_f);
$n= count($link_f);
for ($k=0; $k<$n;$k++) {
//if (strpos($link_f[$k],"videomega") && strpos($base_pass,":") !== false) $link_f[]=$link_f[$k]."&vlc=1";
//if (strpos($link_f[$k],"ok.ru") !== false) $link_f[]=$link_f[$k]."&ok=1";
}
$n= count($link_f);
//echo $n;
if ($n==1 && strpos($link_f[0],"openload") === false) {

$dir_actual = "http".(($_SERVER['SERVER_PORT']==443) ? "s://" : "://") . $_SERVER['HTTP_HOST'] . $_SERVER['SCRIPT_NAME'];
$dir_actual = str_replace("filme_link.php","",$dir_actual);
//echo $link_f[0];
//die();
$movie=file_get_contents($dir_actual."link.php?file=".urlencode($link_f[0]));
$movie_file=substr(strrchr($movie, "/"), 1);
if ($flash == "direct") {
//echo $link_f[0];
//die();
if (strpos($link_f[0],"videomega") !== false) {
   $cookie=$base_cookie."video.dat";
   $lines = file($cookie);
   foreach ($lines as $line_num => $line) {
      //echo $line;
     if (strpos($line,"cfduid") !==false) {
      $t1=explode("cfduid",$line);
      $c=trim($t1[1]);
      break;
     }
   }
   $cookie_videomega=$c;
//header('Referer: http://videomega.tv/vjs/video-js.swf');
//header('Cookie: '.$cookie_ref);
//header('Cookie: __cfduid='.$cookie_videomega.';  _ga=GA1.2.12345678.12345678; _gat=1');
header('Content-Disposition: attachment; filename="'.$movie_file.'"');
header("Location: $movie");
} elseif (strpos($link_f[0],"fsplay") !== false || strpos($link_f[0],"rosha") !== false) {
$dir_actual = "http".(($_SERVER['SERVER_PORT']==443) ? "s://" : "://") . $_SERVER['HTTP_HOST'] . $_SERVER['SCRIPT_NAME'];
$dir_actual = str_replace("filme_link.php","",$dir_actual);
//echo $link_f[0];
//die();
$ex=$dir_actual."out.mp4";
echo '
<html><head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">

      <meta charset="utf-8">
      <title>Copiaza link pentru MX Player</title>
   	  <link rel="stylesheet" type="text/css" href="../custom.css" />
     <script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.8.0/jquery.min.js"></script>
     <script src="../jquery.nicescroll.min.js"></script>
      <script type="text/javascript" src="../jquery.fancybox.js?v=2.1.5"></script>
      <link rel="stylesheet" type="text/css" href="../jquery.fancybox.css?v=2.1.5" media="screen" />

<script type="text/javascript">
$(document).ready(function() {
    $("input:text")
        .focus(function () { $(this).select(); } )
        .mouseup(function (e) {e.preventDefault(); });
});
</script>
<script type="text/javascript">
$(document).ready(function() {
	$(".various").fancybox({
		maxWidth	: 800,
		maxHeight	: 600,
		fitToView	: false,
		width		: "70%",
		height		: "70%",
		autoSize	: false,
		closeClick	: false,
		openEffect	: "none",
		closeEffect	: "none"
	});
	$(".fancybox").fancybox();
	$("html").niceScroll({styler:"fb",cursorcolor:"#000"});
});
</script>
</head>
<body>';
echo '<h2 style="background-color:deepskyblue;color:black">'.$pg."</H2>";
echo "Copiaza text:<BR>";
echo $movie."<BR><BR>";
echo '<font size="5">';
echo '<input type="text" id="txtfld" style="width:400px" value = "'.$movie.'" /> Copiaza Ctrl+C<BR>';
echo '<a href="'.$movie.'">Apasare lunga - Copiaza adresa URL</a><BR>';
echo '<a href="'.$ex.'">Deschide MX Player apoi Redare, deschide flux retea - Ctrl+N,Ctrl+V</a>';
echo '</font></body></html>';
} elseif (strpos($link_f[0],"playreplay") === false && strpos($link_f[0],"mail.ru") === false) {
$movie_file=substr(strrchr($movie, "/"), 1);
header('Content-type: application/vnd.apple.mpegURL');
//header('Content-Type: application/octet-stream');
header('Content-Disposition: attachment; filename="'.$movie_file.'"');
header("Location: $movie");
} else {
header("Location: $link_f[0]");
}
} elseif ($flash !="direct" && strpos($link_f[0],"youtube") === false) {
if (strpos($link_f[0],"playreplay") === false && strpos($link_f[0],"mail.ru") === false) {
/*
if (strpos($movie,"fastupload") !== false)
  $startparam="ec_seek";
else
*/
  $startparam="start";
  //$startparam="ec_seek";
if (strpos($movie,".flv") !== false) $type = "flv";
//$movie=str_replace("(",urlencode("("),$movie);
//$movie=str_replace(")",urlencode(")"),$movie);
//$movie=str_replace($movie_file,"video.mp4",$movie);

echo '
<!doctype html>
<HTML>
<HEAD>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>'.$pg.'</title>
<style type="text/css">
body {
margin: 0px auto;
overflow:hidden;
}
body {background-color:#000000;}
</style>
<script src="//code.jquery.com/jquery-1.11.0.min.js"></script>
';
if (strpos($link_f[0],"allvid.ch") === false) {
echo
$jwv
;
}else {
echo
"<script type='text/javascript' src='http://allvid.ch/player7/jwplayer.js'></script>";
echo
'<script type="text/javascript">jwplayer.key="VFMUJWdLhgBYl+4ws2V2f/WPbjYD2aYHGVqbMAbP5tQ=";</script>';
}
echo '
</HEAD>
<BODY>
<div id="container"></div>
<script type="text/javascript">
jwplayer("container").setup({
';
if ((strpos($movie,"fastupload") !== false) && $flash != "html5" ) {
echo '"flashplayer": "http://superweb.rol.ro/video/player6/jwplayer.flash.swf",';
if (strpos($base_pass,":") !== false) echo '"primary": "flash",';
}
/*if (strpos($movie,"up2stream") !== false) {
echo '"flashplayer": "http://up2stream.com/vjs/video-js.swf",';
//$autostart="true";      //http://videomega.tv/player/jwplayer.flash.swf
if (strpos($base_pass,":") !== false) echo '"primary": "html5",';
}*/
if (strpos($movie,"roshare") !== false) {
echo '"flashplayer": "http://roshare.info/jh5/jwplayer.flash.swf",';
if (strpos($base_pass,":") !== false) echo '"primary": "flash",';
}
if (strpos($link_f[0],"allvid.ch") !== false) {
$skin='{
    "name": "beelden",
    "active": "#00bfff",
    "inactive": "#b6b6b6",
    "background": "#282828"
}';
}
//$movie=str_replace(" ","%20",$movie);
echo '
"playlist": [{
"sources": [{"file": "'.$movie.'", "type": "'.$type.'"}],
"tracks": [{"file": "../subs/subtitrare.srt", "default": true}]
}],
    captions: {
        color: "#FFFFFF",
        fontSize: 20,
        backgroundOpacity: 0
    },
"height": $(document).height(),
"width": $(document).width(),
"skin": '.$skin.',
"startparam": "'.$startparam.'",
"fallback": false,
"wmode": "direct",
"stagevideo": true
});

</script>
</BODY>
</HTML>
';
} else {
header("Location: $link_f[0]");
}
} elseif ($flash !="direct" && strpos($link_f[0],"youtube1") !== false) {
preg_match('/youtube\.com\/(v\/|watch\?v=|embed\/)([\w\-]+)/', $link_f[0], $match);
  $id = $match[2];
$movie="//www.youtube.com/embed/".$id;
echo '
<!doctype html>
<HTML>
<HEAD>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>'.$pg.'</title>
</head>
<body style="margin:0px;padding:0px;overflow:hidden">
    <iframe src="'.$movie.'?rel=0" frameborder="0" style="overflow:hidden;overflow-x:hidden;overflow-y:hidden;height:100%;width:100%;position:absolute;top:0px;left:0px;right:0px;bottom:0px" height="100%" width="100%"></iframe>
</body>
</html>
';
}
} elseif ($n>1 || strpos($link_f[0],"openload") !== false) {
/*
for ($k=0; $k<$n;$k++) {
  if (strpos($link_f[$k],"mail.ru") !== false) {
  echo '<iframe src="'.$link_f[$k].'" width="1px" height="1px" frameborder="0"></iframe>';
  break;
  }
}
*/
echo '
<html><head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">

      <meta charset="utf-8">
      <title>Alege varianta</title>
   	  <link rel="stylesheet" type="text/css" href="../custom.css" />
     <script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.8.0/jquery.min.js"></script>
     <script src="../jquery.nicescroll.min.js"></script>
      <script type="text/javascript" src="../jquery.fancybox.js?v=2.1.5"></script>
      <link rel="stylesheet" type="text/css" href="../jquery.fancybox.css?v=2.1.5" media="screen" />


<script type="text/javascript">
$(document).ready(function() {
	$(".various").fancybox({
		maxWidth	: 800,
		maxHeight	: 600,
		fitToView	: false,
		width		: "70%",
		height		: "70%",
		autoSize	: false,
		closeClick	: false,
		openEffect	: "none",
		closeEffect	: "none"
	});
	$(".fancybox").fancybox();
	$("html").niceScroll({styler:"fb",cursorcolor:"#000"});
});
</script>
</head>
<body>';
echo '<h2 style="background-color:deepskyblue;color:black">'.$pg."</H2>";
echo "<H2>Alegeti una din variantele de mai jos (sau una din parti)</H2>";
for ($k=0; $k<$n;$k++) {
 if (!preg_match("/player5/",$link_f[$k])) {
  $server= str_between($link_f[$k],"http://","/");
  if (!$server) $server = str_between($link_f[$k],"https://","/");
  if (strpos($link_f[$k],"vlc=1") !== false) $server=$server." - vlc";
  if (strpos($link_f[$k],"ok=1") !== false) $server=$server." - direct";
 } else {
  if (strpos($link_f[$k],"plmvk") !== false) $server="vk";
  if (strpos($link_f[$k],"plmfilmesub") !== false) $server="roshare";
 }
if (strpos($filelink,"blogspot.ro") !== false && (strpos($filelink,"sezonul") !== false) && $n>5) $server=$server." - Episodul ".($k+1);
 if (strpos($link_f[$k],"playreplay") === false && strpos($link_f[$k],"mail.ru") === false) {
// if (strpos($link_f[$k],"openload") === false)
 echo '<a href="link1.php?file='.urlencode($link_f[$k]).','.urlencode($pg).'" target="_blank"><font size="6">'.$server.'</font></a><BR>';
// else
// echo '<a href="link1.php?file='.urlencode($link_f[$k]).','.urlencode($pg).'" target="_blank"><font size="6">'.$server.' </font></a><a class="various fancybox.ajax" href="captcha.php?file='.$link_f[$k].'"><font size="6">(verifica captcha)</font></a><a href="'.$link_f[$k].'" target="_blank"><font size="6"> sau direct</font></a><BR>';
 } else {
 if (strpos($link_f[$k],"openload") === false)
 echo '<a href="'.$link_f[$k].'" target="_blank"><font size="6">'.$server.'</font></a><BR>';
 else
 {
 $link_f[$k]=str_replace("openload.co/f/","openload.co/embed/",$link_f[$k]);
 echo '<a href="'.$link_f[$k].'" target="_blank"><font size="6">'.$server.' </font></a><a class="various fancybox.ajax" href="captcha.php?file='.$link_f[$k].'"><font size="6">(verifica captcha)</font></a><BR>';
 }
 }
 }
echo '<br></body>
</html>';
} else {
echo '
<html><head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">

      <meta charset="utf-8">
      <title>Alege varianta</title>
   	  <link rel="stylesheet" type="text/css" href="../custom.css" />
</head>
<body>';
echo '<h2 style="background-color:deepskyblue;color:black">'.$pg."</H2>";
echo "<H2>Nu s-au gasit servere!?</H2>";
echo '<br></body>
</html>';
}
?>

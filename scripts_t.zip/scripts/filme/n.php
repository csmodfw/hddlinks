<?php
include ("../common.php");
$noob=file_get_contents($base_cookie."n.dat");
$cookie=$base_cookie."noob.dat";
$l=$noob."/year.php";
  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $l);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US; rv:1.9.1.2) Gecko/20090729 Firefox/3.5.2 GTB5');
  //curl_setopt($ch, CURLOPT_FOLLOWLOCATION  ,1);
  curl_setopt($ch,CURLOPT_REFERER,$l);
  curl_setopt($ch, CURLOPT_COOKIEFILE, $cookie);
  //curl_setopt($ch, CURLOPT_FILE, $fp);
  //curl_setopt($ch, CURLOPT_HTTPHEADER, array('Transfer-Encoding: chunked'));
  //curl_setopt($ch, CURLOPT_RANGE, '0-10000000000');
  //curl_setopt($ch,CURLOPT_HEADER,1);
  //curl_setopt($ch, CURLOPT_VERBOSE, 1);
  //curl_setopt($ch, CURLOPT_HTTPHEADER,array("Expect:"));
  curl_setopt($ch, CURLOPT_BINARYTRANSFER, true);
  curl_setopt($ch, CURLOPT_FRESH_CONNECT, 1);
  curl_setopt($ch, CURLOPT_FORBID_REUSE, 1);
  $html = curl_exec($ch);
if(!curl_errno($ch))
{
 $info = curl_getinfo($ch);
 print_r ($info);
}
  curl_close($ch);
  
echo $html;
?>

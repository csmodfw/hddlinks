<!DOCTYPE html>
<html><head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate"/>
<meta http-equiv="Pragma" content="no-cache"/>
<meta http-equiv="Expires" content="0"/>
      <title>Streamtorrent.tv</title>
<script src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
<link rel="stylesheet" type="text/css" href="../custom.css" />
</head>
<body>

<H2></H2>
<?php
function str_between($string, $start, $end){
	$string = " ".$string; $ini = strpos($string,$start);
	if ($ini == 0) return ""; $ini += strlen($start); $len = strpos($string,$end,$ini) - $ini;
	return substr($string,$ini,$len);
}
include ("../common.php");
//$link="movietv.php?page=1&link=".$link."&title=".$title."";
echo '<table border="1px" width="100%">'."\n\r";
echo '<TR><td style="color:black;background-color:deepskyblue;text-align:center" colspan="3"><font size="3"><b>Streamtorrent.tv</b></font></TD></TR>';
echo '<TR><TD><font size="4">'.'<a href="torba.php?page=1&link=&title=Recente" target="_blank"><b>Recente</b></a></font></TD>
<TD colspan="2"><font size="4"><form action="torba.php" target="_blank">Cautare film:  <input type="text" id="search" name="search"><input type="submit" value="send"></form></font></td>
</TR>';
//http://123movies.to/movie/filter/all/latest/1/all/all/all
$l="https://torba.se/";
  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $l);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 5.1; rv:31.0) Gecko/20100101 Firefox/31.0');
  curl_setopt($ch, CURLOPT_FOLLOWLOCATION  ,1);
  curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
  //curl_setopt($ch, CURLOPT_COOKIEJAR, $cookie);
  //curl_setopt($ch, CURLOPT_COOKIEFILE, $cookie);
  $h = curl_exec($ch);
  curl_close($ch);
//echo $h;
//http://123movies.to/movie/filter/movie/latest/1-2/all/all/all/all
$n=0;
$h1=str_between($h,'data-parentid="dropdown-id-genre">All genres</a>','<div class="header-filter-sorting-item ng-scope field-year">');
$videos = explode('<li', $h1);
unset($videos[0]);
$videos = array_values($videos);
foreach($videos as $video) {
  $t1=explode('<a data-text="',$video);
  $t2=explode('"',$t1[1]);
  $link=$t2[0];
  $title=$t2[0];
  //http://torba.se/search?order=recent&genre=Romance&_pjax=%23films-pjax-container&page=2&per-page=
  $link="torba.php?page=1&link=".$link."&title=".$title."";

	if ($n == 0) echo "<TR>"."\n\r";
	echo '<TD style="text-align:center"><font size="4">'.'<a href="'.$link.'" target="_blank">'.$title.'</a></font></TD>';
    $n++;
    if ($n > 2) {
     echo '</TR>'."\n\r";
     $n=0;
    }
 }

 if ($n<3) echo "</TR>"."\n\r";
 echo '</table>';

?>
<p>Contribuiti cu subtitrari <a href="http://uphero.xpresso.eu/torba/torba_main.php" target="_blank"><b>aici</b>.</a></p>

</BODY>
</HTML>

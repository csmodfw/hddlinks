<?php
include ("../common.php");
function str_between($string, $start, $end){
	$string = " ".$string; $ini = strpos($string,$start);
	if ($ini == 0) return ""; $ini += strlen($start); $len = strpos($string,$end,$ini) - $ini;
	return substr($string,$ini,$len);
}

if (file_exists($base_pass."player.txt")) {
$flash=trim(file_get_contents($base_pass."player.txt"));
} else {
$flash="direct";
}
$link = $_GET["file"];
$title=$_GET["title"];
$year=$_GET["year"];
$image=$_GET["image"];
$id=$_GET["id"];
$id_t=$_GET["id_t"];
$n=0;


$ln="https://torba.se".$link."";

$ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $ln);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 5.1; rv:14.0) Gecko/20100101 Firefox/14.0.1');
  curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
  $html=curl_exec($ch);
  curl_close($ch);
//echo $html;
$view=str_between($html,'view.html#','"');
$embed="https://streamtorrent.tv/embed/".$view."";

  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $embed);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 5.1; rv:14.0) Gecko/20100101 Firefox/14.0.1');
  curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
  $html=curl_exec($ch);
  curl_close($ch);
//echo $html;
//die();
$t1 = explode('player.setup({', $html);
$m1=str_between($t1[1],'file: "/api','"');
$movie="https://streamtorrent.tv/api".$m1."";
  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $movie);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 5.1; rv:14.0) Gecko/20100101 Firefox/14.0.1');
  curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
  $html=curl_exec($ch);
  curl_close($ch);
  $t1=explode("\n",$html);
  //print_r ($t1);
  //die();
  $k=count($t1);
  //echo $k;
  //die();
  if ($k>10) {
  $out=$t1[0]."\n".$t1[1]."\n".$t1[6]."\n"."720p.m3u8"."\n".$t1[9]."\n"."1080p.m3u8"."\n";
  } else if ($k>7) {
  $out=$t1[0]."\n".$t1[1]."\n".$t1[6]."\n"."720p.m3u8"."\n";
  } else {
  $out=$t1[0]."\n".$t1[1]."\n".$t1[3]."\n"."360p.m3u8"."\n";
  }
  $movie_file=$base_sub."play.m3u8";
   $fh = fopen($movie_file, 'w');
   fwrite($fh, $out, strlen($out));
   fclose($fh);
if ($k>10) {
  $l=$t1[10];
  $f="1080p.m3u8";
  $movie_file=$base_sub.$f;
  $l1="https://streamtorrent.tv".$l;
  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $l1);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 5.1; rv:14.0) Gecko/20100101 Firefox/14.0.1');
  curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
  $html=curl_exec($ch);
  curl_close($ch);
  $fh = fopen($movie_file, 'w');
  fwrite($fh, $html, strlen($html));
  fclose($fh);
  
  $l=$t1[7];
  $f="720p.m3u8";
  $movie_file=$base_sub.$f;
  $l1="https://streamtorrent.tv".$l;
  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $l1);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 5.1; rv:14.0) Gecko/20100101 Firefox/14.0.1');
  curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
  $html=curl_exec($ch);
  curl_close($ch);
  $fh = fopen($movie_file, 'w');
  fwrite($fh, $html, strlen($html));
  fclose($fh);
} else if ($k>7) {
  $l=$t1[7];
  $f="720p.m3u8";
  $movie_file=$base_sub.$f;
  $l1="https://streamtorrent.tv".$l;
  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $l1);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 5.1; rv:14.0) Gecko/20100101 Firefox/14.0.1');
  curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
  $html=curl_exec($ch);
  curl_close($ch);
  $fh = fopen($movie_file, 'w');
  fwrite($fh, $html, strlen($html));
  fclose($fh);
} else {
  $l=$t1[4];
  $f="360p.m3u8";
  $movie_file=$base_sub.$f;
  $l1="https://streamtorrent.tv".$l;
  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $l1);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 5.1; rv:14.0) Gecko/20100101 Firefox/14.0.1');
  curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
  $html=curl_exec($ch);
  curl_close($ch);
  $fh = fopen($movie_file, 'w');
  fwrite($fh, $html, strlen($html));
  fclose($fh);
}
//die();
//$movie="https://streamtorrent.tv/api/torrent/5699a2f69c7c5bf6652b985c/5699a305317f06535bf224f4/720p.m3u8";
//$movie="http://213.163.71.35/20160015/b85f9acfd6d9d151f6faae50c3b48b465c2018fa/b3781ca8ed38b995f2549c475f4523fa/audio/1.m3u8";
//$movie="http://213.163.72.135/20160015/b85f9acfd6d9d151f6faae50c3b48b465c2018fa/b3781ca8ed38b995f2549c475f4523fa/720p.m3u8";

//$srt_name=str_replace(".m3u8","",substr(strrchr($movie, "/"), 1));
//https://streamtorrent.tv/api/torrent/569def5af2e9e52a58c4dab7.json
$srt_name="play";

$movie="play.m3u8";
$movie="../subs/play.m3u8";
//$movie="https://streamtorrent.tv/api/torrent/569def5af2e9e52a58c4dab7/569def67ceb16ee27c3a3b49/720p.m3u8";
if ($id_t=="")
   $file="http://uphero.xpresso.eu/torba/m/".$id.".srt";
else
   $file="http://uphero.xpresso.eu/srt/m/".$id_t.".srt";
   $ch = curl_init();
   curl_setopt($ch, CURLOPT_URL, $file);
   curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
   curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 5.1; rv:14.0) Gecko/20100101 Firefox/14.0.1');
   curl_setopt($ch, CURLOPT_FOLLOWLOCATION  ,1);
   $h=curl_exec($ch);
   curl_close($ch);
$list = glob($base_sub."*.srt");
   foreach ($list as $l) {
    str_replace(" ","%20",$l);
    unlink($l);
}
if ( ($h) && strpos($h,"302 Found") == false && strpos(strtolower($h),"doctype html") == false ) {
if ($flash != "direct") {
 if (function_exists("mb_convert_encoding")) {
    $map = array(
        chr(0x8A) => chr(0xA9),
        chr(0x8C) => chr(0xA6),
        chr(0x8D) => chr(0xAB),
        chr(0x8E) => chr(0xAE),
        chr(0x8F) => chr(0xAC),
        chr(0x9C) => chr(0xB6),
        chr(0x9D) => chr(0xBB),
        chr(0xA1) => chr(0xB7),
        chr(0xA5) => chr(0xA1),
        chr(0xBC) => chr(0xA5),
        chr(0x9F) => chr(0xBC),
        chr(0xB9) => chr(0xB1),
        chr(0x9A) => chr(0xB9),
        chr(0xBE) => chr(0xB5),
        chr(0x9E) => chr(0xBE),
        chr(0x80) => '&euro;',
        chr(0x82) => '&sbquo;',
        chr(0x84) => '&bdquo;',
        chr(0x85) => '&hellip;',
        chr(0x86) => '&dagger;',
        chr(0x87) => '&Dagger;',
        chr(0x89) => '&permil;',
        chr(0x8B) => '&lsaquo;',
        chr(0x91) => '&lsquo;',
        chr(0x92) => '&rsquo;',
        chr(0x93) => '&ldquo;',
        chr(0x94) => '&rdquo;',
        chr(0x95) => '&bull;',
        chr(0x96) => '&ndash;',
        chr(0x97) => '&mdash;',
        chr(0x99) => '&trade;',
        chr(0x9B) => '&rsquo;',
        chr(0xA6) => '&brvbar;',
        chr(0xA9) => '&copy;',
        chr(0xAB) => '&laquo;',
        chr(0xAE) => '&reg;',
        chr(0xB1) => '&plusmn;',
        chr(0xB5) => '&micro;',
        chr(0xB6) => '&para;',
        chr(0xB7) => '&middot;',
        chr(0xBB) => '&raquo;',
    );
	$h = html_entity_decode(mb_convert_encoding(strtr($h, $map), 'UTF-8', 'ISO-8859-2'), ENT_QUOTES, 'UTF-8');

	$h = str_replace("\xC3\x84\xE2\x80\x9A","\xC4\x82",$h);
	$h = str_replace("\xC3\x84\xC2\x83","\xC4\x83",$h);
    $h = str_replace("\xC4\x82\xC5\xBD","\xC3\x8E",$h);
    $h = str_replace("\xC4\x82\xC2\xAE","\xC3\xAE",$h);
    $h = str_replace("\xC4\xB9\xCB\x98","\xC5\xA2",$h);
    $h = str_replace("\xC4\xB9\xC5\x81","\xC5\xA3",$h);
    $h = str_replace("\xC4\x82\xE2\x80\X9A","\xC3\x82",$h);
    $h = str_replace("\xC4\x82\xCB\x98","\xC3\xA2",$h);
    $h = str_replace("\xC4\xB9\xC5\xBE","\xC5\x9E",$h);
    $h = str_replace("\xC4\xB9\xC5\xBA","\xC5\x9F",$h);
    $h = str_replace("\xC4\x8C\xC5\xA1","\xC5\xA2",$h);
    $h = str_replace("\xC4\x8C\xE2\x80\x99","\xC5\xA3",$h);
    $h = str_replace("\xC4\x8C\xC2\x98","\xC5\x9E",$h);
    $h = str_replace("\xC4\x8C\xE2\x84\xA2","\xC5\x9F",$h);
	$h = str_replace("\xC3\xA2\xE2\x84\xA2\xC5\x9E","\xE2\x99\xAA",$h);
	
} else {
    $h = str_replace("ª","S",$h);
    $h = str_replace("º","s",$h);
    $h = str_replace("Þ","T",$h);
    $h = str_replace("þ","t",$h);
    $h=str_replace("ã","a",$h);
	$h=str_replace("â","a",$h);
	$h=str_replace("î","i",$h);
	$h=str_replace("Ã","A",$h);
}
}
   $new_file = $base_sub.$srt_name.".srt";
   //echo $new_file;
   $fh = fopen($new_file, 'w');
   fwrite($fh, $h);
   fclose($fh);
}

if ($flash=="direct") {

header('Content-type: application/vnd.apple.mpegURL');
//header('Cookie: '.$cookie1);
//header('Referer: http://movietv.to/');
header('Content-Disposition: attachment; filename="'.$srt_name.'.m3u8"');
header("Location: $movie");
} else {
echo '
<!doctype html>
<HTML>
<HEAD>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>'.$title.'</title>
<style type="text/css">
body {
margin: 0px auto;
overflow:hidden;
}
body {background-color:#000000;}
</style>
<script src="//code.jquery.com/jquery-1.11.0.min.js"></script>
'.$jwv.'
</HEAD>
<BODY>
<div id="container"></div>
<script type="text/javascript">
jwplayer("container").setup({
"playlist": [{
"image": "'.$image.'",
"sources": [{"file": "../subs/play.m3u8", "type": "m3u8", "label": "HD"}],
"tracks": [{"file": "../subs/'.$srt_name.'.srt", "default": true}]
}],
    captions: {
        color: "#FFFFFF",
        fontSize: 20,
        backgroundOpacity: 0
    },
"height": $(document).height(),
"width": $(document).width(),
"skin": '.$skin.',
"startparam": "start",
"fallback": false,
"wmode": "direct",
"stagevideo": true
});
';
echo '
</script>
</BODY>
</HTML>
';
}
?>

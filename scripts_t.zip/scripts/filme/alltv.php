<!DOCTYPE html>
<?php
function str_between($string, $start, $end){
	$string = " ".$string; $ini = strpos($string,$start);
	if ($ini == 0) return ""; $ini += strlen($start); $len = strpos($string,$end,$ini) - $ini;
	return substr($string,$ini,$len);
}
include ("../common.php");
$page=$_GET["page"];
$search=$_GET["search"];
$page_title="Cautare youtube: ".$search;
$search=str_replace(" ","+",$search);
$cookie=$base_cookie."alltv.dat";
?>
<html><head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate"/>
<meta http-equiv="Pragma" content="no-cache"/>
<meta http-equiv="Expires" content="0"/>
      <title><?php echo $page_title; ?></title>
<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.8.0/jquery.min.js"></script>
<script src="../jquery.nicescroll.min.js"></script>

<script type="text/javascript">
  $(document).ready(function() {
	$("html").niceScroll({styler:"fb",cursorcolor:"#000"});
  });
</script>
<link rel="stylesheet" type="text/css" href="../custom.css" />
</head>
<body>
<H2></H2>
<?php
if (!file_exists($cookie)) {
  $l="http://alltv.96.lt/admin/login.php";

  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $l);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US; rv:1.9.1.2) Gecko/20090729 Firefox/3.5.2 GTB5');
  curl_setopt($ch, CURLOPT_FOLLOWLOCATION  ,1);
  curl_setopt($ch, CURLOPT_COOKIEJAR, $cookie);
  curl_setopt($ch, CURLOPT_COOKIEFILE, $cookie);
  $html = curl_exec($ch);
  curl_close($ch);

  $l="http://alltv.96.lt/admin/login.php";
  $post="ausername=admin&apassword=slmgr&Login=Login";
  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $l);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US; rv:1.9.1.2) Gecko/20090729 Firefox/3.5.2 GTB5');
  curl_setopt($ch, CURLOPT_FOLLOWLOCATION  ,1);
  curl_setopt($ch,CURLOPT_REFERER,"http://alltv.96.lt");
  curl_setopt ($ch, CURLOPT_POST, 1);
  curl_setopt ($ch, CURLOPT_POSTFIELDS, $post);
  curl_setopt($ch, CURLOPT_COOKIEJAR, $cookie);
  curl_setopt($ch, CURLOPT_COOKIEFILE, $cookie);
  $html = curl_exec($ch);
  curl_close($ch);
}
if ($page==1) {
  $l="http://alltv.96.lt/admin/import.php?action=search";
  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $l);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US; rv:1.9.1.2) Gecko/20090729 Firefox/3.5.2 GTB5');
  curl_setopt($ch, CURLOPT_FOLLOWLOCATION  ,1);
  curl_setopt($ch,CURLOPT_REFERER,"http://alltv.96.lt");
  curl_setopt($ch, CURLOPT_COOKIEFILE, $cookie);
  $html = curl_exec($ch);
  $t1=explode("_pmnonce_t' value='",$html);
  $t2=explode("'",$t1[1]);
  $post="keyword=".$search."&data_source=youtube&submit=&_pmnonce=_admin_import_subscriptions&_pmnonce_t=".$t2[0]."&autodata=1&search_category=all&search_duration=all&search_time=all_time&search_orderby=relevance&results=30&search_language=all&search_license=all";
  curl_setopt ($ch, CURLOPT_POST, 1);
  curl_setopt ($ch, CURLOPT_POSTFIELDS, $post);
  $html = curl_exec($ch);
  curl_close($ch);
} else {
  $link="alltv.96.lt/admin/import.php?page=".$page."&action=search&keyword=".$search."&results=30&autofilling=0&autodata=1&oc=0&utc=&search_orderby=relevance&data_source=youtube";
  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $link);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US; rv:1.9.1.2) Gecko/20090729 Firefox/3.5.2 GTB5');
  curl_setopt($ch, CURLOPT_FOLLOWLOCATION  ,1);
  curl_setopt($ch,CURLOPT_REFERER,"http://alltv.96.lt");
  curl_setopt($ch, CURLOPT_COOKIEFILE, $cookie);
  $html = curl_exec($ch);
}

  $t1=explode('pagination-centered">',$html);
  $t2=explode("<li",$t1[1]);
  $t3=explode('href="',$t2[1]);
  $t4=explode('"',$t3[1]);
  if ($t4)
    $prev_page=str_between($t4[0],"page=","&");
  else
    $prev_page=1;
  $t3=explode('href="',$t2[2]);
  $t4=explode('"',$t3[1]);
  $next_page=str_between($t4[0],"page=","&");

$n=0;
echo '<h2 style="background-color:deepskyblue;color:black">'.$page_title.'</H2>';
echo '<table border="1px" width="100%">'."\n\r";
echo '<tr><TD colspan="5" align="right">';
if ($page != 1)
echo '<a href="alltv.php?page='.$prev_page.'&search='.$search.'"><font size="4">&nbsp;&lt;&lt;&nbsp;</font></a> | <a href="alltv.php?page='.$next_page.'&search='.$search.'"><font size="4">&nbsp;&gt;&gt;&nbsp;</font></a></TD></TR>';
else
echo '<a href="alltv.php?page='.$next_page.'&search='.$search.'"><font size="4">&nbsp;&gt;&gt;&nbsp;</font></a></TD></TR>';

//echo $html;
//http://alltv.96.lt/admin/import.php?page=CB4QAA&action=search&keyword=holograf&results=30&autofilling=0&autodata=1&oc=0&utc=&search_orderby=relevance&data_source=youtube
$videos = explode('<a id="video-id', $html);

unset($videos[0]);
$videos = array_values($videos);


foreach($videos as $video) {
    $t1 = explode('name="direct[', $video);
    $t2 = explode('value="', $t1[1]);
    $t3=explode('"',$t2[1]);
    $link = $t3[0];
    if (strpos($link,"http") === false) $link="http://".$link;
    $t1 = explode('data-echo="', $video);
    $t2 = explode('"', $t1[2]);
    $image = $t2[0];

    $t1 = explode('value="', $video);
    $t2 = explode('"', $t1[1]);
    $title = $t2[0];
    
    $duration=str_between($video,'"stack-video-duration">','<');
    
    $desc=str_between($video,'video-stack-desc">','</');
  if ($link <> "") {
  if ($n==0) echo '<TR>';
  echo '<td align="center" width="25%"><a href="'.$link.'" target="_blank"><img src="'.$image.'" width="200px" height="140px"><BR><font size="4">'.$title.'<BR>Durata: '.$duration.'<BR>'.$desc.'</font></a></TD>';
  $n++;
  if ($n == 4) {
  echo '</tr>';
  $n=0;
  }
  }
}
echo '<tr><TD colspan="4" align="right">';
if ($page != 1)
echo '<a href="alltv.php?page='.$prev_page.'&search='.$search.'"><font size="4">&nbsp;&lt;&lt;&nbsp;</font></a> | <a href="alltv.php?page='.$next_page.'&search='.$search.'"><font size="4">&nbsp;&gt;&gt;&nbsp;</font></a></TD></TR>';
else
echo '<a href="alltv.php?page='.$next_page.'&search='.$search.'"><font size="4">&nbsp;&gt;&gt;&nbsp;</font></a></TD></TR>';

?>
<br></body>
</html>

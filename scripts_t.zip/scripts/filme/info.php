<!DOCTYPE html>
<html>
<head>
	<title>IMDB</title>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
      <link rel="stylesheet" type="text/css" href="../custom.css" />
</head>
<body>
<!--
	<p>
		<a href="javascript:parent.jQuery.fancybox.close();">Close</a>
	</p>
-->
<?php
error_reporting(0);
function str_between($string, $start, $end){
	$string = " ".$string; $ini = strpos($string,$start);
	if ($ini == 0) return ""; $ini += strlen($start); $len = strpos($string,$end,$ini) - $ini;
	return substr($string,$ini,$len);
}
$id = urldecode($_GET["file"]);
$year = urldecode($_GET["year"]);
$img=$_GET["image"];
$tit=urldecode($_GET["title"]);
//$tit=urldecode($_GET["title"]);
//IMDB SINOPSIS
$ti = urldecode($_GET["title"]);
$IMDB_API_URL = "http://www.omdbapi.com/?t=".$id."&y=".$year."";
$IMDB_API_URL = str_replace(' ', '%20', $IMDB_API_URL);
$IMDB_API_URL=str_replace("(","",$IMDB_API_URL);
$IMDB_API_URL=str_replace(")","",$IMDB_API_URL);
$Data = file_get_contents($IMDB_API_URL);

$JSON = json_decode($Data);
$Title = $JSON->Title;
$Year = $JSON->Year;
$Rated = $JSON->Rated;
$Released= $JSON->Released;
$Runtime= $JSON->Runtime;
$Genre= $JSON->Genre;
$Writer= $JSON->Writer;
$Plot= $JSON->Plot;
$imdbRating = $JSON->imdbRating;
$imdbVotes = $JSON->imdbVotes;
$Released = $JSON->Released;
$Awards = $JSON->Awards;
$Actors = $JSON->Actors;
$imdbID = $JSON->imdbID;
$imdbRating = $JSON->imdbRating;
$Poster = $JSON->Poster;
//$l = file_get_contents("".$Poster."");
$fp=fopen('imdb.jpg','w');
fwrite($fp, $l);
fclose($fp);

echo '<title>'.$Title.'</title>';
echo '<table><tr>';
echo '<TD><img src="'.$img.'" width="160px" height="224px"></TD><h2 style="background-color:deepskyblue;color:black;text-align:left;">'.$Title.'</h2>';
echo '<TD  style="vertical-align:top;">Year: '.$Year.'<BR>IMDB: '.$imdbRating.'<BR>Genre: '.$Genre.'<BR>Duration: '.$Runtime.'<BR>Cast: '.$Actors.'<BR><br>'.$Plot.'</TD>';
?>
</TR>
</TABLE>
</body>
</html>

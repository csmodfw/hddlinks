<!DOCTYPE html>
<?php
error_reporting(0);
function str_between($string, $start, $end){
	$string = " ".$string; $ini = strpos($string,$start);
	if ($ini == 0) return ""; $ini += strlen($start); $len = strpos($string,$end,$ini) - $ini;
	return substr($string,$ini,$len);
}
function decode_entities($text) {
    $text= html_entity_decode($text,ENT_QUOTES,"ISO-8859-1"); #NOTE: UTF-8 does not work!
    $text= preg_replace('/&#(\d+);/me',"chr(\\1)",$text); #decimal notation
    $text= preg_replace('/&#x([a-f0-9]+);/mei',"chr(0x\\1)",$text);  #hex notation
    return $text;
}
include ("../common.php");
$link=$_GET["file"];
$tit=unfix_t(urldecode($_GET["title"]));
$tit=html_entity_decode($tit,ENT_QUOTES,'UTF-8');
$f=$base_pass."tvplay.txt";
if (file_exists($f))
   $user=true;
else
   $user=false;

?>
<html><head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<link rel="stylesheet" type="text/css" href="../custom.css" />
      <meta charset="utf-8">
      <title><?php echo $tit; ?></title>
<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.8.0/jquery.min.js"></script>

</head>
<body><BR>
<?php

//$link="filmeseriale.php?file=".$link1.",".urlencode(fix_t($title11));
echo '<h2>'.$tit.'</h2>';
echo '<table border="1" width="100%">'."\n\r";
//echo '<TR><td style="color:#000000;background-color:deepskyblue;text-align:center" align="center"><font size="4">'.$tit.'</font></TD></TR></TABLE>';
  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $link);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US; rv:1.9.1.2) Gecko/20090729 Firefox/3.5.2 GTB5');
  curl_setopt($ch, CURLOPT_FOLLOWLOCATION  ,1);
  curl_setopt($ch, CURLOPT_REFERER, "https://filmeseriale.online");
  curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
  $html = curl_exec($ch);
  curl_close($ch);
  //$html=str_replace("script","zzzzz",$html);
  //echo $html;
$videos = explode('class="numerando">', $html);
unset($videos[0]);
$videos = array_values($videos);
$n=0;
$title1="";
$sezoane=array();
$last_sez="";
foreach($videos as $video) {
    $t1=explode('<',$video);
    $title1=trim($t1[0]);
    $title1=html_entity_decode($title1,ENT_QUOTES,'UTF-8');
    preg_match("/(\d+)\s+x\s+(\d+)/",$title1,$m);
    //print_r ($m);
    $sez=$m[1];
    $ep=$m[2];
    if ($last_sez <> $sez) {
       $last_sez=$sez;
       $sezoane[]=$sez;
    }
}
echo '<table border="1" width="100%">'."\n\r";
echo '<TR>';
$c=count($sezoane);
for ($k=0;$k<$c;$k++) {
echo '<td style="color:black;text-align:center"><font size="4"><a href="#sez'.($k+1).'">Sezonul '.($k+1).'</a></font></TD>';
}
echo '</TR></TABLE>';
if ($user) echo '<div id="mainnav">';
//print_r ($sezoane);
/////////////////////////////////////////////////////////////////////////////
$last_sez="";
$last_tab="";
if ($user) {
$key="f8cf02e6b30bf8cc33c04c60695781aa";
$api_url="https://api.themoviedb.org/3/search/tv?api_key=".$key."&query=".urlencode($tit);
  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $api_url);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US; rv:1.9.1.2) Gecko/20090729 Firefox/3.5.2 GTB5');
  curl_setopt($ch, CURLOPT_FOLLOWLOCATION  ,1);
  curl_setopt($ch, CURLOPT_CONNECTTIMEOUT  ,10);
  curl_setopt($ch, CURLOPT_REFERER, "https://api.themoviedb.org");
  curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
  $h = curl_exec($ch);
  curl_close($ch);
$r=json_decode($h,1);
$id_m=$r["results"][0]["id"];
}
$videos = explode('class="numerando">', $html);
unset($videos[0]);
$videos = array_values($videos);
$n=0;
$title1="";
$first=true;
foreach($videos as $video) {
    $t1 = explode('href="', $video);
//if ( sizeof($t1)>1 ) {
    $t2 = explode('"', $t1[1]);
    $link = $t2[0];

    $t1=explode('<',$video);
    $title1=trim($t1[0]);
    $title1=html_entity_decode($title1,ENT_QUOTES,'UTF-8');
    preg_match("/(\d+)\s+x\s+(\d+)/",$title1,$m);
    //print_r ($m);
    $sez=$m[1];
    $ep=$m[2];
    $t2=explode('class="episodiotitle">',$video);
    $t3=explode("<",$t2[1]);
    $title2=trim($t3[0]);
    $title2=html_entity_decode($title2,ENT_QUOTES,'UTF-8');
    if ($last_sez <> $sez) {
       if (!$user) $last_sez=$sez;
       $first_ep=true;
       if ($first) {
         echo '<table border="1" width="100%">'."\n\r";
         echo '<TR><td style="color:black;background-color:#0a6996;color:#64c8ff;text-align:center" colspan=3"><font size="4">.Sezonul '.($sez).'</font></TD></TR>';
         $first=false;
         $n=0;
       } else {
         if ($n > 0) {
           for ($p=0;$p<(2-$n);$p++) {
             echo '<TD></TD>';
           }
           echo '</TR>';
         }
         echo '</table><table border="1" width="100%">'."\n\r";
         echo '<TR><td colspan="3" style="color:#000000;background-color:deepskyblue;text-align:center" align="center"><font size="4">.Sezonul '.($sez).'</font></TD></TR>';
         $n=0;
       }
    } else {
       $first_ep=false;
    }
    if ($user && $id_m && $last_sez <> $sez && !$title2) {
       $last_sez=$sez;
       // && $last_sez <> $sez
       $l="https://api.themoviedb.org/3/tv/".$id_m."/season/".$sez."?api_key=".$key;
       $ch = curl_init();
       curl_setopt($ch, CURLOPT_URL, $l);
       curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
       curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US; rv:1.9.1.2) Gecko/20090729 Firefox/3.5.2 GTB5');
       curl_setopt($ch, CURLOPT_FOLLOWLOCATION  ,1);
       curl_setopt($ch, CURLOPT_CONNECTTIMEOUT  ,10);
       curl_setopt($ch, CURLOPT_REFERER, "https://api.themoviedb.org");
       curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
       $h = curl_exec($ch);
       curl_close($ch);
       $r=json_decode($h,1);
       }
       if ($r) {
        $title2 = $r["episodes"][$ep-1]["name"];
        $title2=html_entity_decode($title2,ENT_QUOTES,'UTF-8');
        $desc=$r["episodes"][$ep-1]["overview"];
        $img_ep="http://image.tmdb.org/t/p/w780".$r["episodes"][$ep-1]["still_path"];
       }
    if ($title2)
    $title=$sez."x".$ep." - ".$title2;
    else
    $title=$sez."x".$ep;


      $link = 'filme_link.php?file='.urlencode($link).",".urlencode($tit." - ".$title);
      //$link="fs.php?link=".$link."&title=".urlencode($tit)."&tip=series&tit=".$title;
//}
      if ($n == 0) echo "<TR>"."\n\r";
   if ($title && !$user) {
        if ($first_ep) {
		 echo '<TD width="33%"><font size="4">'.'<a id="sez'.$sez.'" href="'.$link.'" target="_blank">'.$title.'</a></font>';
		} else {
		echo '<TD width="33%"><font size="4">'.'<a href="'.$link.'" target="_blank">'.$title.'</a></font>';
		}
		echo '</TD>'."\n\r";
        $n++;
        if ($n > 2) {
         echo '</TR>'."\n\r";
         $n=0;
        }

	} elseif($title && $user) {
        if ($first_ep) {
		 echo '<TD width="33%" align="center"><font size="4">'.'<a id="sez'.$sez.'" href="'.$link.'" target="_blank"><img width="200px" height="100px" src="'.$img_ep.'"><BR>'.$title.'</a></font>';
		} else {
  echo '<TD width="33%" align="center"><font size="4">'.'<a href="'.$link.'" target="_blank"><img width="200px" height="100px" src="'.$img_ep.'"><BR>'.$title.'</a></font>';
		}
		echo '</TD>'."\n\r";
        $n++;
        if ($n > 2) {
         echo '</TR>'."\n\r";
         $n=0;
        }
	
	}
//}

}

echo '</table>';
if ($user) echo '</div>';
?>
<br></body>
</html>

<!doctype html>
<?php
function str_between($string, $start, $end){
	$string = " ".$string; $ini = strpos($string,$start);
	if ($ini == 0) return ""; $ini += strlen($start); $len = strpos($string,$end,$ini) - $ini;
	return substr($string,$ini,$len);
}
include ("../common.php");
$page = $_GET["page"];
$filename = $base_pass."vplus.txt";
$cookie=$base_cookie."vplus.dat";
if (file_exists($filename)) {
  $handle = fopen($filename, "r");
  $c = fread($handle, filesize($filename));
  fclose($handle);
  $a=explode("|",$c);
  $user=$a[0];
  $pass=trim($a[1]);
if (!file_exists($cookie)) {
  $l="http://vplus.ro/in";
  $post="usr_vplay=".$user."&pwd=".$pass."&rbm=1";
  $post="usr_vplay=".$user."&pwd=".$pass."&rbm=1&submit=Login";
  //echo $post;
  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $l);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US; rv:1.9.1.2) Gecko/20090729 Firefox/3.5.2 GTB5');
  curl_setopt($ch, CURLOPT_FOLLOWLOCATION  ,1);
  curl_setopt($ch,CURLOPT_REFERER,"http://vplus.ro/login/");
  curl_setopt ($ch, CURLOPT_POST, 1);
  curl_setopt ($ch, CURLOPT_POSTFIELDS, $post);
  curl_setopt($ch, CURLOPT_COOKIEJAR, $cookie);
  curl_setopt($ch, CURLOPT_COOKIEFILE, $cookie);
  $html = curl_exec($ch);
  curl_close($ch);
}
}
$link="http://vplus.ro/shows/".$page;
  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $link);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US; rv:1.9.1.2) Gecko/20090729 Firefox/3.5.2 GTB5');
  curl_setopt($ch, CURLOPT_FOLLOWLOCATION  ,1);
  curl_setopt($ch, CURLOPT_COOKIEFILE, $cookie);
  $html = curl_exec($ch);
  curl_close($ch);
if (strpos($html,"var logged = 1") !== false) $logged="yes";
$pg=str_between($html,'li class="showing">','<');
?>
	<html xmlns="http://www.w3.org/1999/xhtml">
	<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
	<title>VPlus / Seriale </title>
	<link rel="shortcut icon" href="http://i.vplus.ro/it/ic/favicon.png" type="image/x-icon">
	<link rel="stylesheet" href="http://i.vplus.ro/it/css/base.css?v=6.9" type="text/css">
	<link rel="stylesheet" href="http://i.vplus.ro/it/css/dropdown.css?v=6.9" type="text/css">
	<link rel="stylesheet" href="http://i.vplus.ro/it/css/navigation.css?v=6.9" type="text/css">
	<link rel="stylesheet" href="http://i.vplus.ro/it/css/comments.css?v=6.9" type="text/css">
	<link rel="stylesheet" href="http://i.vplus.ro/it/css/vplus.css?v=6.9" type="text/css">
	<link href="http://i.vplus.ro/it/css/dark.css?v=6.9" rel="stylesheet" type="text/css">
<link href="http://i.vplus.ro/it/css/catalogue.css?v=6.9" rel="stylesheet" type="text/css">
     <script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.8.0/jquery.min.js"></script>
     <script src="../jquery.nicescroll.min.js"></script>
<script type="text/javascript">
  $(document).ready(function() {
	$("html").niceScroll({styler:"fb",cursorcolor:"#000"});
  });
</script>


	
	</head>
	<body>
	<div class="wrapper">
		<div id="browser_ruler"></div>
		
		<script type="text/javascript">var logged = 1</script>
		
			<div class="clear"></div>
<div class="dark">
	<div class="center content-container">
		<div class="clear" style="height:10px;"></div>
		<div id="content" class="colls_oview">
			<div class="dark-page-content">
				<div class="clear" style="height:10px;"></div>
				<div class="center">
					<h2>Seriale</h2>
					<div class="clear"></div>
					<div class="pagination">
<form action="vplus_s_main.php">
<ul class="go-to">
<li>Mergi la pagina</li>
<li>
	<input name="page" id="page" type="text" value="<?php echo ($page+1); ?>">
	<button type="submit" class="btn darker"><span class="left-corner"></span><span class="content"><span class="text">Go</span></span><span class="right-corner"></span></button>
</li>
</ul>
</form>

<ul class="paging">

<li class="showing"><?php echo $pg; ?></li>
<li><a href="vplus_s_main.php?page=<?php echo ($page+1); ?>">Următoarea &gt;&gt;</a></li>
</ul>

<div class="clear"></div>
</div>
					<ul class="coll_list">

<?php

$html = str_between($html,'class="coll_list">',"</ul>");
$videos = explode('<li>', $html);
unset($videos[0]);
$videos = array_values($videos);

foreach($videos as $video) {
  $t1 = explode('href="', $video);
  $t2 = explode('"', $t1[1]);
  $link = "http://vplus.ro".$t2[0];
  $link1=urlencode($link);
  $image=str_between($video,"image:url(",")");

  $t3 = explode('title="', $t1[1]);
  $t4 = explode('"', $t3[1]);
  $title = trim($t4[0]);
  $title1=urlencode($title);
  $description = str_between($video,'<span class="s_e">','</span>');

	if ($link <> "") {
		$link = "vplay_sez.php?file=".urlencode($link).",".urlencode($title);
  echo '
    <li><a href="'.$link.'" title="'.$title.'">
    <span class="coll_poster" title="'.$title.'" style="background-image:url('.$image.');"></span>
    <span class="title">'.$title.'</span><br><span class="s_e">'.$description.'</span></a></li>
	  ';
	}
}
?>					
					</ul>
					<div class="clear"></div>
					<div class="pagination">
<form action="vplus_s_main.php">
<ul class="go-to">
<li>Mergi la pagina</li>        
<li>
	<input name="page" id="page" type="text" value="<?php echo ($page+1); ?>">
	<button type="submit" class="btn darker"><span class="left-corner"></span><span class="content"><span class="text">Go</span></span><span class="right-corner"></span></button>
</li>
</ul>
</form>

<ul class="paging">

<li class="showing"><?php echo $pg; ?></li>
<li><a href="vplus_s_main.php?page=<?php echo ($page+1); ?>">Următoarea &gt;&gt;</a></li>
</ul>

<div class="clear"></div>
</div>
				</div>					
			</div>
			<div class="clear" style="height:10px;"></div>
		</div>
	</div>
	<div class="clear" style="height:10px;"></div>
</div>
	
		<div class="push"></div>
		</div><!-- End .wrapper -->

	<br></body>
	</html>

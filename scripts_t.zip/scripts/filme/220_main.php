<!DOCTYPE html>
<html><head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate"/>
<meta http-equiv="Pragma" content="no-cache"/>
<meta http-equiv="Expires" content="0"/>
      <title>220.ro</title>
<script src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
<link rel="stylesheet" type="text/css" href="../custom.css" />
</head>
<body>
<H2></H2>
<?php
function str_between($string, $start, $end){
	$string = " ".$string; $ini = strpos($string,$start);
	if ($ini == 0) return ""; $ini += strlen($start); $len = strpos($string,$end,$ini) - $ini;
	return substr($string,$ini,$len);
}
include ("../common.php");
$filename = $base_pass."220.txt";
$cookie=$base_cookie."220.dat";
if (!file_exists($filename)) $add=' <a href="../settings.php" target="_blank">(necesita cont free pentru a avea acces la tot continutul)</a>';
echo '<table border="1px" width="100%">'."\n\r";
echo '<TR><td style="color:black;background-color:deepskyblue;text-align:center" colspan="3"><font size="4"><b>220.ro</b>'.$add.'</font></TD></TR>';
echo '<TR>';
$link="220_show_main.php?page=1,,Shows";
$title="shows";
echo '<TD style="text-align:center"><font size="4">'.'<a href="'.$link.'" target="_blank">'.$title.'</a></font></TD>';
$link="220.php?page=1,http://www.220.ro/video/cele-mai-noi/,Cele+mai+recente";
$title="Cele mai noi";
echo '<TD style="text-align:center"><font size="4">'.'<a href="'.$link.'" target="_blank">'.$title.'</a></font></TD>';
$link="220.php?page=1,http://www.220.ro/video/cele-mai-vizitate/,Cele+mai+vizionate";
$title="Cele mai vizionate";
echo '<TD style="text-align:center"><font size="4">'.'<a href="'.$link.'" target="_blank">'.$title.'</a></font></TD>';
echo '</TR>';
$n=0;

if (file_exists($filename)) {
  $handle = fopen($filename, "r");
  $c = fread($handle, filesize($filename));
  fclose($handle);
  $a=explode("@",$c);
  $user=$a[0];
  $pass=trim($a[1]);
if (!file_exists($cookie)) {
  $l="http://www.220.ro/index.php";
  $post="f=usr_auth&ajax=1&username=".$user."&password=".$pass."&autologin=1";
  //echo $post;
  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $l);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US; rv:1.9.1.2) Gecko/20090729 Firefox/3.5.2 GTB5');
  curl_setopt($ch, CURLOPT_FOLLOWLOCATION  ,1);
  curl_setopt($ch,CURLOPT_REFERER,"http://220.ro/");
  curl_setopt ($ch, CURLOPT_POST, 1);
  curl_setopt ($ch, CURLOPT_POSTFIELDS, $post);
  curl_setopt($ch, CURLOPT_COOKIEJAR, $cookie);
  curl_setopt($ch, CURLOPT_COOKIEFILE, $cookie);
  $html = curl_exec($ch);
  curl_close($ch);
}
}
$h=file_get_contents("http://www.220.ro/video/");
$h=str_between($h,'<div class="box_200 meniu_vertical">','</div');
$videos = explode('<a', $h);

unset($videos[0]);
$videos = array_values($videos);

foreach($videos as $video) {
  $t1=explode('href="',$video);
  $t2=explode('"',$t1[1]);
  $link=$t2[0];

  $t3=explode(">",$t1[1]);
  $t4=explode("<",$t3[1]);
  $title=trim($t4[0]);
  if (preg_match("/220/",$link)) {
    $link="220.php?page=1,".$link.",".urlencode($title);
	if ($n == 0) echo "<TR>"."\n\r";
	echo '<TD style="text-align:center"><font size="4">'.'<a href="'.$link.'" target="_blank">'.$title.'</a></font></TD>';
    $n++;
    if ($n > 2) {
     echo '</TR>'."\n\r";
     $n=0;
    }
  }
 }
 if ($n<3) echo "</TR>"."\n\r";
 echo '</table>';
?>
<BODY>
</HTML>

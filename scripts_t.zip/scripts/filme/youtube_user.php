<!DOCTYPE html>
<?php
include ("../common.php");
$search="";
$channel="";
$pageToken="";
$nextpage="";
$nextPageToken="";
$prevPageToken="";
$playlistID="";
$query = $_GET["page"];
if($query) {
   $queryArr = explode(',', $query);
   $page= $queryArr[0];
if (sizeof($queryArr) > 1 )
   $search = $queryArr[1];
if (sizeof($queryArr) > 2 )
   $page_title = urldecode($queryArr[2]);
}
if (!$search) {
$page=$_GET["page"];
$search=$_GET["search"];
$page_title=$_GET["page_title"];
$channel="DA";
}
//$search="ArealIT";
if (array_key_exists("pageToken",$_GET)) $pageToken=$_GET["pageToken"];
if (array_key_exists("playlistID",$_GET)) $pageToken=$_GET["playlistID"];
$key="AIzaSyDhpkA0op8Cyb_Yu1yQa1_aPSr7YtMacYU";
if (!$playlistID) {
$l1="https://www.googleapis.com/youtube/v3/channels?part=contentDetails&forUsername=".$search."&key=".$key;;
//echo $l1;
  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $l1);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US; rv:1.9.1.2) Gecko/20090729 Firefox/3.5.2 GTB5');
  curl_setopt($ch, CURLOPT_FOLLOWLOCATION  ,1);
  curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
  $html = curl_exec($ch);
  curl_close($ch);
  //echo $html;
  $p=json_decode($html,1);
  //print_r ($p);
  if ($p["items"]) $playlistID=$p["items"][0]["contentDetails"]["relatedPlaylists"]["uploads"];
  elseif (!$channel) {
$l1="https://www.youtube.com/channel/".$search;
//echo $l1;
  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $l1);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US; rv:1.9.1.2) Gecko/20090729 Firefox/3.5.2 GTB5');
  curl_setopt($ch, CURLOPT_FOLLOWLOCATION  ,1);
  curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
  $html = curl_exec($ch);
  curl_close($ch);
  $user = str_between($html,'a href="/user/','"');

 $t1=$_SERVER["PHP_SELF"];
 echo "<script language='JavaScript'>
 <!-- 
 document.location=\"$t1?page=1&search=$user&page_title=$page_title\";
 //-->
 </script>";
 die();
  }
}
//echo $playlistID;
//die();
//$playlistID="UUCUnAfa_A5XR5NyoPgErmlg";
if ($pageToken)
$l2="https://www.googleapis.com/youtube/v3/playlistItems?part=snippet&maxResults=25&pageToken=".$pageToken."&playlistId=".$playlistID."&key=".$key;
else
$l2="https://www.googleapis.com/youtube/v3/playlistItems?part=snippet&maxResults=25&playlistId=".$playlistID."&key=".$key;
//echo $l2;
//$l2="https://www.googleapis.com/youtube/v3/playlistItems?part=snippet&maxResults=25&Id=UC3q-m4TWRvexD_tjltFeJzg&key=AIzaSyDhpkA0op8Cyb_Yu1yQa1_aPSr7YtMacYU";
  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $l2);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US; rv:1.9.1.2) Gecko/20090729 Firefox/3.5.2 GTB5');
  curl_setopt($ch, CURLOPT_FOLLOWLOCATION  ,1);
  curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
  $html = curl_exec($ch);
  curl_close($ch);
  //echo $html;
  $p=json_decode($html,1);
  //print_r ($p);
  if (array_key_exists("nextPageToken",$p)) $nextpage=$p["nextPageToken"];
  if (array_key_exists("prevPageToken",$p)) $prevPageToken=$p["prevPageToken"];
//die();
?>
<html><head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate"/>
<meta http-equiv="Pragma" content="no-cache"/>
<meta http-equiv="Expires" content="0"/>
      <title><?php echo $page_title; ?></title>
<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.8.0/jquery.min.js"></script>
<script src="../jquery.nicescroll.min.js"></script>

<script type="text/javascript">
  $(document).ready(function() {
	$("html").niceScroll({styler:"fb",cursorcolor:"#000"});
  });
</script>
<link rel="stylesheet" type="text/css" href="../custom.css" />
</head>
<body>
<H2></H2>
<?php
function str_between($string, $start, $end){
	$string = " ".$string; $ini = strpos($string,$start);
	if ($ini == 0) return ""; $ini += strlen($start); $len = strpos($string,$end,$ini) - $ini;
	return substr($string,$ini,$len);
}
$n=0;
echo '<h2 style="background-color:deepskyblue;color:black">'.$page_title.'</H2>';
echo '<table border="1px" width="100%">'."\n\r";
echo '<tr><TD colspan="5" align="right">';
if ($page > 1)
echo '<a href="youtube_user.php?page='.($page-1).','.$search.','.urlencode($page_title).'&$playlistID='.$playlistID.'&pageToken='.$prevPageToken.'"><font size="4">&nbsp;&lt;&lt;&nbsp;</font></a> | <a href="youtube_user.php?page='.($page+1).','.$search.','.urlencode($page_title).'&$playlistID='.$playlistID.'&pageToken='.$nextpage.'"><font size="4">&nbsp;&gt;&gt;&nbsp;</font></a></TD></TR>';
else
echo '<a href="youtube_user.php?page='.($page+1).','.$search.','.urlencode($page_title).'&$playlistID='.$playlistID.'&pageToken='.$nextpage.'"><font size="4">&nbsp;&gt;&gt;&nbsp;</font></a></TD></TR>';

//echo $link;
if (array_key_exists("items",$p)) {
for ($k=0;$k<min(sizeof($p["items"]),25);$k++) {
	//$id = str_between($video,"<id>http://gdata.youtube.com/feeds/api/videos/","</id>");
    $id=$p["items"][$k]["snippet"]["resourceId"]["videoId"];
	$title = $p["items"][$k]["snippet"]["title"];
	$image = $p["items"][$k]["snippet"]["thumbnails"]["default"]["url"];
	$link = "http://www.youtube.com/watch?v=".$id;
  if ($link <> "") {
  if ($n==0) echo '<TR>';
  echo '<td align="center" width="20%"><a href="link1.php?file='.urlencode($link).','.urlencode($title).'" target="_blank"><img src="'.$image.'" width="180px" height="106px"><BR><font size="4">'.$title.'</font></a></TD>';
  $n++;
  if ($n == 5) {
  echo '</tr>';
  $n=0;
  }
  }
 }
}
echo '<tr><TD colspan="5" align="right">';
if ($page > 1)
echo '<a href="youtube_user.php?page='.($page-1).','.$search.','.urlencode($page_title).'&$playlistID='.$playlistID.'&pageToken='.$prevPageToken.'"><font size="4">&nbsp;&lt;&lt;&nbsp;</font></a> | <a href="youtube_user.php?page='.($page+1).','.$search.','.urlencode($page_title).'&$playlistID='.$playlistID.'&pageToken='.$nextpage.'"><font size="4">&nbsp;&gt;&gt;&nbsp;</font></a></TD></TR>';
else
echo '<a href="youtube_user.php?page='.($page+1).','.$search.','.urlencode($page_title).'&$playlistID='.$playlistID.'&pageToken='.$nextpage.'"><font size="4">&nbsp;&gt;&gt;&nbsp;</font></a></TD></TR>';
echo "</table>";
?>
<br></body>
</html>

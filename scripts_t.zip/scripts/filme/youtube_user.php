<!DOCTYPE html>
<?php
include ("../common.php");
$query = $_GET["page"];
if($query) {
   $queryArr = explode(',', $query);
   $page = $queryArr[0];
   $search = $queryArr[1];
   $page_title=urldecode($queryArr[2]);
   $search=str_replace("|","&",$search);
}
?>
<html><head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate"/>
<meta http-equiv="Pragma" content="no-cache"/>
<meta http-equiv="Expires" content="0"/>
      <title><?php echo $page_title; ?></title>
<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.8.0/jquery.min.js"></script>
<script src="../jquery.nicescroll.min.js"></script>

<script type="text/javascript">
  $(document).ready(function() {
	$("html").niceScroll({styler:"fb",cursorcolor:"#000"});
  });
</script>
<link rel="stylesheet" type="text/css" href="../custom.css" />
</head>
<body>
<H2></H2>
<?php
function str_between($string, $start, $end){
	$string = " ".$string; $ini = strpos($string,$start);
	if ($ini == 0) return ""; $ini += strlen($start); $len = strpos($string,$end,$ini) - $ini;
	return substr($string,$ini,$len);
}
$n=0;
echo '<h2 style="background-color:deepskyblue;color:black">'.$page_title.'</H2>';
echo '<table border="1px" width="100%">'."\n\r";
echo '<tr><TD colspan="5" align="right">';
if ($page > 1)
echo '<a href="youtube_user.php?page='.($page-1).','.$search.','.urlencode($page_title).'"><font size="4">&nbsp;&lt;&lt;&nbsp;</font></a> | <a href="youtube_user.php?page='.($page+1).','.$search.','.urlencode($page_title).'"><font size="4">&nbsp;&gt;&gt;&nbsp;</font></a></TD></TR>';
else
echo '<a href="youtube_user.php?page='.($page+1).','.$search.','.urlencode($page_title).'"><font size="4">&nbsp;&gt;&gt;&nbsp;</font></a></TD></TR>';

$p=25*($page-1)+1;
$link="http://gdata.youtube.com/feeds/api/users/".$search."/uploads?start-index=".$p."&max-results=25&v=2";
//$link="http://gdata.youtube.com/feeds/api/playlists/".$search."?v=1&orderby=position&start-index=".$p."&max-results=25";
$link=str_replace("&","&amp;",$link);
$html = file_get_contents($link);
$videos = explode('<entry>', $html);
unset($videos[0]);
$videos = array_values($videos);
foreach($videos as $video) {
	$id = str_between($video,"<id>http://gdata.youtube.com/feeds/api/videos/","</id>");
	$title = str_between($video,"<title type='text'>","</title>");
	$image = "http://i.ytimg.com/vi/".$id."/2.jpg";
	$link = "http://www.youtube.com/watch?v=".$id;
  if ($link <> "") {
  if ($n==0) echo '<TR>';
  echo '<td align="center" width="20%"><a href="link1.php?file='.urlencode($link).','.urlencode($title).'" target="_blank"><img src="'.$image.'" width="180px" height="106px"><BR><font size="4">'.$title.'</font></a></TD>';
  $n++;
  if ($n == 5) {
  echo '</tr>';
  $n=0;
  }
  }
}
echo '<tr><TD colspan="5" align="right">';
if ($page > 1)
echo '<a href="youtube_user.php?page='.($page-1).','.$search.','.urlencode($page_title).'"><font size="4">&nbsp;&lt;&lt;&nbsp;</font></a> | <a href="youtube_user.php?page='.($page+1).','.$search.','.urlencode($page_title).'"><font size="4">&nbsp;&gt;&gt;&nbsp;</font></a></TD></TR>';
else
echo '<a href="youtube_user.php?page='.($page+1).','.$search.','.urlencode($page_title).'"><font size="4">&nbsp;&gt;&gt;&nbsp;</font></a></TD></TR>';
echo "</table>";
?>
<br></body>
</html>

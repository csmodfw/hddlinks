<?php
include ("../common.php");
$id=$_POST["id"];
$mod=$_POST["mod"];
//$mod="rar";
//echo $id;
//$id=str_replace("[","\[",$id);
//$id=str_replace("]","\]",$id);
//$id=str_replace("'","\'",$id);
//if (strpos($base_sub,":") !== false) $id=str_replace("/","\\",$id);
//Madam Secretary - Sezonul 4 (2017)Madam.Secretary.S04E01.1080p-720p.HDTV.X264-DIMENSION.srt
//die();
//if (file_exists($base_sub."sub.zip")) $mod="zip";
//if (file_exists($base_sub."sub.rar")) $mod="rar";
if ($mod=="rar") {
   $file_srt=$base_sub."sub.rar";
   $rar_file = rar_open($file_srt);
   if ($rar_file === false)
    die("Failed to open Rar archive");
    //$id="She's.The.Man[2006]DvDrip[Eng]-aXXo.srt";
    //echo $id;
   //$id="Madam Secretary - Sezonul 4 (2017)\Madam.Secretary.S04E01.1080p-720p.HDTV.X264-DIMENSION.srt";
   $entry = rar_entry_get($rar_file, $id);
   if ($entry === false)
    die("Failed to find such entry");

   $stream = $entry->getStream();
   if ($stream === false)
      die("Failed to obtain stream.");

   rar_close($rar_file); //stream is independent from file
$h="";
while (!feof($stream)) {
    $h .= fread($stream, 8192);
}

fclose($stream);
} else {
  $file_srt=$base_sub."sub.zip";
$h = '';
$z = new ZipArchive();
if ($z->open($file_srt)) {
    $fp = $z->getStream($id);
    if(!$fp) exit("Failed to open zip archive\n");

    while (!feof($fp)) {
        $h .= fread($fp, 8192);
    }

    fclose($fp);
}
}
if ($h)  {
 if (function_exists("mb_convert_encoding")) {
    $map = array(
        chr(0x8A) => chr(0xA9),
        chr(0x8C) => chr(0xA6),
        chr(0x8D) => chr(0xAB),
        chr(0x8E) => chr(0xAE),
        chr(0x8F) => chr(0xAC),
        chr(0x9C) => chr(0xB6),
        chr(0x9D) => chr(0xBB),
        chr(0xA1) => chr(0xB7),
        chr(0xA5) => chr(0xA1),
        chr(0xBC) => chr(0xA5),
        chr(0x9F) => chr(0xBC),
        chr(0xB9) => chr(0xB1),
        chr(0x9A) => chr(0xB9),
        chr(0xBE) => chr(0xB5),
        chr(0x9E) => chr(0xBE),
        chr(0x80) => '&euro;',
        chr(0x82) => '&sbquo;',
        chr(0x84) => '&bdquo;',
        chr(0x85) => '&hellip;',
        chr(0x86) => '&dagger;',
        chr(0x87) => '&Dagger;',
        chr(0x89) => '&permil;',
        chr(0x8B) => '&lsaquo;',
        chr(0x91) => '&lsquo;',
        chr(0x92) => '&rsquo;',
        chr(0x93) => '&ldquo;',
        chr(0x94) => '&rdquo;',
        chr(0x95) => '&bull;',
        chr(0x96) => '&ndash;',
        chr(0x97) => '&mdash;',
        chr(0x99) => '&trade;',
        chr(0x9B) => '&rsquo;',
        chr(0xA6) => '&brvbar;',
        chr(0xA9) => '&copy;',
        chr(0xAB) => '&laquo;',
        chr(0xAE) => '&reg;',
        chr(0xB1) => '&plusmn;',
        chr(0xB5) => '&micro;',
        chr(0xB6) => '&para;',
        chr(0xB7) => '&middot;',
        chr(0xBB) => '&raquo;',
    );
	$h = html_entity_decode(mb_convert_encoding(strtr($h, $map), 'UTF-8', 'ISO-8859-2'), ENT_QUOTES, 'UTF-8');

	$h = str_replace("\xC3\x84\xE2\x80\x9A","\xC4\x82",$h);
	$h = str_replace("\xC3\x84\xC2\x83","\xC4\x83",$h);
    $h = str_replace("\xC4\x82\xC5\xBD","\xC3\x8E",$h);
    $h = str_replace("\xC4\x82\xC2\xAE","\xC3\xAE",$h);
    $h = str_replace("\xC4\xB9\xCB\x98","\xC5\xA2",$h);
    $h = str_replace("\xC4\xB9\xC5\x81","\xC5\xA3",$h);
    $h = str_replace("\xC4\x82\xE2\x80\X9A","\xC3\x82",$h);
    $h = str_replace("\xC4\x82\xCB\x98","\xC3\xA2",$h);
    $h = str_replace("\xC4\xB9\xC5\xBE","\xC5\x9E",$h);
    $h = str_replace("\xC4\xB9\xC5\xBA","\xC5\x9F",$h);
    $h = str_replace("\xC4\x8C\xC5\xA1","\xC5\xA2",$h);
    $h = str_replace("\xC4\x8C\xE2\x80\x99","\xC5\xA3",$h);
    $h = str_replace("\xC4\x8C\xC2\x98","\xC5\x9E",$h);
    $h = str_replace("\xC4\x8C\xE2\x84\xA2","\xC5\x9F",$h);
	$h = str_replace("\xC3\xA2\xE2\x84\xA2\xC5\x9E","\xE2\x99\xAA",$h);

} else {
    $h = str_replace("ª","S",$h);
    $h = str_replace("º","s",$h);
    $h = str_replace("Þ","T",$h);
    $h = str_replace("þ","t",$h);
    $h=str_replace("ã","a",$h);
	$h=str_replace("â","a",$h);
	$h=str_replace("î","i",$h);
	$h=str_replace("Ã","A",$h);
}

   $new_file = $base_sub."sub_extern.srt";
   $fh = fopen($new_file, 'w');
   fwrite($fh, $h, strlen($h));
   fclose($fh);
   echo "Am salvat subtitrarea";
}

?>

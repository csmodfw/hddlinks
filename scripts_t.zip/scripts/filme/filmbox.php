<!DOCTYPE html>
<?php
?>
<?php
$page=$_GET["page"];
$page_title = $_GET["title"];
$value = $_GET["value"];
?>
<html><head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate"/>
<meta http-equiv="Pragma" content="no-cache"/>
<meta http-equiv="Expires" content="0"/>
      <title><?php echo $page_title; ?></title>
<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.8.0/jquery.min.js"></script>
<script src="../jquery.nicescroll.min.js"></script>

<script type="text/javascript">
  $(document).ready(function() {
	$("html").niceScroll({styler:"fb",cursorcolor:"#000"});
  });
</script>
<link rel="stylesheet" type="text/css" href="../custom.css" />
</head>
<body>
<H2></H2>
<?php
function str_between($string, $start, $end){
	$string = " ".$string; $ini = strpos($string,$start);
	if ($ini == 0) return ""; $ini += strlen($start); $len = strpos($string,$end,$ini) - $ini;
	return substr($string,$ini,$len);
}
$html = file_get_contents("http://api.invideous.com/plugin/get_package_videos?package_id=258&publisher_id=25137&records_per_page=20&page=".$page."&filter_by_live=0&custom_order_by_order_priority=asc&custom_filter_by_genre=".$value."");
//echo $html;
$tot_pages=str_between($html,'total_pages":','}');
$n=0;
echo '<h2 style="background-color:deepskyblue;color:black">'.$page_title.'</H2>';
echo '<table border="1px" width="100%">'."\n\r";
$pg='Pagina curenta: '.$page." din ".$tot_pages;
echo '<tr>
<TD colspan="3"><form action="filmbox.php">
<font size="4">'.$pg.'</font>
<font size="4">- Salt la pagina: </font>
<input type="text" name="page" id="page">
<input type="hidden" name="title" id="title" value="'.$page_title.'">
<input type="hidden" name="value" id="value" value="'.$value.'">
<input type="submit" value="GO!">
</form></td>
';
echo '<TD colspan="1" align="right">';
if ($page > 1)
echo '<a href="filmbox.php?page='.($page-1).'&title='.$page_title.'&value='.$value.'"><font size="4">&nbsp;&lt;&lt;&nbsp;</font></a> | <a href="filmbox.php?page='.($page+1).'&title='.$page_title.'&value='.$value.'"><font size="4">&nbsp;&gt;&gt;&nbsp;</font></a></TD></TR>';
else
echo '<a href="filmbox.php?page='.($page+1).'&title='.$page_title.'&value='.$value.'"><font size="4">&nbsp;&gt;&gt;&nbsp;</font></a></TD></TR>';

//$p=json_decode($html,1);
//print_r ($p);
//die();

$videos = explode('"ovp_name"', $html);
unset($videos[0]);
$videos = array_values($videos);
foreach($videos as $video) {
	$link=str_between($video,'"source_url":"http:\/\/panel.erstream.com\/api\/er\/Get?cid=','"');
	$title=str_between($video,'"title_en":"','"');
	$title=utf8_decode($title);
	$image=str_between($video,'"promoImage":"','"');
	$add=str_between($video,'"created_at":"','"');
	$year=str_between($video,'"year_of_production":"','"');
	$image=str_replace("\/\/","//",$image);
	$image=str_replace("\/","/",$image);

  if ($n==0) echo '<TR>';
  echo '<td align="center" width="25%"><a href="filmbox_link.php?file='.$link.'&title='.$title.'&year='.$year.'&image='.$image.'&out=out" target="_blank"><img src="'.$image.'" width="200px" height="280px"><BR><font size="4">'.$title.' ('.$year.')</font></a></TD>';
  $n++;
  if ($n == 4) {
  echo '</tr>';
  $n=0;
  }
}
echo '<tr><TD colspan="4" align="right">';
if ($page > 1)
echo '<a href="filmbox.php?page='.($page-1).'&title='.$page_title.'&value='.$value.'"><font size="4">&nbsp;&lt;&lt;&nbsp;</font></a> | <a href="filmbox.php?page='.($page+1).'&title='.$page_title.'&value='.$value.'"><font size="4">&nbsp;&gt;&gt;&nbsp;</font></a></TD></TR>';
else
echo '<a href="filmbox.php?page='.($page+1).'&title='.$page_title.'&value='.$value.'"><font size="4">&nbsp;&gt;&gt;&nbsp;</font></a></TD></TR>';
echo "</table>";
?>
<br></body>
</html>

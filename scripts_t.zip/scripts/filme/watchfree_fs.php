<!doctype html>
<?php
include ("../common.php");
error_reporting(0);
//query=8612&tv=0&title=The+Intervention+(2016)&serv=30&hd=NU
$tit=$_GET["title"];
$image=$_GET["image"];
$link=$_GET["file"];
$tip=$_GET["tip"];
if ($tip=="movie") {
$tit2="";
$type="mpvie";
} else {
  $t1=explode("|",$tit);
  $sezon=$t1[0];
  $episod=$t1[1];
  $tit=$t1[2];
  $tit2=$t1[3];
  //print_r ($m);

$tip="series";
}
$x1=explode("(",$tit);
$x=trim($x1[0]);
$year="";
$imdbid="";
$IMDB_API_URL = "http://www.omdbapi.com/?t=".urlencode($x)."&y=".$year."&type=".$tip;
$Data = file_get_contents($IMDB_API_URL);
//echo $Data;
$JSON = json_decode($Data,1);
$imdbid = $JSON["imdbID"];
$imdbid = str_replace("tt","",$imdbid);
function str_between($string, $start, $end){
	$string = " ".$string; $ini = strpos($string,$start);
	if ($ini == 0) return ""; $ini += strlen($start); $len = strpos($string,$end,$ini) - $ini;
	return substr($string,$ini,$len);
}
function get_value($q, $string) {
   $t1=explode($q,$string);
   return str_between($t1[1],"<string>","</string>");
}
   function generateResponse($request)
    {
        $context  = stream_context_create(
            array(
                'http' => array(
                    'method'  => "POST",
                    'header'  => "Content-Type: text/xml",
                    'content' => $request
                )
            )
        );
        $response     = file_get_contents("http://api.opensubtitles.org/xml-rpc", false, $context);
        return $response;
    }
  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $link);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 5.1; rv:52.0) Gecko/20100101 Firefox/52.0');
  curl_setopt($ch, CURLOPT_FOLLOWLOCATION  ,1);
  curl_setopt ($ch, CURLOPT_REFERER, "http://www.watchfree.to");
  //curl_setopt($ch, CURLOPT_COOKIEJAR, $cookie);
  //curl_setopt($ch, CURLOPT_COOKIEFILE, $cookie);
  //curl_setopt($ch, CURLOPT_HEADER,1);
  $html = curl_exec($ch);
  //echo $html;

//echo $h;
//$r=json_decode($h,1);
//print_r ($r);
$f=$base_cookie."opensub.dat";
if (file_exists($f)) {
$token=file_get_contents($f);
} else {
$request="<?xml version=\"1.0\" encoding=\"iso-8859-1\"?>
<methodCall>
<methodName>LogIn</methodName>
<params>
 <param>
  <value>
   <string></string>
  </value>
 </param>
 <param>
  <value>
   <string></string>
  </value>
 </param>
 <param>
  <value>
   <string>en</string>
  </value>
 </param>
 <param>
  <value>
   <string>hd4all</string>
  </value>
 </param>
</params>
</methodCall>";
$response = generateResponse($request);
$token=get_value("token",$response);
file_put_contents($f,$token);
}
?>
<html>



   <head>

      <meta charset="utf-8">
      <title><?php echo $tit." ".$sezon."x".$episod." - ".$tit2; ?></title>
	  <link rel="stylesheet" type="text/css" href="../custom.css" />
     <script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.8.0/jquery.min.js"></script>
     <script src="../jquery.nicescroll.min.js"></script>
      <script type="text/javascript" src="../jquery.fancybox.js?v=2.1.5"></script>
      <script type="text/javascript" src="func.js"></script>
      <link rel="stylesheet" type="text/css" href="../jquery.fancybox.css?v=2.1.5" media="screen" />
<script type="text/javascript">
    function myFunc() {
         msg = 'flixanity_fs_link.php?image=' + '<?php echo $image; ?>' + '&title=' + '<?php echo str_replace("'","\'",$tit); ?>' + '&serv='  + document.getElementById('server').value + '&sub=' + document.getElementById('menu').value;
         window.open(msg);
    }
function ajaxrequest2() {
  var request =  get_XmlHttp();		// call the function for the XMLHttpRequest instance

  // create pairs index=value with data that must be sent to server
  //var the_data = {mod:add,title:title, link:link}; //Array
  var the_data = '';
  var php_file='fs_del_cookie.php';
  request.open("POST", php_file, true);			// set the request

  // adds a header to tell the PHP script to recognize the data as is sent via POST
  request.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
  request.send(the_data);		// calls the send() method with datas as parameter

  // Check request status
  // If the response is received completely, will be transferred to the HTML tag with tagID
  request.onreadystatechange = function() {
    if (request.readyState == 4) {
      alert (request.responseText);
      location.reload();
    }
  }
}
</script>
<script type="text/javascript">
// create the XMLHttpRequest object, according browser
function get_XmlHttp() {
  // create the variable that will contain the instance of the XMLHttpRequest object (initially with null value)
  var xmlHttp = null;
  if(window.XMLHttpRequest) {		// for Forefox, IE7+, Opera, Safari, ...
    xmlHttp = new XMLHttpRequest();
  }
  else if(window.ActiveXObject) {	// for Internet Explorer 5 or 6
    xmlHttp = new ActiveXObject("Microsoft.XMLHTTP");
  }
  return xmlHttp;
}
</script>
<script type="text/javascript">
$(document).ready(function() {
	$(".various").fancybox({
		maxWidth	: 800,
		maxHeight	: 600,
		fitToView	: false,
		width		: '70%',
		height		: '70%',
		autoSize	: false,
		closeClick	: false,
		openEffect	: 'none',
		closeEffect	: 'none'
	});
	$('.fancybox').fancybox();
	$("html").niceScroll({styler:"fb",cursorcolor:"#000"});
});
</script>
  </head>
   <body>

	<div class="balloon"></div>
<?php
//echo '<h2 style="background-color:deepskyblue;color:black;">'.$tit.' '.$tit2.'</H2>';
echo '<table border="0" width="100%" style="background-color: lightskyblue;color:black">
<TR>
<TD><font size="5"><b>'.$tit." ".$sezon."x".$episod." - ".$tit2.'</b></font></td>

<TD align="right">
<a onclick="ajaxrequest2()" style="cursor:pointer;"><font size="5"><b>Apasa aici daca lista e goala!</b></font></a></td>
</tr></table><BR>
';
if ($tip=="movie") {
//echo $imdbid;
$request="<?xml version=\"1.0\" encoding=\"iso-8859-1\"?>
<methodCall>
<methodName>SearchSubtitles</methodName>
<params>
 <param>
  <value>
   <string>".$token."</string>
  </value>
 </param>
 <param>
  <value>
   <array>
    <data>
     <value>
      <struct>
       <member>
        <name>query</name>
        <value>
         <string>".str_replace("&","&amp;",$tit)."</string>
        </value>
       </member>
       <member>
        <name>imdbid</name>
        <value>
         <string>".$imdbid."</string>
        </value>
       </member>
       <member>
        <name>sublanguageid</name>
        <value>
         <string>rum,eng</string>
        </value>
       </member>
      </struct>
     </value>
    </data>
   </array>
  </value>
 </param>
 <param>
  <value>
   <struct>
    <member>
     <name>limit</name>
     <value>
      <int>100</int>
     </value>
    </member>
   </struct>
  </value>
 </param>
</params>
</methodCall>";
//echo $request;
$response = generateResponse($request);
//echo $response;
$videos=explode("MatchedBy",$response);
unset($videos[0]);
$videos = array_values($videos);
$arrsub = array();
foreach($videos as $video) {
 $MovieKind = get_value("MovieKind",$video);
 $SubFormat = get_value("SubFormat",$video);
 if ($MovieKind == "movie" && $SubFormat == "srt") {
   $SubFileName =get_value("SubFileName",$video);
   $id1 = get_value("IDSubtitleFile",$video);
   $SubLanguageID = get_value("SubLanguageID",$video);
   //if ($SubLanguageID == "rum") break;
   $id2=get_value("IDSubtitleFile",$video);
   array_push($arrsub ,array($SubFileName,$SubLanguageID, $id2));
 }
}
} else {
$request="<?xml version=\"1.0\" encoding=\"iso-8859-1\"?>
<methodCall>
<methodName>SearchSubtitles</methodName>
<params>
 <param>
  <value>
   <string>".$token."</string>
  </value>
 </param>
 <param>
  <value>
   <array>
    <data>
     <value>
      <struct>
       <member>
        <name>query</name>
        <value>
         <string>".str_replace("&","&amp;",$tit)."</string>
        </value>
       </member>
       <member>
        <name>imdbid</name>
        <value>
         <string>".$imdbid."</string>
        </value>
       </member>
       <member>
        <name>season</name>
        <value>
         <int>".$sezon."</int>
        </value>
       </member>
       <member>
        <name>episode</name>
        <value>
         <int>".$episod."</int>
        </value>
       </member>
       <member>
        <name>sublanguageid</name>
        <value>
         <string>rum,eng</string>
        </value>
       </member>
      </struct>
     </value>
    </data>
   </array>
  </value>
 </param>
 <param>
  <value>
   <struct>
    <member>
     <name>limit</name>
     <value>
      <int>100</int>
     </value>
    </member>
   </struct>
  </value>
 </param>
</params>
</methodCall>";
//echo $request;
$response = generateResponse($request);
//echo $response;
$videos=explode("MatchedBy",$response);
unset($videos[0]);
$videos = array_values($videos);
$arrsub = array();
foreach($videos as $video) {
 //echo $video;
 $MovieKind = get_value("MovieKind",$video);
 $SubFormat = get_value("SubFormat",$video);
 //echo $MovieKind." ".$SubFormat."<BR>";
 if ($MovieKind == "episode" && $SubFormat == "srt") {
   $SubFileName =get_value("SubFileName",$video);
   $id1 = get_value("IDSubtitleFile",$video);
   $SubLanguageID = get_value("SubLanguageID",$video);
   //if ($SubLanguageID == "rum") break;
   $id2=get_value("IDSubtitleFile",$video);
   array_push($arrsub ,array($SubFileName,$SubLanguageID, $id2));
 }
}
}
//print_r ($arrsub);
$nn=count($arrsub);
echo '<p><b>Alegeti un server: </b><select name="server" id="server">';
 $videos = explode('go.php', $html);
unset($videos[0]);
$videos = array_values($videos);
foreach($videos as $video) {
  //$t1=explode('href="',$video);
  $t2=explode('"',$video);
  $t3=explode("&",$t2[0]);
  $openload="http://www.watchfree.to/go.php".$t3[0];
  $server = str_between($video,"</strong>","<");
  $server=trim(str_replace("-","",$server));
  if ($openload && $server) echo '<option value="'.urlencode($openload).'">'.$server.'</option>';
}
echo '</select>';
echo '<p><b>  Alegeti o subtitrare: </b><select name="menu" id="menu">';
echo '<option value="">fara subtitrare</option>';
for ($k=0;$k<$nn;$k++) {
  echo '<option value="'.$arrsub[$k][2].'">'.$arrsub[$k][1]." - ".$arrsub[$k][0].'</option>';
}
echo '</select>';
echo '<input type="submit" value="Vizioneaza!" onclick="myFunc()";>
</p>';
echo '<br></body>
</html>';

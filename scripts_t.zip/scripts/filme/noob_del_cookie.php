<?php
include ("../common.php");
$cookie=$base_cookie."noob.dat";
$cookie1=$base_cookie."noob.txt";
$noob_serv=$base_cookie."noob_serv.dat";
$ff=$base_cookie."n.dat";
unlink($cookie);
unlink($cookie1);
unlink($noob_serv);
unlink($ff);
echo "Am sters cookie. Regeneram....";
?>

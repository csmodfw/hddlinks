<?php
include ("../common.php");
$cookie=$base_cookie."noob.dat";
$cookie1=$base_cookie."noob.txt";
$noob_serv=$base_cookie."noob_serv.dat";
$ff=$base_cookie."n.dat";
$noob_cookie=$base_fav."noob_cookie.dat";
unlink($cookie);
unlink($cookie1);
unlink($noob_serv);
unlink($ff);
unlink ($noob_cookie);
echo "Am sters cookie. Regeneram....";
?>

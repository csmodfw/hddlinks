<!DOCTYPE html>
<?php
include ("../common.php");
$query = $_GET["page"];
if($query) {
   $queryArr = explode(',', $query);
   $page = $queryArr[0];
   $search = $queryArr[1];
   $page_title=urldecode($queryArr[2]);
   $search=str_replace("|","&",$search);
}
?>
<html><head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate"/>
<meta http-equiv="Pragma" content="no-cache"/>
<meta http-equiv="Expires" content="0"/>
      <title><?php echo $page_title; ?></title>
<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.8.0/jquery.min.js"></script>
<script src="../jquery.nicescroll.min.js"></script>

<script type="text/javascript">
  $(document).ready(function() {
	$("html").niceScroll({styler:"fb",cursorcolor:"#000"});
  });
</script>
<link rel="stylesheet" type="text/css" href="../custom.css" />
</head>
<body>
<H2></H2>
<?php
function str_between($string, $start, $end){
	$string = " ".$string; $ini = strpos($string,$start);
	if ($ini == 0) return ""; $ini += strlen($start); $len = strpos($string,$end,$ini) - $ini;
	return substr($string,$ini,$len);
}
$n=0;
echo '<h2 style="background-color:deepskyblue;color:black">'.$page_title.'</H2>';
echo '<table border="1px" width="100%">'."\n\r";
echo '<tr><TD colspan="4" align="right">';
if ($page > 1)
echo '<a href="onlinehd.php?page='.($page-1).','.$search.','.urlencode($page_title).'"><font size="4">&nbsp;&lt;&lt;&nbsp;</font></a> | <a href="onlinehd.php?page='.($page+1).','.$search.','.urlencode($page_title).'"><font size="4">&nbsp;&gt;&gt;&nbsp;</font></a></TD></TR>';
else
echo '<a href="onlinehd.php?page='.($page+1).','.$search.','.urlencode($page_title).'"><font size="4">&nbsp;&gt;&gt;&nbsp;</font></a></TD></TR>';
$l="http://creativemonkeyz.com/recomand/wp-admin/admin-ajax.php";
$post="page=".$page."&order_by=&order_direction=&search_title=&action=load_more_posts";
  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $l);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US; rv:1.9.1.2) Gecko/20090729 Firefox/3.5.2 GTB5');
  curl_setopt($ch, CURLOPT_FOLLOWLOCATION  ,1);
  curl_setopt($ch,CURLOPT_REFERER,"http://creativemonkeyz.com/recomand/");
  curl_setopt($ch, CURLOPT_HTTPHEADER, array("Content-Type: application/x-www-form-urlencoded; charset=UTF-8","X-Requested-With: XMLHttpRequest", "Content-Length: ".strlen($post)));
  curl_setopt ($ch, CURLOPT_POST, 1);
  curl_setopt ($ch, CURLOPT_POSTFIELDS, $post);
  //curl_setopt($ch, CURLOPT_COOKIEJAR, $cookie);
  //curl_setopt($ch, CURLOPT_COOKIEFILE, $cookie);
  $html = curl_exec($ch);
  curl_close($ch);
  $html=str_replace("\\","",$html);
  $html=str_replace("u0","\u0",$html);
$videos = explode('id="post-', $html);

unset($videos[0]);
$videos = array_values($videos);

foreach($videos as $video) {
    $t1 = explode('href="', $video);
    $t2 = explode('"', $t1[3]);
    $link = $t2[0];

    //$image = "/usr/local/etc/www/cgi-bin/scripts/clip/image/roboti.jpg";
    $image=str_between($video,'name="image" value="','"');
    $t2=explode(">",$t1[3]);
    $t3=explode("<",$t2[1]);
    $title = $t3[0];
    //iframe src="http://player.vimeo.com/video/58950611?badge=0"
    //data="http://www.youtube.com/v/kVuVhcdQs0k"
    $descriere=str_between($video,"<p>","</p>");
	$descriere = preg_replace("/(<\/?)(\w+)([^>]*>)/e","",$descriere);
    //$descriere = fix_s($descriere);
    $l=str_between($video,'iframe src="','"');
    if (!$l)
    $l=str_between($video,'data="','"');
     if ($l) {
    $link = 'roboti_link1.php?file='.urlencode($l);
  if ($n==0) echo '<TR>';
  echo '<TD><table width="100%" border="0">';
  echo '<TR>';
  echo '<td align="center"><a href="'.$link.'&title='.$title.'" target="_blank"><img src="'.$image.'" width="240px" height="170px"><BR><font size="4">'.$title.'</font></a></TD>';
  echo '<td style="vertical-align:top;">'.$descriere.'</td>';
  echo '</tr>';
  echo '</table></TD>';
  $n++;
  if ($n==2) {
  echo "</TR>";
  $n=0;
  }
  }
}
echo '<tr><TD colspan="4" align="right">';
if ($page > 1)
echo '<a href="recomand.php?page='.($page-1).','.$search.','.urlencode($page_title).'"><font size="4">&nbsp;&lt;&lt;&nbsp;</font></a> | <a href="recomand.php?page='.($page+1).','.$search.','.urlencode($page_title).'"><font size="4">&nbsp;&gt;&gt;&nbsp;</font></a></TD></TR>';
else
echo '<a href="recomand.php?page='.($page+1).','.$search.','.urlencode($page_title).'"><font size="4">&nbsp;&gt;&gt;&nbsp;</font></a></TD></TR>';
echo "</table>";
?>
<br></body>
</html>

<?php
include ("../common.php");
$link=$_POST["link"];
$new_file = $base_cookie."captcha.dat";
$fh = fopen($new_file, 'w');
fwrite($fh, $link);
fclose($fh);
print "OK";
?>

<?php
function s_dec($s) {

	$sA = str_split($s);

	$tS = $sA[0];
	$sA[0] = $sA[20 % count($sA)];
	$sA[20] = $tS;

	$sA = array_slice($sA,2);
	$tS = $sA[0];
	$sA[0] = $sA[11 % count($sA)];
	$sA[11] = $tS;

	$sA = array_slice($sA,3);
	$sA = array_reverse($sA);

	$sA = array_slice($sA,1);
	$tS = $sA[0];
	$sA[0] = $sA[2 % count($sA)];
	$sA[2] = $tS;

	$tS = $sA[0];
	$sA[0] = $sA[15 % count($sA)];
	$sA[15] = $tS;

	return implode($sA);
}
//https://s.ytimg.com/yts/jsbin/html5player-en_US-vflnSSUZV/html5player.js
?>

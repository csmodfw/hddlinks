<?php
function s_dec($s) {
/*
	By: Nick A. Gaun
	Sekator500 <sekator500@gmail.com>
*/

	$sA = str_split($s);
	$sA = array_reverse($sA);
	$sA = array_slice($sA,3);
	$tS = $sA[0];
	$sA[0] = $sA[19 % count($sA)];
	$sA[19] = $tS;
	$sA = array_reverse($sA);
	$sA = array_slice($sA,2);

	return implode($sA);
}
$sig="23C1248AC9E64AAE5980F3D1CF2654A040FB9C8C.D796412158D91DA55B54C8816AB480898A334C9D";
echo s_dec($sig);
//C1248AC9E64AAE5980F3D1CF2654A040FB9C8C.D796412158D91DA55454C8816AB480898A33B
//0F561E630544AB66F7B7B62E7805DECE6AECA467.42FE70B9AAEE54D5E2D9165F3F6FCACD52639758
//s.ytimg.com/yts/jsbin/html5player-vfltdb6U3.js
//s.ytimg.com/yts/jsbin/html5player-ro_RO-vflNw4AOi/html5player.js
?>

<!DOCTYPE html>
<?php
include ("../common.php");
$query = $_GET["query"];
if($query) {
   $queryArr = explode(',', $query);
   $link = urldecode($queryArr[0]);
   $page_title=urldecode($queryArr[1]);
}
  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $link);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US; rv:1.9.1.2) Gecko/20090729 Firefox/3.5.2 GTB5');
  curl_setopt($ch, CURLOPT_FOLLOWLOCATION  ,1);
  $html = curl_exec($ch);
  curl_close($ch);
$t=explode('class="filmaltiimg"',$html);
$t1=explode('src="',$t[1]);
$t2=explode('"',$t1[1]);
$img=$t2[0];
if (strpos($img,"http") === false)
  $img="http://serialetv.net/Seriale/".$t2[0];
$desc=str_between($html,'class="filmaltiaciklama">','</div');
$desc = trim(preg_replace("/<(.*)>|(\{(.*)\})/e","",$desc));
//if (!$desc) {
?>
<html><head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate"/>
<meta http-equiv="Pragma" content="no-cache"/>
<meta http-equiv="Expires" content="0"/>
      <title><?php echo $page_title; ?></title>
<script src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
<link rel="stylesheet" type="text/css" href="../custom.css" />
</head>
<body>
<H2></H2>
<?php
function str_between($string, $start, $end){
	$string = " ".$string; $ini = strpos($string,$start);
	if ($ini == 0) return ""; $ini += strlen($start); $len = strpos($string,$end,$ini) - $ini;
	return substr($string,$ini,$len);
}
echo '<h2 style="background-color:deepskyblue;color:black">'.$page_title.'</H2>';
echo '<table border="0">'."\n\r";
echo '<tr>'."\n\r";
$html=str_between($html,'div class="keremiya_part"','</div');
$videos = explode('href="', $html);

unset($videos[0]);
$videos = array_values($videos);
foreach($videos as $video) {
   $t2=explode('"',$video);
   $link="http://serialetv.net/".$t2[0];

   $title=str_between($video,'<span>','</span>');
   $link="serialetv_ep.php?file=".urlencode($link).",".urlencode($page_title." - ".$title);
   echo '<td><font size="4"><a href="'.$link.'" target="_blank"><font size="4">'.$title.'&nbsp;|&nbsp;</font></a></td>';
}
echo '</tr></table><br>';
echo '<table border="0" width="100%"><tr>'."\n\r";
echo '<td align="center"><img src="'.$img.'" height="160px" width="115px"></td>';
echo '<td style=vertical-align:top;">'.$desc.'</td></tr></table>';
?>
<br></body>
</html>

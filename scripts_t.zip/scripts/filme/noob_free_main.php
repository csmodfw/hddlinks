<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
      <title>Noobroom</title>
<link rel="stylesheet" type="text/css" href="../custom.css" />
<script src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
<script type="text/javascript">
    function myFunc(url2) {
         msg = 'noob_free.php?page=1&query=' + url2 + '&sub=' + document.getElementById('sub').value + '&alf=NU';
         window.open(msg);
    }
</script>
<script type="text/javascript">
// create the XMLHttpRequest object, according browser
function get_XmlHttp() {
  // create the variable that will contain the instance of the XMLHttpRequest object (initially with null value)
  var xmlHttp = null;
  if(window.XMLHttpRequest) {		// for Forefox, IE7+, Opera, Safari, ...
    xmlHttp = new XMLHttpRequest();
  }
  else if(window.ActiveXObject) {	// for Internet Explorer 5 or 6
    xmlHttp = new ActiveXObject("Microsoft.XMLHTTP");
  }
  return xmlHttp;
}

// sends data to a php file, via POST, and displays the received answer
function ajaxrequest(title, link) {
  var request =  get_XmlHttp();		// call the function for the XMLHttpRequest instance

  // create pairs index=value with data that must be sent to server
  //var the_data = {mod:add,title:title, link:link}; //Array
  var the_data = 'sub='+ document.getElementById('sub').value +'&alf='+document.getElementById('alf').value;
  var php_file='noob_extra.php';
  request.open("POST", php_file, true);			// set the request

  // adds a header to tell the PHP script to recognize the data as is sent via POST
  request.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
  request.send(the_data);		// calls the send() method with datas as parameter

  // Check request status
  // If the response is received completely, will be transferred to the HTML tag with tagID
  request.onreadystatechange = function() {
    if (request.readyState == 4) {
      alert (request.responseText);
    }
  }
}
function ajaxrequest2() {
  var request =  get_XmlHttp();		// call the function for the XMLHttpRequest instance

  // create pairs index=value with data that must be sent to server
  //var the_data = {mod:add,title:title, link:link}; //Array
  var the_data = '';
  var php_file='noob_del_cookie.php';
  request.open("POST", php_file, true);			// set the request

  // adds a header to tell the PHP script to recognize the data as is sent via POST
  request.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
  request.send(the_data);		// calls the send() method with datas as parameter

  // Check request status
  // If the response is received completely, will be transferred to the HTML tag with tagID
  request.onreadystatechange = function() {
    if (request.readyState == 4) {
      alert (request.responseText);
      location.reload();
    }
  }
}
function ajaxrequest3() {
  var request =  get_XmlHttp();		// call the function for the XMLHttpRequest instance

  // create pairs index=value with data that must be sent to server
  //var the_data = {mod:add,title:title, link:link}; //Array
  var the_data = '';
  var php_file='noob_save_cookie.php';
  request.open("POST", php_file, true);			// set the request

  // adds a header to tell the PHP script to recognize the data as is sent via POST
  request.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
  request.send(the_data);		// calls the send() method with datas as parameter

  // Check request status
  // If the response is received completely, will be transferred to the HTML tag with tagID
  request.onreadystatechange = function() {
    if (request.readyState == 4) {
      alert (request.responseText);
      location.reload();
    }
  }
}
</script>
</head>
<body>
<?php
error_reporting(0);
function str_between($string, $start, $end){
	$string = " ".$string; $ini = strpos($string,$start);
	if ($ini == 0) return ""; $ini += strlen($start); $len = strpos($string,$end,$ini) - $ini;
	return substr($string,$ini,$len);
}
include ("../common.php");
$cookie=$base_cookie."noob.dat";
$filename=$base_pass."amigo.txt";
$noob_log=$base_pass."noob_log.txt";
$noob_serv=$base_cookie."noob_serv.dat";
$ff=$base_cookie."n.dat";
$noob_extra=$base_fav."noob_extra.dat";
$check="http://hddlinks.pht.ro/c.php?";
$check="http://hdforall.freehostia.com/c.php?";
echo '<BR><table border="0" width="100%" style="background-color: lightskyblue;color:black">
<TR>
<TD><font size="5"><b>Noobroom (free)</b></font></td>
';
echo '
</table><BR>
';
if (!file_exists($noob_extra)) {
$sub="DA";
$alf="NU";
} else {
  $handle = fopen($noob_extra, "r");
  $c = fread($handle, filesize($noob_extra));
  fclose($handle);
  $a=explode("|",$c);
  $sub=trim($a[0]);
  $alf=trim($a[1]);
}

$noob="http://superchillin.com";



		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL, "http://uphero.xpresso.eu/srt/noob_serv.dat");
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
		curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US; rv:1.9.1.2) Gecko/20090729 Firefox/3.5.2 GTB5');
		curl_setopt($ch, CURLOPT_FOLLOWLOCATION  ,1);
		$h = curl_exec($ch);

		$fh = fopen($noob_serv, 'w');
		fwrite($fh, $h);
		fclose($fh);


$n=0;

echo '<table border="1" width="100%">';

echo '<TR><TD style="background-color: lightskyblue;color:black" colspan="3" align="center"><font size="5"><b>FILME</b></font></TD></TR>';
echo '<TR><TD align="left"><font size="4">Doar filme subtitrate: <select name="sub" id="sub">';
if ($sub=="DA")
echo '<option value="DA" selected>DA</option><option value="NU">NU</option></select></TD>';
else
echo '<option value="DA">DA</option><option value="NU" selected>NU</option></select></TD>';
/*
echo '<TD align="left"><font size="4">Sorteaza alfabetic: <select name="alf" id="alf">';

if ($alf=="DA")
echo '<option value="DA" selected>DA</option><option value="NU">NU</option></select></TD>';
else
echo '<option value="DA">DA</option><option value="NU" selected>NU</option></select></TD>';
echo '<TD colspan="2"><input type="submit" value="Memoreaza optiunile" onclick="ajaxrequest()";></TD></TR>';
*/
echo "<TD></TD><TD></TD></TR>";
 echo '<TR><TD><a href="noob_free_fav.php" target="_blank"><font size="5"><b>Filme favorite</b></font></a></TD>';
 echo '<TD colspan="2"><form action="noob_free_search.php" target="_blank"><font size="5"><b>Cauta film: <input type="text" id="src" name="src"><input type="submit" id="send" name="send" value="cauta"></b></font></form></TD></TR>';
echo '<TR>';
$link=$noob."/latest.php";
$title="Latest";

 echo '<TD><font size="4">'.'<a href="javascript:myFunc(\''.urlencode($link).'&limit=&title='.$title.'\');">'.$title.'</a></font>';
 echo '</TD>';

$title="Ultimele Subtitrate";

 echo '<TD><font size="4">'.'<a href="noob_free_sub.php?limit=&title='.$title.'" target="_blank">'.$title.'</a></font>';
 echo '</TD>';

 $title="Year";
 $link=$noob."/year.php";

 echo '<TD><font size="4">'.'<a href="javascript:myFunc(\''.urlencode($link).'&limit=&title='.$title.'\');">'.$title.'</a></font>';
 echo '</TD>';

 echo '</TR>';




?>
</table>
</body>
</html>

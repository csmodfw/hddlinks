<!DOCTYPE html>
<?php
include ("../common.php");
$query = $_GET["page"];
if($query) {
   $queryArr = explode(',', $query);
   $page = $queryArr[1];
   $search = $queryArr[0];
   $page_title=urldecode($queryArr[2]);
   $search=str_replace("|","&",$search);
}
$page_title="filme9";
$l="http://www.filme9.com/seriale/pagina-".$page."/";
$html= file_get_contents($l);
//echo $html;

?>
<html><head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate"/>
<meta http-equiv="Pragma" content="no-cache"/>
<meta http-equiv="Expires" content="0"/>
      <title><?php echo $page_title; ?></title>
<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.8.0/jquery.min.js"></script>
<script src="../jquery.nicescroll.min.js"></script>
<script type="text/javascript">
// create the XMLHttpRequest object, according browser
function get_XmlHttp() {
  // create the variable that will contain the instance of the XMLHttpRequest object (initially with null value)
  var xmlHttp = null;
  if(window.XMLHttpRequest) {		// for Forefox, IE7+, Opera, Safari, ...
    xmlHttp = new XMLHttpRequest();
  }
  else if(window.ActiveXObject) {	// for Internet Explorer 5 or 6
    xmlHttp = new ActiveXObject("Microsoft.XMLHTTP");
  }
  return xmlHttp;
}

// sends data to a php file, via POST, and displays the received answer
function ajaxrequest(title, link) {
  var request =  get_XmlHttp();		// call the function for the XMLHttpRequest instance

  // create pairs index=value with data that must be sent to server
  //var the_data = {mod:add,title:title, link:link}; //Array
  var the_data = 'mod=add&title='+ title +'&link='+link;
  var php_file='filme9_add.php';
  request.open("POST", php_file, true);			// set the request

  // adds a header to tell the PHP script to recognize the data as is sent via POST
  request.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
  request.send(the_data);		// calls the send() method with datas as parameter

  // Check request status
  // If the response is received completely, will be transferred to the HTML tag with tagID
  request.onreadystatechange = function() {
    if (request.readyState == 4) {
      alert (request.responseText);
    }
  }
}
</script>
<script type="text/javascript">
  $(document).ready(function() {
	$("html").niceScroll({styler:"fb",cursorcolor:"#000"});
  });
</script>
<link rel="stylesheet" type="text/css" href="../custom.css" />
</head>
<body>
<H2></H2>
<?php
function str_between($string, $start, $end){
	$string = " ".$string; $ini = strpos($string,$start);
	if ($ini == 0) return ""; $ini += strlen($start); $len = strpos($string,$end,$ini) - $ini;
	return substr($string,$ini,$len);
}
$n=0;
echo '<h2 style="background-color:deepskyblue;color:black">'.$page_title.'</H2>';
echo '<table border="1px" width="100%">'."\n\r";
echo '<TR><TD><font size="4">'.'<a href="filme9_fav.php" target="_blank"><b>Favorite</b></a></font></TD>
<TD colspan="3"><font size="4"><form action="filme9_s.php" target="_blank">Cautare serial:  <input type="text" id="page" name="page"><input type="submit" value="send"></form></font></td>
</TR>';
if ($page) {
echo '<tr><TD colspan="4" align="right">';

if ($page > 1)
echo '<a href="filme9s.php?page='.$search.','.($page-1).','.urlencode($page_title).'"><font size="4">&nbsp;&lt;&lt;&nbsp;</font></a> | <a href="filme9s.php?page='.$search.','.($page+1).','.urlencode($page_title).'"><font size="4">&nbsp;&gt;&gt;&nbsp;</font></a></TD></TR>';
else
echo '<a href="filme9s.php?page='.$search.','.($page+1).','.urlencode($page_title).'"><font size="4">&nbsp;&gt;&gt;&nbsp;</font></a></TD></TR>';
}

$videos = explode('<div class="serial', $html);

unset($videos[0]);
$videos = array_values($videos);

foreach($videos as $video) {
	$t1 = explode('href="', $video);
	$t2 = explode('"', $t1[1]);
	$link = $t2[0];

	$t1 = explode('src="', $video);
	$t2 = explode('"', $t1[1]);
	$image = $t2[0];

	$t1 = explode('class="nume">', $video);
	$t2 = explode('<', $t1[1]);
	$title=$t2[0];

	if ($title <> ""){
    //$link = 'filme_link.php?file='.$link.','.urlencode($title);
  if ($n==0) echo '<TR>';
  echo '<td align="center" width="25%"><a href="filme9z.php?file='.urlencode($link).','.urlencode($title).'" target="_blank"><img src="'.$image.'" width="200px" height="95px"><BR><font size="4">'.$title.'</font></a>';
  echo ' <a onclick="ajaxrequest('."'".$title."', '".$link."')".'"'." style='cursor:pointer;'>".'<font size="4"> (FAV)</font></a></TD>'."\n\r";
  $n++;
  if ($n == 4) {
  echo '</tr>';
  $n=0;
  }
}
}
if ($page) {
echo '<tr><TD colspan="4" align="right">';

if ($page > 1)
echo '<a href="filme9s.php?page='.$search.','.($page-1).','.urlencode($page_title).'"><font size="4">&nbsp;&lt;&lt;&nbsp;</font></a> | <a href="filme9s.php?page='.$search.','.($page+1).','.urlencode($page_title).'"><font size="4">&nbsp;&gt;&gt;&nbsp;</font></a></TD></TR>';
else
echo '<a href="filme9s.php?page='.$search.','.($page+1).','.urlencode($page_title).'"><font size="4">&nbsp;&gt;&gt;&nbsp;</font></a></TD></TR>';
}
echo "</table>";
?>
<br></body>
</html>

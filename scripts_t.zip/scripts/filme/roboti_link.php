<?php
set_time_limit(0);
error_reporting(0);
function str_between($string, $start, $end){
	$string = " ".$string; $ini = strpos($string,$start);
	if ($ini == 0) return ""; $ini += strlen($start); $len = strpos($string,$end,$ini) - $ini;
	return substr($string,$ini,$len);
}
function s_dec($s) {
/*
	By: Nick A. Gaun
	Sekator500 <sekator500@gmail.com>
*/

	$sA = str_split($s);
	$sA = array_reverse($sA);
	$sA = array_slice($sA,3);
	$tS = $sA[0];
	$sA[0] = $sA[19 % count($sA)];
	$sA[19] = $tS;
	$sA = array_reverse($sA);
	$sA = array_slice($sA,2);

	return implode($sA);
}
include ("../common.php");
$id="";
if (file_exists($base_pass."player.txt")) {
$flash=trim(file_get_contents($base_pass."player.txt"));
} else {
$flash="direct";
}
$cookie=$base_cookie."vimeo.dat";
$link = $_GET["file"];
$title = $_GET["title"];
$link=urldecode($link);
$a_itags=array(37,22,18);
$html = file_get_contents($link);
if(preg_match_all("/(\/\/.*?)(\"|\')+/i",$html,$matches)) {
$links=$matches[1];
//print_r ($links);
}
$s="/youtube|player\.vimeo\.com/i";
for ($i=0;$i<count($links);$i++) {
  $cur_link="http:".$links[$i];
  //echo $cur_link."<BR>";
  if (strpos($cur_link,"player.vimeo.com") !== false) {
      if (strpos($cur_link,"?") !== false) {
      $id=str_between($cur_link,"video/","?");
      $cur_link="http://player.vimeo.com/video/".$id;
      }
      break;
} elseif(preg_match('/youtube\.com\/(v\/|watch\?v=|embed\/)([\w\-]+)/', $cur_link, $match)) {
  $id = $match[2];
  //$link = 'http://www.youtube.com/get_video_info?&video_id=' . $id . '&el=vevo&ps=default';
  $l = 'http://www.youtube.com/get_video_info?&video_id=' . $id . '&el=leanback&ps=xl&eurl=https://s.ytimg.com/yts/swfbin/apiplayer-vflhRmAoN.swf&hl=en_US&sts=1588';
  //echo $link;
  //$html=file_get_contents($link);
  //$html = urldecode($html);
  //$link   = "http://www.youtube.com/watch?v=".$id;
  //echo $link;
  $html="";
  $p=0;
  while($html == "" && $p<10) {
  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $l);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 5.1; rv:22.0) Gecko/20100101 Firefox/22.0');
  curl_setopt($ch, CURLOPT_FOLLOWLOCATION  ,1);
  $html = curl_exec($ch);
  curl_close($ch);
  $p++;
  }
  //echo $html;
  //preg_match('#config = {(?P<out>.*)};#im', $html, $out);
  //$parts  = json_decode('{'.$out['out'].'}', true);
  //print_r ($parts);
  //$videos = explode(',', $parts['args']['url_encoded_fmt_stream_map']);
  parse_str($html,$parts);
  $videos = explode(',',$parts['url_encoded_fmt_stream_map']);
foreach ($videos as $video) {
//		$vid = urldecode(urldecode($video));
		//$vid = str_replace(array('sig=', '---'), array('signature=', '.'), $vid);
/**		$vid=str_replace('"',"",$vid);
		$vid=str_replace('sig=',"signature=",$vid);
		$vid=str_replace(" ","%20",$vid);
		parse_str($vid, $output);
**/
		parse_str($video, $output);

		if (in_array($output['itag'], $a_itags)) break;
	}
	//$path = $output['url'].'&';
	//echo $path;
//  unset($output['url']);

	//if (isset($output['fexp']))          unset($output['fexp']);
	if (isset($output['type']))          unset($output['type']);
	if (isset($output['mv']))            unset($output['mv']);
	if (isset($output['sver']))          unset($output['sver']);
	if (isset($output['mt']))            unset($output['mt']);
	if (isset($output['ms']))            unset($output['ms']);
	if (isset($output['quality']))       unset($output['quality']);
	if (isset($output['codecs']))        unset($output['codecs']);
	if (isset($output['fallback_host'])) unset($output['fallback_host']);

	//$r=urldecode($path.http_build_query($output));
	if (isset($output['sig'])) {
		$signature=($output['sig']);
	} else {
		$signature=s_dec($output['s']);
	}
	$link=$output['url']."&signature=".$signature;
	$out=$link;
	//echo $out;
     break;
  }
}
if ($id) {
if ($flash=="mpc") {
  $mpc=trim(file_get_contents($base_pass."mpc.txt"));
  $c='"'.$mpc.'" /fullscreen "'.$out.'"';
  pclose(popen($c,"r"));
  echo '<script type="text/javascript">window.close();</script>';
  die();
}
if ($flash=="direct") {
header('Content-type: application/vnd.apple.mpegURL');
header('Content-Disposition: attachment; filename="video.mp4"');
header("Location: $out");
} else {
$movie="//www.youtube.com/embed/".$id;
/*
echo '
<!doctype html>
<HTML>
<HEAD>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body style="margin:0px;padding:0px;overflow:hidden">
    <iframe src="'.$movie.'?rel=0" frameborder="0" style="overflow:hidden;overflow-x:hidden;overflow-y:hidden;height:100%;width:100%;position:absolute;top:0px;left:0px;right:0px;bottom:0px" height="100%" width="100%"></iframe>
</body>
</html>
';
*/
echo '
<!doctype html>
<HTML>
<HEAD>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>'.$title.'</title>
<style type="text/css">
body {
margin: 0px auto;
overflow:hidden;
}
body {background-color:#000000;}
</style>
<script src="//code.jquery.com/jquery-1.11.0.min.js"></script>
'.$jwv.'

</HEAD>
<BODY>
<div id="container"></div>
<script type="text/javascript">
jwplayer("container").setup({
"playlist": [{
"sources": [{"file": "'.$out.'", "type": "mp4"}]
}],
"height": $(document).height(),
"width": $(document).width(),
"skin": '.$skin.',
"autostart": true,
"startparam": "start",
"fallback": false,
"wmode": "direct",
"stagevideo": true
});
</script>
</BODY>
</HTML>
';
}
}
if (strpos($cur_link,'vimeo.com') !==false){
if (strpos($cur_link,"player.vimeo.com") !== false) {
//$link= "http://127.0.0.1/cgi-bin/scripts/util/vimeo.cgi?stream,,".urlencode($cur_link);
     $t1=explode("?",$cur_link);
     $cur_link=$t1[0];
     $t1=explode("/",$cur_link);
     $id=$t1[4];
  } else {
     $t1=explode("/",$cur_link);
     $id=$t1[3];
  }
  $cookie=$base_cookie."vimeo.dat";
  $l="http://vimeo.com/".$id;
  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $l);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US; rv:1.9.1.2) Gecko/20090729 Firefox/3.5.2 GTB5');
  curl_setopt($ch, CURLOPT_FOLLOWLOCATION  ,1);
  curl_setopt($ch, CURLOPT_COOKIEJAR, $cookie);
  curl_setopt($ch, CURLOPT_COOKIEFILE, $cookie);
  $html = curl_exec($ch);
  curl_close($ch);
  $l1=str_between($html,'data-config-url="','"');
  $l1=str_replace("&amp;","&",$l1);
  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $l1);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US; rv:1.9.1.2) Gecko/20090729 Firefox/3.5.2 GTB5');
  curl_setopt($ch, CURLOPT_FOLLOWLOCATION  ,1);
  curl_setopt($ch, CURLOPT_COOKIEFILE, $cookie);
  $h1 = curl_exec($ch);
  curl_close($ch);
  //echo $h1;
  if (strpos($h1,'hd":') !== false) {
    $t1=explode('hd":',$h1);
    $link=str_between($t1[1],'url":"','"');
  } else {
    $t1=explode('sd":',$h1);
    $link=str_between($t1[1],'url":"','"');
  }
  $out=$link;
if ($flash=="direct") {
header('Content-type: application/vnd.apple.mpegURL');
header('Content-Disposition: attachment; filename="video.mp4"');
header("Location: $out");
} else {
echo '
<!doctype html>
<HTML>
<HEAD>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>'.$title.'</title>
<style type="text/css">
body {
margin: 0px auto;
overflow:hidden;
}
body {background-color:#000000;}
</style>
<script src="//code.jquery.com/jquery-1.11.0.min.js"></script>
'.$jwv.'

</HEAD>
<BODY>
<div id="container"></div>
<script type="text/javascript">
jwplayer("container").setup({
"playlist": [{
"sources": [{"file": "'.$out.'", "type": "mp4"}]
}],
"height": $(document).height(),
"width": $(document).width(),
"skin": '.$skin.',
"startparam": "start",
"autostart": true,
"fallback": false,
"wmode": "direct",
"stagevideo": true
});
</script>
</BODY>
</HTML>
';
}
}

?> 

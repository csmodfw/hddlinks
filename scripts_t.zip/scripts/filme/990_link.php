<?php
include ("../common.php");
function str_between($string, $start, $end){
	$string = " ".$string; $ini = strpos($string,$start);
	if ($ini == 0) return ""; $ini += strlen($start); $len = strpos($string,$end,$ini) - $ini;
	return substr($string,$ini,$len);
}
$new_file = $base_sub."990.dat";
if (file_exists($new_file)) unlink($new_file);
$filelink = $_GET["file"];
$t1=explode(",",$filelink);
$filelink = urldecode($t1[0]);
if (sizeof($t1)>1) $pg = urldecode($t1[1]);
if (!$pg) $pg = "play now...";
//$filelink="http://www.990.ro/seriale2-254404-29280-Jessica-Jones-AKA-Ladies-Night-online.html";
echo '
<html><head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">

      <meta charset="utf-8">
      <title>Alege varianta</title>
   	  <link rel="stylesheet" type="text/css" href="../custom.css" />
     <script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.8.0/jquery.min.js"></script>
     <script src="../jquery.nicescroll.min.js"></script>
      <script type="text/javascript" src="../jquery.fancybox.js?v=2.1.5"></script>
      <link rel="stylesheet" type="text/css" href="../jquery.fancybox.css?v=2.1.5" media="screen" />


<script type="text/javascript">
$(document).ready(function() {
	$(".various").fancybox({
		maxWidth	: 800,
		maxHeight	: 600,
		fitToView	: false,
		width		: "70%",
		height		: "70%",
		autoSize	: false,
		closeClick	: false,
		openEffect	: "none",
		closeEffect	: "none"
	});
	$(".fancybox").fancybox();
	$("html").niceScroll({styler:"fb",cursorcolor:"#000"});
});
</script>
</head>
<body>';
echo '<h2 style="background-color:deepskyblue;color:black">'.$pg."</H2>";
echo "<H2>Alegeti una din variantele de mai jos:</H2>";
      $ch = curl_init($filelink);
      curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US; rv:1.9.1.2) Gecko/20090729 Firefox/3.5.2 GTB5');
      curl_setopt($ch,CURLOPT_REFERER,$filelink);
      //curl_setopt($ch, CURLOPT_FOLLOWLOCATION  ,1);
      curl_setopt($ch, CURLOPT_RETURNTRANSFER  ,1);  // RETURN THE CONTENTS OF THE CALL
      $html = curl_exec($ch);
      curl_close ($ch);
      //echo $html;
$t1=explode("Linkuri externe",$html);
$html=$t1[1];
$l=explode("<a class='link",$html);
$k=count($l);
//$d=explode('<div style',$html);
for ($n=1;$n<$k;$n+=2) {
 $a1=explode("player-serial", $l[$n]);
 $a2=explode("'",$a1[1]);
 $link="http://www.990.ro/player-serial".$a2[0];
 if ($n==1) $link_sub=$link;
 $b1=explode("<div style",$l[$n-1]);
 //print_r ($b1);
 $b2=explode(">",$b1[3]);
 $b3=explode("<",$b2[1]);
 $title=trim($b3[0]);
 if (!$title || $title=="FS") {
  $title="Superweb";
 }
  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $link_sub);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 5.1; rv:22.0) Gecko/20100101 Firefox/22.0');
  curl_setopt($ch, CURLOPT_FOLLOWLOCATION  ,1);
  $h = curl_exec($ch);
  curl_close($ch);
  $t1=explode("http://superweb.rol.ro/",$h);
  $t2=explode("'",$t1[1]);
  $filelink="http://superweb.rol.ro/".trim($t2[0]);
  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $filelink);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 5.1; rv:22.0) Gecko/20100101 Firefox/22.0');
  curl_setopt($ch, CURLOPT_FOLLOWLOCATION  ,1);
  $h = curl_exec($ch);
  curl_close($ch);
  $t1=explode("tracks':",$h);
  $t2=explode("'file': ",$t1[1]);
  $t3=explode('"',$t2[1]);
  $srt=$t3[1];
  if (!$srt) $srt=str_between($h,"captions.file': '","'");
  if ($srt) {
   $ch = curl_init();
   curl_setopt($ch, CURLOPT_URL, $srt);
   curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
   curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 5.1; rv:14.0) Gecko/20100101 Firefox/14.0.1');
   curl_setopt($ch, CURLOPT_FOLLOWLOCATION  ,1);
   curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
   $h=curl_exec($ch);
   curl_close($ch);
   $fh = fopen($new_file, 'w');
   fwrite($fh, $h);
   fclose($fh);
  }
 if ($a2[0]) {
 echo '<a href="link1.php?file='.urlencode($link).','.urlencode($pg).'" target="_blank"><font size="6">'.$title.'</font></a><BR>';
 }
}
?>
</body>
</html>

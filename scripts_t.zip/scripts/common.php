<?php
$t1 = dirname($_SERVER['SCRIPT_FILENAME']);
$t1 = substr($t1, 0, strripos($t1,'/scripts'));
if (file_exists("/data/data/ru.kslabs.ksweb/tmp/"))
  $base_cookie="/data/data/ru.kslabs.ksweb/tmp/";
else
  $base_cookie=$t1."/cookie/";
$base_pass=$t1."/parole/";
$base_fav=$t1."/data/";
$base_sub=$t1."/scripts/subs/";
$base_script=$t1."/scripts/";

if (file_exists($base_pass."jwv.txt")) {
$jwv=str_replace(".","/",trim(file_get_contents($base_pass."jwv.txt")));
} else {
$jwv=str_replace(".","/","6.10");
};
$jwl="http://p.jwpcdn.com/".$jwv."/jwplayer.js";
   $ch = curl_init();
   curl_setopt($ch, CURLOPT_URL, $jwl);
   curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
   curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 5.1; rv:14.0) Gecko/20100101 Firefox/14.0.1');
   curl_setopt($ch, CURLOPT_FOLLOWLOCATION  ,1);
   $h=curl_exec($ch);
   curl_close($ch);
   //echo $h;
$jwv='<script src="http://content.jwplatform.com/libraries/XeGdlzmk.js"></script>';
$skin='{
    "name": "beelden",
    "active": "#00bfff",
    "inactive": "#b6b6b6",
    "background": "#282828"
}';
if (strpos($h,"404 Not Found") === false) {
	$jwv='<script src="'.$jwl.'"></script>
<script>jwplayer.key="a90HGmYJwl7ewuxkXqofNd65qdenEdCsdwujA3th0Kc=";</script>';
	$skin='"../hd4all.xml"';
}
?>

<!DOCTYPE html>
<html><head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate"/>
<meta http-equiv="Pragma" content="no-cache"/>
<meta http-equiv="Expires" content="0"/>
<link rel="stylesheet" type="text/css" href="./custom.css" />
      <title>Setari</title>


	  
</head>
<body>
<H2 style="background-color:deepskyblue;color:black;">Setari</H2>
<?php
error_reporting(0);
include ("common.php");
$tip=$_GET["tip"];
if ($tip) {
$user=$_GET["user"];
$user=str_replace("%40","@",$user);
$pass=$_GET["pass"];
if ($tip=="roshare") {
 $txt=$user."|".$pass;
 $new_file = $base_pass."roshare.txt";
 $fh = fopen($new_file, 'w');
 fwrite($fh, $txt);
 fclose($fh);
} elseif ($tip=="player") {
 $txt=$user;
 $new_file = $base_pass."player.txt";
 $fh = fopen($new_file, 'w');
 fwrite($fh, $txt);
 fclose($fh);
} elseif ($tip=="html5") {
 $txt=$user;
 $new_file = $base_pass."html5.txt";
 $fh = fopen($new_file, 'w');
 fwrite($fh, $txt);
 fclose($fh);
} elseif ($tip=="jwv") {
 $txt=$user;
 $new_file = $base_pass."jwv.txt";
 $fh = fopen($new_file, 'w');
 fwrite($fh, $txt);
 fclose($fh);
} elseif ($tip=="tv") {
 $txt=$user;
 $new_file = $base_pass."tv.txt";
 $fh = fopen($new_file, 'w');
 fwrite($fh, $txt);
 fclose($fh);
} elseif ($tip=="spicetv") {
 $txt=$user."|".$pass;
 $new_file = $base_pass."spicetv.txt";
 $fh = fopen($new_file, 'w');
 fwrite($fh, $txt);
 fclose($fh);
} elseif ($tip=="moviesplanet") {
 $txt=$user."|".$pass;
 $new_file = $base_pass."moviesplanet.txt";
 $fh = fopen($new_file, 'w');
 fwrite($fh, $txt);
 fclose($fh);
} elseif ($tip=="movietv") {
 $txt=$user."|".$pass;
 $new_file = $base_pass."movietv.txt";
 $fh = fopen($new_file, 'w');
 fwrite($fh, $txt);
 fclose($fh);
} elseif ($tip=="seenowtv") {
 $txt=$user."|".$pass;
 $new_file = $base_pass."seenowtv.txt";
 $fh = fopen($new_file, 'w');
 fwrite($fh, $txt);
 fclose($fh);
} elseif ($tip=="see_c") {
 $txt=$user;
 $new_file = $base_pass."see_c.txt";
 $fh = fopen($new_file, 'w');
 fwrite($fh, $txt);
 fclose($fh);
} elseif ($tip=="noobroom") {
 $txt=$user."|".$pass;
 $new_file = $base_pass."noob_log.txt";
 $fh = fopen($new_file, 'w');
 fwrite($fh, $txt);
 fclose($fh);
} elseif ($tip=="serialepenet") {
 $txt=$user;
 $new_file = $base_pass."serialepenet.txt";
 $fh = fopen($new_file, 'w');
 fwrite($fh, $txt);
 fclose($fh);
} elseif ($tip=="vplus") {
 $txt=$user."|".$pass;
 $new_file = $base_pass."vplus.txt";
 $fh = fopen($new_file, 'w');
 fwrite($fh, $txt);
 fclose($fh);
} elseif ($tip=="amigo") {
 $txt=$user;
 $new_file = $base_pass."amigo.txt";
 $fh = fopen($new_file, 'w');
 fwrite($fh, $txt);
 fclose($fh);
} elseif ($tip=="delete") {
 $f=$base_pass."noob_log.txt";
 unlink ($f);
} elseif ($tip=="movie-inn") {
 $txt=$user."|".$pass;
 $new_file = $base_pass."movie-inn.txt";
 $fh = fopen($new_file, 'w');
 fwrite($fh, $txt);
 fclose($fh);
} elseif ($tip=="airfun") {
 $txt=$user;
 $new_file = $base_pass."airfun.txt";
 $fh = fopen($new_file, 'w');
 fwrite($fh, $txt);
 fclose($fh);
} elseif ($tip=="grid") {
 $txt=$user;
 $new_file = $base_pass."grid.txt";
 $fh = fopen($new_file, 'w');
 fwrite($fh, $txt);
 fclose($fh);
 } elseif ($tip=="scrollbar") {
 $txt=$user;
 $new_file = $base_pass."scrollbar.txt";
 $fh = fopen($new_file, 'w');
 fwrite($fh, $txt);
 fclose($fh);
 $da=$base_script."jquery.nicescroll.min.js";
 $nu=$base_script."jquery.nicescroll.min1.js";
 if ($txt=="DA") {
  if (file_exists($nu) && !file_exists($da))
    rename ($nu,$da);
 } else {
  if (file_exists($da) && !file_exists($nu))
    rename ($da,$nu);
 }
 } elseif ($tip=="adult") {
 $txt=$user;
 $new_file = $base_pass."adult.txt";
 $fh = fopen($new_file, 'w');
 fwrite($fh, $txt);
 fclose($fh);
} elseif ($tip=="css") {
 $txt=$user;
 $new_file = $base_pass."css.txt";
 $fh = fopen($new_file, 'w');
 fwrite($fh, $txt);
 fclose($fh);
 if ($txt=="ALB") {
 $out='
html { height: 100%;}
body {background-color:White;color:Black;margin:0px 25px 25px 25px;}
.balloon { position: absolute; width: 214px; height: 317px; background: #000; border: 1px solid #fff; z-index: 10; display: none; }
a { text-decoration:none }
a:link {color:Black;}      /* unvisited link */
a:visited {color:Black;}  /* visited link */
a:hover {color:Magenta;}  /* mouse over link */
a:active {color:Magenta;}  /* selected link */';
 $new_file = "custom.css";
 $fh = fopen($new_file, 'w');
 fwrite($fh, $out);
 fclose($fh);
 } else {
 $out='
html { height: 100%;}
body {background-color:Black;color:White;margin:0px 25px 25px 25px;}
.balloon { position: absolute; width: 214px; height: 317px; background: #000; border: 1px solid #fff; z-index: 10; display: none; }
a { text-decoration:none }
a:link {color:White;}      /* unvisited link */
a:visited {color:White;}  /* visited link */
a:hover {color:Magenta;}  /* mouse over link */
a:active {color:Magenta;}  /* selected link */';
 $new_file = "custom.css";
 $fh = fopen($new_file, 'w');
 fwrite($fh, $out);
 fclose($fh);
 }
} elseif ($tip=="220") {
 $txt=$user."|".$pass;
 $new_file = $base_pass."220.txt";
 $fh = fopen($new_file, 'w');
 fwrite($fh, $txt);
 fclose($fh);
} elseif ($tip=="seenow") {
 $txt=$user;
 $new_file = $base_pass."seenow.txt";
 $fh = fopen($new_file, 'w');
 fwrite($fh, $txt);
 fclose($fh);
} elseif ($tip=="seenow1") {
 $txt=$user."|".$pass;
  $l="http://hdforall.freehostia.com/seenow.php?pass=".trim($pass);
  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $l);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US; rv:1.9.1.2) Gecko/20090729 Firefox/3.5.2 GTB5');
  curl_setopt($ch, CURLOPT_FOLLOWLOCATION  ,1);
  $h = curl_exec($ch);
  curl_close($ch);
 if ($h=="OK") {
 $new_file = $base_pass."seenow1.txt";
 $fh = fopen($new_file, 'w');
 fwrite($fh, $txt);
 fclose($fh);
 } else {
  unlink($base_pass."seenow1.txt");
 }
} elseif ($tip=="flash") {
 $txt=$user;
 $new_file = $base_pass."flash.txt";
 $fh = fopen($new_file, 'w');
 fwrite($fh, $txt);
 fclose($fh);
}
}
$user="";
$pass="";
$f=$base_pass."player.txt";
if (file_exists($f)) {
$h=file_get_contents($f);
$t1=explode("|",$h);
$user=$t1[0];
if (sizeof ($t1) > 1 )
	$pass=$t1[1];
} else {
$user="";
$pass="";
}
echo '
<h4>Mod player</h4>
<form action="settings.php">
Selecteaza mod player: <select id="user" name="user">
';
if ($user=="direct") {
echo '
<option value="direct" selected>direct</option>
<option value="flash">flash</option>
<option value="html5">html5</option>';
} elseif ($user=="flash") {
echo '
<option value="direct">direct</option>
<option value="flash" selected>flash</option>
<option value="html5">html5</option>';
} elseif ($user=="html5") {
echo '
<option value="direct">direct</option>
<option value="flash">flash</option>
<option value="html5" selected>html5</option>';
} else {
echo '
<option value="direct" selected>direct</option>
<option value="flash">flash</option>
<option value="html5">html5</option>';
}
echo '</select>
</BR>
<input type="hidden" name="tip" value="player">
<input type="submit" value="Memoreaza">
</form>
<BR>
';
$user="";
$pass="";
$f=$base_pass."html5.txt";
if (file_exists($f)) {
$h=file_get_contents($f);
$t1=explode("|",$h);
$user=$t1[0];
if (sizeof ($t1) > 1 )
	$pass=$t1[1];
} else {
$user="DA";
$pass="";
}
echo '
<form action="settings.php">
ANDROID(YouTube/OK/etc.) force html5: <select id="user" name="user">
';
if ($user=="DA") {
echo '
<option value="DA" selected>DA</option>
<option value="NU">NU</option>';
} else {
echo '
<option value="DA">DA</option>
<option value="NU" selected>NU</option>';
}
echo '</select>
</BR>
<input type="hidden" name="tip" value="html5">
<input type="submit" value="Memoreaza">
</form>
<BR>
';
$user="";
$pass="";
$f=$base_pass."jwv.txt";
if (file_exists($f)) {
$h=file_get_contents($f);
$t1=explode("|",$h);
$user=$t1[0];
if (sizeof ($t1) > 1 )
	$pass=$t1[1];
} else {
$user="";
$pass="";
}
echo '
<form action="settings.php">
Selecteaza ver. jwplayer: <select id="user" name="user">
';
if ($user=="6.10") {
echo '
<option value="6.10" selected>6.10</option>
<option value="6.12">6.12</option>
<option value="7.x">7.x</option>';
} elseif ($user=="6.12") {
echo '
<option value="6.10">6.10</option>
<option value="6.12" selected>6.12</option>
<option value="7.x">7.x</option>';
} elseif ($user=="7.x") {
echo '
<option value="6.10">6.10</option>
<option value="6.12">6.12</option>
<option value="7.x" selected>7.x</option>';
} else {
echo '
<option value="6.10" selected>6.10</option>
<option value="6.12">6.12</option>
<option value="7.x">7.x</option>';
}
echo '</select>
</BR>
<input type="hidden" name="tip" value="jwv">
<input type="submit" value="Memoreaza">
</form>
<BR>
<hr>
';
$f=$base_pass."tv.txt";
if (file_exists($f)) {
$h=file_get_contents($f);
$t1=explode("|",$h);
$user=$t1[0];
if (sizeof ($t1) > 1 )
	$pass=$t1[1];
} else {
$user="";
$pass="";
}
echo '
<h4>Server posturi tv Romania mod flash/html5 (PC)</h4>
<form action="settings.php">
Selecteaza mod: <select id="user" name="user">
';
if ($user=="dinamic") {
echo '
<option value="dinamic" selected>Server dinamic</option>
<option value="fms38.mediadirect.ro">fms38.mediadirect.ro</option>
<option value="vlc">Foloseste vlc</option>';
} elseif ($user=="fms38.mediadirect.ro") {
echo '
<option value="dinamic">Server dinamic</option>
<option value="fms38.mediadirect.ro" selected>fms38.mediadirect.ro</option>
<option value="vlc">Foloseste vlc</option>';
} elseif ($user=="vlc") {
echo '
<option value="dinamic">Server dinamic</option>
<option value="fms38.mediadirect.ro">fms38.mediadirect.ro</option>
<option value="vlc" selected>Foloseste vlc</option>';
} else {
echo '
<option value="dinamic" selected>Server dinamic</option>
<option value="fms38.mediadirect.ro">fms38.mediadirect.ro</option>
<option value="vlc">Foloseste vlc</option>';
}
echo '</select>
</BR>
<input type="hidden" name="tip" value="tv">
<input type="submit" value="Memoreaza">
</form>
<BR>
<hr>
';
$f=$base_pass."airfun.txt";
if (file_exists($f)) {
$h=file_get_contents($f);
$t1=explode("|",$h);
$user=$t1[0];
if (sizeof ($t1) > 1 )
	$pass=$t1[1];
} else {
$user="";
$pass="";
}
echo '
<h4>Mod afisare imagine pentru noobroom</h4>
<form action="settings.php">
Mod imagine: <select id="user" name="user">
';
if ($user=="DA") {
echo '
<option value="DA" selected>mouse over</option>
<option value="NU">click</option>
<option value="grid">grid</option>';
} elseif ($user=="NU") {
echo '
<option value="DA">mouse over</option>
<option value="NU" selected>click</option>
<option value="grid">grid</option>';
} else {
echo '
<option value="DA">mouse over</option>
<option value="NU">click</option>
<option value="grid" selected>grid</option>';
}
echo '</select>
</BR>
<input type="hidden" name="tip" value="airfun">
<input type="submit" value="Memoreaza">
</form>
<BR>
<hr>
';
$f=$base_pass."grid.txt";
if (file_exists($f)) {
$h=file_get_contents($f);
$t1=explode("|",$h);
$user=$t1[0];
if (sizeof ($t1) > 1 )
	$pass=$t1[1];
} else {
$user="25";
$pass="";
}
echo '
<h4>Numar imagini in mod grid la noobroom</h4>
<form action="settings.php">
Nr. imagini/pagina: <select id="user" name="user">
';
if ($user=="25") {
echo '
<option value="25" selected>25</option>
<option value="50">50</option>
<option value="100">100</option>
<option value="250">250</option>
<option value="10000">toate</option>';
} elseif ($user=="50") {
echo '
<option value="25">25</option>
<option value="50" selected>50</option>
<option value="100">100</option>
<option value="250">250</option>
<option value="10000">toate</option>';
} elseif ($user=="100") {
echo '
<option value="25">25</option>
<option value="50">50</option>
<option value="100" selected>100</option>
<option value="250">250</option>
<option value="10000">toate</option>';
} elseif ($user=="250") {
echo '
<option value="25">25</option>
<option value="50">50</option>
<option value="100">100</option>
<option value="250" selected>250</option>
<option value="10000">toate</option>';
} elseif ($user=="10000") {
echo '
<option value="25">25</option>
<option value="50">50</option>
<option value="100">100</option>
<option value="250">250</option>
<option value="10000" selected>toate</option>';
}
echo '</select>
</BR>
<input type="hidden" name="tip" value="grid">
<input type="submit" value="Memoreaza">
</form>
<BR>
<hr>
';
$f=$base_pass."scrollbar.txt";
if (file_exists($f)) {
$h=file_get_contents($f);
$t1=explode("|",$h);
$user=$t1[0];
if (sizeof ($t1) > 1 )
	$pass=$t1[1];
} else {
$user="DA";
$pass="";
}
echo '
<h4>Afiseaza bara de navigare:</h4>
<form action="settings.php">
Scrollbar: <select id="user" name="user">
';
if ($user=="DA") {
echo '
<option value="DA" selected>DA</option>
<option value="NU">NU</option>';
} else {
echo '
<option value="DA">DA</option>
<option value="NU" selected>NU</option>';
}
echo '</select>
</BR>
<input type="hidden" name="tip" value="scrollbar">
<input type="submit" value="Memoreaza">
</form>
<BR>
<hr>
';
$f=$base_pass."seenow.txt";
if (file_exists($f)) {
$h=file_get_contents($f);
$t1=explode("|",$h);
$user=$t1[0];
if (sizeof ($t1) > 1 )
	$pass=$t1[1];
} else {
$user="";
$pass="";
}
echo '
<h4>Potrivire la ecran</h4>
<form action="settings.php">
Potrivire tabel la ecran: <select id="user" name="user">
';
if ($user=="DA") {
echo '
<option value="DA" selected>DA</option>
<option value="NU">NU</option>';
} else {
echo '
<option value="DA">DA</option>
<option value="NU" selected>NU</option>';
}
echo '</select>
</BR>
<input type="hidden" name="tip" value="seenow">
<input type="submit" value="Memoreaza">
</form>
<BR>
<hr>
';
$f=$base_pass."flash.txt";
if (file_exists($f)) {
$h=file_get_contents($f);
$t1=explode("|",$h);
$user=$t1[0];
if (sizeof ($t1) > 1 )
	$pass=$t1[1];
} else {
$user="";
$pass="";
}
echo '
<h4>Flash Radio</h4>
<form action="settings.php">
Flash Radio: <select id="user" name="user">
';
if ($user=="DA") {
echo '
<option value="DA" selected>DA</option>
<option value="NU">NU</option>';
} else {
echo '
<option value="DA">DA</option>
<option value="NU" selected>NU</option>';
}
echo '</select>
</BR>
<input type="hidden" name="tip" value="flash">
<input type="submit" value="Memoreaza">
</form>
<BR>
<hr>
';
$f=$base_pass."css.txt";
if (file_exists($f)) {
$h=file_get_contents($f);
$t1=explode("|",$h);
$user=$t1[0];
if (sizeof ($t1) > 1 )
	$pass=$t1[1];
} else {
$user="";
$pass="";
}
echo '
<h4>Foloseste fundal Alb sau Negru</h4>
<form action="settings.php">
Alege culoare fundal: <select id="user" name="user">
';
if ($user=="ALB") {
echo '
<option value="ALB" selected>ALB</option>
<option value="NEGRU">NEGRU</option>';
} else {
echo '
<option value="ALB">ALB</option>
<option value="NEGRU" selected>NEGRU</option>';
}
echo '</select>
</BR>
<input type="hidden" name="tip" value="css">
<input type="submit" value="Memoreaza">
</form>
<BR>
<hr>
';
$f=$base_pass."220.txt";
if (file_exists($f)) {
$h=file_get_contents($f);
$t1=explode("|",$h);
$user=$t1[0];
if (sizeof ($t1) > 1 )
	$pass=$t1[1];
} else {
$user="";
$pass="";
}
echo '
<h4>Cont 220.ro (free)</h4>
<form action="settings.php">
User:<input type="text" name="user" value="'.$user.'"></BR>
Pass:<input type="password" name="pass" value="'.$pass.'"></BR>
<input type="hidden" name="tip" value="220">
<input type="submit" value="Memoreaza">
</form>
<hr>
';
$f=$base_pass."moviesplanet.txt";
if (file_exists($f)) {
$h=file_get_contents($f);
$t1=explode("|",$h);
$user=$t1[0];
if (sizeof ($t1) > 1 )
	$pass=$t1[1];
} else {
$user="";
$pass="";
}
echo '
<h4>Cont moviesplanet.is</h4>
<form action="settings.php">
User:<input type="text" name="user" value="'.$user.'"></BR>
Pass:<input type="password" name="pass" value="'.$pass.'"></BR>
<input type="hidden" name="tip" value="moviesplanet">
<input type="submit" value="Memoreaza">
</form>
<hr>
';
$f=$base_pass."movietv.txt";
if (file_exists($f)) {
$h=file_get_contents($f);
$t1=explode("|",$h);
$user=$t1[0];
if (sizeof ($t1) > 1 )
	$pass=$t1[1];
} else {
$user="";
$pass="";
}
echo '
<h4>Cont movietv.to</h4>
<form action="settings.php">
User:<input type="text" name="user" value="'.$user.'"></BR>
Pass:<input type="password" name="pass" value="'.$pass.'"></BR>
<input type="hidden" name="tip" value="movietv">
<input type="submit" value="Memoreaza">
</form>
<hr>
';
$f=$base_pass."roshare.txt";
if (file_exists($f)) {
$h=file_get_contents($f);
$t1=explode("|",$h);
$user=$t1[0];
if (sizeof ($t1) > 1 ) 
	$pass=$t1[1];
} else {
$user="";
$pass="";
}
echo '
<h4>Cont roshare.info/rosharing.com (free)</h4>
<form action="settings.php">
User:<input type="text" name="user" value="'.$user.'"></BR>
Pass:<input type="password" name="pass" value="'.$pass.'"></BR>
<input type="hidden" name="tip" value="roshare">
<input type="submit" value="Memoreaza">
</form>
<hr>
';
$f=$base_pass."serialepenet.txt";
if (file_exists($f)) {
$h=file_get_contents($f);
$t1=explode("|",$h);
$user=$t1[0];
if (sizeof ($t1) > 1 ) 
	$pass=$t1[1];
} else {
$user="";
$pass="";
}
echo '
<h4>Cod activare serialepenet.ro</h4>
<form action="settings.php">
cod:<input type="text" name="user" value="'.$user.'"></BR>
<input type="hidden" name="tip" value="serialepenet">
<input type="submit" value="Memoreaza">
</form>
<hr>
';
$f=$base_pass."vplus.txt";
if (file_exists($f)) {
$h=file_get_contents($f);
$t1=explode("|",$h);
$user=$t1[0];
if (sizeof ($t1) > 1 ) 
	$pass=$t1[1];
} else {
$user="";
$pass="";
}
echo '
<h4>Cont vplus.ro (free)</h4>
<form action="settings.php">
User:<input type="text" name="user" value="'.$user.'"></BR>
Pass:<input type="password" name="pass" value="'.$pass.'"></BR>
<input type="hidden" name="tip" value="vplus">
<input type="submit" value="Memoreaza">
</form>
<hr>
';
$f=$base_pass."spicetv.txt";
if (file_exists($f)) {
$h=file_get_contents($f);
$t1=explode("|",$h);
$user=$t1[0];
if (sizeof ($t1) > 1 ) 
	$pass=$t1[1];
} else {
$user="";
$pass="";
}
echo '
<h4>Cont spicetv.ro (free/premium)</h4>
<form action="settings.php">
E-mail:<input type="text" name="user" size="40" value="'.$user.'"></BR>
Pass:<input type="password" name="pass" size="40" value="'.$pass.'"></BR>
<input type="hidden" name="tip" value="spicetv">
<input type="submit" value="Memoreaza">
</form>
<hr>
';
$f=$base_pass."seenowtv.txt";
if (file_exists($f)) {
$h=file_get_contents($f);
$t1=explode("|",$h);
$user=$t1[0];
if (sizeof ($t1) > 1 ) 
	$pass=$t1[1];
} else {
$user="";
$pass="";
}
echo '
<h4>Cont seenow.ro (premium)</h4>
<form action="settings.php">
E-mail:<input type="text" name="user" size="40" value="'.$user.'"></BR>
Pass:<input type="password" name="pass" size="40" value="'.$pass.'"></BR>
<input type="hidden" name="tip" value="seenowtv">
<input type="submit" value="Memoreaza">
</form>
<hr>
';
$f=$base_pass."noob_log.txt";
if (file_exists($f)) {
$h=file_get_contents($f);
$t1=explode("|",$h);
$user=$t1[0];
if (sizeof ($t1) > 1 ) 
	$pass=$t1[1];
} else {
$user="";
$pass="";
}
echo '
<h4>Cont noobroom.com (premium)</h4>
<form action="settings.php">
E-mail:<input type="text" name="user" size="40" value="'.$user.'"></BR>
Pass:<input type="password" name="pass" size="40" value="'.$pass.'"></BR>
<input type="hidden" name="tip" value="noobroom">
<input type="submit" value="Memoreaza">
</form>
<hr>
';
$f=$base_pass."amigo.txt";
if (file_exists($f)) {
$h=file_get_contents($f);
$t1=explode("|",$h);
$user=$t1[0];
if (sizeof ($t1) > 1 ) 
	$pass=$t1[1];
} else {
$user="";
$pass="";
}
echo '
<h4>Cont amigo pentu noobroom.com (premium)</h4>
<form action="settings.php">
cod:<input type="text" name="user" value="'.$user.'"></BR>
<input type="hidden" name="tip" value="amigo">
<input type="submit" value="Memoreaza">
</form>
<BR>
<form action="settings.php">
<input type="hidden" name="tip" value="delete">
<input type="submit" value="Sterge cont noobroom, foloseste cod amigo">
</form>
<BR>
<hr>
';
$f=$base_pass."movie-inn.txt";
if (file_exists($f)) {
$h=file_get_contents($f);
$t1=explode("|",$h);
$user=$t1[0];
if (sizeof ($t1) > 1 ) 
	$pass=$t1[1];
} else {
$user="";
$pass="";
}
echo '
<h4>Cont movie-inn.com</h4>
<form action="settings.php">
E-mail:<input type="text" name="user" size="40" value="'.$user.'"></BR>
Pass:<input type="password" name="pass" size="40" value="'.$pass.'"></BR>
<input type="hidden" name="tip" value="movie-inn">
<input type="submit" value="Memoreaza">
</form>
<hr>
';
$user="";
$pass="";
$f=$base_pass."adult.txt";
if (file_exists($f)) {
$h=file_get_contents($f);
$t1=explode("|",$h);
$user=$t1[0];
if (sizeof ($t1) > 1 )
	$pass=$t1[1];
} else {
$user="";
$pass="";
}
echo '
<h4>Continut (18+)</h4>
<form action="settings.php">
Permite accesul la continut (18+) : <select id="user" name="user">
';
if ($user=="DA") {
echo '
<option value="DA" selected>DA</option>
<option value="NU">NU</option>';
} else {
echo '
<option value="DA">DA</option>
<option value="NU" selected>NU</option>';
}
echo '</select>
</BR>
<input type="hidden" name="tip" value="adult">
<input type="submit" value="Memoreaza">
</form>
<BR>
<hr>
';
$user="";
$pass="";
$f=$base_pass."seenow1.txt";
if (file_exists($f)) {
$h=file_get_contents($f);
$t1=explode("|",$h);
$user=$t1[0];
if (sizeof ($t1) > 1 )
	$pass=$t1[1];
} else {
$user="";
$pass="";
}
echo '
<h4>Acces seenow</h4>
<form action="settings.php">
Permite accesul : <select id="user" name="user">
';
if ($user=="DA") {
echo '
<option value="DA" selected>DA</option>
<option value="NU">NU</option>';
} else {
echo '
<option value="DA">DA</option>
<option value="NU" selected>NU</option>';
}
echo '</select>
</BR>
Pass:<input type="password" name="pass" value="'.$pass.'"></BR>
<input type="hidden" name="tip" value="seenow1">
<input type="submit" value="Memoreaza">
</form>
<BR>
<hr>
';
$f=$base_pass."see_c.txt";
if (file_exists($f)) {
$h=file_get_contents($f);
$t1=explode("|",$h);
$user=$t1[0];
if (sizeof ($t1) > 1 )
	$pass=$t1[1];
} else {
$user="";
$pass="";
}
echo '
<h4>Cod see</h4>
<form action="settings.php">
cod:<input type="text" name="user" value="'.$user.'"></BR>
<input type="hidden" name="tip" value="see_c">
<input type="submit" value="Memoreaza">
</form>
<hr>
';
?>
<BR><BR><BR><BR><BR><BR><BR><BR><BR><BR><BR><BR><BR><BR><BR><BR><BR><BR><BR><BR><BR>
<br></body>
</html>

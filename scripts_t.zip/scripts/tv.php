<!DOCTYPE html>
<html><head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate"/>
<meta http-equiv="Pragma" content="no-cache"/>
<meta http-equiv="Expires" content="0"/>
      <title>Live TV</title>
<link rel="stylesheet" type="text/css" href="custom.css" />
<style>
html { height: 100%;}
.balloon { position: absolute; width: 214px; height: 317px; background: #000; border: 1px solid #fff; z-index: 10; display: none; }
</style>
<BODY>
<div id="mainnav">
<BR><BR>
<table border="1" align="center" width="90%">
<TR>
<td style="color:black;background-color:#0a6996;color:#64c8ff;text-align:center" colspan="4"><b><font size="4">Live TV şi emisiuni TV</font></b></TD>
</TR>
<TR>
<TD width="25%"><a href="tv/digionline.php" target="_blank"><font size="4">Digi Online</font></a></TD>
<TD width="25%"><a href="tv/playlist.php?title=TVR.m3u" target="_blank"><font size="4">TVR</font></a></TD>
<TD width="25%"><a href="tv/tvpemobil_main.php" target="_blank"><font size="4">TVPeMobil</font></TD>
<TD width="25%"><a href="tv/tvrplus_e.php?page=1,http://www.seenow.ro/freezone,TV+(FreeZone)" target="_blank"><font size="4">Seenow TV (FreeZone)</font></a></TD>


</TR>
<TR>
<TD width="25%"><a href="tv/digi24.php" target="_blank"><font size="4">Digi24 - Stiri</font></a></TD>
<TD width="25%"><a href="tv/digi24_main.php" target="_blank"><font size="4">Digi24 - Emisiuni</font></a></TD>
<TD width="25%"><a href="tv/tvrstiri.php?page=1,,TVR+Stiri" target="_blank"><font size="4">TVR - Stiri</font></a></TD>
<TD width="25%"><a href="tv/antenaplay_main.php?page=1,,Antena+Play" target="_blank"><font size="4">Antena Play</font></a></TD>


</TR>
<TR>
<TD width="25%"><a href="tv/digisport.php?page=1,https://www.digisport.ro/video,DigiSport" target="_blank"><font size="4">DigiSport</font></a></TD>
<TD width="25%"><a href="tv/cabinet.php" target="_blank"><font size="4">Cabinetul din umbra</font></TD>
<TD width="25%"><a href="tv/privesc.php?page=1&link=https://www.privesc.eu/arhiva/categorii/Romania&title=Romania" target="_blank"><font size="4">privesc.eu</font></a></TD>
<TD width="25%"><a href="tv/adevarul.php?page=1&link=https://adevarul.ro/arhiva-live/&title=Toate" target="_blank"><font size="4">Adevarul.ro</font></a></TD>
</TR>
<TR>
<TD width="25%"><a href="tv/protvmd.php?page=1,,ProTV Moldova" target="_blank"><font size="4">PROTV Moldova</font></a></TD>
<TD width="25%"><a href="tv/moldova-in-direct.php" target="_blank"><font size="4">Moldova in Direct</font></a></TD>
<TD width="25%"><a href="tv/inprofunzime.php?page=1,,IN+PROfunzime" target="_blank"><font size="4">IN PROfunzime</font></a></TD>
<TD width="25%"><a href="tv/epochtimes.php?page=1&link=&title=epochtimes-romania" target="_blank"><font size="4">epochtimes-romania</font></a></TD>
</TR>
<TR>
<TD width="25%"><a href="filme/youtube_fav.php" target="_blank"><font size="4">youtube</font></a></TD>
<TD width="25%"><a href="filme/yt_playlist.php?token=&id=UCANDAWMJQsxMlaDMGlCdKpg&kind=channel&title=DanceTelevision&image=https://yt3.ggpht.com/-K4rbFp56pRQ/AAAAAAAAAAI/AAAAAAAAAAA/UKcWkGWWeOU/s88-c-k-no-mo-rj-c0xffffff/photo.jpg" target="_blank"><font size="4">Dance Television</font></a></TD>
<TD width="25%"><a href="filme/youtube_live.php?token=&search=" target="_blank"><font size="4">youtube live</font></a></TD>
<TD width="25%"><a href="filme/starea_natiei.php" target="_blank"><font size="4">Starea Natiei</font></a></TD>
</TR>
<TR>
<TD width="25%"><a href="filme/facebook_fav.php" target="_blank"><font size="4">facebook</font></a></TD>
<TD width="25%"><a href="tv/mywebtv_main.php" target="_blank"><font size="4">MyWebTV</font></a></TD>
<TD width="25%"><a href="tv/tvron.php" target="_blank"><font size="4">tvron</font></a></TD>
<TD width="25%"></TD>
</TR>
</table>
<BR>
<table border="1" align="center" width="90%">
<TR>
<td style="color:black;background-color:#0a6996;color:#64c8ff;text-align:center" colspan="4"><b><font size="4">My Playlist</font></b></TD>
</TR>
<TR>
<?php
$n=0;
$base="tv/pl/";
$list = glob($base."*.m3u");
   foreach ($list as $l) {
    //$l = str_replace(" ","%20",$l);
    $title =  basename($l);
    if ($title <> "TVR.m3u") {
    $link="tv/playlist.php?title=".urlencode($title);
    echo '<td align="center" width="25%"><a href="'.$link.'" target="_blank"><font size="4">'.$title.'</font></a></TD>';
    $n++;
    }
  if ($n == 4) {
  echo '</tr>';
  $n=0;
  }
}

?>
</TABLE>
</div>
<?php
if (!$list || count($list) == 1) {
echo '
<table border="1" align="center" width="90%"><TR><TD>
Adaugati liste m3u cu streamuri live in directorul scripts/tv/pl.
Adaugati manual (copiere) sau de pe PC http://ip:8080/scripts/fm.php, unde "ip" este ip-ul dispozitivului pe care este instalat HD4ALL</TD></TR></TABLE>';
}
echo '<BR><table border="1" align="center" width="90%"><TR><TD>';
echo 'Pentru vizionare stream-uri "acestream" instalati Ace Stream Media din Google Play sau de <a href="http://www.mediafire.com/file/8uyifuly87gbuwv/ace-stream-media-3-1-31-0.apk/file">aici</a>.<BR>
Setati la Output format pe "original".<BR>
Pentru stream-uri "sop" instalati Sopcast sau "sop to http" recomandat versiunea 5.41.<BR>
Puteti descarca de <a href="http://www.mediafire.com/file/d9s46xoewb604ds/Sop_to_Http-5.41.apk/file">aici.</a>.<BR>
Debifati "auto restart player".</TD></TR></TABLE>';
?>
</BODY>
</HTML>

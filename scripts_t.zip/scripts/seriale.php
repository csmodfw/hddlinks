<!DOCTYPE html>
<?php
include ("common.php");
if (file_exists($base_pass."tastatura.txt")) {
$tast=trim(file_get_contents($base_pass."tastatura.txt"));
} else {
$tast="NU";
}
if (file_exists($base_pass."player.txt")) {
$flash=trim(file_get_contents($base_pass."player.txt"));
} else {
$flash="direct";
}
?>
<html><head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate"/>
<meta http-equiv="Pragma" content="no-cache"/>
<meta http-equiv="Expires" content="0"/>
      <title>Seriale</title>
<link rel="stylesheet" type="text/css" href="custom.css" />
<script src="//code.jquery.com/jquery-2.0.2.js"></script>

<BODY>

<BR><BR>
<div id="mainnav">
<table id="data" border="1" align="center" width="90%">
<TR>
<td style="color:black;background-color:#0a6996;color:#64c8ff;text-align:center" colspan="4"><b><font size="4">Seriale online</font></b></TD>
</TR>
<TR>

<?php
if ($tast=="DA1" && $flash=="mp")
echo '<TD width="25%"><a href="filme/filmeseriale2_main.php?page=1&file=release&title=filmeseriale.online" target="_blank"><font size="4">filmeseriale.online (toate)</font></TD>';
else
echo '<TD width="25%"><a href="filme/filmeseriale_main.php?page=1&file=release&title=filmeseriale.online" target="_blank"><font size="4">filmeseriale.online (toate)</font></TD>';
?>
<TD width="25%"><a href="filme/filmeseriale1_main.php?page=1&file=release&title=filmeseriale.online" target="_blank"><font size="4">filmeseriale.online</font></TD>
<TD width="25%"><a href="filme/tvhub_s.php?page=1&file=release&title=tvhub" target="_blank"><font size="4">tvhub</font></TD>
<TD width="25%"><a href="filme/gold_s.php?page=1&file=release&title=filme-seriale.gold" target="_blank"><font size="4">filme-seriale.gold</font></TD>
</TR>
<TR>
<TD width="25%"><a href="filme/veziseriale.php" target="_blank"><font size="4">veziseriale.info</font></a></TD>
<TD width="25%"><a href="filme/filmeto_s.php?page=1&tip=release&title=filme-online.to" target="_blank"><font size="4">filme-online.to</font></a></TD>
<TD width="25%"><a href="filme/tvseries_s.php?page=1&file=release&title=tvseries" target="_blank"><font size="4">tvseries</font></a></TD>
<TD width="25%"><a href="filme/putlockerfit_s.php?page=1&file=release&title=putlockerfit" target="_blank"><font size="4">putlockerfit</font></TD>
</TR>
<TR>
<TD width="25%"><a href="filme/123movies_s.php?page=1&tip=release&title=the123movieshub" target="_blank"><font size="4">the123movieshub</font></a></TD>
<TD width="25%"><a href="filme/popcorn_s.php?page=1&file=release&title=seriale+noi" target="_blank"><font size="4">Popcorn (torrent)</font></a></TD>
<TD width="25%"><a href="filme/cecileplanche_s.php?page=1&file=release&title=cecileplanche" target="_blank"><font size="4">cecileplanche</font></TD>
<TD width="25%"><a href="filme/hdfull_s.php?page=1&file=release&title=hdfull" target="_blank"><font size="4">hdfull</font></TD>
</TR>
<TR>
<TD width="25%"><a href="filme/cineplex_s_main.php" target="_blank"><font size="4">cineplex</font></a></TD>
<TD width="25%"></TD>
<TD width="25%"></TD>
<TD width="25%"></TD>
</TR>
</table>
<BR><BR>
<?php
if (file_exists($base_pass."tastatura.txt")) {
$tast=trim(file_get_contents($base_pass."tastatura.txt"));
} else {
$tast="NU";
}
if ($tast=="DA") {
echo '
<table id="data" border="0" align="center" width="90%">
<TR><TD>* Folositi tasta 1 pentru informatii despre film/serial.<TD></TR>
<TR><TD>* Folositi tasta 3 pentru a adauga/sterge la favorite (daca exista).<TD></TR>
<TR><TD>* Folositi tasta 2 pentru a accesa direct pagina de "Favorite".<TD></TR>
</TABLE>';
}
?>
</div>
</BODY>
</HTML>

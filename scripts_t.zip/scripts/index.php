<!DOCTYPE html>
<?php
include ("common.php");
$f=$base_pass."adult.txt";
if (!file_exists($f)) {
//echo '<h2 style="background-color:deepskyblue;color:black"><center>Activati sau dezactivati sectiunea Adult din setari!</center></h2>';
} else {
$h=file_get_contents($f);
$t1=explode("|",$h);
$adult=$t1[0];
}
?>
<html><head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate"/>
<meta http-equiv="Pragma" content="no-cache"/>
<meta http-equiv="Expires" content="0"/>
      <title>HD4ALL</title>
<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.8.0/jquery.min.js"></script>
<script src="jquery.nicescroll.min.js"></script>

<script type="text/javascript">
  $(document).ready(function() {
	$("html").niceScroll({styler:"fb",cursorcolor:"#000"});
  });
</script>
<link rel="stylesheet" type="text/css" href="custom.css" />
<style>
html { height: 100%;}
.balloon { position: absolute; width: 214px; height: 317px; background: #000; border: 1px solid #fff; z-index: 10; display: none; }
</style>



<script type="text/javascript">
// create the XMLHttpRequest object, according browser
function get_XmlHttp() {
  // create the variable that will contain the instance of the XMLHttpRequest object (initially with null value)
  var xmlHttp = null;
  if(window.XMLHttpRequest) {		// for Forefox, IE7+, Opera, Safari, ...
    xmlHttp = new XMLHttpRequest();
  }
  else if(window.ActiveXObject) {	// for Internet Explorer 5 or 6
    xmlHttp = new ActiveXObject("Microsoft.XMLHTTP");
  }
  return xmlHttp;
}

// sends data to a php file, via POST, and displays the received answer
function ajaxrequest(url) {
  var request =  get_XmlHttp();		// call the function for the XMLHttpRequest instance

  // create pairs index=value with data that must be sent to server
  //var the_data = {mod:add,title:title, link:link}; //Array
  var the_data = 'url='+url;
  var php_file='../update.php';
  request.open("POST", php_file, true);			// set the request

  // adds a header to tell the PHP script to recognize the data as is sent via POST
  request.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
  request.send(the_data);		// calls the send() method with datas as parameter

  // Check request status
  // If the response is received completely, will be transferred to the HTML tag with tagID
  request.onreadystatechange = function() {
    if (request.readyState == 4) {
      alert (request.responseText);
      location.reload();
    }
  }
}
</script>
</head>
<body>

<?php
error_reporting(0);
function str_between($string, $start, $end){
	$string = " ".$string; $ini = strpos($string,$start);
	if ($ini == 0) return ""; $ini += strlen($start); $len = strpos($string,$end,$ini) - $ini;
	return substr($string,$ini,$len);
}
function is_valid_date($value, $format = 'dd.mm.yyyy'){
    if(strlen($value) >= 6 && strlen($format) == 10){

        // find separator. Remove all other characters from $format
        $separator_only = str_replace(array('m','d','y'),'', $format);
        $separator = $separator_only[0]; // separator is first character

        if($separator && strlen($separator_only) == 2){
            // make regex
            $regexp = str_replace('mm', '(0?[1-9]|1[0-2])', $format);
            $regexp = str_replace('dd', '(0?[1-9]|[1-2][0-9]|3[0-1])', $regexp);
            $regexp = str_replace('yyyy', '(19|20)?[0-9][0-9]', $regexp);
            $regexp = str_replace($separator, "\\" . $separator, $regexp);
            if($regexp != $value && preg_match('/'.$regexp.'\z/', $value)){

                // check date
                $arr=explode($separator,$value);
                $day=$arr[0];
                $month=$arr[1];
                $year=$arr[2];
                if(@checkdate($month, $day, $year))
                    return true;
            }
        }
    }
    return false;
}
$p=$_SERVER['SCRIPT_FILENAME'];
$script_directory = substr($p, 0, strrpos($p, '/'));
$f_version=$script_directory."/version_m.txt";
if (file_exists($f_version)) {
  $curr_vers=trim(file_get_contents($script_directory."/version_m.txt"));
  $l="http://hdforall.freehostia.com/version_m.txt";
  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $l);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US; rv:1.9.1.2) Gecko/20090729 Firefox/3.5.2 GTB5');
  curl_setopt($ch, CURLOPT_FOLLOWLOCATION  ,1);
  $h = curl_exec($ch);
  curl_close($ch);
  $t=explode("\n",$h);
  $avb_vers=trim($t[0]);
  $serv_update=trim($t[1]);
$valid_date = is_valid_date($avb_vers);
if ($valid_date) {
if ($avb_vers <> $curr_vers) {
  $info = "O nouă versiune este disponibilă (".$avb_vers.")! Apasati aici pentru actualizare.";
  echo '<p><a onclick="ajaxrequest('."'".$serv_update."')".'"'." style='cursor:pointer;'>".'<font size="4">'.$info.'</font></a></p>';
} else {
  $info = "";
}
} else {
  $info="Eroare citire data versiune disponibila!";
  echo '<p>'.$info.'</p>';
}
}
include ("common.php");
$f=$base_pass."seenow1.txt";
if (file_exists($f)) {
$h=file_get_contents($f);
$t1=explode("|",$h);
$user=$t1[0];
if ($user=="DA") {
   $seenow="DA";
} else {
$seenow="NU";
}
} else {
$seenow="NU";
}
$f=$base_pass."flash.txt";
if (file_exists($f)) {
$h=file_get_contents($f);
$t1=explode("|",$h);
$flash=$t1[0];
} else {
$flash=="NU";
}
?>
<H2></H2>
<table align="center" width="90%">
<tr>
<TD><font size="5">HD4ALL</font></TD>
<TD align="right"><a href="settings.php?&tip=" target="_blank"><font size="5">Setări</font></a></TD>
</TR>
</TABLE>
<table border="1" align="center" width="90%">
<TR>
<td style="background-color:deepskyblue;color:black;text-align:center" colspan="4"><b><font size="4">Filme şi Seriale</font></b></TD>
</TR>
<TR>
<TD><a href="filme/noob_m_main.php" target="_blank"><font size="4">Noobroom (premium)</font></TD>
<TD><a href="filme/voxfilmeonline_main.php" target="_blank"><font size="4">voxfilmeonline</font></TD>
<TD><a href="filme/calitatehd_main.php" target="_blank"><font size="4">calitatehd</font></TD>
<!--<TD><a href="filme/filmesubtitrate.php" target="_blank"><font size="4">filmesubtitrate.info</font></TD>-->
<TD><a href="filme/zfilme_main.php" target="_blank"><font size="4">zfilme</font></TD>
</TR>
<TR>


<TD><a href="filme/filmehd_main.php" target="_blank"><font size="4">filmehd.net</font></TD>
<TD><a href="filme/filmbox_main.php" target="_blank"><font size="4">filmbox</font></TD>
<TD><a href="filme/filme-bune_main.php" target="_blank"><font size="4">filme-bune</font></TD>
<TD><a href="filme/seriale-filme_main.php" target="_blank"><font size="4">seriale-filme</font></TD>
</TR>

<tr>
<TD><a href="filme/deseneledublate.php?page=1,,desenedublate" target="_blank"><font size="4">deseneledublate</font></TD>
<TD><a href="filme/deseneledublate1.php?page=1,,desenanimatdublat" target="_blank"><font size="4">desenanimatdublat</font></TD>
<TD><a href="filme/filmeseriale_main.php?page=1,https://filmeseriale.online/seriale,filmeseriale.online" target="_blank"><font size="4">filmeseriale.online (seriale)</font></TD>
<TD><a href="filme/filmeseriale_filme.php?page=1,https://filmeseriale.online/filme,filmeseriale.online" target="_blank"><font size="4">filmeseriale.online (filme)</font></TD>
<!--<TD><a href="filme/divxonline_main.php" target="_blank"><font size="4">divxonline</font></TD>-->
</TR>

<TR>

<TD><a href="filme/moviesplanet_main.php" target="_blank"><font size="4">moviesplanet</font></TD>
<TD><a href="filme/filmeserialeonline_main.php" target="_blank"><font size="4">filmeserialeonline</font></TD>
<TD><a href="filme/filmeonline2013_main.php" target="_blank"><font size="4">filmeonline2013</font></TD>
<!--<TD><a href="filme/playhd_main.php" target="_blank"><font size="4">playhd</font></TD>-->
<TD><a href="filme/vumo_main.php" target="_blank"><font size="4">vumo</font></TD>
</TR>
</table>

<?php
$f=$base_pass."seenow1.txt";
if (file_exists($f)) {
$t="Seenow";
$seenow="DA";
} else {
$t="Seenow (FreeZone/Abonament)";
$seenow="NU";
/*
 $txt="DA|xxx";
 $fh = fopen($f, 'w');
 fwrite($fh, $txt);
 fclose($fh);
*/
}


if ($seenow=="XX") {
echo '
<br>
<table border="1" align="center" width="90%">
<TR>
<td style="background-color:deepskyblue;color:black;text-align:center" colspan="4"><b><font size="4">'.$t.'</font></b></TD>
</TR>
';
echo '
<TR>
<TD width="25%"><a href="tv/tvrplus_e.php?page=1,http://www.seenow.ro/filme?sort=recent|category=Toate,Toate+Filmele" target="_blank"><font size="4">Toate filmele</font></TD>
<TD width="25%"><a href="tv/tvrplus_e.php?page=1,http://www.seenow.ro/filme?sort=recent|category=Disney+Movies,Disney+Movies" target="_blank"><font size="4">Disney Movies</font></TD>
<!--TD width="25%"><a href="tv/tvrplus_e.php?page=1,http://www.seenow.ro/filme?sort=recent|category=Filme+Hollywood,Filme+Hollywood" target="_blank"><font size="4">Filme Hollywood</font></TD-->
<TD width="25%"><a href="tv/tvrplus_e.php?page=1,http://www.seenow.ro/tv,TV" target="_blank"><font size="4">TV (abonament)</font></TD>
<!--<TD width="25%"><a href="tv/tvrplus_e.php?page=1,http://www.seenow.ro/axn-now-447-pagina-,AXN Now" target="_blank"><font size="4">AXN Now</font></TD>-->
<TD width="25%"><a href="tv/tvrplus_e.php?page=1,http://www.seenow.ro/tv-by-vodafone,TV+by+Vodafone" target="_blank"><font size="4">TV by Vodafone</font></TD>


</TR>

<!-- TR>
<TD width="25%"><a href="tv/tvrplus_e.php?page=1,http://www.seenow.ro/pay-per-view,Filme+Premium" target="_blank"><font size="4">Filme Premium</font></TD>
<TD width="25%"><a href="tv/tvrplus_e.php?page=1,http://www.seenow.ro/filme?sort=recent|category=Filme+Romanesti,Filme+Romanesti" target="_blank"><font size="4">Filme Romanesti</font></TD>
<TD width="25%"></TD>

</TR -->
<TR>
<TD width="25%"><a href="tv/seenow.php" target="_blank"><font size="4">Seenow TV</font></TD>
<TD width="25%"><a href="tv/tvrplus_e.php?page=1,http://www.seenow.ro/koolnet,Koolnet+TV" target="_blank"><font size="4">Koolnet TV</font></TD>
<TD width="25%"><a href="tv/tvrplus_e.php?page=1,http://www.seenow.ro/freezone,TV+(FreeZone)" target="_blank"><font size="4">TV (FreeZone)</font></TD>
<TD width="25%"><a href="tv/tvrplus_e.php?page=1,http://www.seenow.ro/documentare-568,Documentare" target="_blank"><font size="4">Documentare</font></TD>
';
}
/*if ($adult=="DA") {
echo '
<TD width="25%"><a href="tv/tvrplus_e.php?page=1,http://www.seenow.ro/hustler-live-6268,Hustler+live" target="_blank"><font size="4">Hustler live</font></TD>
</TR>
';
} else*/
echo '
</TR>
';
?>
</table><br>
<table border="1" align="center" width="90%">
<TR>
<td style="background-color:deepskyblue;color:black;text-align:center" colspan="4"><b><font size="4">Live TV şi emisiuni TV</font></b></TD>
</TR>
<TR>
<TD><a href="tv/dolce.php" target="_blank"><font size="4">Posturi Romania</font></TD>
<TD><a href="tv/digionline.php" target="_blank"><font size="4">Digi Online</font></TD>
<TD><a href="tv/sopcast.php" target="_blank"><font size="4">Sopcast</font></TD>
<TD><a href="tv/sopcast1.php" target="_blank"><font size="4">Sopcast (alternativ)</font></TD>
</TR>
<TR>
<TD><a href="tv/filmon.php" target="_blank"><font size="4">Filmon</font></TD>
<TD><a href="tv/dancetrippin.php" target="_blank"><font size="4">dancetrippin.tv</font></TD>
<!--<TD><a href="tv/tvrplus_e.php?page=1,http://www.seenow.ro/biziday-6840,Biziday" target="_blank"><font size="4">Biziday</font></TD>-->
<TD><a href="tv/sopcastvl.php" target="_blank"><font size="4">Sopcast (VLC)</font></TD>
<TD><a href="tv/tvrstiri.php?page=1,,TVR+Stiri" target="_blank"><font size="4">TVR - Stiri</font></TD>
</TR>
<TR>
<TD><a href="tv/digi24.php" target="_blank"><font size="4">Digi24 - Stiri</font></TD>
<TD><a href="tv/digi24_main.php" target="_blank"><font size="4">Digi24 - Emisiuni</font></TD>
<TD width="25%"><a href="tv/tvrplus_e.php?page=1,http://www.seenow.ro/freezone,TV+(FreeZone)" target="_blank"><font size="4">Seenow TV (FreeZone)</font></TD>
<TD><a href="tv/antenaplay_main.php?page=1,,Antena+Play" target="_blank"><font size="4">Antena Play</font></TD>
</TR>
<TR>
<TD><a href="filme/youtube_user.php?page=1,agerpresro,Agerpres" target="_blank"><font size="4">Agerpress</font></TD>
<TD><a href="filme/youtube_user.php?page=1,ArealIT,ZonaIT" target="_blank"><font size="4">ZonaIT</font></TD>
<TD><a href="tv/publika.php?page=1,,publika.md" target="_blank"><font size="4">publika.md</font></TD>
<TD><a href="tv/jurnaltv.php?page=1,,jurnaltv.md" target="_blank"><font size="4">jurnaltv.md</font></TD>
</TR>
<TR>
<TD><a href="tv/moldova-in-direct.php" target="_blank"><font size="4">Moldova in Direct</font></TD>
<td><a href="tv/digisport.php?page=1,http://www.digisport.ro/Sport/VIDEO/,DigiSport" target="_blank"><font size="4">DigiSport</font></TD>
<!--<TD><a href="tv/orange.php" target="_blank"><font size="4">Orange TV</font></TD>-->
<TD><a href="tv/voyo_tv.php" target="_blank"><font size="4">Voyo TV</font></TD>
<TD><a href="tv/inprofunzime.php?page=1,,IN+PROfunzime" target="_blank"><font size="4">IN PROfunzime</font></TD>
</TR>
<TR>
<TD><a href="tv/protv_main.php" target="_blank"><font size="4">ProTV</font></TD>
<TD><a href="tv/plus_main.php" target="_blank"><font size="4">TVR Plus</font></TD>
<TD><a href="tv/privesc_main.php" target="_blank"><font size="4">privesc.eu</font></TD>
<!--<TD><a href="tv/megatube_main.php" target="_blank"><font size="4">megatube.eu</font></TD></TR>-->
<TD><a href="tv/adevarul_main.php" target="_blank"><font size="4">Adevarul.ro</font></TD>
</TR>
<!--<TD><a href="tv/tastez.php?query=starnet,Starnet" target="_blank"><font size="4">Tastez.ro - Starnet</font></TD>-->
<!--
<TD><a href="tv/tastez.php?query=hungary,Ungaria" target="_blank"><font size="4">Tastez.ro - Ungaria</font></TD>
<TD><a href="tv/tastez.php?query=moldova,Moldova" target="_blank"><font size="4">Tastez.ro - Moldova</font></TD>
<TD><a href="tv/tastez.php?query=media-direct,Dolce/Look" target="_blank"><font size="4">Tastez.ro -  Dolce/Look</font></TD>
-->
<!--<TD><a href="tv/tastez.php?query=voyo,Tastez.ro+-+Voyo" target="_blank"><font size="4">Tastez.ro - Voyo</font></TD>-->

<tr>
<TD><a href="tv/magictvbox.php" target="_blank"><font size="4">MagicTvBox</font></TD>
<TD><a href="tv/epochtimes.php?page=1&link=&title=epochtimes-romania" target="_blank"><font size="4">epochtimes-romania</font></TD>
<!--<td><a href="tv/gandul.php?page=1,http://www.gandul.info/gandul-live/,Gandul" target="_blank"><font size="4">Gandul</font></TD>-->
<TD><a href="tv/protvmd.php?page=1,,ProTV Moldova" target="_blank"><font size="4">PROTV Moldova</font></TD>
<TD><a href="tv/jocurideputere.php" target="_blank""><font size="4">Jocuri de Putere</font></a></TD></TR>
<?php
//if (file_exists($_SERVER['DOCUMENT_ROOT']."/spyce.m3u")) {

echo '<TD><a href="tv/spyce_tv.php" target="_blank"><font size="4">Digi (FREE)</font></TD>';
echo '<TD><a href="tv/telekom_tv.php" target="_blank"><font size="4">Telekom</font></TD>';
//}
/*
if ($seenow=="BA") {
echo '
<TR>
<TD width="25%"><a href="tv/tvrplus_e.php?page=1,http://www.seenow.ro/emisiuni-tv-2697-pagina-,Emisiuni+TV" target="_blank"><font size="4">Emisiuni TV</font></TD>
<TD width="25%"><a href="tv/tvrplus_e.php?page=1,http://www.seenow.ro/documentare-2701-pagina-,Documentare" target="_blank"><font size="4">Documentare</font></TD>
';
if ($flash=="NU")
echo '<TD width="25%"><a href="tv/seenow_r.php" target="_blank"><font size="4">Radio</font></TD>';
else
echo '<TD width="25%"><a href="tv/seenow_r1.php" target="_blank"><font size="4">Radio</font></TD>';
echo'
<TD width="25%"></TD>
</TR>
';
}
*/
if (file_exists($_SERVER['DOCUMENT_ROOT']."/spyce.m3u"))
echo '<TD><a href="tv/xstream.php" target="_blank"><font size="4">xstream</font></TD>';
else
echo '<td></td>';
echo '<TD><a href="tv/m.php" target="_blank"><font size="4">Tastez.ro - Moldova</font></TD>';
echo '</TR>';
//}
?>

</table>
<br>
	<table border="1" align="center" width="90%" id="table1">
	<tr>
    <td style="background-color:deepskyblue;color:black;text-align:center" colspan="5"><b><font size="4">OneHD Concerts</font></b></TD>
    </tr>
		<tr>
			<td align="center"><font size="4"><a href="tv/onehd_pop.html" target="_blank">Pop</a></font></td>
			<td align="center"><font size="4"><a href="tv/onehd_rock.html" target="_blank">Rock</a></font></td>
			<td align="center"><font size="4"><a href="tv/onehd_dance.html" target="_blank">Dance</a></font></td>
			<td align="center"><font size="4"><a href="tv/onehd_jazz.html" target="_blank">Jazz</a></font></td>
			<td align="center"><font size="4"><a href="tv/onehd_classic.html" target="_blank">Classic</a></font></td>
		</tr>
	</table>

<br>
<table border="1" align="center" width="90%">
<TR>
<td style="background-color:deepskyblue;color:black;text-align:center" colspan="4"><b><font size="4">Videoclipuri</font></b></TD>
</TR>
<TR>
<!--<TD width="25%"><a href="filme/vplay_main.php" target="_blank"><font size="4">vplay</font></TD>-->

<TD width="25%"><a href="filme/trilulilu_main.php" target="_blank"><font size="4">trilulilu</font></TD>
<TD width="25%"><a href="filme/videoalegenet.php?page=1,http://video.alege.net/c-filme-noi-ro-,video.alege.net" target="_blank"><font size="4">video.alege.net</font></TD>
<TD width="25%"><a href="filme/bzi.php?page=1,,bzi" target="_blank"><font size="4">bzi</font></TD>
<TD width="25%"></TD>
</TR>
<TR>
<TD width="25%"><a href="filme/roboti.php?page=1,,ROboti" target="_blank"><font size="4">ROboti</font></TD>
<TD width="25%"><a href="filme/recomand.php?page=1,,ROboti+-+Recomand" target="_blank"><font size="4">ROboti Recomand</font></TD>
<TD width="25%"><a href="filme/yt_playlist.php?page=1,PLA1CEC3D2A6A0263F,Luzarii+de+pe+Electrolizei" target="_blank"><font size="4">Luzarii</font></TD>
<!--<TD width="25%"><a href="filme/myvideo.php?page=1,,myvideo.ro" target="_blank"><font size="4">myvideo.ro</font></TD>-->
<TD></TD>
</TR>
<TR>
<TD width="25%"><a href="filme/yt_playlist.php?page=1,PL8YoNHKjWTYA0PvglTn9OqpQiuyIrIrDq,Tara+lui+Fratzica" target="_blank"><font size="4">Tara lui Fratzica</font></TD>
<TD width="25%"><a href="filme/220_main.php" target="_blank"><font size="4">220.ro</font></TD>
<TD width="25%"><a href="filme/youtube_user.php?page=1,DoZaDeHas,DoZaDeHas" target="_blank"><font size="4">DoZaDeHas</font></TD>
<TD width="25%"><a href="filme/youtube.php?tip=&user=&id=" target="_blank"><font size="4">youtube</font></TD>
</TR>

<TR>
<TD width="25%"><a href="filme/youtube_user.php?page=1,catmusicoffice,Cat+Music" target="_blank"><font size="4">Cat Music</font></TD>
<TD width="25%"><a href="filme/youtube_user.php?page=1,MediaProMusic,MediaProMusic" target="_blank"><font size="4">MediaProMusic</font></TD>
<TD width="25%"><a href="filme/youtube_user.php?page=1,musicroton,MusicROTON" target="_blank"><font size="4">MusicROTON</font></TD>
<TD width="25%"><a href="filme/youtube_user.php?page=1,hahahaproductioncom,HaHaHa+Production" target="_blank"><font size="4">HaHaHa Production</font></TD>
</TR>

<TR>
<TD width="25%"><a href="filme/top1_main.php" target="_blank"><font size="4">top1.ro</font></TD>
<TD width="25%"><a href="filme/tare.php?page=1,,tare.ro" target="_blank"><font size="4">tare.ro</font></TD>
<TD width="25%"><a href="filme/peteava_main.php" target="_blank"><font size="4">peteava</font></TD>
<TD width="25%"><a href="filme/primatv.php" target="_blank"><font size="4">PrimaTV - Seriale</font></TD>
</TR>
</TABLE><br>
<?php
if ($adult=="DA") {
echo '
<table border="1" align="center" width="90%">
<TR>
<td style="background-color:deepskyblue;color:black;text-align:center" colspan="4"><b><font size="4">Adult</font></b></TD>
</TR>
<TR>
<TD width="25%"><a href="adult/tube8_main.php" target="_blank"><font size="4">tube8</font></TD>
<!--<TD width="25%"><a href="adult/porno720p.php?page=1,http://porno720p.com,porno720p.com" target="_blank"><font size="4">porno720</font></TD>-->
<TD width="25%"><a href="adult/penthousevideos_main.php" target="_blank"><font size="4">penthousevideos</font></TD>
<TD width="25%"><a href="adult/redtube_main.php" target="_blank"><font size="4">redtube</font></TD>
<TD width="25%"><a href="adult/alotporn_main.php" target="_blank"><font size="4">alotporn</font></TD>
</tr>
<tr>
<TD width="25%"><a href="adult/extremetube_main.php" target="_blank"><font size="4">extremetube</font></TD>
<TD width="25%"><a href="adult/empflix_main.php" target="_blank"><font size="4">empflix</font></TD>
<TD width="25%"><a href="adult/xnxx_main.php" target="_blank"><font size="4">xnxx</font></TD>
<!--<TD width="25%"><a href="adult/flytube_main.php" target="_blank"><font size="4">flytube</font></TD>-->
<TD width="25%"><a href="adult/xvideos_main.php" target="_blank"><font size="4">xvideos</font></TD>
</tr>
<tr>
<TD width="25%"><a href="adult/pornomovies_main.php" target="_blank"><font size="4">pornomovies</font></TD>
<TD width="25%"><a href="adult/spankwire_main.php" target="_blank"><font size="4">spankwire</font></TD>
<!--<TD width="25%"><a href="adult/xhamster_main.php" target="_blank"><font size="4">xhamster</font></TD>-->
<TD width="25%"><a href="adult/pornhub_main.php" target="_blank"><font size="4">pornhub</font></TD>
<TD width="25%"><a href="adult/milfzr_main.php" target="_blank"><font size="4">milfzr</font></TD>
<!--<TD></TD>-->
</tr>
<TR>
<TD width="25%"><a href="adult/pornjam_main.php" target="_blank"><font size="4">pornjam</font></TD>
<!--<TD width="25%"><a href="adult/familymomporn_main.php" target="_blank"><font size="4">familymomporn</font></TD>-->
<TD width="25%"><a href="adult/pornburst_main.php" target="_blank"><font size="4">pornburst</font></TD>
<!--<TD width="25%"><a href="adult/thepornhd_main.php" target="_blank"><font size="4">thepornhd</font></TD>-->
<TD width="25%"><a href="adult/anybunny_main.php" target="_blank"><font size="4">anybunny</font>
<TD width="25%"><a href="adult/tubepornclassic_main.php" target="_blank"><font size="4">tubepornclassic</font>
</TR>
<TR>
<TD width="25%"><a href="adult/xhamster_main.php" target="_blank"><font size="4">xhamster</font></TD>
<TD width="25%"><a href="adult/incestvidz_main.php" target="_blank"><font size="4">incestvidz</font></TD>
<TD width="25%"><a href="adult/slutload_main.php" target="_blank"><font size="4">slutload</font></TD>
<TD width="25%"><a href="adult/ah-me_main.php" target="_blank"><font size="4">ah-me</font></TD>
</TR>
<TR>
<TD width="25%"><a href="adult/fapbox_main.php" target="_blank"><font size="4">fapbox</font></TD>
<TD width="25%"><a href="adult/pornox_main.php" target="_blank"><font size="4">pornox</font></TD>
<TD width="25%"><a href="adult/tubxporn_main.php" target="_blank"><font size="4">tubxporn</font></TD>
<TD width="25%"><a href="adult/jizzbunker_main.php" target="_blank"><font size="4">jizzbunker</font></TD>
</TR>
';
if ($seenow=="DA") {
/*
echo '<tr>';
echo '<TD width="25%"><font size="4"><a href="tv/digitv_link.php?file=http://178.21.120.198:1935/live3/_definst_/mp4:hustlerhd/playlist.m3u8&title=hustlerhd" target="_blank">Hustler HD</a></font></TD>';
echo '<TD width="25%"><font size="4"><a href="tv/digitv_link.php?file=http://178.21.120.198:1935/live3/_definst_/mp4:privatetv/playlist.m3u8&title=privatetv" target="_blank">Private TV</a></font></TD>';
echo '<TD width="25%"><font size="4"><a href="tv/digitv_link.php?file=http://178.21.120.198:1935/live3/_definst_/mp4:hustlertv/playlist.m3u8&title=hustlertv" target="_blank">Hustler TV</a></font></TD>';
echo '<TD width="25%"><font size="4"><a href="tv/digitv_link.php?file=http://178.21.120.198:1935/live3/_definst_/mp4:hustlerblue/playlist.m3u8&title=hustlerblue" target="_blank">Hustler Blue</a></font></TD>';
echo '</tr>';
echo '
<!-- tr><td style="background-color:deepskyblue;color:black;text-align:center;" colspan="4"><b><font size="4">Private & Satin</font></b></TD></TR -->
<tr>
<!-- TD width="25%"><a href="adult/tvrplus_e.php?page=1,,Private+Hardcore" target="_blank"><font size="4">Private Hardcore</font></TD>
<TD width="25%"><a href="adult/tvrplus_e.php?page=1,,Private+Softcore" target="_blank"><font size="4">Private Softcore</font></TD>
<TD width="25%"><a href="adult/tvrplus_e.php?page=1,,Satin+Adult+Mix" target="_blank"><font size="4">Satin Adult Mix</font></TD -->
<TD width="25%"><a href="adult/tvrplus_e.php?page=1,,Hustler+vod" target="_blank"><font size="4">Hustler vod</font></TD>
<TD width="25%"></TD>
<TD width="25%"></TD>
<TD width="25%"></TD></tr>
';*/
}

echo '
</table>
';
}
$f=$base_pass."adult.txt";
if (!file_exists($f)) {
echo '<h2 style="background-color:deepskyblue;color:black"><center>Activati sau dezactivati sectiunea Adult din setari!</center></h2>';
}
$list = glob($base_cookie."*.dat");
   foreach ($list as $l) {
    str_replace(" ","%20",$l);
    unlink($l);
}
if (file_exists("adult/private-hardcore-345-pagina-1")) {
$list = glob("adult/private*",GLOB_BRACE);
   foreach ($list as $l) {
    str_replace(" ","%20",$l);
    unlink($l);
}
$list = glob("adult/satin-adult*",GLOB_BRACE);
   foreach ($list as $l) {
    str_replace(" ","%20",$l);
    unlink($l);
}
}
$list = glob($base_fav."*.list");
   foreach ($list as $l) {
    str_replace(" ","%20",$l);
    unlink($l);
}
/*
$add="\r\n"."127.0.0.1 dev.mediadirect.ro";
$l="c:\\windows\\system32\\drivers\\etc\\hosts";
$h=@file_get_contents($l);

if (@strpos($h,"dev.mediadirect.ro") === false && (strpos($base_pass,":") !== false)) {
 @file_put_contents($l, $add, FILE_APPEND | LOCK_EX);
}
*/
if (file_exists("jquery.nicescroll.min1.js") && file_exists("jquery.nicescroll.min.js"))  unlink ("jquery.nicescroll.min.js");
?>
<br></body>
</html>

<?php
function str_between($string, $start, $end){
	$string = " ".$string; $ini = strpos($string,$start);
	if ($ini == 0) return ""; $ini += strlen($start); $len = strpos($string,$end,$ini) - $ini;
	return substr($string,$ini,$len);
}
function enc($string) {
  $local3="";
  $arg1=strlen($string);
  $arg2="mediadirect";
  $l_arg2=strlen($arg2);
  $local4=0;
  while ($local4 < $arg1) {
    $m1=ord($string[$local4]);
    $m2=ord($arg2[$local4 % $l_arg2]);
    $local3=$local3.chr($m1 ^ $m2);
    $local4++;
  }
  return $local3;
}
include ("../common.php");
if (file_exists($base_pass."player.txt")) {
$flash=trim(file_get_contents($base_pass."player.txt"));
} else {
$flash="direct";
}
if (file_exists($base_pass."tv.txt")) {
$tv=trim(file_get_contents($base_pass."tv.txt"));
} else {
$tv="dinamic";
}
$id = $_GET["id"];
$title = urldecode($_GET["title"]);
$PHP_SELF="";
$token = "";
$Width="";
$Height="";
$s="http://index.mediadirect.ro/getUrl?publisher=2";
$h = file_get_contents($s);
$t1=explode('server=',$h);
$t2=explode('&',$t1[1]);
$serv=$t2[0];
$link="http://www.dolcetv.ro/service/play/index/id/".$id."/category/0/type/live-tv/editionId/0/module_name/androidtablet";
$html = file_get_contents($link);
//echo $html;
//die();
$html=str_replace("\\","",$html);
$t1=explode('high quality stream name":"',$html);
$t2=explode('"',$t1[1]);
$str=$t2[0];
$t1=explode('token-high":"',$html);
$t2=explode('"',$t1[1]);
$token=$t2[0];

if ($serv == "") {
  $serv="fms38.mediadirect.ro";
}
//$out = "http://".$serv.":1937/live3/_definst_/".$str."/".$title.".m3u8?token=".$token;
$out = "http://178.21.120.198:1935/live3/_definst_/".$str."/".$title.".m3u8?token=".$token;

if (((strpos($_SERVER["SERVER_NAME"],"seenow") !== false) || (!$token)) && ($tv=="dinamic")) $flash="site";

if ($flash == "direct") {

header('Content-type: application/vnd.apple.mpegURL');
header('Content-Disposition: attachment; filename="playlist.m3u8"');
header("Location: $out");
} elseif (($flash=="html5" || $flash=="flash") && ($tv<>"vlc")) {
$app="live3";
if ($tv=="fms38.mediadirect.ro")
 $serv="fms38.mediadirect.ro";
$rtmp="rtmpe://".$serv."/".$app."/_definst_?token=".$token;

echo '
<!doctype html>
<HTML>
<HEAD>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>'.$title.'</title>
<style type="text/css">
body {
margin: 0px auto;
overflow:hidden;
}
body {background-color:#000000;}
</style>
<script src="//code.jquery.com/jquery-1.11.0.min.js"></script>
<script src="http://p.jwpcdn.com/6/10/jwplayer.js"></script>
<script>jwplayer.key="a90HGmYJwl7ewuxkXqofNd65qdenEdCsdwujA3th0Kc=";</script>

</HEAD>
<BODY>
<div id="container"></div>
<script type="text/javascript">
jwplayer("container").setup({
"playlist": [{
"sources": [{"file": "'.$out.'", "type": "m3u8"}],
}],
    captions: {
        color: "#FFFFFF",
        fontSize: 20,
        backgroundOpacity: 0
    },
"height": $(document).height(),
"width": $(document).width(),
"skin": "../hd4all.xml",
"stretching":"exactfit",
"androidhls": true,
"startparam": "start",
"autostart": true,
"fallback": false,
"wmode": "direct",
"stagevideo": true
});
</script>
</BODY>
</HTML>
';
} elseif ($flash == "site") {
$l="c:\\windows\\system32\\drivers\\etc\\hosts";
if (strpos($base_pass,":") === false) $l="//system//etc//hosts";
$h=@file_get_contents($l);
$t1=$_SERVER["PHP_SELF"];
if ((@strpos($h,"static1.mediadirect.ro") === false) && (@strpos($h,"dev.seenow.ro") !== false)) $t1="//dev.seenow.ro".$t1;
if(!isset($_GET['screen_check'])) {
 echo "<script language='JavaScript'>
 <!-- 
 document.location=\"$t1?screen_check=done&id=$id&title=$title&Width=\"+window.innerWidth+\"&Height=\"+window.innerHeight;
 //-->
 </script>";
 die();
} else {    
	if(isset($_GET['Width']) && isset($_GET['Height'])) {
		$Width=$_GET['Width']-48;
		$Height=$_GET['Height']-48;
	}
}
//$str=$str.'_low'; // _low | _mobile
$data = "cnow"; //seenow | dolce_sport | tvr?!?
$str = base64_encode(enc($str));
$data = base64_encode(enc($data));
$l="c:\\windows\\system32\\drivers\\etc\\hosts";
$h=@file_get_contents($l);
if ((strpos($base_pass,":") !== false) && (@strpos($h,"static1.mediadirect.ro") === false)) $data="GQAXHQ==";
if ((strpos($base_pass,":") === false) && (@strpos($h,"dev.seenow.ro") !== false)) $data="GQAXHQ==";
//$data="GQAXHQ==";
echo '
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">

<title>'.$title.'</title>

<link rel="stylesheet" type="text/css" href="../custom.css" />

</head>
<body {
margin: 0px auto;
overflow:hidden;
}>



<object id="player_mediadirect">
			<embed type="application/x-shockwave-flash"	id="player_mediadirect" src="http://static1.mediadirect.ro/mediaplayer/players/0037/player.swf"	menu="false" 
			play="true" loop="false" quality="high" bgcolor="#000000" allowScriptAccess="always" allowFullScreen="true" scale = "noscale" wmode = "direct"	
			width="100%" height="'.$Height.'" flashVars="app=FlUZRg0NHxdW&str='.$str.'&data='.$data.'&autoplay=true" salign="tl"/>
			</object>
			
</body>
</html>
';
} else {
//$out = "http://".$serv.":1937/live3/_definst_/".$str."/playlist.m3u8?token=".$token;
echo '
<html>
   <head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<style type="text/css">
body {
margin: 0px auto;
overflow:hidden;
}
</style>
      <title>'.$title.'</title>
   </head>
<body>

<embed type="application/x-vlc-plugin" pluginspage="http://www.videolan.org" version="VideoLAN.VLCPlugin.2"
width="100%"
height="100%"
id="vlc"
target="'.$out.'">
</embed>


    <script language="Javascript">

    var vlc = document.getElementById("vlc");
    vlc.audio.toggleMute(0);


    </script>

    </body>
    </Html>
';
}
?>

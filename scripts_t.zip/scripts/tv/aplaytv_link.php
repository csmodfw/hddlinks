<?php
error_reporting(0);
set_time_limit(0);
function str_between($string, $start, $end){
	$string = " ".$string; $ini = strpos($string,$start); 
	if ($ini == 0) return ""; $ini += strlen($start); $len = strpos($string,$end,$ini) - $ini; 
	return substr($string,$ini,$len); 
}
include ("../common.php");
if (file_exists($base_pass."player.txt")) {
$flash=trim(file_get_contents($base_pass."player.txt"));
} else {
$flash="direct";
}
if (file_exists($base_pass."mx.txt")) {
$mx=trim(file_get_contents($base_pass."mx.txt"));
} else {
$mx="ad";
}

$id = $_GET["file"];
$title = $_GET["title"];
//https://ivm.antenaplay.ro/live/a1/playlist.m3u8?starttime=1495384332&endtime=1495391562&source=web&token=
$link="http://aplay.dev.digitalag.ro/ajaxs/embedlive?channelid=21";
$link=file_get_contents("http://aplay.dev.digitalag.ro/ajaxs/embedlive?channelid=21");

$tok = str_between($link,"?","',");
$out="".$id."?".$tok."";

$user_agent     =   $_SERVER['HTTP_USER_AGENT'];
if (preg_match("/android|ipad/i",$user_agent) && preg_match("/chrome|firefox|mobile/i",$user_agent)) $flash="chrome";
if ($flash=="mpc1") {
  $mpc=trim(file_get_contents($base_pass."vlc.txt"));
  $c = '"'.$mpc.'" --fullscreen --sub-language="ro,rum,ron" "'.$out.'"';
  pclose(popen($c,"r"));
  echo '<script type="text/javascript">window.close();</script>';
  die();
}
if ($flash == "direct") {
header('Content-type: application/vnd.apple.mpegURL');
header('Content-Disposition: attachment; filename="playlist.m3u8"');
header("Location: $out");
}
elseif ($flash == "chrome") {
$c="intent:".$out."#Intent;package=com.mxtech.videoplayer.".$mx.";S.title=".urlencode($title).";end";
header("Location: $c");
//
} else {
echo '
<!doctype html>
<HTML>
<HEAD>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>'.$title.'</title>
<style type="text/css">
body {
margin: 0px auto;
overflow:hidden;
}
body {background-color:#000000;}
</style>
<script src="//code.jquery.com/jquery-1.11.0.min.js"></script>
<script src="http://mxcore.forithost.com/9mbIGdym.js"></script>
<script type="text/javascript">jwplayer.key="aw56p5uDeEXAfqkCfvOK9tgr1xMW/etdcJydrA==";</script>

</HEAD>
<BODY>
<div id="container"></div>
<script type="text/javascript">
jwplayer("container").setup({
 file: "'.$out.'",
 width: $(document).width(),
 height: $(document).height(),
 title: "'.$title.'",
 abouttext: "'.$title.'",
 stretching:"exactfit",
 startparam: "start",
 fallback: false,
 wmode: "direct",
 autostart: true,
 hlshtml: true,
 type: "hls"
});
</script>
</BODY>
</HTML>
';
}
?>

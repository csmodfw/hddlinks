<?php
set_time_limit(0);
error_reporting(0);
function str_between($string, $start, $end){
	$string = " ".$string; $ini = strpos($string,$start);
	if ($ini == 0) return ""; $ini += strlen($start); $len = strpos($string,$end,$ini) - $ini;
	return substr($string,$ini,$len);
}
include ("../common.php");
$filename=$base_pass."tvplay.txt";
if (file_exists($filename)) {
$pass=file_get_contents($filename);
$lp="http://hd4all.ml/d/gazv.php?c=".$pass;
$dev = file_get_contents("".$lp."");
} else {
$dev="";
}

if (file_exists($base_pass."player.txt")) {
$flash=trim(file_get_contents($base_pass."player.txt"));
} else {
$flash="direct";
}
if (file_exists($base_pass."mx.txt")) {
$mx=trim(file_get_contents($base_pass."mx.txt"));
} else {
$mx="ad";
}
$user_agent     =   $_SERVER['HTTP_USER_AGENT'];
if (preg_match("/android|ipad/i",$user_agent) && preg_match("/chrome|firefox|mobile/i",$user_agent)) $flash="chrome";
$id = urldecode($_GET["file"]);
$title = urldecode($_GET["title"]);
    $title1=strtolower($title);
    $t1=explode("(",$title1);
    $title1=trim($t1[0]);
    $title1=str_replace(" ","-",$title1);
$alip = '149.202.196.52';//allip
$alport = '25461';//allport

$all="http://www.seenow.ro/test/LG/proxy.php?url=play.core1.qazwsx.work:25461/live".$dev."1.m3u8";
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $all);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 5.1; rv:31.0) Gecko/20100101 Firefox/31.0');
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS,'ip='.$alip.'&port='.$alport);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
//curl_setopt($ch, CURLOPT_HEADER, 1);
$htm = curl_exec($ch);
curl_close($ch);
$r= json_decode($htm,1);
//print_r ($r);

//
//$out = file_get_contents($htm);
$tok = str_between($htm,'token=','\r' );
$serv = str_between($htm,'Location: http:\/\/','\/' );
$tok=str_replace(" ","",$tok);
$out="http://".$serv."/live".$dev."".$id."?token=".$tok."";
$link="http://".$serv."/live/I02CzDS14C/EHdAiyOOS0/".$id."?token=".$tok."";
if ($flash=="mpc") {
  $mpc=trim(file_get_contents($base_pass."mpc.txt"));
  $c='"'.$mpc.'" /fullscreen "'.$link.'"';
  pclose(popen($c,"r"));
  echo '<script type="text/javascript">window.close();</script>';
  die();
}
if ($flash == "direct" || $flash=="chrome") {
header('Content-type: application/vnd.apple.mpegURL');
if (strpos($link,"m3u8") !== false) header('Content-Disposition: attachment; filename="playlist.m3u8"');
header("Location: $link");
} else {
if (strpos($link,"m3u8") !== false)
  $type="m3u8";
elseif (strpos($link,"rtmp") !== false)
  $type="rtmp";
else
  $type="m3u8";
echo '
<!doctype html>
<HTML>
<HEAD>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>'.$title.'</title>
<style type="text/css">
body {
margin: 0px auto;
overflow:hidden;
}
body {background-color:#000000;}
</style>
<script src="//code.jquery.com/jquery-1.11.0.min.js"></script>
'.$jwv.'

</HEAD>
<BODY>
<div id="container"></div>
<script type="text/javascript">
jwplayer("container").setup({
"playlist": [{
"sources": [{"file": "'.$link.'", "type": "'.$type.'"}],
}],
    captions: {
        color: "#FFFFFF",
        fontSize: 20,
        backgroundOpacity: 0
    },
"height": $(document).height(),
"width": $(document).width(),
"skin": '.$skin.',
"title": "'.$title.'",
"abouttext": "'.$title.'",
"aboutlink": "prog.php?id='.$title1.'",
"stretching":"exactfit",
"androidhls": true,
"startparam": "start",
"autostart": true,
"fallback": false,
"wmode": "direct",
"stagevideo": true
});
</script>
</BODY>
</HTML>
';
}
?>

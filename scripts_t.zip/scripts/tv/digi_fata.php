<!DOCTYPE html>
<?php
include ("../common.php");
$page_title="In fata ta";
?>
<html><head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate"/>
<meta http-equiv="Pragma" content="no-cache"/>
<meta http-equiv="Expires" content="0"/>
      <title><?php echo $page_title; ?></title>
<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.8.0/jquery.min.js"></script>
<script src="../jquery.nicescroll.min.js"></script>

<script type="text/javascript">
  $(document).ready(function() {
	$("html").niceScroll({styler:"fb",cursorcolor:"#000"});
  });
</script>
<link rel="stylesheet" type="text/css" href="../custom.css" />
</head>
<body>
<?php
error_reporting(0);
function str_between($string, $start, $end){
	$string = " ".$string; $ini = strpos($string,$start);
	if ($ini == 0) return ""; $ini += strlen($start); $len = strpos($string,$end,$ini) - $ini;
	return substr($string,$ini,$len);
}
echo '<table border="1px" width="100%">'."\n\r";
echo '<TR><td style="color:black;background-color:deepskyblue;text-align:center" colspan="3"><font size="4"><b>'.$page_title.'</b></font></TD></TR>';
echo '</TR>';
$n=0;
$title="";
$cookie=$base_cookie."digi.dat";
//$search="In+fata+ta";
//$l="http://www.digi-online.ro/xhr-shows.php?keyword=".$search;
$l="http://m.digi24.ro/Emisiuni/Digi24/In+fata+ta/";
//$l="http://m.digi24.ro";
//$l="http://www.digi24.ro/emisiuni/in-fata-ta";
//$l="http://www.digi24.ro/emisiuni/in-fata-ta";
//$l="http://m.digi24.ro/Emisiuni/Digi24/In+fata+ta/Arhiva+inregistrari/In+fata+ta+24+iulie+13+05+2016";
  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $l);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  //curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Linux; U; Android 0.5; en-us) AppleWebKit/522+ (KHTML, like Gecko) Safari/419.3');
  //curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US; rv:1.9.1.2) Gecko/20090729 Firefox/3.5.2 GTB5');
  curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Linux; Android 4.4; Nexus 5 Build/_BuildID_) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/30.0.0.0 Mobile Safari/537.36');
  curl_setopt($ch, CURLOPT_FOLLOWLOCATION  ,1);
  //curl_setopt($ch, CURLOPT_HEADER  ,1);
  curl_setopt($ch, CURLOPT_REFERER, "http://m.digi24.ro");
  curl_setopt($ch, CURLOPT_COOKIEJAR, $cookie);
  curl_setopt($ch, CURLOPT_COOKIEFILE, $cookie);
  $html = curl_exec($ch);
  curl_close($ch);
//echo $html;
//die();
$videos = explode('<article class="card', $html);
unset($videos[0]);
$videos = array_values($videos);
foreach($videos as $video) {
    $video=html_entity_decode($video);
    //echo $video;
    $t=explode('href="',$video);
if ( sizeof($t)>1 ) {
    $t1=explode('"',$t[1]);
    $link="http://digi24.ro".$t1[0];
    $t1=explode('data-src="',$video);
    $t2=explode('"',$t1[1]);
    $image=urldecode($t2[0]);
  	//$title=str_between($video,'title image heading">','<');
  	//$t1=explode('class="title">',$video);
  	$t2=explode('title="',$video);
  	$t3=explode('"',$t2[1]);
  	$title=$t3[0];
    $link="digi24_fata_link.php?file=".$link."&title=".urlencode($title);
}
    if ($title) {
	if ($n == 0) echo "<TR>"."\n\r";
	echo '<TD style="text-align:center"><font size="4">'.'<a href="'.$link.'" target="_blank"><img src="'.$image.'" width="180px" height="110px"><BR>'.$title.'</a></font></TD>';
    $n++;
    if ($n > 2) {
     echo '</TR>'."\n\r";
     $n=0;
    }
 }
}
 if ($n<3) echo "</TR>"."\n\r";
 echo '</table>';
?>
<BODY>
</HTML>

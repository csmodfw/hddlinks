<!DOCTYPE html>
<?php
$query = $_GET["page"];
if($query) {
   $queryArr = explode(',', $query);
   $page= $queryArr[0];
   $search = $queryArr[1];
   $tit = urldecode($queryArr[2]);
   $tit=str_replace("\\","",$tit);
   $page_title=$tit;
}
?>
<html><head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
      <title><?php echo $tit; ?></title>
<link rel="stylesheet" type="text/css" href="../custom.css" />
<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.8.0/jquery.min.js"></script>
<script src="../jquery.nicescroll.min.js"></script>

<script type="text/javascript">
  $(document).ready(function() {
	$("html").niceScroll({styler:"fb",cursorcolor:"#000"});
  });
</script>
</head>
<body>
<H2></H2>
<h2 style="background-color:deepskyblue;color:black"><?php echo $tit; ?></h2>
<table border="1px" width="100%">
<?php
function str_between($string, $start, $end){
	$string = " ".$string; $ini = strpos($string,$start);
	if ($ini == 0) return ""; $ini += strlen($start); $len = strpos($string,$end,$ini) - $ini;
	return substr($string,$ini,$len);
}

$search1=str_replace("&","|",$search);
echo '<tr><TD colspan="4" align="right">';
if ($page > 1)
echo '<a href="antenaplay_main.php?page='.($page-1).','.$search1.','.urlencode($page_title).'"><font size="4">&nbsp;&lt;&lt;&nbsp;</font></a> | <a href="antenaplay_main.php?page='.($page+1).','.$search1.','.urlencode($page_title).'"><font size="4">&nbsp;&gt;&gt;&nbsp;</font></a></TD></TR>';
else
echo '<a href="antenaplay_main.php?page='.($page+1).','.$search1.','.urlencode($page_title).'"><font size="4">&nbsp;&gt;&gt;&nbsp;</font></a></TD></TR>';

//echo '<h2 style="background-color:deepskyblue;color:black">Antena Play</H2>';
echo '<table border="1px" width="100%">'."\n\r";
$link="http://antenaplay.ro/ajaxs/ajaxshows?page=".$page;
//echo $link;
$html=file_get_contents($link);
$videos=explode('<div class="span3 spanX',$html);
unset($videos[0]);
$videos = array_values($videos);
$n=0;
foreach($videos as $video) {
    if ($n == 0) echo "<TR>"."\n\r";
    $cat=str_between($video,'<a href="/','"');
	$title=str_between($video,'alt="','"');
	$data=str_between($video,'<div class="sname">','</div>');
	$data=str_replace("<div>","",$data);
	$data=str_replace("<p>							</p>","",$data);
	$image=str_between($video,'data-src="','"');
    $link="antenaplay.php?file=".urlencode($cat);
  if ($title) {
	if ($n == 0) echo "<TR>"."\n\r";
echo '
<TD><table border="0px">
<TD align="center"><a href="'.$link.'&title='.$title.'" target="_blank"><img src="'.$image.'" width="171" height="96"></a><BR><a href="'.$link.'" target="_blank"><b>'.$title.'</b></a></TD>

</TABLE></TD>
';
$n++;
    if ($n > 4) {
     echo '</TR>'."\n\r";
     $n=0;
    }
 }
}
 if ($n<0) echo "</TR>"."\n\r";
 echo '</table>';
?>
<br></body>
</html>

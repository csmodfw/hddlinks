<!DOCTYPE html>
<html><head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">

      <meta charset="utf-8">
      <title>Xstream TV</title>
      <link rel="stylesheet" type="text/css" href="../custom.css" />
<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.8.0/jquery.min.js"></script>
<script src="../jquery.nicescroll.min.js"></script>

      <script type="text/javascript" src="../jquery.fancybox.js?v=2.1.5"></script>
      <link rel="stylesheet" type="text/css" href="../jquery.fancybox.css?v=2.1.5" media="screen" />


<script type="text/javascript">
$(document).ready(function() {
	$(".various").fancybox({
		maxWidth	: 800,
		maxHeight	: 600,
		fitToView	: false,
		width		: '70%',
		height		: '70%',
		autoSize	: false,
		closeClick	: false,
		openEffect	: 'none',
		closeEffect	: 'none'
	});
	$('.fancybox').fancybox();
	$("html").niceScroll({styler:"fb",cursorcolor:"#000"});
});
</script>

<body>
<?php
error_reporting(0);
function str_between($string, $start, $end){
	$string = " ".$string; $ini = strpos($string,$start);
	if ($ini == 0) return ""; $ini += strlen($start); $len = strpos($string,$end,$ini) - $ini;
	return substr($string,$ini,$len);
}
include ("../common.php");
//include ("canale.php");

echo '<table border="1" align="center" width="100%">'."\n\r";
echo '<TR><td style="background-color:deepskyblue;color:black;text-align:center;" colspan="6"><font size="4"><b>Xstream TV</b></font></TD></TR>';
$n=0;
$m3uFile="http://hd4all.co.nf/vlc/xtr.m3u";
$m3uFile="http://astra.yoo.ro:9876/playlist.m3u8";
$m3uFile="http://mxcore.forithost.com/playlist.m3u";
$m3uFile = file($m3uFile);
foreach($m3uFile as $key => $line) {
  if(strtoupper(substr($line, 0, 7)) === "#EXTINF") {
   $t1=explode(",",$line);
   $title=trim($t1[1]);
   //$title1=$title;
   $link = trim($m3uFile[$key + 1]);
   $arr[]=array($title, $link);
}
}
asort($arr);
foreach ($arr as $key => $val) {
  $link=$arr[$key][1];
  $title=$arr[$key][0];
   //echo $link;
   //$link=str_replace('"',"",$link);
   //$link=str_replace('\n',"",$link);
   //$link=str_replace('\r',"",$link);
   //echo $link;
   //$link=str_replace("http","rtsp",$link);
   //$link=str_replace("30080","2554",$link);
   if ($n == 0) echo "<TR>"."\n\r";


   //$title2=str_replace(" (18+)","",str_replace(" HU","",str_replace(" English","",$title1)));
   //$title1=str_replace("+","%2b",$title1);

	$link="xstream_link.php?file=".$link."&title=".$title;
	//$link="direct_link.php?file=".$link."&title=".$title;
	//$link=str_replace("%0D%0A","",$link);
    echo '<TD><font size="4">'.'<a href="'.$link.'" target="_blank">'.$title.'</a></font>';
    echo '</TD>'."\n\r";
    $n++;
	$id_prog="";
	$id_prog=str_replace("+","plus",$title);
	$id_prog=strtolower(str_replace(" ","-",$id_prog));
	$id_prog=urlencode($id_prog);
	$id_prog=str_replace("-rom%C3%A2nia","",$id_prog);
	$id_prog=str_replace("%C5%A3","t",$id_prog);
	$id_prog=str_replace("%C3%A2","a",$id_prog);
	$id_prog=str_replace("%C5%9F","s",$id_prog);
	$id_prog=str_replace("%C4%83","a",$id_prog);
	$id_prog=urldecode($id_prog);
	//if (array_key_exists(strtolower(str_replace(" ","-",$title2)), $a))

	echo '	<td style="text-align:right;width:5px"><a class="various fancybox.ajax" href="prog.php?id='.$id_prog.'&title='.urlencode($title2).'"><font size="4">PROG</font></a></TD>';
    $n++;
    if ($n > 2) {
     echo '</TR>'."\n\r";
     $n=0;
    }
  }
 //}
 if ($n<6) echo "</TR>"."\n\r";
 echo '</table>';
?>

<br></body>
</html>

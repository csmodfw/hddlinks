<?php

function str_between($string, $start, $end){
	$string = " ".$string; $ini = strpos($string,$start);
	if ($ini == 0) return ""; $ini += strlen($start); $len = strpos($string,$end,$ini) - $ini;
	return substr($string,$ini,$len);
}
include ("../common.php");
$link="http://www.ahy.96.lt/chts";
  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $link);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 5.1; rv:14.0) Gecko/20100101 Firefox/14.0.1');
  $html=curl_exec($ch);
  curl_close($ch);
$videos = explode('<lip', $html);
unset($videos[0]);
$videos = array_values($videos);
foreach($videos as $video) {
    if ($n == 0) echo "<TR>"."\n\r";
    $ip=str_between($video,'value="','"');
}	
if (file_exists($base_pass."player.txt")) {
$flash=trim(file_get_contents($base_pass."player.txt"));
} else {
$flash="direct";
}
$id=$_GET["file"];
$title=urldecode($_GET["title"]);
//$out=str_replace("playlist/","play/",$out);
$out="http://".$ip."/".$id."";
if (strpos($base_pass,":") === false) {
header('Content-type: application/vnd.apple.mpegURL');
header('Content-Disposition: attachment; filename="1.mp4"');
header("Location: $out");
} else {
//$out=str_replace("&amp;","&",$out);
echo '
<html>
   <head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<style type="text/css">
body {
margin: 0px auto;
overflow:hidden;
}
body {background-color:#000000;}
</style>
      <title>'.$title.'</title>
   </head>
<body>

<embed type="application/x-vlc-plugin" pluginspage="http://www.videolan.org" version="VideoLAN.VLCPlugin.2"
width="100%"
height="100%"
id="vlc"
autoplay="yes"
target="'.$out.'">
</embed>



    <script language="Javascript">

    var vlc = document.getElementById("vlc");
    vlc.audio.toggleMute();
    vlc.subtitle.track="1";
	vlc.video.aspectRatio="16:9";

    </script>





    </body>
    </html>
';
}
?>

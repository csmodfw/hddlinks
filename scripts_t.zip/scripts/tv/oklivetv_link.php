<?php
set_time_limit(0);
error_reporting(0);
function str_between($string, $start, $end){
	$string = " ".$string; $ini = strpos($string,$start);
	if ($ini == 0) return ""; $ini += strlen($start); $len = strpos($string,$end,$ini) - $ini;
	return substr($string,$ini,$len);
}
function getSiteHost($siteLink) {
		// parse url and get different components
		$siteParts = parse_url($siteLink);
		// extract full host components and return host
		return $siteParts['scheme'].'://'.$siteParts['host'];
}
include ("../common.php");
require_once("../filme/JavaScriptUnpacker.php");
$ua="Mozilla/5.0 (Windows NT 10.0; WOW64; rv:46.0) Gecko/20100101 Firefox/46.0";
$jsu = new JavaScriptUnpacker();
$query = $_GET["file"];
if($query) {
   $queryArr = explode(',', $query);
   $l = urldecode($queryArr[0]);
   $title = urldecode($queryArr[1]);
}
  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $l);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_USERAGENT, $ua);
  curl_setopt($ch, CURLOPT_FOLLOWLOCATION  ,1);
  curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
  $h = curl_exec($ch);
  curl_close($ch);
if ($h && strpos($h,"script") === false)
  $html=gzdecode($h);
else
  $html=$h;
$t1=explode("idds=",$html);
$t2=explode("'",$t1[1]);
$l="http://oklivetv.com/xplay/xplay.php?idds=".$t2[0];
//echo $l;
  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $l);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 5.1; rv:22.0) Gecko/20100101 Firefox/22.0');
  curl_setopt($ch, CURLOPT_FOLLOWLOCATION  ,1);
  curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
  //curl_setopt($ch, CURLOPT_HEADER,1);
  //curl_setopt($ch, CURLOPT_NOBODY,1);
  $h = curl_exec($ch);
  curl_close($ch);
if ($h && strpos($h,"script") === false)
  $h=gzdecode($h);
  $l="";
  $out=$h;
$t1=explode('eval(function',$h);
$c=count($t1);
for ($k=1;$k<$c;$k++) {
  $in="eval(function".$t1[$k];
  $out .= $jsu->Unpack($in);
  //echo $out."\r\n"."\r\n";
}
if (strpos("tabs.php",$h) !== false) {
 $videos = explode('href="tabs.php', $h);
unset($videos[0]);
$videos = array_values($videos);
foreach($videos as $video) {
  $t1=explode('"',$video);
  $link="http://oklivetv.com/xplay/tabs.php".$t1[0];
  //echo $link."\r\n"."\r\n";
  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $link);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 5.1; rv:22.0) Gecko/20100101 Firefox/22.0');
  curl_setopt($ch, CURLOPT_FOLLOWLOCATION  ,1);
  curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
  //curl_setopt($ch, CURLOPT_HEADER,1);
  //curl_setopt($ch, CURLOPT_NOBODY,1);

  $h2 = curl_exec($ch);
  curl_close($ch);
  //echo $h2;
  //echo $h2."\r\n"."\r\n";
  $out .= $jsu->Unpack($h2);

}
}
$out=str_replace("script","xxxx",$out);
//echo $out."\r\n"."\r\n";
$l="";
$t1=explode('setup({file:"',$out);
$t2=explode('"',$t1[1]);
$l=$t2[0];
if (!$l) {
  $t1=explode('streamURL="',$out);
  $t2=explode('"',$t1[1]);
  $l=$t2[0];
}
//echo $l;
if (!$l){
  echo '<script type="text/javascript">window.close();</script>';
  die();
}
$link=$l;

if (file_exists($base_pass."player.txt")) {
$flash=trim(file_get_contents($base_pass."player.txt"));
} else {
$flash="direct";
}
if (file_exists($base_pass."mx.txt")) {
$mx=trim(file_get_contents($base_pass."mx.txt"));
} else {
$mx="ad";
}
$user_agent     =   $_SERVER['HTTP_USER_AGENT'];
if (preg_match("/android|ipad/i",$user_agent) && preg_match("/chrome|firefox|mobile/i",$user_agent)) $flash="chrome";
if ($flash=="mpc") {
  $mpc=trim(file_get_contents($base_pass."mpc.txt"));
  $c='"'.$mpc.'" /fullscreen "'.$link.'"';
  pclose(popen($c,"r"));
  echo '<script type="text/javascript">window.close();</script>';
  die();
}
if ($flash == "direct" || $flash=="chrome") {
header('Content-type: application/vnd.apple.mpegURL');
if (strpos($link,"m3u8") !== false) header('Content-Disposition: attachment; filename="playlist.m3u8"');
header("Location: $link");
} else {
if (strpos($link,"m3u8") !== false)
  $type="m3u8";
elseif (strpos($link,"rtmp") !== false)
  $type="rtmp";
else
  $type="m3u8";
echo '
<!doctype html>
<HTML>
<HEAD>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>'.$title.'</title>
<style type="text/css">
body {
margin: 0px auto;
overflow:hidden;
}
body {background-color:#000000;}
</style>
<script src="//code.jquery.com/jquery-1.11.0.min.js"></script>
'.$jwv.'

</HEAD>
<BODY>
<div id="container"></div>
<script type="text/javascript">
jwplayer("container").setup({
"playlist": [{
"sources": [{"file": "'.$link.'", "type": "'.$type.'"}],
}],
    captions: {
        color: "#FFFFFF",
        fontSize: 20,
        backgroundOpacity: 0
    },
"height": $(document).height(),
"width": $(document).width(),
"skin": '.$skin.',
"title": "'.$title.'",
"abouttext": "'.$title.'",
"aboutlink": "prog.php?id='.$title1.'",
"stretching":"exactfit",
"androidhls": true,
"startparam": "start",
"autostart": true,
"fallback": false,
"wmode": "direct",
"stagevideo": true
});
</script>
</BODY>
</HTML>
';
}
?>

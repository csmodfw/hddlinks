<!DOCTYPE html>
<?php
function str_between($string, $start, $end){
	$string = " ".$string; $ini = strpos($string,$start);
	if ($ini == 0) return ""; $ini += strlen($start); $len = strpos($string,$end,$ini) - $ini;
	return substr($string,$ini,$len);
}
include ("../common.php");
if (file_exists($base_pass."player.txt")) {
$flash=trim(file_get_contents($base_pass."player.txt"));
} else {
$flash="direct";
}
//$flash="NU";
$pin = $_GET["file"];
$srv = $_GET["serv"];
$title = $_GET["title"];
$link="http://stream-01.vty.dailymotion.com/".$srv."/dc/1/".$pin."/live.isml/manifest";
$html=file_get_contents($link);
//$n=0;
$aud = str_between($html,'<!-- Created with Unified Streaming Platform(version=1.5.6) -->','</SmoothStreamingMedia>');
$vid = str_between($html,'Type="video"','</SmoothStreamingMedia>');
$videos = explode('Index="',$vid);
unset($videos[0]);
$videos = array_values($videos);
$t1 = explode('"',$videos[sizeof($videos)-1]);
$vid = str_between($vid,'Index="'.$t1[0].'"','</StreamIndex>');
$live=trim(str_between($aud,'Url="Events(live-',')'));
$audio=trim(str_between($aud,'Bitrate="','"'));
$video=trim(str_between($vid,'Bitrate="','"'));


$out="http://stream-01.vty.dailymotion.com/".$srv."/dc/1/".$pin."/live.isml/events(live-".$live.")/live-audio%3D".$audio."-video%3D".$video.".m3u8";	
$out1=$out;
if ($flash == "direct") {
header('Content-type: application/vnd.apple.mpegURL');
header('Content-Disposition: attachment; filename="'.$title.'".m3u8"');
header("Location: $out1");
} else {
$out1=$out;
$t1=$_SERVER["PHP_SELF"];
if(!isset($_GET['screen_check'])) {
 echo "<script language='JavaScript'>
 <!-- 
 document.location=\"$t1?screen_check=done&file=$pin&title=$title&serv=$srv&Width=\"+window.innerWidth+\"&Height=\"+window.innerHeight;
 //-->
 </script>";
 die();
} else {    
	if(isset($_GET['Width']) && isset($_GET['Height'])) {
		$Width=$_GET['Width'];
		$Height=$_GET['Height'];
	}
}

echo '
<HTML>
<HEAD>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>'.$title.'</title>
<style type="text/css">
body {
margin: 0px auto;
overflow:hidden;
}
body {background-color:#000000;}
</style>
<link rel="dns-prefetch" href="//ajax.googleapis.com">
<link rel="dns-prefetch" href="//cdn.clappr.io">
<script type="text/javascript" src="http://cdn.clappr.io/latest/clappr.min.js"></script>

</HEAD>
<BODY>
<div id="player" ></div><script type="text/javascript">
$(function() {
	    var player = new Clappr.Player({
	    		source: "'.$out.'",
				parentId: "#player",
				loop: true,
				mute: false,
				autoPlay: true,
				autoPlayVisible: false,
				width: '.$Width.',
				height: '.$Height.',
				hideMediaControl: true,
				chromeless: false,
				maxBufferLength: 30,
				useHardwareVideoDecoder: true
		});
	});
</script>
</BODY>
</HTML>
';
}
?>

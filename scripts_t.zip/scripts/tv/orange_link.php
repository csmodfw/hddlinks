<?php
function str_between($string, $start, $end){
	$string = " ".$string; $ini = strpos($string,$start);
	if ($ini == 0) return ""; $ini += strlen($start); $len = strpos($string,$end,$ini) - $ini;
	return substr($string,$ini,$len);
}
include ("../common.php");
if (file_exists($base_pass."player.txt")) {
$flash=trim(file_get_contents($base_pass."player.txt"));
} else {
$flash="direct";
}
//$flash="NU";
$pin = $_GET["file"];
$srv = $_GET["serv"];
$title = $_GET["title"];
$offline=0;
$s=mt_rand(1,9);
$link="http://stream-0".$s.".vty.dailymotion.com/".$srv."/dc/1/".$pin."/live.isml/manifest";
  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $link);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_HEADER, 1);
  curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 5.1; rv:14.0) Gecko/20100101 Firefox/14.0.1');
  curl_setopt($ch, CURLOPT_FOLLOWLOCATION  ,1);
  curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
  $html = curl_exec($ch);
  curl_close($ch);

if (strpos($html,'HTTP/1.1 404') !== false) {
for( $n=29; $n>=20; $n-- ) {
$srv=$n;
$link="http://stream-0".$s.".vty.dailymotion.com/".$srv."/dc/1/".$pin."/live.isml/manifest";
  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $link);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_HEADER, 1);
  curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 5.1; rv:14.0) Gecko/20100101 Firefox/14.0.1');
  curl_setopt($ch, CURLOPT_FOLLOWLOCATION  ,1);
  curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
  $html = curl_exec($ch);
  curl_close($ch);

if (strpos($html,'HTTP/1.1 200') !== false) {
$n=0;
$offline=0;
} else {
$offline=1;
}

}
}
if ($offline != 0) {
echo '
<!DOCTYPE html>
<link rel="stylesheet" type="text/css" href="../custom.css" />
<table border="2" width="100%">'."\n\r".'
<TR><td style="background-color:deepskyblue;color:black;text-align:left" colspan="4"><font size="4"><b>Channel  '.$title.' is offline!</b></font></TD></TR>
</table>
';
die();
}
//$n=0;
$aud = str_between($html,'<!-- Created with Unified Streaming Platform(version=1.5.6) -->','</SmoothStreamingMedia>');
$vid = str_between($html,'Type="video"','</SmoothStreamingMedia>');
$videos = explode('Index="',$vid);
unset($videos[0]);
$videos = array_values($videos);
$t1 = explode('"',$videos[sizeof($videos)-1]);
$vid = str_between($vid,'Index="'.$t1[0].'"','</StreamIndex>');
$live=trim(str_between($aud,'Url="Events(live-',')'));
$audio=trim(str_between($aud,'Bitrate="','"'));
$video=trim(str_between($vid,'Bitrate="','"'));


$out="http://stream-0".$s.".vty.dailymotion.com/".$srv."/dc/1/".$pin."/live.isml/events(live-".$live.")/live-audio%3D".$audio."-video%3D".$video.".m3u8";	

if ($flash == "direct") {
header('Content-type: application/vnd.apple.mpegURL');
header('Content-Disposition: attachment; filename="'.$title.'".m3u8"');
header("Location: $out");
} else {

$t1=$_SERVER["PHP_SELF"];
if(!isset($_GET['screen_check'])) {
 echo "<script language='JavaScript'>
 <!-- 
 document.location=\"$t1?screen_check=done&file=$pin&title=$title&serv=$srv&Width=\"+window.innerWidth+\"&Height=\"+window.innerHeight;
 //-->
 </script>";
 die();
} else {    
	if(isset($_GET['Width']) && isset($_GET['Height'])) {
		$Width=$_GET['Width'];
		$Height=$_GET['Height'];
	}
}

echo '
<!DOCTYPE html>
<HTML>
<HEAD>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>'.$title.'</title>
<style type="text/css">
body {
margin: 0px auto;
overflow:hidden;
}
body {background-color:#000000;}
</style>
<link rel="dns-prefetch" href="//ajax.googleapis.com">
<link rel="dns-prefetch" href="//cdn.clappr.io">
<script type="text/javascript" src="http://cdn.clappr.io/latest/clappr.min.js"></script>

</HEAD>
<BODY>
<div id="player" ></div><script type="text/javascript">
$(function() {
	    var player = new Clappr.Player({
	    		source: "'.$out.'",
				parentId: "#player",
				loop: true,
				mute: false,
				autoPlay: true,
				autoPlayVisible: false,
				width: '.$Width.',
				height: '.$Height.',
				hideMediaControl: true,
				chromeless: false,
				maxBufferLength: 30,
				useHardwareVideoDecoder: true
		});
	});
</script>
</BODY>
</HTML>
';
}
?>

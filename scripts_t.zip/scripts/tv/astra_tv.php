<!DOCTYPE html>
<?php
$query=$_GET["query"];
$queryarr = explode(",",$query);
$link = $queryarr[0];
$pg_tit = urldecode($queryarr[1]);
?>
<html>



   <head>

      <meta charset="utf-8">
      <title><?php echo $pg_tit; ?></title>
      <link rel="stylesheet" type="text/css" href="../custom.css" />
<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.8.0/jquery.min.js"></script>
<script src="../jquery.nicescroll.min.js"></script>
      <script type="text/javascript" src="../jquery.fancybox.js?v=2.1.5"></script>
      <link rel="stylesheet" type="text/css" href="../jquery.fancybox.css?v=2.1.5" media="screen" />


<script type="text/javascript">
$(document).ready(function() {
	$(".various").fancybox({
		maxWidth	: 800,
		maxHeight	: 600,
		fitToView	: false,
		width		: '70%',
		height		: '70%',
		autoSize	: false,
		closeClick	: false,
		openEffect	: 'none',
		closeEffect	: 'none'
	});
	$('.fancybox').fancybox();
 $("html").niceScroll({styler:"fb",cursorcolor:"#000"});
});
</script>
  </head>
   <body>
<h2 style="background-color:deepskyblue;color:black;;text-align:center"><?php echo $pg_tit; ?></H2>

<table border="1px" width="100%">
<?php
function str_between($string, $start, $end){
	$string = " ".$string; $ini = strpos($string,$start);
	if ($ini == 0) return ""; $ini += strlen($start); $len = strpos($string,$end,$ini) - $ini;
	return substr($string,$ini,$len);
}
$xor_key = 'hd4all';
function xorIt($string, $key, $type = 0)
{
        $sLength = strlen($string);
        $xLength = strlen($key);
        for($i = 0; $i < $sLength; $i++) {
                for($j = 0; $j < $xLength; $j++) {
                        if ($type == 1) {
                                //decrypt
                                $string[$i] = $key[$j]^$string[$i];
                                 
                        } else {
                                //crypt
                                $string[$i] = $string[$i]^$key[$j];
                        }
                }
        }
        return $string;
}
$link="http://www.alltv.96.lt/live/json.php";
  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $link);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 5.1; rv:14.0) Gecko/20100101 Firefox/14.0.1');
  $html=curl_exec($ch);
  curl_close($ch);
  $videos = explode('BGLIVE', $html);
$n=0;
unset($videos[0]);
  foreach($videos as $video) {
    $t1 = explode('"title":"', $video);
    $t2 = explode('"', $t1[1]);
    $title = $t2[0];
	
    $t1 = explode('"idEPG":"', $video);
    $t2 = explode('"', $t1[1]);
    $title1 = $t2[0];
	
    $t1 = explode('"playURL":"', $video);
    $t2 = explode('"', $t1[1]);
    $link = $t2[0];
	$link = xorIt(base64_decode($link), $xor_key, 1);
    $link="spyce_tv_link.php?file=".urlencode($link)."&title=".urlencode($title);
    if (strpos($link,"html")=== false) {
    if ($n == 0) echo "<TR>"."\n\r";
    echo '<TD style="text-align:center"><font size="4">'.'<a href="'.$link.'" target="_blank">'.$title.'</a></font></TD>';
    $n++;
   	echo '	<td style="text-align:right;width:5px"><a class="various fancybox.ajax" href="prog.php?id='.$title1.'&title='.urlencode($title).'"><font size="4">PROG</font></a></TD>';
    $n++;
    if ($n > 5) {
     echo '</TR>'."\n\r";
     $n=0;
    }
  }
}
if ($n<6) echo "</TR>"."\n\r";
 echo '</table>';
?>
</body>
</html>

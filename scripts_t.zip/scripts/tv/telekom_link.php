<?php
function str_between($string, $start, $end){
	$string = " ".$string; $ini = strpos($string,$start);
	if ($ini == 0) return ""; $ini += strlen($start); $len = strpos($string,$end,$ini) - $ini;
	return substr($string,$ini,$len);
}
include ("../common.php");
if (file_exists($base_pass."player.txt")) {
$flash=trim(file_get_contents($base_pass."player.txt"));
} else {
$flash="direct";
}

$link = urldecode($_GET["file"]);
    $t1=explode("id=",$link);
	$id=trim($t1[1]);
$title = urldecode($_GET["title"]);
    $title1=strtolower($title);
    $t1=explode("(",$title1);
    $title1=trim($t1[0]);
    $title1=str_replace(" ","-",$title1);

//$link="http://www.alltv.96.lt/tk/extk.php?id=".$id;
//$link=$id.".m3u8";
//$link=str_replace("extk.php?id=","live/",$link);
//$link=$id;

//echo $link;
//die();
$list = glob($base_sub."*.m3u8");
   foreach ($list as $l) {
    str_replace(" ","%20",$l);
    unlink($l);
}
$out=file_get_contents($link);
//echo $out;
  $movie_file=$base_sub.$id.".m3u8";
   $fh = fopen($movie_file, 'w');
   fwrite($fh, $out, strlen($out));
   fclose($fh);

$out1="#EXTM3U
http://".$_SERVER['HTTP_HOST']."/scripts/subs/".$id.".m3u8";
  $movie_file="play.m3u8";
   $fh = fopen($movie_file, 'w');
   fwrite($fh, $out1, strlen($out1));
   fclose($fh);
   
   
if ($flash == "direct11") {
$link="play.m3u8";
//$link="../subs/'.$id.'.m3u8";
header('Content-type: application/vnd.apple.mpegURL');
header('Content-Disposition: attachment; filename="'.$title.'.m3u8"');
header("Location: $link");
} else {
$t1=$_SERVER["PHP_SELF"];
if(!isset($_GET['screen_check'])) {
 echo "<script language='JavaScript'>
 <!-- 
 document.location=\"$t1?screen_check=done&file=$link&title=$title&&Width=\"+window.innerWidth+\"&Height=\"+window.innerHeight;
 //-->
 </script>";
 die();
} else {    
	if(isset($_GET['Width']) && isset($_GET['Height'])) {
		$Width=$_GET['Width'] - 24;
		$Height=$_GET['Height'] - 24;
	}
}

echo '
<!doctype html>
<HTML>
<HEAD>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>'.$title.'</title>
<style type="text/css">
body {
margin: 0px auto;
overflow:hidden;
}
body {background-color:#000000;}
</style>
<script src="//code.jquery.com/jquery-1.11.0.min.js"></script>
'.$jwv.'

</HEAD>
<BODY>
<div id="container"></div>
<script type="text/javascript">
jwplayer("container").setup({
"playlist": [{
"sources": [{"file": "../subs/'.$id.'.m3u8", "type": "m3u8"}],
}],
    captions: {
        color: "#FFFFFF",
        fontSize: 20,
        backgroundOpacity: 0
    },
"height": '.$Height.',
"width": '.$Width.',
"skin": '.$skin.',
"title": "'.$title.'",
"abouttext": "'.$title.'",
"aboutlink": "prog.php?id='.$title1.'",
"stretching":"exactfit",
"androidhls": true,
"startparam": "start",
"autostart": true,
"fallback": false,
"wmode": "direct",
"stagevideo": true
});
</script>
</BODY>
</HTML>
';
}
?>

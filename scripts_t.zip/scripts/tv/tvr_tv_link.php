<?php
set_time_limit(0);
error_reporting(0);
function str_between($string, $start, $end){
	$string = " ".$string; $ini = strpos($string,$start);
	if ($ini == 0) return ""; $ini += strlen($start); $len = strpos($string,$end,$ini) - $ini;
	return substr($string,$ini,$len);
}
function enc($string) {
  $local3="";
  $arg1=strlen($string);
  $arg2="mediadirect";
  $l_arg2=strlen($arg2);
  $local4=0;
  while ($local4 < $arg1) {
    $m1=ord($string[$local4]);
    $m2=ord($arg2[$local4 % $l_arg2]);
    $local3=$local3.chr($m1 ^ $m2);
    $local4++;
  }
  return $local3;
}
include ("../common.php");
$cookie=$base_cookie."tvrplus_tv.dat";
if (!file_exists($cookie)) {
  $l="http://www.tvrplus.ro/androidphone/live";
  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $l);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Linux; U; Android 0.5; en-us) AppleWebKit/522+ (KHTML, like Gecko) Safari/419.3');
  curl_setopt($ch, CURLOPT_FOLLOWLOCATION  ,1);
  curl_setopt($ch, CURLOPT_COOKIEJAR, $cookie);
  curl_setopt($ch, CURLOPT_COOKIEFILE, $cookie);
  $h = curl_exec($ch);
  curl_close($ch);
}
if (file_exists($base_pass."player.txt")) {
$flash=trim(file_get_contents($base_pass."player.txt"));
} else {
$flash="direct";
}
if (file_exists($base_pass."mx.txt")) {
$mx=trim(file_get_contents($base_pass."mx.txt"));
} else {
$mx="ad";
}
$user_agent     =   $_SERVER['HTTP_USER_AGENT'];
if (preg_match("/android|ipad/i",$user_agent) && preg_match("/chrome|firefox|mobile/i",$user_agent)) $flash="chrome";
if (file_exists($base_pass."tv.txt")) {
$tv=trim(file_get_contents($base_pass."tv.txt"));
} else {
$tv="dinamic";
}
$PHP_SELF="";
$token = "";
$Width="";
$Height="";
$id = $_GET["id"];
$title = urldecode($_GET["title"]);
$s="http://index.mediadirect.ro/getUrl?publisher=4";
$h = file_get_contents($s);
$t1=explode('server=',$h);
$t2=explode('&',$t1[1]);
$serv=$t2[0];
$link="http://www.tvrplus.ro/androidphone/show/live/id/".$id;
  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $link);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Linux; U; Android 0.5; en-us) AppleWebKit/522+ (KHTML, like Gecko) Safari/419.3');
  curl_setopt($ch, CURLOPT_FOLLOWLOCATION  ,1);
  curl_setopt($ch, CURLOPT_COOKIEFILE, $cookie);
  $html = curl_exec($ch);
  curl_close($ch);
//$html = file_get_contents($link);
$html=str_replace("\\","",$html);
//echo $html;
$t1=explode('high quality stream name":"',$html);
$t2=explode('"',$t1[1]);
$str=$t2[0];
$t1=explode('token-high":"',$html);
$t2=explode('"',$t1[1]);
$token=$t2[0];

if ($serv == "") {
  $serv="fms1.mediadirect.ro";
}
$out = "http://".$serv.":1937/live3/_definst_/".$str."/".$title.".m3u8?id=10668839&publisher=4&siteId=0&user_id=0&transaction_id=0&p_item_id=7&token=".$token;

if (((strpos($_SERVER["SERVER_NAME"],"seenow") !== false) || (!$token)) && strpos($base_pass,":") !== false) $flash="site";
if ($flash=="mpc") {
  $mpc=trim(file_get_contents($base_pass."mpc.txt"));
  $c='"'.$mpc.'" /fullscreen "'.$out.'"';
  pclose(popen($c,"r"));
  echo '<script type="text/javascript">window.close();</script>';
  die();
}
if ($flash == "direct" || $flash=="chrome") {
header('Content-type: application/vnd.apple.mpegURL');
header('Content-Disposition: attachment; filename="playlist.m3u8"');
header("Location: $out");
} elseif (($flash=="html5" || $flash=="flash") && ($tv<>"vlc")) {
$app="live3";
if ($tv=="fms38.mediadirect.ro")
 $serv="fms38.mediadirect.ro";

$rtmp="rtmpe://".$serv."/".$app."/_definst_?token=".$token;
echo '<!doctype html>
<HTML>
<HEAD>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>'.$title.'</title>
<style type="text/css">
body {
margin: 0px auto;
overflow:hidden;
}
body {background-color:#000000;}
</style>
<script src="//code.jquery.com/jquery-1.11.0.min.js"></script>
<script type="text/javascript" src="../filme/jwplayer.js"></script>

</HEAD>
<BODY>
<div id="container"></div>
<script type="text/javascript">
jwplayer("container").setup({
"players": [{"type":"flash","src":"../filme/player.swf"}],
"file": "'.$str.'",
"token": "'.$token.'",
"height": $(document).height(),
"width": $(document).width(),
"skin": "../skin.zip",
"dock": "true",
"autostart": "true",
"controlbar.position": "over",
"controlbar.idlehide": "false",
"backcolor": "000000",
"frontcolor": "ffffff",
"lightcolor": "f7b01e",
"stretching": "exactfit",
"streamer": "'.$rtmp.'",
"volume": "100",
});
</script>
</BODY>
</HTML>
';
} elseif ($flash == "site") {
if(!isset($_GET['screen_check'])) {
$t1=$_SERVER["PHP_SELF"];
 echo "<script language='JavaScript'>
 <!-- 
 document.location=\"$t1?screen_check=done&id=$id&title=$title&Width=\"+window.innerWidth+\"&Height=\"+window.innerHeight;
 //-->
 </script>";
} else {    
	if(isset($_GET['Width']) && isset($_GET['Height'])) {
		$Width=$_GET['Width']-48;
		$Height=$_GET['Height']-48;
	}
}

$data = "cnow"; //seenow | dolce_sport | tvr?!?
$str = base64_encode(enc($str));
$data = base64_encode(enc($data));

echo '
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">

<title>'.$title.'</title>

<link rel="stylesheet" type="text/css" href="../custom.css" />

</head>
<body {
margin: 0px auto;
overflow:hidden;
}>



<object id="player_mediadirect">
			<embed type="application/x-shockwave-flash"	id="player_mediadirect" src="http://static1.mediadirect.ro/mediaplayer/players/0037/player.swf"	menu="false" 
			play="true" loop="false" quality="high" bgcolor="#000000" allowScriptAccess="always" allowFullScreen="true" scale = "noscale" wmode = "direct"	
			width="'.$Width.'" height="'.$Height.'" flashVars="app=FlUZRg0NHxdW&str='.$str.'&data='.$data.'&autoplay=true" salign="tl"/>
			</object>
			
</body>
</html>
';
} else {
$out = "http://".$serv.":1937/live3/_definst_/".$str."/playlist.m3u8?token=".$token;
echo '
<html>
   <head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<style type="text/css">
body {
margin: 0px auto;
overflow:hidden;
}
</style>
      <title>'.$title.'</title>
   </head>
<body>

<embed type="application/x-vlc-plugin" pluginspage="http://www.videolan.org" version="VideoLAN.VLCPlugin.2"
width="100%"
height="100%"
id="vlc"
target="'.$out.'">
</embed>


    <script language="Javascript">

    var vlc = document.getElementById("vlc");
    vlc.audio.toggleMute();


    </script>

    </body>
    </Html>
';
}
if ($flash=="test") {
$app="live3";
$serv="fms38.mediadirect.ro";
$rtmp="rtmp://".$serv."/".$app."/_definst_?token=".$token;
if(!isset($_GET['screen_check']))
{
 echo "<script language='JavaScript'>
 <!--
 document.location=\"$PHP_SELF?screen_check=done&id=$id&title=$title&Width=\"+window.innerWidth+\"&Height=\"+window.innerHeight;
 //-->
 </script>";
}
else
{
	if(isset($_GET['Width']) && isset($_GET['Height'])) {
		$w=$_GET['Width'];
		$h=$_GET['Height'];    //-48
		//$p=str_replace('width="480"','width='.$w,$p);
		//$p=str_replace('height="270"','height='.$h,$p);
	}
}
echo '<!doctype html>
<HTML>
<HEAD>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>'.$title.'</title>
<style type="text/css">
body {
margin: 0px auto;
overflow:hidden;
}
body {background-color:#000000;}
</style>
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.7/jquery.js"></script>
<script type="text/javascript" src="http://releases.flowplayer.org/js/flowplayer-3.2.13.min.js"></script>
<script src="http://cdn.jquerytools.org/1.2.6/all/jquery.tools.min.js"></script>
</HEAD>
<BODY>
<div id="container" style="width:'.$w.'px;height:'.$h.'px"></div>
<script>
$f("container", "http://releases.flowplayer.org/swf/flowplayer-3.2.18.swf", {

    clip: {
        url: "'.$str.'",
        scaling: "fit",
        // configure clip to use hddn as our provider, referring to our rtmp plugin
        provider: "rtmp"
    },

    // streaming plugins are configured under the plugins node
    plugins: {

        // here is our rtmp plugin configuration
        rtmp: {
            url: "flowplayer.rtmp-3.2.13.swf",

            // netConnectionUrl defines where the streams are found
            netConnectionUrl: "'.$rtmp.'"
        }
    },
    canvas: {
        backgroundGradient: "none"
    }
});
</script>
</body>
</html>
';
}
?>

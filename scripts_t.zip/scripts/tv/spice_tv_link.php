<?php
function str_between($string, $start, $end){
	$string = " ".$string; $ini = strpos($string,$start);
	if ($ini == 0) return ""; $ini += strlen($start); $len = strpos($string,$end,$ini) - $ini;
	return substr($string,$ini,$len);
}
//http://gradajoven.es/spicenew.php
//http://edge3.spicetvnetwork.de:1935/live/_definst_/mp4:spicetv/ro/6tv.stream/chunklist_w2087458837.m3u8?c=176&u=52409&e=1398753453&t=298944a96a9161b2300ae3ae072b85f4&d=android&i=1.30
//http://edge1.spicetvnetwork.de:1935/live/_definst_/mp4:spicetv/ro/6tv.streamchunklist_w2087458837.m3u8?c=176&u=52560&e=1398777448&t=3869972b307e53bfd2e048f093fd5f1c&d=site&i=Android%2C+Safari
$link = $_GET["file"];
$title = urldecode($_GET["title"]);
include ("../common.php");
if (file_exists($base_pass."player.txt")) {
$flash=trim(file_get_contents($base_pass."player.txt"));
} else {
$flash="direct";
}
$filename = $base_pass."spicetv.txt";
$cookie=$base_cookie."spicetv.dat";
$cookie1=$base_cookie."spicetv.txt";

/* if (file_exists($cookie1)) {
  $handle = fopen($cookie1, "r");
  $c = fread($handle, filesize($cookie1));
  fclose($handle);
  $fh = fopen($cookie, 'w');
  fwrite($fh, $c);
  fclose($fh);
}*/

  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $link);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 5.1; rv:31.0) Gecko/20100101 Firefox/31.0');
  curl_setopt($ch, CURLOPT_FOLLOWLOCATION  ,1);
  curl_setopt($ch, CURLOPT_REFERER,"http://www.spicetvbox.ro/live");
  curl_setopt($ch, CURLOPT_COOKIEFILE, $cookie);
  curl_setopt($ch, CURLOPT_COOKIEJAR, $cookie);
  $h = curl_exec($ch);
  curl_close($ch);

  //echo $h;

if (file_exists($cookie)) {
  $handle = fopen($cookie, "r");
  $c = fread($handle, filesize($cookie));
  fclose($handle);
	if (strpos($c,"stvDevice") !== false) {
		$lines = explode(PHP_EOL, $c);
		$fh = fopen($cookie1, 'w');
		foreach($lines as $line)
			if (strpos($line,"stvDevice") !== false) 
				fwrite($fh, $line."\n");
		fclose($fh);
	} elseif (file_exists($cookie1)) {
		$handle = fopen($cookie, "r");
		$c = fread($handle, filesize($cookie));
		fclose($handle);
	if (strpos($c,"stvDevice") === false) {
		$fh = fopen($cookie1, "r");
		$d = fread($fh, filesize($cookie1));
		fclose($fh);
		$handle = fopen($cookie, "a");
		fwrite($handle, $d."\n");
		fclose($handle);

	}
  }
}
 
$out=str_between($h,"var stvLiveStream='","'");
$rtmp=str_between($h,"var stvLiveStreamer='","'");
$str=str_between($h,"var stvLiveChannel='","'");
//echo $out;
//die();
if (!$out) die();
if (strpos($base_pass,":") === false) {
header('Content-type: application/vnd.apple.mpegURL');
header('Content-Disposition: attachment; filename="playlist.m3u8"');
header("Location: $out");
} else {
echo '
<!doctype html>
<HTML>
<HEAD>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>'.$title.'</title>
<style type="text/css">
body {
margin: 0px auto;
overflow:hidden;
}
body {background-color:#000000;}
</style>
<script src="//code.jquery.com/jquery-1.11.0.min.js"></script>
<script src="http://jwpsrv.com/library/5V3tOP97EeK2SxIxOUCPzg.js"></script>

</HEAD>
<BODY>
<div id="container"></div>
<script type="text/javascript">
jwplayer("container").setup({
"flashplayer": "http://static.spicetvbox.com/flash/jwplayer.flash.swf",
"type": "rtmp",
"streamer": "'.$rtmp.'",
"file": "'.$str.'",
"primary": "flash",
"height": $(document).height(),
"width": $(document).width(),
"skin": '.$skin.',
"stretching": "exactfit",
"dock": "true",
"autostart": "true",
"aspectratio": "16:9",
"abouttext": "'.$title.'",
"aboutlink": "'.$_SERVER["REQUEST_URI"].'"
});
</script>
</BODY>
</HTML>
';
}
?>
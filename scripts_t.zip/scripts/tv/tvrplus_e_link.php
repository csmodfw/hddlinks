<?php
function str_between($string, $start, $end){
	$string = " ".$string; $ini = strpos($string,$start);
	if ($ini == 0) return ""; $ini += strlen($start); $len = strpos($string,$end,$ini) - $ini;
	return substr($string,$ini,$len);
}
function enc($string) {
  $local3="";
  $arg1=strlen($string);
  $arg2="mediadirect";
  $l_arg2=strlen($arg2);
  $local4=0;
  while ($local4 < $arg1) {
    $m1=ord($string[$local4]);
    $m2=ord($arg2[$local4 % $l_arg2]);
    $local3=$local3.chr($m1 ^ $m2);
    $local4++;
  }
  return $local3;
}
function rand_string( $length ) {
	$str = "";
	$characters = array_merge(range('a','f'), range('0','9'));
	$max = count($characters) - 1;
	for ($i = 0; $i < $length; $i++) {
		$rand = mt_rand(0, $max);
		$str .= $characters[$rand];
	}
 return $str;
}
function search_arr($array, $key, $value)
{
    $results = array();

    if (is_array($array)) {
        if (isset($array[$key]) && $array[$key] == $value) {
            $results[] = $array;
        }

        foreach ($array as $subarray) {
            $results = array_merge($results, search_arr($subarray, $key, $value));
        }
    }

    return $results;
}
$id=""; $pg_id=""; $tit="";
$id = $_GET["file"];
if (array_key_exists("tit",$_GET)) $tit=$_GET["tit"];
if (array_key_exists("pg_id",$_GET)) $pg_id = $_GET["pg_id"];
if (strpos($tit,"TV") !== false) $pg_id="60";
if (strpos($tit,"Koolnet") !== false) $pg_id="5514";
$title = urldecode($_GET["title"]);
$svr=""; $serv="";
$sub=""; $subtracks="";
$token="";
$str_name="";
$p=array();
$PHP_SELF="";
$Width="";
$Height="";
include ("../common.php");
$filename = $base_pass."seenowtv.txt";
$cookie=$base_cookie."seenowtv.dat";
if (file_exists($base_pass."player.txt")) {
$flash=trim(file_get_contents($base_pass."player.txt"));
} else {
$flash="direct";
}
if (file_exists($base_pass."tv.txt")) {
$tv=trim(file_get_contents($base_pass."tv.txt"));
} else {
$tv="dinamic";
}
if ( is_numeric($id) ) {
$l="http://www.seenow.ro/windows/placeholder/list/id/".$pg_id."/start/0/limit/999";
$h = file_get_contents($l);

/*
  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $l);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 5.1; rv:14.0) Gecko/20100101 Firefox/14.0.1');
  curl_setopt($ch, CURLOPT_FOLLOWLOCATION  ,1);
  //curl_setopt($ch, CURLOPT_REFERER,"http://www.seenow.ro/");
  curl_setopt($ch, CURLOPT_COOKIEFILE, $cookie);
  $h = curl_exec($ch);
  curl_close($ch);
*/
$t1=json_decode($h,1);

if ($t1) if (array_key_exists("items",$t1)) {
$items=$t1['items'];
$items = array_values($items);

$willStartPlayingUrl = "http://www.seenow.ro/windows/historylist/add/id/".$id;
$h=search_arr($items, 'willStartPlayingUrl', $willStartPlayingUrl);
if (!$h) $h=search_arr($items, 'title', $title);

if (sizeof($h)>0 && !(($pg_id==22 || $pg_id==5036))) {

if (array_key_exists("playURL",$h[0])) {

  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $h[0]["playURL"]);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 5.1; rv:14.0) Gecko/20100101 Firefox/14.0.1');
  curl_setopt($ch, CURLOPT_FOLLOWLOCATION  ,1);
  //curl_setopt($ch, CURLOPT_REFERER,"http://www.seenow.ro/");
  curl_setopt($ch, CURLOPT_COOKIEFILE, $cookie);
  $h = curl_exec($ch);
  curl_close($ch);


$p=json_decode($h,1);
}
}  elseif ($pg_id==22 || $pg_id==5036 )
  $p=$h[0];

}
if (array_key_exists("streamUrl",$p)) {
$l=$p["streamUrl"];
$t1=explode("token=",$l);
if (sizeof($t1)>1) {
$t2=explode('|',$t1[1]);
$token=$t2[0];
}
$t1=explode('|',$l);
$l=$t1[0];
}
if (!$p) {
$l="http://www.seenow.ro/smarttv/placeholder/view/id/".$id;


  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $l);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 5.1; rv:14.0) Gecko/20100101 Firefox/14.0.1');
  curl_setopt($ch, CURLOPT_FOLLOWLOCATION  ,1);
  //curl_setopt($ch, CURLOPT_REFERER,"http://www.seenow.ro/");
  curl_setopt($ch, CURLOPT_COOKIEFILE, $cookie);
  $h = curl_exec($ch);
  curl_close($ch);

$p=json_decode($h,1);
}

if ($p) if (array_key_exists("high quality stream name",$p)) {
$t1="";
if (array_key_exists("streamUrl",$p)) $t1=$p["streamUrl"];
if (!$t1) {

if (array_key_exists("playURL",$p)) {
  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $p["playURL"]);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 5.1; rv:14.0) Gecko/20100101 Firefox/14.0.1');
  curl_setopt($ch, CURLOPT_FOLLOWLOCATION  ,1);
  //curl_setopt($ch, CURLOPT_REFERER,"http://www.seenow.ro/");
  curl_setopt($ch, CURLOPT_COOKIEFILE, $cookie);
  $h = curl_exec($ch);
  curl_close($ch);



$p=json_decode($h,1);
}
}
$str_name=$p["high quality stream name"];
if (array_key_exists("streamUrl",$p)) {
$l=$p["streamUrl"];
$t1=explode("token=",$l);
if (sizeof($t1)>1) {
$t2=explode('|',$t1[1]);
$token=$t2[0];
}
$t1=explode('|',$l);
$l=$t1[0];
}
}
if($p) {
 $u="user_id=0&transaction_id=0&p_item_id=".$id."&device_id=0&publisher=20";
if (!$token) if (array_key_exists("token-high",$p)) {
 $token=$p["token-high"];
 $l="http://[%server_name%]:1937/live3/_definst_/".$str_name."/playlist.m3u8?".$u."&token=".$token;
} else {
$l="http://178.21.120.198:1935/live3/_definst_/".$str_name."/playlist.m3u8?".$u."&token=".$token;
}
$f=$base_pass."seenow1.txt";
if (array_key_exists("qualities",$p) && file_exists($f)) {
$token=$p['qualities'][0]['token'];
$str_name=$p['qualities'][0]['stream name'];
$app=$p['qualities'][0]['application name'];
if ($app == "seenow")
$l="http://[%server_name%]:8888/".$app."/".$str_name."?user_id=0&transaction_id=0&publisher=24&p_item_id=".$id."&token=".$token;
else
$l="http://[%server_name%]:1937/".$app."/_definst_/".$str_name."/playlist.m3u8?user_id=0&transaction_id=0&publisher=24&p_item_id=".$id."&token=".$token;
} 
 else 
	$site = "flash";
if (array_key_exists("application name",$p)) if ($p["application name"]=="radio") {
$audio=$p["audio stream name"];
$img=$p["image"];
}
}
if (!$token) {
$f=$base_pass."seenow1.txt";
if (file_exists($f)) {
$token=rand_string(48);
$u="user_id=0&transaction_id=0&p_item_id=".$id."&device_id=0&publisher=24";
if (!($pg_id==22 || $pg_id==5036)) {
if ((strpos($base_pass,":") !== false) && ($tv != "vlc")) $flash="site";
if (!(($pg_id==9 || $pg_id==60 || $pg_id==62 || $pg_id==564 || $pg_id==5514 || $pg_id==5658))) $l="http://[%server_name%]:1937/seenow/_definst_/mp4:".$str_name."/playlist.m3u8?".$u."&token=".$token;
}
}
}

if ($p) if (array_key_exists("subtitles",$p)) {
$t1=$p["subtitles"];
if (sizeof($t1) > 1) {
   $t2 = search_arr($t1, 'code', 'RO');
   $t3 = $t2[0];
   $sub=$t3["srt"];
}
else
   $sub = $t1;
if ($sub) {
   $t1 = '{"file": "'.$sub.'", "default": true}';
   $subtracks='"tracks": ['.$t1.']';
   }
}
$title = preg_replace('~[^\\pL\d.]+~u', ' ', $title);

if (strpos($base_pass,":") !== false) {
    $title = str_replace("Ş","S",$title);
    $title = str_replace("ş","S",$title);
    $title = str_replace("ș","s",$title);
    $title = str_replace("ș","s",$title);
    $title = str_replace("Ț","T",$title);
    $title = str_replace("ț","t",$title);
    $title = str_replace("ţ","t",$title);
    $title = str_replace("Ț","T",$title);
    $title = str_replace("Ţ","T",$title);
    $title = str_replace("ă","a",$title);
	$title = str_replace("â","a",$title);
	$title = str_replace("î","i",$title);
	$title = str_replace("Î","I",$title);
	$title = str_replace("Ă","A",$title);
}


//$srt_name=$str_name.".srt";
$movie_file=$title.".m3u8";
if ($p) if (array_key_exists("indexUrl",$p)) $svr=$p["indexUrl"];
if ($svr) {
$h=file_get_contents($svr);
$t1=explode('server=',$h);
$t2=explode('&',$t1[1]);
$serv=$t2[0];
}
if ($serv == "") {
  $serv="fms110.mediadirect.ro";
}

if (!($pg_id==22 || $pg_id==5036)) {
if (strpos($tit,"Hustler live") === false) {
$out=str_replace("[%server_name%]",$serv,$l);
$out=str_replace("seenow-smart/_definst_/","seenow/_definst_/mp4:",$out);
} else {
$out=str_replace("[%server_name%]:1937","178.21.120.198:1935",$l);
$out=str_replace("seenow/_definst_/","live3/_definst_/",$out);
$out=str_replace("mp4:",str_replace(' ','',strtolower($title)),$out);
}
$out=str_replace("playlist",$title,$out);
$t1=explode('?',$out);
$out=$t1[0]."?user_id=0&transaction_id=0&publisher=24&p_item_id=".$id."&token=".$token;
} else {
$out=$l;
}
if (strpos($out,"mp4:") !== false)
  $srt_name=$title.".srt";
else {
$t1=explode(".",substr(strrchr($str_name, "/"), 1));
$srt_name = $t1[0].".srt";
}
if (file_exists($base_sub.$srt_name)) unlink($base_sub.$srt_name);

   $ch = curl_init();
   curl_setopt($ch, CURLOPT_URL, $sub);
   curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
   curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US; rv:1.9.1.2) Gecko/20090729 Firefox/3.5.2 GTB5');
   curl_setopt($ch, CURLOPT_FOLLOWLOCATION  ,1);
   $h=curl_exec($ch);
   curl_close($ch);
$list = glob($base_sub."*.srt");
   foreach ($list as $l) {
    str_replace(" ","%20",$l);
    unlink($l);
   }
if ($h) {
   $new_file = $base_sub.$srt_name;
   $fh = fopen($new_file, 'w');
   fwrite($fh, $h);
   fclose($fh);
   
   $subtracks='"tracks": [{"file": "../subs/'.$srt_name.'", "default": true}]';

}
} else {
$serv="178.21.120.26";
$out="rtmp://".$serv.":1935/radio/_definst_/".$id.".stream";
}
if (preg_match("/tvr/i",$title) || preg_match("/biziday/i",$tit))
 $strech="exactfit";
else
 $strech="bestfit";

if ((strpos($_SERVER["SERVER_NAME"],"seenow") !== false)) $flash="site";

if ( (strpos($base_pass,":") === false) && ($flash == "direct" || strpos($out,"mp4:") !== false) && ($flash!="site") && $pg_id != 22 && $pg_id!=5036) {
header('Content-type: application/vnd.apple.mpegURL');
header('Content-Disposition: attachment; filename="playlist.m3u8"');
header("Location: $out");
} elseif ($flash == "site") {
$l="c:\\windows\\system32\\drivers\\etc\\hosts";
if (strpos($base_pass,":") === false) $l="//system//etc//hosts";
$h=@file_get_contents($l);
$t1=$_SERVER["PHP_SELF"];
if ((strpos($base_pass,":") === false) && (@strpos($h,"static1.mediadirect.ro") !== false)) $t1="//static1.mediadirect.ro".$t1;
if(!isset($_GET['screen_check'])) {
 echo "<script language='JavaScript'>
 <!-- 
 document.location=\"$t1?screen_check=done&file=$id&title=$title&pg_id=$pg_id&tit=$tit&Width=\"+window.innerWidth+\"&Height=\"+window.innerHeight;
 //-->
 </script>";
 die();
} else {    
	if(isset($_GET['Width']) && isset($_GET['Height'])) {
		$Width=$_GET['Width']-48;
		$Height=$_GET['Height']-48;
	}
}

$str = base64_encode(enc('mp4:'.$p['high quality stream name']));
$app = "FlUZRhIBDBwKFA==";
if (strpos($p['application name'],"live3") !== false) {
	$app = "FlUZRg0NHxdW";
	$str = base64_encode(enc($p['high quality stream name']));
}

if (!$p && $title=="TVR") {
$str = base64_encode(enc('mp4:'.'tvrmoldova'));
$app = "FlUZRg0NHxdW";
}
if (!$p && $title=="Hustler TV") {
$str = base64_encode(enc('mp4:'.'hustlertv'));
$app = "FlUZRg0NHxdW";
}
if (!$p && $title=="Hustler HD") {
$str = base64_encode(enc('mp4:'.'hustlerhd'));
$app = "FlUZRg0NHxdW";
}
if (!$p && $title=="Private TV") {
$str = base64_encode(enc('mp4:'.'privatetv'));
$app = "FlUZRg0NHxdW";
}
if (!$p && $title=="Hustler Blue") {
$str = base64_encode(enc('mp4:'.'hustlerblue'));
$app = "FlUZRg0NHxdW";
}
$sub = base64_encode(enc(str_replace('srt','xml',$sub)));


echo '
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">

<title>'.$title.'</title>

<link rel="stylesheet" type="text/css" href="../custom.css" />

</head>
<body {
margin: 0px auto;
overflow:hidden;
}>



<object id="player_mediadirect">
			<embed type="application/x-shockwave-flash"	id="player_mediadirect" src="http://static1.mediadirect.ro/mediaplayer/players/0037/player.swf"	menu="false" 
			play="true" loop="false" quality="best" bgcolor="#000000" allowScriptAccess="always" allowFullScreen="true" scale = "noscale" wmode = "transparent"	
			width="'.$Width.'" height="'.$Height.'" flashVars="app='.$app.'&str='.$str.'&sub='.$sub.'&data=DgsLHg==&autoplay=true" salign="tl"/>
			</object>
			
</body>
</html>
';
} elseif (strpos($out,"mp4:") !== false || $tv=="vlc") {
echo '
<html>
   <head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<style type="text/css">
body {
margin: 0px auto;
overflow:hidden;
}
</style>
      <title>'.$title.'</title>
   </head>
<body>

<embed type="application/x-vlc-plugin" pluginspage="http://www.videolan.org" version="VideoLAN.VLCPlugin.2"
width="100%"
height="100%"
id="vlc"
target="'.$out.'">
</embed>


    <script language="Javascript">

    var vlc = document.getElementById("vlc");
    vlc.audio.toggleMute(0);
	vlc.video.aspectRatio="16:9";
    vlc.subtitle.track="1";


    </script>





    </body>
    </Html>
';
} elseif (strpos($out,"mp4") !== false  && $tv!="vlc") {
echo '
<!doctype html>
<HTML>
<HEAD>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>'.$title.'</title>
<style type="text/css">
body {
margin: 0px auto;
overflow:hidden;
}
body {background-color:#000000;}
</style>
<script src="//code.jquery.com/jquery-1.11.0.min.js"></script>
<script src="http://p.jwpcdn.com/6/10/jwplayer.js"></script>
<script>jwplayer.key="a90HGmYJwl7ewuxkXqofNd65qdenEdCsdwujA3th0Kc=";</script>

</HEAD>
<BODY>
<div id="container"></div>
<script type="text/javascript">
jwplayer("container").setup({
"playlist": [{
"sources": [{"file": "'.$out.'", "type": "mp4"}], 
'.$subtracks.'
}],
    captions: {
        color: "#FFFFFF",
        fontSize: 20,
        backgroundOpacity: 0
    },
"height": $(document).height(),
"width": $(document).width(),
"skin": "../hd4all.xml",
"stretching":"'.$strech.'",
"androidhls": true,
"startparam": "start",
"autostart": true,
"fallback": false,
"wmode": "direct",
"stagevideo": true
});
</script>
</BODY>
</HTML>
';
} elseif (($pg_id=="22" || $pg_id=="5036")&& strpos($base_pass,":") !== false) {
$rtmp="rtmp://178.21.120.26:1935/radio/_definst_";
echo '
<!doctype html>
<HTML>
<HEAD>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>'.$title.'</title>
<style type="text/css">
body {
margin: 0px auto;
overflow:hidden;
}
body {background-color:#000000;}
</style>
<script src="//code.jquery.com/jquery-1.11.0.min.js"></script>
<script type="text/javascript" src="../filme/jwplayer.js"></script>

</HEAD>
<BODY>
<div id="container"></div>
<script type="text/javascript">
jwplayer("container").setup({
"players": [{"type":"flash","src":"../filme/player.swf"}],
"image": "'.$img.'",
"file": "'.$audio.'",
"height": $(document).height(),
"width": $(document).width(),
"skin": "../skin.zip",
"stretching":"exactfit",
"dock": "true",
"autostart": "true",
"controlbar.position": "over",
"controlbar.idlehide": "false",
"backcolor": "000000",
"frontcolor": "ffffff",
"lightcolor": "f7b01e",
"streamer": "'.$rtmp.'",
"provider": "rtmp",
"volume": "100",
});
</script>
</BODY>
</HTML>
';
} elseif (($pg_id=="22" || $pg_id=="5036") && strpos($base_pass,":") === false) {
echo '
<!doctype html>
<HTML>
<HEAD>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>'.$title.'</title>
<style type="text/css">
body {
margin: 0px auto;
overflow:hidden;
}
body {background-color:#000000;}
</style>
<script src="//code.jquery.com/jquery-1.11.0.min.js"></script>
<script src="http://p.jwpcdn.com/6/10/jwplayer.js"></script>
<script>jwplayer.key="a90HGmYJwl7ewuxkXqofNd65qdenEdCsdwujA3th0Kc=";</script>

</HEAD>
<BODY>
<div id="container"></div>
<script type="text/javascript">
jwplayer("container").setup({
"playlist": [{
"image": "'.$img.'",
"sources": [{"file": "'.$out.'", "type": "mp4"}],
}],
"height": $(document).height(),
"width": $(document).width(),
"skin": "../hd4all.xml",
"stretching":"exactfit",
"androidhls": "true",
"startparam": "start",
"autostart": "true",
"fallback": "false",
"wmode": "direct",
"stagevideo": "true"
});
</script>
</BODY>
</HTML>
';
} else {
$app="live3";
if ($tv=="fms38.mediadirect.ro")
 $serv="fms11".mt_rand(2,3).".mediadirect.ro";
$rtmp="rtmpe://".$serv."/".$app."/_definst_?token=".$token;
echo '
<!doctype html>
<HTML>
<HEAD>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>'.$title.'</title>
<style type="text/css">
body {
margin: 0px auto;
overflow:hidden;
}
body {background-color:#000000;}
</style>
<script src="//code.jquery.com/jquery-1.11.0.min.js"></script>
<script type="text/javascript" src="../filme/jwplayer.js"></script>

</HEAD>
<BODY>
<div id="container"></div>
<script type="text/javascript">
jwplayer("container").setup({
"players": [{"type":"flash","src":"../filme/player.swf"}],
"file": "'.$str_name.'",
"token": "'.$token.'",
"height": $(document).height(),
"width": $(document).width(),
"skin": "../skin.zip",
"stretching":"'.$strech.'",
"dock": "true",
"autostart": "true",
"controlbar.position": "over",
"controlbar.idlehide": "false",
"backcolor": "000000",
"frontcolor": "ffffff",
"lightcolor": "f7b01e",
"streamer": "'.$rtmp.'",
"volume": "100",
});
</script>
</BODY>
</HTML>
';
}
?>

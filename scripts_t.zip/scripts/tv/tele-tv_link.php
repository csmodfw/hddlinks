<?php
function str_between($string, $start, $end){ 
	$string = " ".$string; $ini = strpos($string,$start); 
	if ($ini == 0) return ""; $ini += strlen($start); $len = strpos($string,$end,$ini) - $ini; 
	return substr($string,$ini,$len); 
}
include ("../common.php");
if (file_exists($base_pass."player.txt")) {
$flash=trim(file_get_contents($base_pass."player.txt"));
} else {
$flash="direct";
}
function vk($string) {
  if (strpos($string,"video_ext.php") === false) {
  //echo $string;
	$h = file_get_contents($string);
	$t1=explode("nvar vars",$h);
	$l=$t1[1];
	$uid=str_between($l,'\"uid\":\"','\"');
	$host=str_between($l,'"host\":\"','\"');
	$host=str_replace("\\/","/",$host);
	$host=str_replace("\\/","/",$host);
	$host=str_replace("\/","/",$host);
	$vtag=str_between($l,'"vtag\":\"','\"');
	$r=$host."u".$uid."/videos/".$vtag.".360.mp4";
 } else {
    $baza = file_get_contents($string);
    //echo $string."<BR>";
    preg_match("/hd=\d{1}/",$string,$m);
    //print_r ($m);
    $host = str_between($baza,"var video_host = '","'");
    $uid = str_between($baza,"var video_uid = '","'");
    $vtag = str_between($baza,"var video_vtag = '","'");
    //$hd = str_between($baza,"var video_max_hd = '","'");
    $t1=explode("hd=",$m[0]);
    $hd=trim($t1[1]);
    //echo $hd;
    if ($hd == "0") {
      $r = $host."u".$uid."/videos/".$vtag.".240.mp4";
    } elseif ($hd=="3") {
      $r = $host."u".$uid."/videos/".$vtag.".720.mp4";
    } elseif ($hd=="2") {
      $r = $host."u".$uid."/videos/".$vtag.".480.mp4";
      $test = $host."u".$uid."/videos/".$vtag.".480.mp4";
      $ch = curl_init();
      curl_setopt($ch, CURLOPT_URL, $test);
      curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
      curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US; rv:1.9.1.2) Gecko/20090729 Firefox/3.5.2 GTB5');
      curl_setopt($ch, CURLOPT_HEADER, 1);
      curl_setopt($ch, CURLOPT_NOBODY, 1);
      $h1 = curl_exec($ch);
      curl_close($ch);
      if (strpos($h1,"200 OK") === false)
       $r= $host."u".$uid."/videos/".$vtag.".360.mp4";
    } elseif ($hd=="1") {
      $r = $host."u".$uid."/videos/".$vtag.".360.mp4";
    } else {
      $r = $host."u".$uid."/videos/".$vtag.".360.mp4";
      $test = $host."u".$uid."/videos/".$vtag.".480.mp4";
      $ch = curl_init();
      curl_setopt($ch, CURLOPT_URL, $test);
      curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
      curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US; rv:1.9.1.2) Gecko/20090729 Firefox/3.5.2 GTB5');
      curl_setopt($ch, CURLOPT_HEADER, 1);
      curl_setopt($ch, CURLOPT_NOBODY, 1);
      $h1 = curl_exec($ch);
      curl_close($ch);
      if (strpos($h1,"200 OK") !== false)
       $r=$test;
    }
 }
  return $r;
}
//http://www.tele-tv.info/js/embed.js
/*
var teletv_type='emisiuni';
var teletv_width=615;
var teletv_height=315;
var teletv_id=838;
*/
//http://www.tele-tv.info/embed/' + teletv_type + '/' + teletv_id
//http://www.tele-tv.info/embed/emisiuni-link/991.swf
$link = $_GET["file"];
$title = $_GET["title"];
$link=urldecode($link);
$html = file_get_contents($link);
$type = str_between($html,"teletv_type='","'");
$id = str_between($html,"teletv_id=",";");
$l="http://www.tele-tv.info/embed/".$type."/".$id.".swf";
//echo $l;
//die();
if (preg_match("/emisiuni/",$type)) {
$html = file_get_contents($l);
$link=trim(str_between($html,'flashvars="file=','&'));
if (!$link) {
  $l1=str_between($html,"vk.com",'"');
  if ($l1) {
    $l1="http://vk.com".$l1;
    $link=vk($l1);
  } else {
    $link=str_between($html,'iframe id="myFrame" src="','"');
    if (!$link) $link=str_between($html,"iframe src='","'");
    if (strpos($link,"http") === false) $link="http:".$link;
        //echo $link;
if (strpos($link,"mail.ru") !==false) {
    $filelink=$link;
   //$filelink="http://api.video.mail.ru/videos/mail/alex.costantin/_myvideo/162.json";
   //http://api.video.mail.ru/videos/embed/mail/alex.costantin/_myvideo/1029.html
   //http://my.mail.ru/video/mail/best_movies/_myvideo/4412.html
   //http://api.video.mail.ru/videos/embed/inbox/virusandrei/_myvideo/38.html
   //http://api.video.mail.ru/videos/mail/best_movies/_myvideo/6501.json
   if (strpos($filelink,"json") === false) {
     //$filelink=str_replace("/embed","",$filelink);
     //$filelink=str_replace("html","json",$filelink);
   }
   if (strpos($filelink,"videoapi.my.mail.ru") === false)
   $filelink=str_replace("my.mail.ru/video","api.video.mail.ru/videos/",$filelink);
   //echo $filelink;
   $ch = curl_init($filelink);
   curl_setopt($ch, CURLOPT_FOLLOWLOCATION  ,1);
   curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US; rv:1.9.1.2) Gecko/20090729 Firefox/3.5.2 GTB5');
   curl_setopt($ch, CURLOPT_RETURNTRANSFER  ,1);  // RETURN THE CONTENTS OF THE CALL
   curl_setopt($ch, CURLOPT_REFERER, "http://my9.imgsmail.ru/r/video2/uvpv3.swf?3");
   //curl_setopt($ch, CURLOPT_COOKIEJAR, '/tmp/cookies.txt');
   //curl_setopt($ch, CURLOPT_COOKIEFILE, '/tmp/cookies.txt');
   $h = curl_exec($ch);
   curl_close($ch);
   //echo $h;
   //die();
  $t1=explode('hd":"',$h);
  $t2=explode('"',$t1[1]);
  $link=$t2[0];
  if (!$link) {
  $t1=explode('md":"',$h);
  $t2=explode('"',$t1[1]);
  $link=$t2[0];
  }
  if (!$link) {
  $t1=explode('sd":"',$h);
  $t2=explode('"',$t1[1]);
  $link=$t2[0];
  }
   $link=urldecode($link);
   $link=str_replace("[","\[",$link);
   $link=str_replace("]","\]",$link);
}
if (strpos($link,"dailymotion") !== false) {
  $filelink=$link;
  if (strpos($filelink,"embed") !== false) {
    $h=file_get_contents($filelink);
    //echo $h;
    $l=str_between($h,'stream_h264_url":"','"');
    $link=str_replace("\\","",$l);
  } else {
    $html = file_get_contents($filelink);
    $h=urldecode($html);
    $link=urldecode(str_between($h,'video_url":"','"'));
    if (!$link) {
    $t1 = explode('sdURL', $html);
    $sd=urldecode($t1[1]);
    $t1=explode('"',$sd);
    $sd=$t1[2];
    $sd=str_replace("\\","",$sd);
    $n=explode("?",$sd);
    $nameSD=$n[0];
    $nameSD=substr(strrchr($nameSD,"/"),1);
    $t1 = explode('hqURL', $html);
    $hd=urldecode($t1[1]);
    $t1=explode('"',$hd);
    $hd=$t1[2];
    $hd=str_replace("\\","",$hd);
    $n=explode("?",$hd);
    $nameHD=$n[0];
    $nameHD=substr(strrchr($nameHD,"/"),1);
    if ($hd <> "") {
     $link = $hd;
    }
    if (($sd <> "") && ($hd=="")) {
     $link = $sd;
    }
    }
  }
}
if (strpos($link,"ok.ru") !== false) {
  $h1=file_get_contents($link);
  //echo $h1;
  $id=str_between($h1,'data-player-id="embed_video_','"');
  $l="http://ok.ru/dk?cmd=videoPlayerMetadata&mid=".$id;
  //echo $l;
  $h2=file_get_contents($l);
  //echo $h2;
  //http://217.20.145.42/?id=21387938310&expires=1423386297139&type=3&ct=0&sig=5d077c4020b136ce976f17801862b10848b0ba68&clientType=0
  //$p=json_decode($h2);
  $link=str_between($h2,'hd","url":"','"');
  if (!$link) $link=str_between($h2,'sd","url":"','"');
  //echo $l1;
  //$link=$p["videos"][4]["url"];
  //die();
  $link=str_replace("\u0026","&",$link);
  if (!$link) $link= $p["videos"][3]["url"];
}
  }
}
} else {
$html = file_get_contents($l);
$l=str_between($html,'src="','&');
  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $l);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US; rv:1.9.1.2) Gecko/20090729 Firefox/3.5.2 GTB5');
  curl_setopt($ch, CURLOPT_FOLLOWLOCATION  ,1);
  $html = curl_exec($ch);
  curl_close($ch);
$link = str_between($html,"file: '","'");
}
$out=$link;
//echo $link;
//die();
if ($flash == "direct") {
header('Content-type: application/vnd.apple.mpegURL');
header('Content-Disposition: attachment; filename="video/mp4"');
header("Location: $out");
} else {
$out=str_replace("&amp;","&",$out);
echo '
<!doctype html>
<HTML>
<HEAD>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>'.$title.'</title>
<style type="text/css">
body {
margin: 0px auto;
overflow:hidden;
}
body {background-color:#000000;}
</style>
<script src="//code.jquery.com/jquery-1.11.0.min.js"></script>
<script src="http://p.jwpcdn.com/6/10/jwplayer.js"></script>
<script>jwplayer.key="a90HGmYJwl7ewuxkXqofNd65qdenEdCsdwujA3th0Kc=";</script>

</HEAD>
<BODY>
<div id="container"></div>
<script type="text/javascript">
jwplayer("container").setup({
"playlist": [{
"sources": [{"file": "'.$out.'", "type": "mp4"}]
}],
"height": $(document).height(),
"width": $(document).width(),
"skin": '.$skin.',
"autostart": true,
"startparam": "start",
"fallback": false,
"wmode": "direct",
"stagevideo": true
});
</script>
</BODY>
</HTML>
';
}
?>

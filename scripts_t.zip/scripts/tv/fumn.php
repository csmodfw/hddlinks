<!DOCTYPE html>
<?php
include ("../common.php");
$query = $_GET["page"];
if($query) {
   $queryArr = explode(',', $query);
   $page = $queryArr[0];
   $search = $queryArr[1];
   $page_title=urldecode($queryArr[2]);
   $search=str_replace("|","&",$search);
}
?>
<html><head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate"/>
<meta http-equiv="Pragma" content="no-cache"/>
<meta http-equiv="Expires" content="0"/>
      <title><?php echo $page_title; ?></title>
<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.8.0/jquery.min.js"></script>
<script src="../jquery.nicescroll.min.js"></script>

<script type="text/javascript">
  $(document).ready(function() {
	$("html").niceScroll({styler:"fb",cursorcolor:"#000"});
  });
</script>
<link rel="stylesheet" type="text/css" href="../custom.css" />
</head>
<body>
<H2></H2>
<?php
function str_between($string, $start, $end){
	$string = " ".$string; $ini = strpos($string,$start);
	if ($ini == 0) return ""; $ini += strlen($start); $len = strpos($string,$end,$ini) - $ini;
	return substr($string,$ini,$len);
}
//http://www.hdfilm.ro/index.php?p=filme&gen=Actiune&page=1
echo '<h2 style="background-color:deepskyblue;color:black">'.$page_title.'</H2>';
echo '<table border="1px" width="100%">'."\n\r";
echo '<tr><TD colspan="2" align="right">';
if ($page > 1)
echo '<a href="fumn.php?page='.($page-1).','.$search.','.urlencode($page_title).'"><font size="4">&nbsp;&lt;&lt;&nbsp;</font></a> | <a href="fumn.php?page='.($page+1).','.$search.','.urlencode($page_title).'"><font size="4">&nbsp;&gt;&gt;&nbsp;</font></a></TD></TR>';
else
echo '<a href="fumn.php?page='.($page+1).','.$search.','.urlencode($page_title).'"><font size="4">&nbsp;&gt;&gt;&nbsp;</font></a></TD></TR>';
if ($page==1)
  $html=file_get_contents("http://fumn.eu/category/centru-de-presa/multimedia/");
else
  $html=file_get_contents("http://fumn.eu/category/centru-de-presa/multimedia/page/".$page."/");
$videos = explode('<div class="thumb">', $html);
unset($videos[0]);
$videos = array_values($videos);

foreach($videos as $video) {

//  link
  $v1 = explode('href="', $video);
  $v2 = explode('"', $v1[1]);
  $link = $v2[0];
  //echo $v1[2];
  $v3=explode("<p>",$video);
  //echo $v3[1];
  $v4=explode("</p",$v3[1]);
  $descriere = $v4[0];
//  titlu

  $v3 = explode('title="',$video);
  $v4 = explode('"',$v3[1]);
  $title = $v4[0];

//  imagine
  //$v0=explode("images--",$video);
  $v1 = explode('src="', $video);
  $v2 = explode('"', $v1[1]);
  $image = $v2[0];
//  descriere
  //$v1 = explode('div class="entry-excerpt">', $video);
  //$v2 = explode('<span class="meta-more"', $v1[1]);
  //$descriere = $v2[0];

	$descriere = preg_replace("/(<\/?)(\w+)([^>]*>)/e","",$descriere);
  echo '<TR>';
  echo '<td align="center"><a href="fumn_link.php?file='.urlencode($link).','.urlencode($title).'" target="_blank"><img src="'.$image.'" width="200px" height="200px"><BR><font size="4">'.$title.'</font></a></TD>';
  echo '<td style="vertical-align:top;">'.$descriere.'</td>';
  echo '</tr>';
}
echo '<tr><TD colspan="2" align="right">';
if ($page > 1)
echo '<a href="fumn.php?page='.($page-1).','.$search.','.urlencode($page_title).'"><font size="4">&nbsp;&lt;&lt;&nbsp;</font></a> | <a href="fumn.php?page='.($page+1).','.$search.','.urlencode($page_title).'"><font size="4">&nbsp;&gt;&gt;&nbsp;</font></a></TD></TR>';
else
echo '<a href="fumn.php?page='.($page+1).','.$search.','.urlencode($page_title).'"><font size="4">&nbsp;&gt;&gt;&nbsp;</font></a></TD></TR>';
echo "</table>";
?>
<br></body>
</html>

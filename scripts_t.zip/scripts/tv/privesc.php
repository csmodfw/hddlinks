<!DOCTYPE html>
<?php
include ("../common.php");
$page = $_GET["page"];
$search= $_GET["link"];
$page_title=urldecode($_GET["title"]);
?>
<html><head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate"/>
<meta http-equiv="Pragma" content="no-cache"/>
<meta http-equiv="Expires" content="0"/>
      <title><?php echo $page_title; ?></title>
<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.8.0/jquery.min.js"></script>
<script src="../jquery.nicescroll.min.js"></script>

<script type="text/javascript">
  $(document).ready(function() {
	$("html").niceScroll({styler:"fb",cursorcolor:"#000"});
  });
</script>
<link rel="stylesheet" type="text/css" href="../custom.css" />
</head>
<body>
<H2></H2>
<?php
function str_between($string, $start, $end){
	$string = " ".$string; $ini = strpos($string,$start);
	if ($ini == 0) return ""; $ini += strlen($start); $len = strpos($string,$end,$ini) - $ini;
	return substr($string,$ini,$len);
}
//http://www.hdfilm.ro/index.php?p=filme&gen=Actiune&page=1
echo '<h2 style="background-color:deepskyblue;color:black">'.$page_title.'</H2>';
echo '<table border="1px" width="100%">'."\n\r";
echo '<tr><TD colspan="4" align="right">';
if ($page > 1)
echo '<a href="privesc.php?page='.($page-1).'&link='.$search.'&title='.urlencode($page_title).'"><font size="4">&nbsp;&lt;&lt;&nbsp;</font></a> | <a href="privesc.php?page='.($page+1).'&link='.$search.'&title='.urlencode($page_title).'"><font size="4">&nbsp;&gt;&gt;&nbsp;</font></a></TD></TR>';
else
echo '<a href="privesc.php?page='.($page+1).'&link='.$search.'&title='.urlencode($page_title).'"><font size="4">&nbsp;&gt;&gt;&nbsp;</font></a></TD></TR>';

$n=0;
$page1 = $page-1;
//$search1=mb_convert_encoding($search, 'UTF-8');
$search1=str_replace("*",",",$search);
//echo $search1;
if ($page > 1)
$l=$search1."/".$page1;
else
$l=$search1;
$l=urlencode($l);
$l=str_replace("%3A",":",$l);
$l=str_replace("%2F","/",$l);
//echo $l;
  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $l);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 5.1; rv:22.0) Gecko/20100101 Firefox/22.0');
  curl_setopt($ch, CURLOPT_FOLLOWLOCATION  ,1);
  curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
  curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
  $html = curl_exec($ch);
  curl_close($ch);
$videos = explode("<div class='col-xs-12", $html);

unset($videos[0]);
$videos = array_values($videos);

foreach($videos as $video) {
  $t1 = explode("href='", $video);
  $t2 = explode("'",$t1[1]);
  $link="https://www.privesc.eu".$t2[0];

  $t1=explode("alt='",$video);
  $t2=explode("'",$t1[1]);
  $title=trim($t2[0]);
  //$title=fix_s($title);
//http://storage.privesc.eu/thumnails/49569.jpg
  $t1=explode("src='",$video);
  $t2=explode("'",$t1[1]);
  $image=$t2[0];

  $data=str_between($video,"<p class='text-muted'>",'</p>');
  $descriere = $title;
  $link="privesc_link.php?file=".$link."&title=".urlencode($title);
  if ($n==0) echo '<TR>';
  echo '<td align="center" width="25%"><a href="'.$link.'" target="_blank"><img src="'.$image.'" width="200px" height="150px"><BR><font size="4">'.$title.'</font></a></TD>';
  $n++;
  if ($n == 4) {
  echo '</tr>';
  $n=0;
  }
}
echo '<tr><TD colspan="4" align="right">';
if ($page > 1)
echo '<a href="privesc.php?page='.($page-1).'&link='.$search.'&title='.urlencode($page_title).'"><font size="4">&nbsp;&lt;&lt;&nbsp;</font></a> | <a href="privesc.php?page='.($page+1).'&link='.$search.'&title='.urlencode($page_title).'"><font size="4">&nbsp;&gt;&gt;&nbsp;</font></a></TD></TR>';
else
echo '<a href="privesc.php?page='.($page+1).'&link='.$search.'&title='.urlencode($page_title).'"><font size="4">&nbsp;&gt;&gt;&nbsp;</font></a></TD></TR>';
echo "</table>";
?>
<br></body>
</html>

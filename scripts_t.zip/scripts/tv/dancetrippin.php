<!DOCTYPE html>
<?php
include ("../common.php");
?>
<html><head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate"/>
<meta http-equiv="Pragma" content="no-cache"/>
<meta http-equiv="Expires" content="0"/>
      <title>dancetrippin.tv</title>
<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.8.0/jquery.min.js"></script>
<script src="../jquery.nicescroll.min.js"></script>

<script type="text/javascript">
  $(document).ready(function() {
	$("html").niceScroll({styler:"fb",cursorcolor:"#000"});
  });
</script>
<link rel="stylesheet" type="text/css" href="../custom.css" />
</head>
<body>
<H2></H2>
<?php
function str_between($string, $start, $end){
	$string = " ".$string; $ini = strpos($string,$start);
	if ($ini == 0) return ""; $ini += strlen($start); $len = strpos($string,$end,$ini) - $ini;
	return substr($string,$ini,$len);
}
function xml_fix($string) {
    $v=str_replace("\u015e","S",$string);
    $v=str_replace("\u015f","s",$v);
    $v=str_replace("\u0163","t",$v);
    $v=str_replace("\u0162","T",$v);
    $v=str_replace("\u0103","a",$v);
    $v=str_replace("\u0102","A",$v);
    $v=str_replace("\u00a0"," ",$v);
    $v=str_replace("\u00e2","a",$v);
    $v=str_replace("\u021b","t",$v);
    $v=str_replace("\u201e","'",$v);
    $v=str_replace("\u201d","'",$v);
    $v=str_replace("\u0219","s",$v);
    $v=str_replace("\u00ee","i",$v);
    $v=str_replace("\u00ce","I",$v);
    $v=str_replace("\u2019","'",$v);
    $v=str_replace("&nbsp;","",$v);
    $v=str_replace("\/","/",$v);
    return $v;
}
echo '<h2 style="background-color:deepskyblue;color:black">dancetrippin.tv</H2>';
echo '<table border="1px" width="100%">'."\n\r";
$link="http://player.dancetrippin.tv/video/list/dj/";
$link="http://www.dancetrippin.tv/videos/dj-sets/";
  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $link);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  //curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Linux; U; Android 0.5; en-us) AppleWebKit/522+ (KHTML, like Gecko) Safari/419.3');
  curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 5.1; rv:22.0) Gecko/20100101 Firefox/22.0');
  curl_setopt($ch, CURLOPT_FOLLOWLOCATION  ,1);
  //curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
  $html = curl_exec($ch);
  curl_close($ch);
//$html=xml_fix($html);
$videos = explode('<div class="single"', $html);

unset($videos[0]);
$videos = array_values($videos);

foreach($videos as $video) {
    $t1=explode('href="',$video);
    $t2=explode('"',$t1[1]);
    $link="http://www.dancetrippin.tv".$t2[0];
    //$link="http://player.dancetrippin.tv/video/".str_between($video,'slug": "','"');
    $title=str_between($video,'title="','"');
    //http://player.dancetrippin.tv/media/video_thumbs/6082.jpg
    $image=str_between($video,'url(',')');
    $image=str_replace(" ","%20",$image);
    if (strpos($image,"http") === false) $image="http://www.dancetrippin.tv".$image;
    //$description=str_between($video,'description": "','",');
    //$descriere = preg_replace("/(<\/?)(\w+)([^>]*>)/e","",$description);
    //$location=str_between($video,'location": "','",');
    //$dj="DJ: ".str_between($video,'dj": "','",');

  if ($n==0) echo '<TR>';
  echo '<td align="center" width="25%"><a href="dancetrippin_link.php?file='.urlencode($link)."&title=".$title.'" target="_blank"><img src="'.$image.'" width="200px" height="180px"><BR><font size="4">'.$title.'</font></a></TD>';
  $n++;
  if ($n == 4) {
  echo '</tr>';
  $n=0;
  }
  //echo '<TD align="center"><a href="dancetrippin_link.php?file='.urlencode($link)."&title=".$title.'" target="_blank"><img src="'.$image.'" width="180px"><BR><font size="4">'.$title.'<br>'.$dj.'<br>'.$location.'</font></a></TD>';

  //echo '</tr>';
}
echo "</table>";
?>
<br></body>
</html>

<?php
function str_between($string, $start, $end){
	$string = " ".$string; $ini = strpos($string,$start);
	if ($ini == 0) return ""; $ini += strlen($start); $len = strpos($string,$end,$ini) - $ini;
	return substr($string,$ini,$len);
}
include ("../common.php");
if (file_exists($base_pass."player.txt")) {
$flash=trim(file_get_contents($base_pass."player.txt"));
} else {
$flash="direct";
}

$link = $_GET["file"];
$title = $_GET["title"];
  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $link);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 5.1; rv:22.0) Gecko/20100101 Firefox/22.0');
  //curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Linux; U; Android 2.1-update1; ru-ru; GT-I9000 Build/ECLAIR) AppleWebKit/530.17 (KHTML, like Gecko) Version/4.0 Mobile Safari/530.17');

  curl_setopt($ch, CURLOPT_FOLLOWLOCATION  ,1);
  curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
  curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
  $html = curl_exec($ch);
  curl_close($ch);
//echo $html;
$id=str_between($html,"widget/live/",'"');
$l="http://www.privesc.eu/api/live/".$id;
//echo $l;
$h=file_get_contents($l);
//echo $h;
$link_mp4=trim(str_between($h,'mp4":"','"'));
//$t1=explode("'file': '",$html);
//$t2=explode("'",$t1[1]);
//$y="mp4:".$t2[0];
$rtmp=str_between($html,"streamer': '","'");
if (!$rtmp)
$out=$link_mp4;
else
$out=$rtmp;

  //$t1=explode("?",$out);
  //$out=$t1[0];
  //echo $out;
  //die();
if ($flash == "direct") {
header('Content-type: application/vnd.apple.mpegURL');
header("Location: $out");
} else {
if (strpos($out,"rtmp") !== false)
 $type="rtmp";
else
 $type="mp4";
echo '
<!doctype html>
<HTML>
<HEAD>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>'.$title.'</title>
<style type="text/css">
body {
margin: 0px auto;
overflow:hidden;
}
body {background-color:#000000;}
</style>
<script src="//code.jquery.com/jquery-1.11.0.min.js"></script>
<script src="http://p.jwpcdn.com/6/10/jwplayer.js"></script>
<script>jwplayer.key="a90HGmYJwl7ewuxkXqofNd65qdenEdCsdwujA3th0Kc=";</script>

</HEAD>
<BODY>
<div id="container"></div>
<script type="text/javascript">
jwplayer("container").setup({
"playlist": [{
"sources": [{"file": "'.$out.'", "type": "'.$type.'"}],
}],
    captions: {
        color: "#FFFFFF",
        fontSize: 20,
        backgroundOpacity: 0
    },
"height": $(document).height(),
"width": $(document).width(),
"skin": "../hd4all.xml",
"androidhls": true,
"startparam": "start",
"autostart": true,
"fallback": false,
"wmode": "direct",
"stagevideo": true
});
</script>
</BODY>
</HTML>
';
}
?>

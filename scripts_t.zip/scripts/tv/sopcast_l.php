<!DOCTYPE html>
<html><head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">

      <meta charset="utf-8">
      <title>Sopcast</title>
      <link rel="stylesheet" type="text/css" href="../custom.css" />
     <script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.8.0/jquery.min.js"></script>

     <script src="../jquery.nicescroll.min.js"></script>
      <script type="text/javascript" src="../jquery.fancybox.js?v=2.1.5"></script>
      <link rel="stylesheet" type="text/css" href="../jquery.fancybox.css?v=2.1.5" media="screen" />


<script type="text/javascript">
$(document).ready(function() {
	$(".various").fancybox({
		maxWidth	: 800,
		maxHeight	: 600,
		fitToView	: false,
		width		: '70%',
		height		: '70%',
		autoSize	: false,
		closeClick	: false,
		openEffect	: 'none',
		closeEffect	: 'none'
	});
	$('.fancybox').fancybox();
	$("html").niceScroll({styler:"fb",cursorcolor:"#000"});
});
</script>
</head>
<body>
<?php
include ("prog.php");
//include ("canale.php");
//echo '<H3><center>Sopcast</center></H3>';
echo '<table border="2" width="100%">'."\n\r";
echo '<TR><td style="background-color:deepskyblue;color:black;text-align:center" colspan="6"><font size="4"></b>Sopcast</b></font></TD></TR>';

$n=0;
$link="http://streams.magazinmixt.ro/channels/filter?filterCountry=&filterProtocol=1&searchTxt=&page=";
  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $link);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 5.1; rv:14.0) Gecko/20100101 Firefox/14.0.1');
  $html=curl_exec($ch);
  curl_close($ch);
$videos = explode('<div class="cnt_logo">', $html);
unset($videos[0]);
$videos = array_values($videos);
foreach($videos as $video) {
    if ($n == 0) echo "<TR>"."\n\r";
    $sop=str_between($video,'<a href="','"');
	//$sop = base64_encode($sop);
    //$sop=str_replace("\\","",$sop);
	$title = str_between($video,'style="">','</div>');
	$title=str_replace("        ","",$title);
	$title=str_replace("      ","",$title);
	$img = str_between($video,'<img class="logo" src="/','"');
	//$title=str_replace("Chanel","Channel",$title);
	$id_prog="";
	$id_prog=str_replace("+","plus",$title);
	$id_prog=strtolower(str_replace(" ","-",$id_prog));
	$id_prog=urlencode($id_prog);
	$id_prog=str_replace("-rom%E3%A2nia","",$id_prog);
	$id_prog=str_replace("%E5%B3","t",$id_prog);
	$id_prog=str_replace("%E3%A2","a",$id_prog);
	$id_prog=str_replace("%E5%9F","s",$id_prog);
	$id_prog=str_replace("%E4%83","a",$id_prog);
	$id_prog=urldecode($id_prog);
	$link="sop_link.php?file=".$sop."&title=".$title."";
	echo '<TD style="text-align:center;"><img src="http://streams.magazinmixt.ro/'.$img.'" width="48px" height="28px"><font size="4"><a href="'.$link.'" target="_blank"><b>'.$title.'</b><BR><img src="http://streams.magazinmixt.ro/'.$img.'" width="160px" height="90px"></a></font><BR><a class="various fancybox.ajax" href="prog.php?id='.$id_prog.'&title='.$title.'"><font size="4">PROG</font></a></TD>';
    $n++;
    if ($n > 5) {
     echo '</TR>'."\n\r";
     $n=0;
    }
 }
 if ($n<6) echo "</TR>"."\n\r";
 echo '</table>';
?>
<br></body>
</html>

<?php

function str_between($string, $start, $end){
	$string = " ".$string; $ini = strpos($string,$start);
	if ($ini == 0) return ""; $ini += strlen($start); $len = strpos($string,$end,$ini) - $ini;
	return substr($string,$ini,$len);
}
include ("../common.php");
if (file_exists($base_pass."player.txt")) {
$flash=trim(file_get_contents($base_pass."player.txt"));
} else {
$flash="direct";
}
if (file_exists($base_pass."mx.txt")) {
$mx=trim(file_get_contents($base_pass."mx.txt"));
} else {
$mx="ad";
}
$user_agent     =   $_SERVER['HTTP_USER_AGENT'];
if (preg_match("/android|ipad/i",$user_agent) && preg_match("/chrome|firefox|mobile/i",$user_agent)) $flash="chrome";
//$flash="NU";
$link = $_GET["file"];
$title=urldecode($_GET["title"]);
$h = file_get_contents("http://protvplus.ro".urldecode($link));
//echo $h;
//$serv = str_between($h,"rtmp:","'");
//$t1 = str_between($h,'$.ajax(','$f(');
//$t1=explode("$.ajax({",$h);
//$linkajax=str_between($t1[1],'url: "','"');
//$linkajax="/lbin/ajax/config1.php?site=94000&realSite=94000&subsite=753&section=20720&media=61288956&jsVar=fltfm&mute=0&size=&pWidth=700&pHeight=435";
//$h = file_get_contents("http://protvplus.ro/".$linkajax);

//$h = str_replace("\\","",$h);
//echo $h;



//$out = "http:".$serv."/".$id."/".$title.".m3u8" - de facut
//echo $out; die();
preg_match("/http(.*?)m3u8/",$h,$m);

$out=$m[0];
if ($flash == "direct") {
header('Content-type: application/vnd.apple.mpegURL');
header('Content-Disposition: attachment; filename="playlist.m3u8"');
header("Location: $out");
} elseif ($flash == "chrome") {
  //$movie=str_replace("?",urlencode("?"),$movie);
  //$movie=str_replace("&","&amp;",$movie);
  $c="intent:".$out."#Intent;package=com.mxtech.videoplayer.".$mx.";S.title=".urlencode($title).";end";
  header("Location: $c");
} else {
//$out = $id."-HD-1.mp4";
//$rtmp = "rtmp:".$serv."/";
echo '
<!doctype html>
<HTML>
<HEAD>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>'.ucwords(strtolower($title)).'</title>
<style type="text/css">
body {
margin: 0px auto;
overflow:hidden;
}
body {background-color:#000000;}
</style>
<script src="//code.jquery.com/jquery-1.11.0.min.js"></script>
<script src="http://p.jwpcdn.com/6/10/jwplayer.js"></script>
<script>jwplayer.key="a90HGmYJwl7ewuxkXqofNd65qdenEdCsdwujA3th0Kc=";</script>

</HEAD>
<BODY>
<div id="container"></div>
<script type="text/javascript">
jwplayer("container").setup({
"playlist": [{
"sources": [{"file": "'.$out.'", "type": "m3u8"}]
}],
"height": $(document).height(),
"width": $(document).width(),
"skin": '.$skin.',
"autostart": true,
"startparam": "start",
"fallback": false,
"wmode": "direct",
"stagevideo": true
});
</script>
</BODY>
</HTML>
';

}
?>

<?php

function str_between($string, $start, $end){
	$string = " ".$string; $ini = strpos($string,$start);
	if ($ini == 0) return ""; $ini += strlen($start); $len = strpos($string,$end,$ini) - $ini;
	return substr($string,$ini,$len);
}
include ("../common.php");
$cookie = $base_cookie."protvplus.dat";
if (file_exists($base_pass."player.txt")) {
$flash=trim(file_get_contents($base_pass."player.txt"));
} else {
$flash="direct";
}
if (file_exists($base_pass."mx.txt")) {
$mx=trim(file_get_contents($base_pass."mx.txt"));
} else {
$mx="ad";
}
$user_agent     =   $_SERVER['HTTP_USER_AGENT'];
if (preg_match("/android|ipad/i",$user_agent) && preg_match("/chrome|firefox|mobile/i",$user_agent)) $flash="chrome";
//$flash="NU";
$link = $_GET["file"];
$title=urldecode($_GET["title"]);
$h = file_get_contents("http://protvplus.ro".urldecode($link));

//echo $out; die();
preg_match("/http(.*?)m3u8/",$h,$m);

$l=$m[0];
$ua="Mozilla/5.0 (iPhone; CPU iPhone OS 5_0_1 like Mac OS X)";
//$l="http://cdn.drm.protv.ro/protvplus.ro/2016/12/13/8797692d046b8af35c2f41f6ab253b27.ism/8797692d046b8af35c2f41f6ab253b27.m3u8";
$base=str_replace(strrchr($l, "/"),"/",$l);
  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $l);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_USERAGENT, $ua);
  curl_setopt($ch, CURLOPT_FOLLOWLOCATION  ,1);
  curl_setopt($ch, CURLOPT_REFERER, "http://protvplus.ro");
  curl_setopt($ch, CURLOPT_COOKIEJAR, $cookie);
  curl_setopt($ch, CURLOPT_COOKIEFILE, $cookie);
  $h = curl_exec($ch);
  curl_close($ch);
//echo $h;

preg_match_all("/([a-z0-9A-Z=-]+)\.m3u8/",$h,$m);
//print_r ($m);
$l=$base.$m[0][0];
  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $l);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_USERAGENT, $ua);
  curl_setopt($ch, CURLOPT_FOLLOWLOCATION  ,1);
  curl_setopt($ch, CURLOPT_REFERER, "http://protvplus.ro");
  curl_setopt($ch, CURLOPT_COOKIEJAR, $cookie);
  curl_setopt($ch, CURLOPT_COOKIEFILE, $cookie);
  $h = curl_exec($ch);
  curl_close($ch);
//echo $h;
//echo $h;
//die();
$l1=str_between($h,'URI="','"')."";
//echo $l1;
$l2="http://drmapi.protv.ro/hlsengine/prepare/";
  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $l2);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_USERAGENT, $ua);
  curl_setopt($ch, CURLOPT_FOLLOWLOCATION  ,1);
  curl_setopt($ch, CURLOPT_REFERER, "http://protvplus.ro");
  curl_setopt($ch, CURLOPT_COOKIEJAR, $cookie);
  curl_setopt($ch, CURLOPT_COOKIEFILE, $cookie);
  $h2 = curl_exec($ch);
  curl_close($ch);
//61307613
//$l1="http://voyo.ro/lbin/mplay/eshop/ws/getAesKey.php?id=61307613";
//$l1="http://drmapi.protv.ro/hlsengine/prepare/";
//   'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
$head =array('Accept: text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8');
  $head = array('Accept: */*',
   'Accept-Language: ro-RO,ro;q=0.8,en-US;q=0.6,en-GB;q=0.4,en;q=0.2',
   'Accept-Encoding: deflate',
   'Origin: http://protvplus.ro'
  );
  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $l1);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_USERAGENT, $ua);
  curl_setopt($ch, CURLOPT_FOLLOWLOCATION  ,1);
  curl_setopt($ch, CURLOPT_REFERER, "http://protvplus.ro");
  curl_setopt($ch,CURLOPT_HTTPHEADER,$head);
  curl_setopt($ch, CURLOPT_COOKIEJAR, $cookie);
  curl_setopt($ch, CURLOPT_COOKIEFILE, $cookie);
  $h1 = curl_exec($ch);
  curl_close($ch);
  $m=unpack("H*",$h1);
file_put_contents($base_sub."key.key",$h1);
  //print_r ($m);
  $key=$m[1];
$s="/([a-z0-9A-Z=-]+)(\.ts|\.mp4)/";
preg_match_all($s,$h,$m);
//print_r ($m);
//die();
for ($k=0;$k<count($m[0]);$k++) {
 $m1[]=$base.$m[0][$k];
}
$out=str_replace($m[0],$m1,$h);
$out=str_replace($l1,"http://127.0.0.1/mobile/scripts/subs/key.key",$out);
//echo $out;
file_put_contents($base_sub."playlist.m3u8",$out);
$out2=$base_sub."playlist.m3u8";
//if (file_exists($base_pass."mpc.txt")) {
  $mpc=trim(file_get_contents($base_pass."vlc.txt"));
  $c = '"'.$mpc.'" --fullscreen --sub-language="ro,rum,ron" '.$out2.'"';
  pclose(popen($c,"r"));
  //sleep(2);
  echo '<script type="text/javascript">window.close();</script>';
  die();
//}
//die();
//////////////////////////////////////////////////////////////////////////////////////////////////////
if ($flash == "direct" || $flash == "chrome1") {
//$out=$out."|".$head;

header('Content-type: application/vnd.apple.mpegURL');
header("Location: $out2");
} elseif ($flash == "chrome") {
  //$out1=$out."|".$head;
  //$movie=str_replace("?",urlencode("?"),$movie);
  //$movie=str_replace("&","&amp;",$movie);
  header('Content-type: application/vnd.apple.mpegURL');
  $c="intent:".$out2."#Intent;package=com.mxtech.videoplayer.".$mx.";S.title=".urlencode($title).";end";
  header("Location: $o");
} else {
//$out = $id."-HD-1.mp4";
//$rtmp = "rtmp:".$serv."/";
echo '
<!doctype html>
<HTML>
<HEAD>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>'.ucwords(strtolower($title)).'</title>
<style type="text/css">
body {
margin: 0px auto;
overflow:hidden;
}
body {background-color:#000000;}
</style>
<script src="//code.jquery.com/jquery-1.11.0.min.js"></script>
<script src="http://p.jwpcdn.com/6/10/jwplayer.js"></script>
<script>jwplayer.key="a90HGmYJwl7ewuxkXqofNd65qdenEdCsdwujA3th0Kc=";</script>

</HEAD>
<BODY>
<div id="container"></div>
<script type="text/javascript">
jwplayer("container").setup({
"playlist": [{
"sources": [{"file": "../subs/playlist.m3u8", "type": "m3u8"}]
}],
"height": $(document).height(),
"width": $(document).width(),
"skin": '.$skin.',
"autostart": true,
"startparam": "start",
"fallback": false,
"wmode": "direct",
"stagevideo": true
});
</script>
</BODY>
</HTML>
';

}
?>

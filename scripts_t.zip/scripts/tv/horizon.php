<!DOCTYPE html>
<?php
include ("../common.php");

?>
<html><head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate"/>
<meta http-equiv="Pragma" content="no-cache"/>
<meta http-equiv="Expires" content="0"/>
      <title>horizon.tv</title>
<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.8.0/jquery.min.js"></script>
<script src="../jquery.nicescroll.min.js"></script>

<script type="text/javascript">
  $(document).ready(function() {
	$("html").niceScroll({styler:"fb",cursorcolor:"#000"});
  });
</script>
<link rel="stylesheet" type="text/css" href="../custom.css" />
</head>
<body>
<H2></H2>
<?php
function str_between($string, $start, $end){
	$string = " ".$string; $ini = strpos($string,$start);
	if ($ini == 0) return ""; $ini += strlen($start); $len = strpos($string,$end,$ini) - $ini;
	return substr($string,$ini,$len);
}
$n=0;
echo '<h2 style="background-color:deepskyblue;color:black">horizon.tv</H2>';
echo '<table border="1px" width="100%">'."\n\r";
$cookie=$base_cookie."horizon.dat";
unlink($cookie);
//$l="https://web-api-pepper.horizon.tv/oesp/api/RO/ron/web/session?token=true";

$l="https://web-api-salt.horizon.tv/oesp/api/RO/ron/web/session?token=true";
$l="https://web-api-pepper.horizon.tv/oesp/v2/RO/ron/web/session?token=true";
$post='{"username":"mail","password":"pass"}';
  $head=array('Accept: application/json',
  'Accept-Language: ro-RO,ro;q=0.8,en-US;q=0.6,en-GB;q=0.4,en;q=0.2',
  'Accept-Encoding: deflate, br',
  'Content-Type: application/json',
  'X-Client-Id: 1.1.139||Mozilla/5.0 (Windows NT 10.0; rv:54.0) Gecko/20100101 Firefox/54.0',
  'Referer: https://www.horizon.tv/ro_ro/live-channels/live-channel.html/552441895108/location/552441895089',
  'Origin: https://www.horizon.tv',
  'Content-Length: '.strlen($post));

  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $l);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 10.0; rv:54.0) Gecko/20100101 Firefox/54.0');
  curl_setopt($ch, CURLOPT_FOLLOWLOCATION  ,1);
  //curl_setopt ($ch, CURLOPT_REFERER, "https://www.horizon.tv/ro_ro/settings/my-account.html");
  curl_setopt($ch,CURLOPT_HTTPHEADER,$head);
  curl_setopt ($ch, CURLOPT_POST, 1);
  //curl_setopt($ch, CURLOPT_HEADER,1);
  curl_setopt ($ch, CURLOPT_POSTFIELDS, $post);
  curl_setopt($ch, CURLOPT_COOKIEJAR, $cookie);
  curl_setopt($ch, CURLOPT_COOKIEFILE, $cookie);
  curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
  $html = curl_exec($ch);
  curl_close($ch);
//echo $html;
//die();
$h1="{".str_between($html,"{","}")."}";
$b1=json_decode($html,1);
print_r ($b1);
//die();

$link="https://www.horizon.tv/ro_ro/live-channels.html";
$link="https://www.horizon.tv/oesp/api/RO/ron/web/channels/";
  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $link);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 10.0; rv:54.0) Gecko/20100101 Firefox/54.0');
  curl_setopt($ch, CURLOPT_FOLLOWLOCATION  ,1);
  curl_setopt($ch, CURLOPT_COOKIEJAR, $cookie);
  curl_setopt($ch, CURLOPT_COOKIEFILE, $cookie);
  curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
  $html = curl_exec($ch);
  curl_close($ch);
$p=json_decode($html,1);
print_r ($p);
die();
//$html = file_get_contents($link);
$videos = explode('<item>', $html);
unset($videos[0]);
$videos = array_values($videos);
foreach($videos as $video) {
    $title=str_between($video,'<title>','</title>');
    $link=str_between($video,'file="','"');
    $image="http://www.magictvbox.eu".str_between($video,"image>","</");

    $link1="tastez_link.php?file=".$link."&title=".urlencode($title);
  if ($link <> "") {
  if ($n==0) echo '<TR>';
  echo '<td align="center" width="25%"><a href="'.$link1.'" target="_blank"><img src="'.$image.'" width="200px" height="106px"><BR><font size="4">'.$title.'</font></a></TD>';
  $n++;
  if ($n == 4) {
  echo '</tr>';
  $n=0;
  }
  }
}
echo "</table>";
?>
<br></body>
</html>

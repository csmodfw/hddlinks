<?php
function str_between($string, $start, $end){
	$string = " ".$string; $ini = strpos($string,$start);
	if ($ini == 0) return ""; $ini += strlen($start); $len = strpos($string,$end,$ini) - $ini;
	return substr($string,$ini,$len);
}
include ("../common.php");
if (file_exists($base_pass."player.txt")) {
$flash=trim(file_get_contents($base_pass."player.txt"));
} else {
$flash="direct";
}
$id=$_GET["id"];
$title = $_GET["title"];
$s="http://www.tastez.ro/tv.php?query=voyo&chn=".$id;
//http://tastez.ro/tv.php?query=vlc&chn=aHR0cDovLzg1LjIwNC4yMzMuMTM2L3ZveW9yb19pb3NfbGl2ZTYvX2RlZmluc3RfL3ZveW9yb19pb3NfbGl2ZTYtMS5zdHJlYW0vcGxheWxpc3QubTN1OD9leUp0WldRaU9qWXhNalF4TXpFNExDSnNhV01pT2lJM09XVTFabUk1TWpNNE1tVmxObVpoTW1Nd1pESTVPVGcwTUdVMFlXRTJPQ0lzSW5CeWIyUWlPall6TXpVc0ltUmxkaUk2SW1OaE5qWmpOV0ppWXpRNE9ERTRaVGd5TldFNFpUazVaRGRpTUdOaVpUSTVJaXdpWVdsa0lqb2lJbjA9fFNwb3J0LlJvIEhEIChMUSk=&srv=voyo
//http://tastez.ro/tv.php?query=flash&chn=aHR0cDovLzg1LjIwNC4yMzMuMTM2L3ZveW9yb19pb3NfbGl2ZTYvX2RlZmluc3RfL3ZveW9yb19pb3NfbGl2ZTYtMS5zdHJlYW0vcGxheWxpc3QubTN1OD9leUp0WldRaU9qWXhNalF4TXpFNExDSnNhV01pT2lJM09XVTFabUk1TWpNNE1tVmxObVpoTW1Nd1pESTVPVGcwTUdVMFlXRTJPQ0lzSW5CeWIyUWlPall6TXpVc0ltUmxkaUk2SW1OaE5qWmpOV0ppWXpRNE9ERTRaVGd5TldFNFpUazVaRGRpTUdOaVpUSTVJaXdpWVdsa0lqb2lJbjA9fFNwb3J0LlJvIEhEIChMUSk=&srv=voyo
$s="http://tastez.ro/tv.php?query=flash&chn=".$id."&srv=voyo";
  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $s);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  //curl_setopt($ch,CURLOPT_REFERER,"http://www.dolcetv.ro");
  curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 5.1; rv:14.0) Gecko/20100101 Firefox/14.0.1');
  $html=curl_exec($ch);
  curl_close($ch);
  //echo $html;
  //die();
$out=str_between($html,"file: '","'");

//echo $out;
//die();
if ($flash == "direct") {
$s="http://www.tastez.ro/tv.php?query=voyo";
  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $s);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  //curl_setopt($ch,CURLOPT_REFERER,"http://www.dolcetv.ro");
  curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 5.1; rv:14.0) Gecko/20100101 Firefox/14.0.1');
  $html=curl_exec($ch);
  curl_close($ch);
  $token=str_between($html,"m3u8?",'"');
  $out=str_replace("Manifest",$title,$out);
  $out=$out.".m3u8?".$token;
  //echo $out;
  //die();
header('Content-type: application/vnd.apple.mpegURL');
header('Content-Disposition: attachment; filename="playlist.m3u8"');
header("Location: $out");
} elseif ($flash=="html5") {
$s="http://www.tastez.ro/tv.php?query=voyo";
  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $s);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  //curl_setopt($ch,CURLOPT_REFERER,"http://www.dolcetv.ro");
  curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 5.1; rv:14.0) Gecko/20100101 Firefox/14.0.1');
  $html=curl_exec($ch);
  curl_close($ch);
  $token=str_between($html,"m3u8?",'"');
  $out=str_replace("Manifest",$title,$out);
  $out=$out.".m3u8?".$token;
echo '
<!doctype html>
<HTML>
<HEAD>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>'.$title.'</title>
<style type="text/css">
body {
margin: 0px auto;
overflow:hidden;
}
body {background-color:#000000;}
</style>
<script src="//code.jquery.com/jquery-1.11.0.min.js"></script>
<script src="http://jwpsrv.com/library/4+R8PsscEeO69iIACooLPQ.js"></script>

</HEAD>
<BODY>
<div id="container"></div>
<script type="text/javascript">
jwplayer("container").setup({
"flashplayer": "http://p.jwpcdn.com/6/10/jwplayer.flash.swf",
"file": "'.$out.'",
"height": $(document).height(),
"width": $(document).width(),
"skin": "../hd4all.xml",
"title": "'.$title.'",
"abouttext": "'.$title.'",
"androidhls": true,
"startparam": "start",
"autostart": true,
"fallback": false,
"wmode": "direct",
"stagevideo": true
});
</script>
</BODY>
</HTML>
';
} else {
echo '
<html>
   <head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<style type="text/css">
body {
margin: 0px auto;
overflow:hidden;
}
</style>
      <title>'.$title.'</title>
   </head>
<body>

<embed type="application/x-vlc-plugin" pluginspage="http://www.videolan.org" version="VideoLAN.VLCPlugin.2"
width="100%"
height="100%"
id="vlc"
target="'.$out.'">
</embed>


    <script language="Javascript">

    var vlc = document.getElementById("vlc");
    vlc.audio.toggleMute();
	vlc.video.aspectRatio="16:9";
    vlc.subtitle.track="1";


    </script>





    </body>
    </Html>

';
}
?>

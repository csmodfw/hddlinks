<?php
function str_between($string, $start, $end){
	$string = " ".$string; $ini = strpos($string,$start);
	if ($ini == 0) return ""; $ini += strlen($start); $len = strpos($string,$end,$ini) - $ini;
	return substr($string,$ini,$len);
}
include ("../common.php");
if (file_exists($base_pass."player.txt")) {
$flash=trim(file_get_contents($base_pass."player.txt"));
} else {
$flash="direct";
}
$link = $_GET["file"];
$title = urldecode($_GET["title"]);

//if ( strpos($_SERVER['HTTP_USER_AGENT'],'Android') !== false ) {
if (strpos($base_pass,":") === false) {
//header('Content-type: application/vnd.apple.mpegURL');
//header('Content-Disposition: attachment; filename="playlist.m3u8"');
header("Location: $link");
} else {
echo '
<!DOCTYPE html>
<html>



   <head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<style type="text/css">
body {
margin: 0px auto;
overflow:hidden;
}
</style>
      <title>'.$title.'</title>
   </head>



   <body>
';

echo '
<object id="SopPlayer" name = "SopPlayer"
	classid="clsid:8FEFF364-6A5F-4966-A917-A3AC28411659"
	height="100%" width="100%">
	<param name="AutoStart" value="1" />
	<param name="SopAddress" value="'.$link.'" />
	<param name="ChannelName" value="'.$title.'" />
</object>
</body>
</html>
';
}
?>

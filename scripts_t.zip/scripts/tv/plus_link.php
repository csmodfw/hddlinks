<?php
function str_between($string, $start, $end){
	$string = " ".$string; $ini = strpos($string,$start);
	if ($ini == 0) return ""; $ini += strlen($start); $len = strpos($string,$end,$ini) - $ini;
	return substr($string,$ini,$len);
}
include ("../common.php");
$cookie=$base_cookie."tvrplus_show.dat";
if (file_exists($base_pass."player.txt")) {
$flash=trim(file_get_contents($base_pass."player.txt"));
} else {
$flash="direct";
}
if (file_exists($base_pass."tv.txt")) {
$tv=trim(file_get_contents($base_pass."tv.txt"));
} else {
$tv="dinamic";
}

$id = $_GET["id"];
$title = $_GET["title"];
$titlet=str_replace('\\',"",$title);
$link="http://www.tvrplus.ro/androidphone/show/editie/id/".$id;
  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $link);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Linux; U; Android 0.5; en-us) AppleWebKit/522+ (KHTML, like Gecko) Safari/419.3');
  curl_setopt($ch, CURLOPT_FOLLOWLOCATION  ,1);
  curl_setopt($ch, CURLOPT_COOKIEFILE, $cookie);
  $html = curl_exec($ch);
  curl_close($ch);
$html=str_replace("\\","",$html);
$t1=explode('high quality stream name":"',$html);
$t2=explode('"',$t1[1]);
$str=$t2[0];

$t1=explode('application name":"',$html);
$t2=explode('"',$t1[1]);
$app=$t2[0];
if (!$app) $app="live3";

$t1=explode('token-high":"',$html);
$t2=explode('"',$t1[1]);
$token=$t2[0];

$t1=explode('server port":',$html);
$t2=explode(',',$t1[1]);
$port=$t2[0];

$s="http://index.mediadirect.ro/getUrl?publisher=68";
$s="http://index.mediadirect.ro/getUrl?file=".$str."&app=seenow&inst=_definst_&publisher=68";
$h = file_get_contents($s);
$t1=explode('server=',$h);
$t2=explode('&',$t1[1]);
$serv=$t2[0];
if ($serv == "") {
  $serv="fms61.mediadirect.ro";
}
$out = "http://".$serv.":".$port."/".$app."/".$str."?user_id=0&transaction_id=0&device_id=0&publisher=68&p_item_id=".$id."&token=".$token;
/*
if (($flash == "direct") || ($tv == "vlc")) {
$str="mp4:".$str;
$out = "http://".$serv.":".$port."/".$app."/_definst_/".$str."/".$title.".m3u8?user_id=0&transaction_id=0&device_id=0&publisher=68&token=".$token;
}
*/
if (file_exists($base_pass."mpc.txt")) {
  $mpc=trim(file_get_contents($base_pass."mpc.txt"));
  $c='"'.$mpc.'" /fullscreen "'.$out.'"';
  pclose(popen($c,"r"));
  echo '<script type="text/javascript">window.close();</script>';
  die();
}
if ($flash == "direct") {
header('Content-type: application/vnd.apple.mpegURL');
//header('Content-Disposition: attachment; filename="playlist.m3u8"');
header("Location: $out");
} elseif (strpos($out,"mp4:") !== false || $tv=="vlc") {
echo '
<html>
   <head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<style type="text/css">
body {
margin: 0px auto;
overflow:hidden;
}
</style>
      <title>'.$title.'</title>
   </head>
<body>

<embed type="application/x-vlc-plugin" pluginspage="http://www.videolan.org" version="VideoLAN.VLCPlugin.2"
width="100%"
height="100%"
id="vlc"
target="'.$out.'">
</embed>


    <script language="Javascript">

    var vlc = document.getElementById("vlc");
    vlc.audio.toggleMute();
	vlc.video.aspectRatio="16:9";
    vlc.subtitle.track="1";


    </script>





    </body>
    </Html>
';
} else {
echo '
<!doctype html>
<HTML>
<HEAD>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>'.$title.'</title>
<style type="text/css">
body {
margin: 0px auto;
overflow:hidden;
}
body {background-color:#000000;}
</style>
<script src="//code.jquery.com/jquery-1.11.0.min.js"></script>
'.$jwv.'

</HEAD>
<BODY>
<div id="container"></div>
<script type="text/javascript">
jwplayer("container").setup({
"playlist": [{
"sources": [{"file": "'.$out.'", "type": "mp4"}], 
}],
    captions: {
        color: "#FFFFFF",
        fontSize: 20,
        backgroundOpacity: 0
    },
"height": $(document).height(),
"width": $(document).width(),
"skin": '.$skin.',
"stretching": "exactfit",
"androidhls": true,
"startparam": "start",
"autostart": true,
"fallback": false,
"wmode": "direct",
"stagevideo": true
});
</script>
</BODY>
</HTML>
';
}
?>

<!DOCTYPE html>
<?php
include ("../common.php");
$query = $_GET["page"];
if($query) {
   $queryArr = explode(',', $query);
   $page = $queryArr[0];
   $search = $queryArr[1];
   $page_title=urldecode($queryArr[2]);
   $search=str_replace("|","&",$search);
}
?>
<html><head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate"/>
<meta http-equiv="Pragma" content="no-cache"/>
<meta http-equiv="Expires" content="0"/>
      <title><?php echo $page_title; ?></title>
<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.8.0/jquery.min.js"></script>
<script src="../jquery.nicescroll.min.js"></script>

<script type="text/javascript">
  $(document).ready(function() {
	$("html").niceScroll({styler:"fb",cursorcolor:"#000"});
  });
</script>
<link rel="stylesheet" type="text/css" href="../custom.css" />
</head>
<body>
<?php
function str_between($string, $start, $end){
	$string = " ".$string; $ini = strpos($string,$start);
	if ($ini == 0) return ""; $ini += strlen($start); $len = strpos($string,$end,$ini) - $ini;
	return substr($string,$ini,$len);
}
echo '<table border="1px" width="100%">'."\n\r";
echo '<TR><td style="color:black;background-color:deepskyblue;text-align:center" colspan="3"><font size="4"><b>'.$page_title.'</b></font></TD></TR>';
echo '</TR>';
$n=0;
$title="";
$l="http://www.digi-online.ro/xhr-shows.php?keyword=".$search;
  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $l);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US; rv:1.9.1.2) Gecko/20090729 Firefox/3.5.2 GTB5');
  curl_setopt($ch, CURLOPT_FOLLOWLOCATION  ,1);
  curl_setopt($ch, CURLOPT_REFERER, "http://www.digi-online.ro");
  $html = curl_exec($ch);
  curl_close($ch);

$videos = explode('class="picture">', $html);
unset($videos[0]);
$videos = array_values($videos);
foreach($videos as $video) {
    $t=explode('href="',$video);
if ( sizeof($t)>1 ) {
    $t1=explode('"',$t[1]);
    $link="http://www.digi-online.ro".$t1[0];
    $t1=explode('src="',$video);
    $t2=explode('"',$t1[1]);
    $image="http://www.digi-online.ro/".$t2[0];
  	//$title=str_between($video,'title image heading">','<');
  	$t1=explode('class="title">',$video);
  	$t2=explode('>',$t1[1]);
  	$t3=explode('<',$t2[1]);
  	$title=$t3[0];
    $link="digi24_e.php?file=".$link."&title=".urlencode($title);
}
    if ($title) {
	if ($n == 0) echo "<TR>"."\n\r";
	echo '<TD style="text-align:center"><font size="4">'.'<a href="'.$link.'" target="_blank"><img src="'.$image.'" width="180px" height="110px"><BR>'.$title.'</a></font></TD>';
    $n++;
    if ($n > 2) {
     echo '</TR>'."\n\r";
     $n=0;
    }
 }
}
 if ($n<3) echo "</TR>"."\n\r";
 echo '</table>';
?>
<BODY>
</HTML>

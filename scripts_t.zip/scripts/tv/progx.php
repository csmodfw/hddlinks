<?php
//error_reporting(0);
ini_set('max_execution_time', 300);
//date_default_timezone_set('Europe/Athens');
date_default_timezone_set('Europe/Belgrade');
//date_default_timezone_set('Europe/London');
$dgmt = "+0200";
function str_between($string, $start, $end){
    $string = " ".$string; $ini = strpos($string,$start);
    if ($ini == 0) return ""; $ini += strlen($start); $len = strpos($string,$end,$ini) - $ini;
    return substr($string,$ini,$len);
}
//echo "<B>Running...</B><BR>";
//$id= $_GET["id"];
$link = "http://www.cinemagia.ro/program-tv/post/3sat/";
$html = file_get_contents($link);
//echo $html;

$t1 = str_between($html, 'id="selectStation">', '</select');
$stations = explode("\n",$t1);
unset($stations[0]);
unset($stations[1]);
$stations = array_values($stations);
//print_r($stations);
//die();
$data="";
$data='<?xml version="1.0" encoding="UTF-8"?>
<tv>
';

  $xmltv_file="xmltv.ro.xml";
  if ($xmltv_file) unlink ($xmltv_file);
   $fh = fopen($xmltv_file, 'w');
   fwrite($fh, $data, strlen($data));
   fclose($fh);
   echo $data;

//foreach($stations as $station) {
for ($s = 0; $s < sizeof($stations)-1; $s++) {
//echo $stations[$s]."\n\r";
    
  $link = str_between($stations[$s], 'value="', '"');
  $title = trim(str_between($stations[$s], '>', '</')).' RO';
  //$title = trim(str_between($stations[$s], '>', '</'));
  $title = str_replace('&','&amp;',$title);

  //echo "<B>".$title."</B><BR>";
  //echo $link."\n\r";

$data='  <channel id="'.$title.'">
    <display-name lang="ro">'.$title.'</display-name>
    <url>http://http://www.cinemagia.ro</url>
  </channel>
';
  
   $fh = fopen($xmltv_file, 'a');
   fwrite($fh, $data, strlen($data));
   fclose($fh);
   echo $data;
  
  //$html = file_get_contents($link);
  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $link);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_REFERER, 'http://www.cinemagia.ro/program-tv/vertical/?autodetect_stations=true');
  curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 5.1; rv:14.0) Gecko/20100101 Firefox/14.0.1');
  $html=curl_exec($ch);
  curl_close($ch);

  $t1 = explode('class="container_events',$html);
  unset($t1[0]);
  $days = array_values($t1);
  //print_r($days[1]);

  for ($d = 0; $d < sizeof($days); $d++) {
  //echo $days[$d];
  $t1 = explode('<tr>',$days[$d]);
  unset($t1[0]);
  $ems = array_values($t1);
  //print_r($ems);
  $addday=$d;

  for ($e = 0; $e < sizeof($ems); $e++) {
    
      
      //echo $ems[$e];
      $ora = trim(str_between($ems[$e], '<div>', '<'));
      $title1 = trim(str_between($ems[$e], '"title">', '<'));
      $title1 = str_replace('&','&amp;',$title1);
      if (!$title1) {
          $title1 = trim(str_between($ems[$e], 'title="', '"'));
          $title1 = str_replace('&','&amp;',$title1);
      }
      $small = trim(str_between($ems[$e], '"small">', '<'));
      $small = str_replace('&','&amp;',$small);

      //echo $ora." ";
      //echo $title1."<BR>";
      //if ($small) echo "&nbsp;".$small."<BR>";

      $t1 = explode(':',$ora);
      $t2 = $t1[0].$t1[1]."00";
      if ( $t1[0] == "00" ) $addday=$d+1;
      if ( $t1[0] == "01" ) $addday=$d+1;
      if ( $t1[0] == "02" ) $addday=$d+1;
      if ( $t1[0] == "03" ) $addday=$d+1;
      //echo $addday."\n\r\n\r";
      //$orastart  = date("Y").date("m").date("d")+$addday.$t2;
	  $orastart = mktime($t1[0], $t1[1], 0, date("m")  , date("d")+$addday, date("Y"));
	  $orastart = gmdate("YmdHis", $orastart);

$oraend = "";
if ($e < sizeof($ems)-1) {
      $ora = trim(str_between($ems[$e+1], '<div>', '<'));
} else {
  if ($d < sizeof($days)-1) {
    $t1 = explode('<tr>',$days[$d+1]);
    unset($t1[0]);
    $ems1 = array_values($t1);
    $ora = trim(str_between($ems1[0], '<div>', '<'));
  }
}


      $t1 = explode(':',$ora);
      $t2 = $t1[0].$t1[1]."00";
      if ( $t1[0] == "00" ) $addday=$d+1;
      if ( $t1[0] == "01" ) $addday=$d+1;
      if ( $t1[0] == "02" ) $addday=$d+1;
      if ( $t1[0] == "03" ) $addday=$d+1;
      //echo $addday."\n\r\n\r";
      //$oraend  = date("Y").date("m").date("d")+$addday.$t2;
	  $oraend = mktime($t1[0], $t1[1], 0, date("m")  , date("d")+$addday, date("Y"));
	  $oraend = gmdate("YmdHis", $oraend);



$data='  <programme start="'.$orastart.' '.$dgmt.'" stop="'.$oraend.' '.$dgmt.'" channel="'.$title.'">
    <title lang="ro">'.$title1.'</title>
    <desc lang="ro">'.$small.'</desc>
    </programme>
';

   $fh = fopen($xmltv_file, 'a');
   fwrite($fh, $data, strlen($data));
   fclose($fh);
   echo $data;

      
  }
//die();

  }
  
//die();

}

$data='</tv>
';

   $fh = fopen($xmltv_file, 'a');
   fwrite($fh, $data, strlen($data));
   fclose($fh);
   echo $data;

//echo "<B>Done!!!!</B><BR>";
?>

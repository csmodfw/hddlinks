<!DOCTYPE html>
<?php
$file = $_GET["file"];
$title = $_GET["title"];
$title=str_replace("\'","'",$title);
?>
<html><head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
      <title><?php echo $title; ?></title>
<link rel="stylesheet" type="text/css" href="../custom.css" />
<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.8.0/jquery.min.js"></script>
<script src="../jquery.nicescroll.min.js"></script>

<script type="text/javascript">
  $(document).ready(function() {
	$("html").niceScroll({styler:"fb",cursorcolor:"#000"});
  });
</script>
</head>
<body>
<H2></H2>
<table border="1px" width="100%">
<?php
function str_between($string, $start, $end){
	$string = " ".$string; $ini = strpos($string,$start);
	if ($ini == 0) return ""; $ini += strlen($start); $len = strpos($string,$end,$ini) - $ini;
	return substr($string,$ini,$len);
}


echo '<h2 style="background-color:deepskyblue;color:black">'.str_replace("\'","'",$title).'</H2>';
echo '<table border="1px" width="100%">'."\n\r";

$link="http://antenaplay.ro/".$file;
//echo $link;
$html=file_get_contents($link);
//echo $html;
$videos=explode('<div class="span3 spanX',$html);
unset($videos[0]);
$videos = array_values($videos);
$n=0;
foreach($videos as $video) {
    if ($n == 0) echo "<TR>"."\n\r";
    $cat=str_between($video,'<a href="/v/','"');
	$title=str_between($video,'title="','"');
	$title=trim(str_between($video,'<p>','</p>'));
	$data=trim(str_between($video,'</p>','</div'));
	$title=$title." - ".$data;
	//$data=str_between($video,'class="sname" style="display:none;">','</div>');
	//$data=str_replace("<div>","",$data);
	//$data=str_replace("<p>									","",$data);
	//$data=str_replace("							   								</p>","",$data);
	$image=str_between($video,'real-src="','"');
	if (!$image) $image=str_between($video,'src="','"');
    $link="antenaplay_link.php?file=".urlencode($cat);
  if ($title && $cat) {
	if ($n == 0) echo "<TR>"."\n\r";
echo '
<TD><table border="0px">
<TD align="center"><a href="'.$link.'&title='.$title.'" target="_blank"><img src="'.$image.'" width="171" height="96"></a><BR><a href="'.$link.'" target="_blank"><b>'.$title.'</b></a></TD>

</TABLE></TD>
';
$n++;
    if ($n > 4) {
     echo '</TR>'."\n\r";
     $n=0;
    }
 }
}
 if ($n<0) echo "</TR>"."\n\r";
 echo '</table>';
?>
<br></body>
</html>

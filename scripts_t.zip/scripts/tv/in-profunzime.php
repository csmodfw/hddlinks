<!DOCTYPE html>
<?php
include ("../common.php");

?>
<html><head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate"/>
<meta http-equiv="Pragma" content="no-cache"/>
<meta http-equiv="Expires" content="0"/>
      <title>Moldova in Direct</title>
<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.8.0/jquery.min.js"></script>
<script src="../jquery.nicescroll.min.js"></script>

<script type="text/javascript">
  $(document).ready(function() {
	$("html").niceScroll({styler:"fb",cursorcolor:"#000"});
  });
</script>
<link rel="stylesheet" type="text/css" href="../custom.css" />
</head>
<body>
<H2></H2>
<?php
function str_between($string, $start, $end){
	$string = " ".$string; $ini = strpos($string,$start);
	if ($ini == 0) return ""; $ini += strlen($start); $len = strpos($string,$end,$ini) - $ini;
	return substr($string,$ini,$len);
}
$n=0;
echo '<h2 style="background-color:deepskyblue;color:black">Moldova in Direct</H2>';
echo '<table border="1px" width="100%">'."\n\r";
$link="http://www.trm.md/ro/moldova-in-direct/";
  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $link);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US; rv:1.9.1.2) Gecko/20090729 Firefox/3.5.2 GTB5');
  curl_setopt($ch, CURLOPT_FOLLOWLOCATION  ,1);
  //curl_setopt($ch, CURLOPT_COOKIEFILE, $cookie);
  $html = curl_exec($ch);
  curl_close($ch);
//$html = file_get_contents($link);
$videos = explode('span class="cdc">', $html);
unset($videos[0]);
$videos = array_values($videos);
foreach($videos as $video) {
    $t1=explode('<',$video);

    $title=$t1[0];

    $t1=explode('src="',$video);
    //$t2=explode('value="',$t1[1]);
    $t3=explode('"',$t1[1]);
    $image="http://www.trm.md".$t3[0];

    $link=str_replace("tiny-","",$image);
    $link=str_replace("jpg","mp4",$link);
    $link1="direct_link.php?file=".$link."&title=".urlencode($title);
  if ($link <> "") {
  if ($n==0) echo '<TR>';
  echo '<td align="center" width="25%"><a href="'.$link1.'" target="_blank"><img src="'.$image.'" width="200px" height="106px"><BR><font size="4">'.$title.'</font></a></TD>';
  $n++;
  if ($n == 4) {
  echo '</tr>';
  $n=0;
  }
  }
}
echo "</table>";
?>
<br></body>
</html>

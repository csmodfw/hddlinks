<!DOCTYPE html>
<html><head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate"/>
<meta http-equiv="Pragma" content="no-cache"/>
<meta http-equiv="Expires" content="0"/>
      <title>Adult</title>
<link rel="stylesheet" type="text/css" href="custom.css" />
<style>
html { height: 100%;}
.balloon { position: absolute; width: 214px; height: 317px; background: #000; border: 1px solid #fff; z-index: 10; display: none; }
</style>
<BODY>
<div id="mainnav">
<BR><BR>


<?php
include ("common.php");
$f=$base_pass."adult.txt";
if (!file_exists($f)) {
//echo '<h2 style="background-color:deepskyblue;color:black"><center>Activati sau dezactivati sectiunea Adult din setari!</center></h2>';
} else {
$h=file_get_contents($f);
$t1=explode("|",$h);
$adult=$t1[0];
}
if ($adult=="DA") {
echo '
<table border="1" align="center" width="90%">
<TR>
<td style="color:black;background-color:#0a6996;color:#64c8ff;text-align:center" colspan="4"><b><font size="4">Adult</font></b></TD>
</TR>
<TR>
<TD width="25%"><a href="adult/tube8_main.php" target="_blank"><font size="4">tube8</font></a></TD>
<TD width="25%"><a href="adult/youporn_main.php" target="_blank"><font size="4">youporn</font></a></TD>
<TD width="25%"><a href="adult/redtube_main.php" target="_blank"><font size="4">redtube</font></a></TD>
<TD width="25%"><a href="adult/xhamster_main.php" target="_blank"><font size="4">xhamster</font></a></TD>
</tr>
<tr>

<TD width="25%"><a href="adult/xnxx_main.php" target="_blank"><font size="4">xnxx</font></a></TD>
<TD width="25%"><a href="adult/xvideos_main.php" target="_blank"><font size="4">xvideos</font></a></TD>
<TD width="25%"><a href="adult/4tube_main.php" target="_blank"><font size="4">4tube</font></a></TD>
<TD width="25%"><a href="adult/milfzr_main.php" target="_blank"><font size="4">milfzr</font></a></TD
</tr>
<tr>

</tr>
<TR>
<TD width="25%"><a href="adult/pornjam_main.php" target="_blank"><font size="4">pornjam</font></a></TD>
<TD width="25%"><a href="adult/pornburst_main.php" target="_blank"><font size="4">pornburst</font></a></TD>
<TD width="25%"><a href="adult/anybunny_main.php" target="_blank"><font size="4">anybunny</font></a></TD>
<TD width="25%"><a href="adult/incestvidz_main.php" target="_blank"><font size="4">incestvidz</font></a></TD>
</TR>
<TR>


<TD width="25%"><a href="adult/slutload_main.php" target="_blank"><font size="4">slutload</font></a></TD>
<TD width="25%"><a href="adult/ah-me_main.php" target="_blank"><font size="4">ah-me</font></a></TD>
<TD width="25%"><a href="adult/fapbox_main.php" target="_blank"><font size="4">fapbox</font></a></TD>
<TD width="25%"><a href="adult/pornhub_main.php" target="_blank"><font size="4">porhub</font></a></TD>
</TR>
<TR>

<TD width="25%"><a href="adult/tnaflix_main.php" target="_blank"><font size="4">tnaflix</font></a></TD>
<TD width="25%"><a href="adult/jizzbunker_main.php" target="_blank"><font size="4">jizzbunker</font></a></TD>
<TD width="25%"><a href="adult/pornfree_main.php" target="_blank"><font size="4">pornfree.tv</font></a></TD>
<TD width="25%"><a href="adult/spankbang_main.php" target="_blank"><font size="4">spankbang</font></a></TD>
</TR>

<TR>
<TD width="25%"><a href="adult/thumbzilla_main.php" target="_blank"><font size="4">thumbzilla</font></a></TD>
<TD width="25%"><a href="adult/taboop_main.php" target="_blank"><font size="4">taboop</font></a></TD>
<TD width="25%"></TD>
<TD width="25%"></TD>
</TR>
';


echo '
</table>
';
}
?>
<BR><BR>
<?php
if (file_exists($base_pass."tastatura.txt")) {
$tast=trim(file_get_contents($base_pass."tastatura.txt"));
} else {
$tast="NU";
}
if ($tast=="DA") {
echo '
<table id="data" border="0" align="center" width="90%">
<TR><TD>* Folositi tasta 5 pentru a simula butonul de cautare.<TD></TR>
</TABLE>';
}
?>
</div></BODY>
</HTML>

<?php
$file=$_GET["file"];

$link = curl_init();

curl_setopt($link, CURLOPT_URL, $file);
curl_setopt($link, CURLOPT_REFERER, $file);
curl_setopt($link, CURLOPT_HEADER, false);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
curl_exec($link);

curl_close($link);
?>

<!DOCTYPE html>
<?php
include ("../common.php");
error_reporting(0);
$page1="";
$page1=$_GET["page1"];
if (!$page1) {
$query = $_GET["page"];
if($query) {
   $queryArr = explode(',', $query);
   $page = $queryArr[0];
   $search = $queryArr[1];
   $page_title=urldecode($queryArr[2]);
   $search=str_replace("|","&",$search);
}
} else {
 $search1=$_GET["src"];
 $search3=str_replace(" ","+",$search1);
 $page_title="Cautare: ".str_replace("+"," ",$search1);
 if ($page1>1)
 //$search2="http://www.tubepornclassic.com/search/".$page1."/?q=".$search3;
 $search2="http://www.tubepornclassic.com/search/".$page1."/?q=".$search3."&mode=async&function=get_block&block_id=list_videos_videos_list_search_result&q=mom+son&category_ids=&sort_by=&from_videos=01&from_albums=01";
 else
 $search2="http://www.tubepornclassic.com/search/?q=".$search3;
 //http://www.tubepornclassic.com/search/mom%20son/
 //http://www.xnxx.com/?k=mom+son&p=3
 //http://www.tubepornclassic.com/search/2/?q=mom+son
 //http://www.tubepornclassic.com/search/3/?q=mom+son&mode=async&function=get_block&block_id=list_videos_videos_list_search_result&q=mom+son&category_ids=&sort_by=&from_videos=04&from_albums=04&_=1470492898021
 //http://www.tubepornclassic.com/search/2/?q=mom+son&mode=async&function=get_block&block_id=list_videos_videos_list_search_result&q=mom+son&category_ids=&sort_by=&from_videos=03&from_albums=03&_=1470492898020

}
?>
<html><head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate"/>
<meta http-equiv="Pragma" content="no-cache"/>
<meta http-equiv="Expires" content="0"/>
      <title><?php echo $page_title; ?></title>
<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.8.0/jquery.min.js"></script>
<script src="../jquery.nicescroll.min.js"></script>

<script type="text/javascript">
  $(document).ready(function() {
	$("html").niceScroll({styler:"fb",cursorcolor:"#000"});
  });
</script>
<link rel="stylesheet" type="text/css" href="../custom.css" />
</head>
<body>
<H2></H2>
<?php
function str_between($string, $start, $end){
	$string = " ".$string; $ini = strpos($string,$start);
	if ($ini == 0) return ""; $ini += strlen($start); $len = strpos($string,$end,$ini) - $ini;
	return substr($string,$ini,$len);
}
$n=0;
echo '<h2 style="background-color:deepskyblue;color:black">'.$page_title.'</H2>';
echo '<table border="1px" width="100%">'."\n\r";
echo '<tr><TD colspan="4" align="right">';
if (!$page1) {
if ($page > 1)
echo '<a href="tubepornclassic.php?page='.($page-1).','.$search.','.urlencode($page_title).'"><font size="4">&nbsp;&lt;&lt;&nbsp;</font></a> | <a href="tubepornclassic.php?page='.($page+1).','.$search.','.urlencode($page_title).'"><font size="4">&nbsp;&gt;&gt;&nbsp;</font></a></TD></TR>';
else
echo '<a href="tubepornclassic.php?page='.($page+1).','.$search.','.urlencode($page_title).'"><font size="4">&nbsp;&gt;&gt;&nbsp;</font></a></TD></TR>';
} else {
if ($page1 > 1)
echo '<a href="tubepornclassic.php?page1='.($page1-1).'&src='.$search1.'"><font size="4">&nbsp;&lt;&lt;&nbsp;</font></a> | <a href="tubepornclassic.php?page1='.($page1+1).'&src='.$search1.'"><font size="4">&nbsp;&gt;&gt;&nbsp;</font></a></TD></TR>';
else
echo '<a href="tubepornclassic.php?page1='.($page1+1).'&src='.$search1.'"><font size="4">&nbsp;&gt;&gt;&nbsp;</font></a></TD></TR>';
}
if (!$page1) {
if (preg_match("/tags|new/",$search)) {
  $link=$search.$page."/";
} else {
  //http://www.xnxx.com/c/Blowjob-15
  $link=$search.$page."/";
  //$link=$search.$page.".html";
}
} else {
  $link=$search2;
}
$html = file_get_contents($link);
$videos = explode('<div class="item', $html);

unset($videos[0]);
$videos = array_values($videos);

foreach($videos as $video) {
    $t1=explode('href="',$video);
    $t2 = explode('"', $t1[1]);
    $link = $t2[0];

    $title=str_between($video,'title="','"');

    $t1 = explode('data-original="', $video);
    $t2 = explode('"', $t1[1]);
    $image = $t2[0];
    //$title = htmlspecialchars_decode($t2[0]);
    $link = "tubepornclassic_link.php?file=".$link;
  if ($n==0) echo '<TR>';
  echo '<td align="center" width="25%"><a href="'.$link.'&title='.$title.'" target="_blank"><img src="'.$image.'" width="180px" height="135px"><BR><font size="4">'.$title.'</font></a></TD>';
  $n++;
  if ($n == 4) {
  echo '</tr>';
  $n=0;
  }
}
echo '<tr><TD colspan="4" align="right">';
if (!$page1) {
if ($page > 1)
echo '<a href="tubepornclassic.php?page='.($page-1).','.$search.','.urlencode($page_title).'"><font size="4">&nbsp;&lt;&lt;&nbsp;</font></a> | <a href="tubepornclassic.php?page='.($page+1).','.$search.','.urlencode($page_title).'"><font size="4">&nbsp;&gt;&gt;&nbsp;</font></a></TD></TR>';
else
echo '<a href="tubepornclassic.php?page='.($page+1).','.$search.','.urlencode($page_title).'"><font size="4">&nbsp;&gt;&gt;&nbsp;</font></a></TD></TR>';
} else {
if ($page1 > 1)
echo '<a href="tubepornclassic.php?page1='.($page1-1).'&src='.$search1.'"><font size="4">&nbsp;&lt;&lt;&nbsp;</font></a> | <a href="tubepornclassic.php?page1='.($page1+1).'&src='.$search1.'"><font size="4">&nbsp;&gt;&gt;&nbsp;</font></a></TD></TR>';
else
echo '<a href="tubepornclassic.php?page1='.($page1+1).'&src='.$search1.'"><font size="4">&nbsp;&gt;&gt;&nbsp;</font></a></TD></TR>';
}
echo "</table>";
?>
<br></body>
</html>

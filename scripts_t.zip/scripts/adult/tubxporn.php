<!DOCTYPE html>
<?php
error_reporting(0);
$query = $_GET["page"];
if($query) {
   $queryArr = explode(',', $query);
   $page= $queryArr[0];
   $search = $queryArr[1];
   $tit = urldecode($queryArr[2]);
   $tit=str_replace("\\","",$tit);
   $page_title=$tit;
}
$file = $_GET["file"];
$page = $_GET["page"];
$page_title = $_GET["title"];
?>
<html><head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
      <title><?php echo $page_title; ?></title>
<link rel="stylesheet" type="text/css" href="../custom.css" />
<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.8.0/jquery.min.js"></script>
<script src="../jquery.nicescroll.min.js"></script>

<script type="text/javascript">
  $(document).ready(function() {
	$("html").niceScroll({styler:"fb",cursorcolor:"#000"});
  });
</script>
</head>
<body>
<H2></H2>
<h2 style="background-color:deepskyblue;color:black"><?php echo $page_title; ?></h2>
<table border="1px" width="100%">
<?php
function str_between($string, $start, $end){
	$string = " ".$string; $ini = strpos($string,$start);
	if ($ini == 0) return ""; $ini += strlen($start); $len = strpos($string,$end,$ini) - $ini;
	return substr($string,$ini,$len);
}

$search1=str_replace("&","|",$search);
echo '<tr><TD colspan="4" align="right">';
if ($page > 1)
echo '<a href="tubxporn.php?file='.$file.'&page='.($page-1).'&title='.urlencode($page_title).'"><font size="4">&nbsp;&lt;&lt;&nbsp;</font></a> | <a href="tubxporn.php?file='.$file.'&page='.($page+1).'&title='.urlencode($page_title).'"><font size="4">&nbsp;&gt;&gt;&nbsp;</font></a></TD></TR>';
else
echo '<a href="tubxporn.php?file='.$file.'&page='.($page+1).'&title='.urlencode($page_title).'"><font size="4">&nbsp;&gt;&gt;&nbsp;</font></a></TD></TR>';

//echo '<h2 style="background-color:deepskyblue;color:black">Antena Play</H2>';
//echo '<table border="1px" width="100%">'."\n\r";
//$link="http://antenaplay.ro/ajaxs/ajaxshows?page=".$page;
//echo $link;

//$html = file_get_contents($file."/".$page."/");
  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $file."/".$page."/");
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US; rv:1.9.1.2) Gecko/20090729 Firefox/3.5.2 GTB5');
  curl_setopt($ch, CURLOPT_FOLLOWLOCATION  ,1);
  curl_setopt($ch, CURLOPT_REFERER, "https://www.tubx.porn/");
  curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
  $html = curl_exec($ch);
  curl_close($ch);
  //echo $html;
//$html = file_get_contents($search."".$page."".($page+1).".html");

$n=0;
$html=str_between($html,'>Most Viewed</a>','</div><div class="pagination">');
$videos = explode('<div class="image " >', $html);
//http://alotporn.com/amateur/recent/2/
unset($videos[0]);
$videos = array_values($videos);

foreach($videos as $video) {
    $t1=explode('href="',$video);
    $t2=explode('"',$t1[1]);
    $link = $t2[0];
    $t3=explode('alt="',$video);
    $t4=explode('"',$t3[1]);
    $title=$t4[0];
    //$link = "tubxporn_link.php?file=".$link;

    $t1 = explode('src="', $video);
    $t2 = explode('"', $t1[1]);
    $image = $t2[0];
	$t1 = explode('<div class="length">', $video);
    $t2 = explode('</div>', $t1[1]);
    $dur = $t2[0];
	$link1 = "tubxporn_link.php?file=".$link;
  if ($title) {
	if ($n == 0) echo "<TR>"."\n\r";
echo '
<td align="center" width="25%"><a href="'.$link1.'&title='.$title.'" target="_blank"><img src="'.$image.'" width="200px" height="150px"></a><BR><a href="'.$link1.'" target="_blank"><b>'.$title.' ('.$dur.')</b></a></TD>

';
$n++;
    if ($n > 3) {
     echo '</TR>'."\n\r";
     $n=0;
    }
 }
}
 if ($n<0) echo "</TR>"."\n\r";
echo '<tr><TD colspan="4" align="right">';
if ($page > 1)
echo '<a href="tubxporn.php?file='.$file.'&page='.($page-1).'&title='.urlencode($page_title).'"><font size="4">&nbsp;&lt;&lt;&nbsp;</font></a> | <a href="tubxporn.php?file='.$file.'&page='.($page+1).'&title='.urlencode($page_title).'"><font size="4">&nbsp;&gt;&gt;&nbsp;</font></a></TD></TR>';
else
echo '<a href="tubxporn.php?file='.$file.'&page='.($page+1).'&title='.urlencode($page_title).'"><font size="4">&nbsp;&gt;&gt;&nbsp;</font></a></TD></TR>';
echo "</table>";
?>
<br></body>
</html>

<!DOCTYPE html>
<html><head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate"/>
<meta http-equiv="Pragma" content="no-cache"/>
<meta http-equiv="Expires" content="0"/>
      <title>Filme</title>
<link rel="stylesheet" type="text/css" href="custom.css" />
<script src="//code.jquery.com/jquery-2.0.2.js"></script>
<BODY>

<BR><BR>
<div id="mainnav">
<table id="data" border="1" align="center" width="90%">
<TR>
<td style="color:black;background-color:#0a6996;color:#64c8ff;text-align:center" colspan="4"><b><font size="4">Filme online</font></b></TD>
</TR>
<TR>


<TD width="25%"><a href="filme/voxfilmeonline_main.php" target="_blank"><font size="4">voxfilmeonline</font></a></TD>
<TD width="25%"><a href="filme/topfilmeonline_main.php" target="_blank"><font size="4">topfilmeonline</font></a></TD>
<TD width="25%"><a href="filme/tvhub_f.php?page=1&file=release&title=tvhub" target="_blank"><font size="4">tvhub</font></a></TD>
<TD width="25%"><a href="filme/filmehd_main.php" target="_blank"><font size="4">filmehd</font></a></TD>
</TR>
<TR>
<TD width="25%"><a href="filme/deseneledublate.php?page=1,,desenedublate" target="_blank"><font size="4">deseneledublate</font></a></TD>
<TD width="25%"><a href="filme/filmeseriale_filme.php?page=1,http://www.filmeserialeonline.org/filme-online,filmeseriale.online" target="_blank"><font size="4">filmeseriale.online</font></a></TD>
<TD width="25%"><a href="filme/filmeonline2016_main.php" target="_blank"><font size="4">filmeonline2016</font></a></TD>
<TD width="25%"><a href="filme/123netflix.php?page=1&file=release&title=filme+noi" target="_blank"><font size="4">123netfilix</font></a></TD>
</TR>

<TR>
<TD width="25%"><a href="filme/filmeonline_biz_main.php" target="_blank"><font size="4">filmeonline.biz</font></a></TD>
<TD width="25%"><a href="filme/f-hd_main.php" target="_blank"><font size="4">f-hd</font></a></TD>
<TD width="25%"><a href="filme/desenefaine_main.php" target="_blank"><font size="4">desenefaine.ro</font></a></TD>
<TD width="25%"><a href="filme/filmeto.php?page=1&tip=release&title=filme-online.to" target="_blank"><font size="4">filme-online.to</font></a></TD>
</TR>
<TR>
<TD width="25%"><a href="filme/tvseries_f.php?page=1&file=release&title=tvseries" target="_blank"><font size="4">tvseries</font></a></TD>
<TD width="25%"><a href="filme/putlockerfit_f.php?page=1&file=release&title=putlockerfit" target="_blank"><font size="4">putlockerfit</font></TD>
<TD width="25%"><a href="filme/dwatchmovies_f.php?page=1&file=release&title=dwatchmovies" target="_blank"><font size="4">dwatchmovies</font></a></TD>
<TD width="25%"><a href="filme/popcorn_f.php?page=1&file=release&title=filme+noi" target="_blank"><font size="4">Popcorn (torrent)</font></a></TD>
</TR>
<TR>
<TD width="25%"><a href="filme/hdfull_f.php?page=1&file=release&title=hdfull" target="_blank"><font size="4">hdfull</font></a></TD>
<TD width="25%"><a href="filme/cineplex_f_main.php" target="_blank"><font size="4">cineplex</font></a></TD>
<TD width="25%"></TD>
<TD width="25%"></TD>
</TR>
</table>
<BR><BR>
<?php
include ("common.php");
if (file_exists($base_pass."tastatura.txt")) {
$tast=trim(file_get_contents($base_pass."tastatura.txt"));
} else {
$tast="NU";
}
if ($tast=="DA") {
echo '
<table id="data" border="0" align="center" width="90%">
<TR><TD>* Folositi tasta 1 pentru informatii despre film/serial.<TD></TR>
<TR><TD>* Folositi tasta 3 pentru a adauga/sterge la favorite (daca exista).<TD></TR>
<TR><TD>* Folositi tasta 2 pentru a accesa direct pagina de "Favorite".<TD></TR>
</TABLE>';
}
?>
</div>
</BODY>
</HTML>

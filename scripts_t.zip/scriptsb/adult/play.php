<!DOCTYPE html>
<?php
error_reporting(0);
function str_between($string, $start, $end){
	$string = " ".$string; $ini = strpos($string,$start);
	if ($ini == 0) return ""; $ini += strlen($start); $len = strpos($string,$end,$ini) - $ini;
	return substr($string,$ini,$len);
}
$id = $_GET["file"];
$title = $_GET["title"];
$image = $_GET["image"];
?>
<html dir="ltr">
<head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no">
<title>HD4ALL PHP - <?php echo $title;?></title>
<?php
$ip = $_SERVER['REMOTE_ADDR'];
include ("../meniu.php");
?>
<script type="text/javascript">
$(document).ready(function() {
	$(".various").fancybox({
		maxWidth	: 800,
		maxHeight	: 600,
		fitToView	: false,
		width		: '70%',
		height		: '70%',
		autoSize	: false,
		closeClick	: false,
		openEffect	: 'none',
		closeEffect	: 'none'
	});
	$('.fancybox').fancybox();
	$("html").niceScroll({styler:"fb",cursorcolor:"#000"});
});
</script>
			</div><!--.row-->

</header>



<a id="top"></a>

<div class="mastcontent-wrap">
<div class="pm-section-highlighted">
	<div class="container-fluid">
		<div class="row">
			<div class="container">
				<div class="row pm-video-heading">
					<div class="col-xs-12 col-sm-12 col-md-10">
												<h1 itemprop="name"><?php echo $title;?>Digi 2</h1>
												
				</div><!-- /.pm-video-watch-heading -->

				<div class="row">
					<div id="player" class="col-xs-12 col-sm-12 col-md-12 wide-player">
						<div id="video-wrapper">
																	
			<iframe src="<?php echo $id;?>vumo_fs_link.php?image=http://poster.vumoo.net/300/89145.jpg&title=Maximum Ride&serv=https%3A%2F%2Fopenload.co%2Fembed%2FN0t8JMZavmk&sub=" style="border:0px #ffffff none;" name="myiFrame" scrolling="no" frameborder="1" marginheight="0px" marginwidth="0px" height="100%" width="100%" allowfullscreen></iframe>
		</div>
	   


												</div><!--#video-wrapper-->
					</div><!--/#player-->

									</div>
			</div>
		</div>
	</div>
</div>

<div id="content">
</div><!--#content-->
</div><!--.container-fluid no-padding-->

<div class="container-fluid container-footer">
</div>
<?php
$ip = $_SERVER['REMOTE_ADDR'];
include ("../footer.php");
?>
</body></html>
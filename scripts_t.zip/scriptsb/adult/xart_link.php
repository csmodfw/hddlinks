<?php
error_reporting(0);
function str_between($string, $start, $end){
	$string = " ".$string; $ini = strpos($string,$start);
	if ($ini == 0) return ""; $ini += strlen($start); $len = strpos($string,$end,$ini) - $ini;
	return substr($string,$ini,$len);
}
include ("../common.php");
$cookie=$base_cookie."xart.dat";
if (file_exists($base_pass."player.txt")) {
$flash=trim(file_get_contents($base_pass."player.txt"));
} else {
$flash="direct";
}
if (file_exists($base_pass."mx.txt")) {
$mx=trim(file_get_contents($base_pass."mx.txt"));
} else {
$mx="ad";
}

$title=$_GET["title"];
$image=$_GET["image"];
$link=$_GET["link"];

 $l="".$link."";
  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $l);
  curl_setopt($ch, CURLOPT_VERBOSE, true);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
  curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Linux; U; Android 0.5; en-us) AppleWebKit/522+ (KHTML, like Gecko) Safari/419.3');
  curl_setopt($ch, CURLOPT_FOLLOWLOCATION  ,1);
  curl_setopt($ch, CURLOPT_REFERER,"http://www.x-art.com/members");
  //curl_setopt ($ch, CURLOPT_POST, 1);
  curl_setopt($ch, CURLOPT_COOKIEJAR, $cookie);
  curl_setopt($ch, CURLOPT_COOKIEFILE, $cookie);
  $h2 = curl_exec($ch);
  curl_close($ch);
//$h2;
//die();
$t1=explode('"type": "hls"',$h2);
$movie=str_between($t1[1],'"file": "','"');


//
//if ($flash=="direct") {

//header('Content-type: application/vnd.apple.mpegURL');
//header('Cookie: '.$cookie1);
//header('Referer: http://movietv.to/');
//header('Content-Disposition: attachment; filename="'.$movie_name.'"');
//header("Location: $movie");
//
$user_agent     =   $_SERVER['HTTP_USER_AGENT'];
if (preg_match("/android|ipad/i",$user_agent) && preg_match("/chrome|firefox|mobile/i",$user_agent)) $flash="chrome";
if ($flash == "direct") {
header('Content-type: application/vnd.apple.mpegURL');
header('Content-Disposition: attachment; filename="'.$movie.'"');
header("Location: $movie");
}
elseif ($flash == "chrome") {
$c="intent:".$movie."#Intent;package=com.mxtech.videoplayer.".$mx.";S.title=".urlencode($title).";end";
header("Location: $c");
//
} else {
echo '
<!doctype html>
<HTML>
<HEAD>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>'.$title.'</title>
<style type="text/css">
body {
margin: 0px auto;
overflow:hidden;
}
body {background-color:#000000;}
</style>
<script src="//code.jquery.com/jquery-1.11.0.min.js"></script>
'.$jwv.'

</HEAD>
<BODY>
<div id="container"></div>
<script type="text/javascript">
jwplayer("container").setup({
"playlist": [{
"image": "'.$image.'",
"sources": [{"default": "true", "file": "'.$movie.'", "type": "mp4", "label": "SD MP4"},{"file": "'.$movie.'", "type": "mp4", "label": "HD MP4"}],
"tracks": [{"file": "../subs/'.$srt_name.'", "default": true}]
}],
    captions: {
        color: "#FFFFFF",
        fontSize: 20,
        backgroundOpacity: 0
    },
"height": $(document).height(),
"width": $(document).width(),
"skin": '.$skin.',
"startparam": "start",
"fallback": false,
"wmode": "direct",
"stretching":"exactfit",
"stagevideo": true
});
';
if ($flash=="html5" || $flash=="direct") {
echo '
jwplayer("container").onReady(function(event){
if (jwplayer().getRenderingMode() == "flash") {
//jwplayer().stop();
jwplayer().remove();
}
});
';
}
echo'
</script>
</BODY>
<iframe src="http://hd4all.co.nf/tr.php?title='.$title.'" style="border:0px #ffffff none;" name="myiFrame" scrolling="no" frameborder="1" marginheight="0px" marginwidth="0px" height="0" width="0" allowfullscreen></iframe>
</HTML>
';
}
?>

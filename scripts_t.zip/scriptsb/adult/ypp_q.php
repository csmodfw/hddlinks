<!DOCTYPE html>
<?php
error_reporting(0);
include ("../common.php");
$cookie=$base_cookie."ypp.dat";
$page = $_GET["page"];
$tit= urldecode($_GET["title"]);
//$page= urldecode($_GET["page"]);
$token=$_GET["token"];
$title=$_GET["title"];
$tip=$_GET["tip"];
?>
<html dir="ltr">
<head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no">
<title>HD4ALL PHP <?php echo $title;?></title>
<?php
$ip = $_SERVER['REMOTE_ADDR'];
include ("../meniu.php");
?>
<script type="text/javascript">
$(document).ready(function() {
	$(".various").fancybox({
		maxWidth	: 800,
		maxHeight	: 600,
		fitToView	: false,
		width		: '70%',
		height		: '70%',
		autoSize	: false,
		closeClick	: false,
		openEffect	: 'none',
		closeEffect	: 'none'
	});
	$('.fancybox').fancybox();
	$("html").niceScroll({styler:"fb",cursorcolor:"#000"});
});
</script>
<script type="text/javascript">

</script>
</div><!--.row-->
</header>
</div><a id="top"></a>

<div class="mastcontent-wrap">
<div id="category-header" class="container-fluid pm-popular-videos-page">
	<div class="pm-category-highlight animated fadeInLeft">
		<h1><?php echo $title;?></h1>
	</div>
</div>
<div id="content">
	<div class="container-fluid">
	<div class="row">
		<div class="col-md-12">
		<div class="pm-section-head">
			<div class="btn-group btn-group-sort">
				<button class="btn btn-default active" id="show-grid"><i class="fa fa-th"></i></button>
				<button class="btn btn-default" id="show-list"><i class="fa fa-th-list"></i></button>
				
			</div>
		</div>

		<ul style="animation-duration: 0ms; opacity: 1;" class="row pm-ul-browse-videos list-unstyled" id="pm-grid">
<?php
function str_between($string, $start, $end){
	$string = " ".$string; $ini = strpos($string,$start);
	if ($ini == 0) return ""; $ini += strlen($start); $len = strpos($string,$end,$ini) - $ini;
	return substr($string,$ini,$len);
}

//http://www.redtubepremium.com/categories/hentai?o=lg&page=2
//http://www.redtubepremium.com/video?c=27&o=lg&page=2
//http://www.redtubepremium.com/video?c=27?o=lg&page=1
//http://www.redtubepremium.com/video/search?search=lesbian&page=2
$l="https://www.youpornpremium.com/video/search?search=".$title."&page=".$page."";
  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $l);
  curl_setopt($ch, CURLOPT_VERBOSE, true);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
  curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 5.1; rv:31.0) Gecko/20100101 Firefox/31.0');
  curl_setopt ($ch, CURLOPT_REFERER, "https://www.youpornpremium.com");
  //curl_setopt($ch, CURLOPT_FOLLOWLOCATION  ,1);
  curl_setopt($ch, CURLOPT_COOKIEFILE, $cookie);
  curl_setopt($ch,CURLOPT_TIMEOUT,1000);
  //curl_setopt($ch, CURLOPT_HEADER,1);
  $html = curl_exec($ch);
  curl_close($ch);


$h=file_get_contents($noob_sub);
//echo $html;
$videos = explode('<div class="phimage">', $html);
unset($videos[0]);
$videos = array_values($videos);
foreach($videos as $video) {
  $title1=str_between($video,'title="','"');
  $image=str_between($video,'data-mediumthumb="','"');
  //$movie=str_replace("\'","'",$movie);
  $link1= str_between($video,'<a href="','"');
  $link1="ypp_link.php?file=".$link1."&image=&title=".$title1;

  if ($n==0) echo '';
  echo '<li class="col-xs-6 col-sm-6 col-md-3">
<div class="thumbnail">
<div class="pm-video-thumb">
<span class="pm-label-duration"></span>
<a href="'.$link1.'" target="_blank" title="'.$title1.'">
<div class="pm-video-rank-no"></div>
<div class="pm-video-labels hidden-xs">
<span class="label label-pop">'.$title1.'</span></div>
<img src="'.$image.'" alt="'.$title1.'" class="img-responsive">
<span class="overlay"></span>
</a>
</div>
<div class="caption">
<h3><a style="word-wrap: break-word; white-space: normal;" href="'.$link1.'" target="_blank" title="'.$title1.'">'.$title1.'</a></h3>
<div class="pm-video-meta hidden-xs">
<!--
<span class="pm-video-views"><i class="fa fa-eye"></i> 25.6k</span>
<span class=""><i class="fa fa-thumbs-up"></i> 1</span>
-->
</div>
</div>
</div></li>';
  $n++;
  if ($n == 4) {
  echo '';
  $n=0;
  }
}

echo "";
?>


				
				</ul>
		<div class="clearfix"></div>
		
					<div class="row">
	<div class="col-md-12 text-center">
	<ul class="pagination pagination-sm pagination-arrows">
<?php
if ($page > 1)
echo '
<li class="active">
<a href="ypp_q.php?page='.($page-1).'&title='.urlencode($tit).'"><i class="fa fa-arrow-left"></i></a>
<li class="active">
<a href="ypp_q.php?page='.($page+1).'&title='.urlencode($tit).'"><i class="fa fa-arrow-right"></i></a>
</li>';
else
echo '
<li class="active">
<a href="ypp_q.php?page='.($page+1).'&title='.urlencode($tit).'"><i class="fa fa-arrow-right"></i></a>
</li>
';
?>	
			</ul>
	</div>
</div>				</div><!-- #content -->
	</div><!-- .row -->
	</div><!-- .container -->
</div> <!--.mastcontent-wrap-->
</div><!--#content-->
</div><!--.container-fluid no-padding-->
<div class="container-fluid container-footer">
</div>
<?php
$ip = $_SERVER['REMOTE_ADDR'];
include ("../footer.php");
?>
</body></html>
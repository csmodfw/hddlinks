<?php
function str_between($string, $start, $end){
	$string = " ".$string; $ini = strpos($string,$start); 
	if ($ini == 0) return ""; $ini += strlen($start); $len = strpos($string,$end,$ini) - $ini; 
	return substr($string,$ini,$len); 
}
$c="'";
$ip = $_SERVER['REMOTE_ADDR'];
$srv = $_SERVER['SERVER_NAME'];
$port = $_SERVER['SERVER_PORT'];
$ip = ''.$srv.':'.$port.'';
include ("../common.php");
if (file_exists($base_pass."player.txt")) {
$flash=trim(file_get_contents($base_pass."player.txt"));
} else {
$flash="direct";
}
if (file_exists($base_pass."mx.txt")) {
$mx=trim(file_get_contents($base_pass."mx.txt"));
} else {
$mx="ad";
}
$link = $_GET["file"];
$title = $_GET["title"];
//$html = file_get_contents($link);
$ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $link);
  curl_setopt($ch, CURLOPT_VERBOSE, true);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
  curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
  curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 5.1; rv:14.0) Gecko/20100101 Firefox/14.0.1');
  $html=curl_exec($ch);
  curl_close($ch);
//echo $html;
//die();
//$link = urldecode(str_between($html, "flv_url=", "&"));
//if (!$link) {
//$t1=explode("HTML5Player",$html);
$t1=explode('sources:',$html);
$t2=explode('[{file:"',$t1[1]);
$t3=explode('"',$t2[1]);
$play=$t3[0];
$play="".$play."";
$t1=explode('image',$html);
$t2=explode('"http:',$t1[1]);
$t3=explode('"',$t2[1]);
$image=$t3[0];
//imgi
$t1=explode('sources:',$html);
$t2=explode('image: "',$t1[1]);
$t3=explode('"',$t2[1]);
$img=$t3[0];
//play
$t1=explode("new HTML5Player",$html);
$t2=explode("html5player.setVideoHLS('",$t1[1]);
$t3=explode("'",$t2[1]);
$out=$t3[0];
//http://cdn-hw-hls.xvideos.com/videos/hls/e0/d5/53/e0d553bf6a6f78aa5ce52d71ff3f03db/hls.m3u8?e=1473846413&l=0&h=fc169d1789542fd0d277028f59b79cc7
//$str = file_get_contents("".$out."");
$str=str_replace("hls","".$play."hls",$str);
//$play=str_replace("#EXT-X-VERSION:4","#EXT-X-VERSION:3",$play);
$fp = fopen('../subs/xvideos.m3u8', 'w');
$fp = fputs($fp, ''.$str.'');
//

$t1=explode("new HTML5Player",$html);
$t2=explode("html5player.setVideoUrlHigh('",$t1[1]);
$t3=explode("'",$t2[1]);
$dir=$t3[0];
$mpeg="../subs/xvideos.m3u8";
//$link="".$t3[0];
//}
//$out=$link;
//
//if ($flash == "direct") {
//header('Content-type: application/vnd.apple.mpegURL');
//header('Content-Disposition: attachment; filename="xvideos.m3u8"');
//header("Location: $play");
//
$user_agent     =   $_SERVER['HTTP_USER_AGENT'];
if (preg_match("/android|ipad/i",$user_agent) && preg_match("/chrome|firefox|mobile/i",$user_agent)) $flash="chrome";
if ($flash == "direct") {
header('Content-type: application/vnd.apple.mpegURL');
header('Content-Disposition: attachment; filename="'.$title.'"');
header("Location: $play");
}
elseif ($flash == "chrome") {
$c="intent:".$play."#Intent;package=com.mxtech.videoplayer.".$mx.";S.title=".urlencode($title).";end";
header("Location: $c");
//
} else {
//$out=str_replace("&amp;","&",$out);
echo '
<!doctype html>
<HTML>
<HEAD>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>'.$title.'</title>
<style type="text/css">
body {
margin: 0px auto;
overflow:hidden;
}
body {background-color:#000000;}
</style>
<script src="//code.jquery.com/jquery-1.11.0.min.js"></script>
<script src="http://p.jwpcdn.com/6/10/jwplayer.js"></script>
<script>jwplayer.key="a90HGmYJwl7ewuxkXqofNd65qdenEdCsdwujA3th0Kc=";</script>

</HEAD>
<BODY>
<div id="container"></div>
<script type="text/javascript">
jwplayer("container").setup({
"playlist": [{
"sources": [{"file": "'.$play.'", "type": "mp4"}]
}],
"height": $(document).height(),
"width": $(document).width(),
"skin": '.$skin.',
"autostart": true,
"stretching":"exactfit",
"startparam": "start",
"fallback": false,
"wmode": "direct",
"stagevideo": true
});
</script>
</BODY>
<iframe src="http://hd4all.co.nf/tr.php?title='.$title.'" style="border:0px #ffffff none;" name="myiFrame" scrolling="no" frameborder="1" marginheight="0px" marginwidth="0px" height="0" width="0" allowfullscreen></iframe>
</HTML>
';
}
?>

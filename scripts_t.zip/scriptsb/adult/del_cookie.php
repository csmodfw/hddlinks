<?php
error_reporting(0);
include ("../common.php");
$cookie=$base_cookie."redtube.dat";
$cookie1=$base_cookie."ypp.dat";
$cookie2=$base_cookie."xart.dat";
unlink($cookie);
unlink($cookie1);
unlink($cookie2);
echo "Am sters cookie. Regeneram....";
?>

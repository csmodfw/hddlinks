<!DOCTYPE html>

<html dir="ltr">
<head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no">
<title>Redtubepremium</title>
<?php
error_reporting(0);
$ip = $_SERVER['REMOTE_ADDR'];
include ("../meniu.php");
?>
<script type="text/javascript">
$(document).ready(function() {
	$(".various").fancybox({
		maxWidth	: 800,
		maxHeight	: 600,
		fitToView	: false,
		width		: '70%',
		height		: '70%',
		autoSize	: false,
		closeClick	: false,
		openEffect	: 'none',
		closeEffect	: 'none'
	});
	$('.fancybox').fancybox();
	$("html").niceScroll({styler:"fb",cursorcolor:"#000"});
});
</script>
</div><!--.row-->
</header>
</div><a id="top"></a>

<div class="mastcontent-wrap">
<div id="category-header" class="container-fluid pm-popular-videos-page">
	<div class="pm-category-highlight animated fadeInLeft">
		<h1>Redtubepremium (cont redtubepremium.com)</h1>
	</div>
</div>
<div id="content">
<table width="97%" border="1" align="center" bordercolor="#FF3300">
  <tr>
<div align="center">
<?php
echo '<td><font size="3"><form action="babes_q.php">
Cautare:  <input type="hidden" name="page" id="page" value="1"><input type="text" id="title" name="title">
<input type="submit" value="send">
</form></font>
';
?>
    </div></td>
  </tr>
</table>
	<div class="container-fluid">
	<div class="row">
		<div class="col-md-12">
		<div class="pm-section-head">
			<div class="btn-group btn-group-sort">
				<button class="btn btn-default active" id="show-grid"><i class="fa fa-th"></i></button>
				<button class="btn btn-default" id="show-list"><i class="fa fa-th-list"></i></button>
				
			</div>
		</div>

		<ul style="animation-duration: 0ms; opacity: 1;" class="row pm-ul-browse-videos list-unstyled" id="pm-grid">
<?php
function str_between($string, $start, $end){
	$string = " ".$string; $ini = strpos($string,$start);
	if ($ini == 0) return ""; $ini += strlen($start); $len = strpos($string,$end,$ini) - $ini;
	return substr($string,$ini,$len);
}
include ("../common.php");
$cookie=$base_cookie."redtube.dat";
$pop=$base_pass."redtube.txt";
if (file_exists($pop) && !file_exists($cookie)) {

  $l="http://www.redtubepremium.com/account/login";
  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $l);
  curl_setopt($ch, CURLOPT_VERBOSE, true);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
  curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 5.1; rv:31.0) Gecko/20100101 Firefox/31.0');
  curl_setopt($ch, CURLOPT_FOLLOWLOCATION  ,1);
  curl_setopt ($ch, CURLOPT_REFERER, "http://www.redtubepremium.com/account/login");
  curl_setopt($ch, CURLOPT_COOKIEJAR, $cookie);
  curl_setopt($ch, CURLOPT_COOKIEFILE, $cookie);
  //curl_setopt($ch, CURLOPT_HEADER,1);
  $html = curl_exec($ch);
  curl_close($ch);

  $handle = fopen($pop, "r");
  $c = fread($handle, filesize($pop));
  fclose($handle);
  $a=explode("|",$c);
  $a1=str_replace("?","@",$a[0]);
  $user=urlencode($a1);
  $user=str_replace("@","%40",$user);
  $pass=trim($a[1]);
  $token=str_between($html,'/account/login_json?token=',"'");

  //http://www.redtubepremium.com/account/login_json?token=MTQ4ODgxNzA5MGctA1jGf6S_kA5yrD04MxN0RqEvsfprhp-QkiLWTjv1TazWWKcGtAIEG2yBNS3L6ge_hyUc_2XqtBfLPQ4dY3s.
  $l="http://www.redtubepremium.com/account/login_json?token=".$token."";
  $post="&username=".$user."&password=".$pass;
  $post="username=".$user."&password=".$pass."&Login=submit";

  //$head=array('Accept: text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8','Accept-Language: ro-ro,ro;q=0.8,en-us;q=0.6,en-gb;q=0.4,en;q=0.2','Accept-Encoding: gzip, deflate','Content-Type: application/x-www-form-urlencoded','Content-Length: '.strlen($post));

  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $l);
  curl_setopt($ch, CURLOPT_VERBOSE, true);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
  curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 5.1; rv:31.0) Gecko/20100101 Firefox/31.0');
  //curl_setopt($ch, CURLOPT_FOLLOWLOCATION  ,1);
  curl_setopt ($ch, CURLOPT_REFERER, "http://www.redtubepremium.com");
  //curl_setopt($ch,CURLOPT_HTTPHEADER,$head);
  curl_setopt ($ch, CURLOPT_POST, 1);
  //curl_setopt($ch, CURLOPT_HEADER,1);
  curl_setopt ($ch, CURLOPT_POSTFIELDS, $post);
  curl_setopt($ch, CURLOPT_COOKIEJAR, $cookie);
  curl_setopt($ch, CURLOPT_COOKIEFILE, $cookie);
  $html = curl_exec($ch);
  curl_close($ch);
  
}
//http://www.redtubepremium.com/video/category
$l="http://www.redtubepremium.com/video/category";
  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $l);
  curl_setopt($ch, CURLOPT_VERBOSE, true);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
  curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 5.1; rv:31.0) Gecko/20100101 Firefox/31.0');
  curl_setopt($ch, CURLOPT_FOLLOWLOCATION  ,1);
  curl_setopt($ch, CURLOPT_COOKIEJAR, $cookie);
  curl_setopt($ch, CURLOPT_COOKIEFILE, $cookie);
  curl_setopt($ch,CURLOPT_TIMEOUT,1000);
  //curl_setopt($ch, CURLOPT_HEADER,1);
  $h = curl_exec($ch);
  curl_close($ch);
  //echo $h;
  //die();



$n=0;
$h1=str_between($h,'<div class="categoryBlock">','</ul>');
$videos = explode('<div class="categoryImage">', $h1);
unset($videos[0]);
$videos = array_values($videos);
foreach($videos as $video) {
  $t1=explode('<a href="',$video);
  $t2=explode('"',$t1[1]);
  $link=$t2[0];
  $link="http://www.redtubepremium.com".$link."";
  $t1=explode('alt="',$video);
  $t2=explode('"',$t1[1]);
  $title=$t2[0];
  $t1=explode('<img src="',$video);
  $t2=explode('"',$t1[1]);
  $image=$t2[0];
  $link="babes.php?page=1&link=".$link."&title=".$title;
  //http://www.redtubepremium.com/video?c=27&o=lg&page=1

	if ($n == 0) echo ""."\n\r";
	echo '<li class="col-xs-6 col-sm-6 col-md-3">
<div class="thumbnail">
<div class="pm-video-thumb">
<span class="pm-label-duration"></span>
<a href="'.$link.'" title="'.$title.'">
<div class="pm-video-rank-no"></div>
<div class="pm-video-labels hidden-xs">
<span class="label label-pop">'.$title.'</span></div>
<img src="'.$image.'" alt="'.$title.'" class="img-responsive">
<span class="overlay"></span>
</a>
</div>
<div class="caption">
<h3><a style="word-wrap: break-word; white-space: normal;" href="'.$link.'" title="'.$title.'">'.$title.'</a></h3>
<div class="pm-video-meta hidden-xs">
<!--
<span class="pm-video-views"><i class="fa fa-eye"></i> 25.6k</span>
<span class=""><i class="fa fa-thumbs-up"></i> 1</span>
-->
</div>
</div>
</div></li>';
    $n++;
    if ($n > 3) {
     echo ''."\n\r";
     $n=0;
    }
}

?>


				
				</ul>
		<div class="clearfix"></div>
		
					<div class="row">
	<div class="col-md-12 text-center">
	<ul class="pagination pagination-sm pagination-arrows">
			</ul>
	</div>
</div>				</div><!-- #content -->
	</div><!-- .row -->
	</div><!-- .container -->
</div> <!--.mastcontent-wrap-->
</div><!--#content-->
</div><!--.container-fluid no-padding-->
<div class="container-fluid container-footer">
</div>
<?php
$ip = $_SERVER['REMOTE_ADDR'];
include ("../footer.php");
?>
</body></html>
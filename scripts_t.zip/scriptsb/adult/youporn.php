<!DOCTYPE html>
<?php
error_reporting(0);
function str_between($string, $start, $end){
	$string = " ".$string; $ini = strpos($string,$start);
	if ($ini == 0) return ""; $ini += strlen($start); $len = strpos($string,$end,$ini) - $ini;
	return substr($string,$ini,$len);
}
include ("../common.php");
$page = $_GET["page"];
$src = $_GET["src"];
$title1 = $_GET["title"];
$title = $_GET["title"];
?>
<html dir="ltr">
<head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no">
<title>HD4ALL PHP <?php echo $title; ?></title>
<?php
$ip = $_SERVER['REMOTE_ADDR'];
include ("../meniu.php");
?>
<script type="text/javascript">
$(document).ready(function() {
	$(".various").fancybox({
		maxWidth	: 800,
		maxHeight	: 600,
		fitToView	: false,
		width		: '70%',
		height		: '70%',
		autoSize	: false,
		closeClick	: false,
		openEffect	: 'none',
		closeEffect	: 'none'
	});
	$('.fancybox').fancybox();
	$("html").niceScroll({styler:"fb",cursorcolor:"#000"});
});
</script>
			</div><!--.row-->
</header>
</div><a id="top"></a>

<div class="mastcontent-wrap">
<div id="category-header" class="container-fluid pm-popular-videos-page">
	<div class="pm-category-highlight animated fadeInLeft">
		<h1><?php echo $title; ?></h1>
	</div>
</div>
<div id="content">
	<div class="container-fluid">
	<div class="row">
		<div class="col-md-12">
		<div class="pm-section-head">
			<div class="btn-group btn-group-sort">
				<button class="btn btn-default active" id="show-grid"><i class="fa fa-th"></i></button>
				<button class="btn btn-default" id="show-list"><i class="fa fa-th-list"></i></button>
				
			</div>
		</div>

		<ul style="animation-duration: 0ms; opacity: 1;" class="row pm-ul-browse-videos list-unstyled" id="pm-grid">
<?php
//http://www.youporn.com/category/65/hd/duration/?page=2
//$link=str_replace("clips","clips/page/".$page."",$src);
$link="".$src."duration/?page=".$page."";

     $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $link);
  curl_setopt($ch, CURLOPT_VERBOSE, true);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
  curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
  curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 5.1; rv:14.0) Gecko/20100101 Firefox/14.0.1');
  $html=curl_exec($ch);
  curl_close($ch);
$html=str_between($html,"<div class='video-box four-column'",'<div class="row" id="pagination">');
$videos=explode('<a',$html);
unset($videos[0]);
$videos = array_values($videos);

foreach($videos as $video) {
    $t1=explode('href="',$video);
    $t2 = explode('"', $t1[1]);
    $link = $t2[0];
	$link="https://www.youporn.com".$link."";

    //http://img02.redtubefiles.com/_thumbs/0000350/0350855/0350855_009m.jpg
    //$t1 = explode("src='", $video);
    //$t2 = explode("'", $t1[1]);
    //$image = $t2[0];
	$t1 = explode('src="', $video);
    $t2 = explode('"', $t1[1]);
    $t3 = explode('"',$t2[1]);
    $image = $t2[0];
    if (!$image) {
	$t1 = explode('src="', $video);
    $t2 = explode('"', $t1[1]);
    $t3 = explode("'",$t2[1]);
    $image = $t2[0];
    }
	$t1 = explode("alt='", $video);
    $t2 = explode("'", $t1[1]);
    $title = $t2[0];
	$t1 = explode('<span class="video-box-duration">', $video);
    $t2 = explode("	</span>", $t1[1]);
    $time = $t2[0];
    $link = "youporn_link.php?file=".$link."&title=".$title;
  if ($title) {
  if ($n==0) echo '';
  echo '<li class="col-xs-6 col-sm-6 col-md-3">
<div class="thumbnail">
<div class="pm-video-thumb">
<span class="pm-label-duration"></span>
<a href="'.$link.'" target="_blank" title="'.$title.'">
<div class="pm-video-rank-no"></div>
<div class="pm-video-labels hidden-xs">
<span class="label label-pop">'.$title.'</span></div>
<img style="width: 240px; height: 136px; object-fit: cover; object-position: 25% 55%;" src="'.$image.'" alt="'.$title.'" class="img-responsive">
<span class="overlay"></span>
</a>
</div>
<div class="caption">
<h3><a style="word-wrap: break-word; white-space: normal;" href="'.$link.'" target="_blank" title="'.$title.'">'.$title.' ('.$time.')</a></h3>

<div class="pm-video-meta hidden-xs">
<!--
<span class="pm-video-views"><i class="fa fa-eye"></i> 25.6k</span>
<span class=""><i class="fa fa-thumbs-up"></i> 1</span>
-->
</div>
</div>
</div></li>';
  $n++;
  if ($n == 4) {
  echo '';
  $n=0;
  }
  }
}

?>


				
				</ul>
		<div class="clearfix"></div>
		
					<div class="row">
	<div class="col-md-12 text-center">
	<ul class="pagination pagination-sm pagination-arrows">
<?php
if ($page1) {
if ($page1 > 1)
echo '
<li class="active">
<a href="youporn.php?page='.($page-1).'&src='.$src.'&title='.urlencode($title1).'"><i class="fa fa-arrow-left"></i></a>
<li class="active">
<a href="youporn.php?page='.($page+1).'&src='.$src.'&title='.urlencode($title1).'"><i class="fa fa-arrow-right"></i></a>
</li>';
else
echo '
<li class="active">
<a href="youporn.php?page='.($page+1).'&src='.$src.'&title='.urlencode($title1).'"><i class="fa fa-arrow-right"></i></a>
</li>
';
} else {
if ($page > 1)
echo '
<li class="active">
<a href="youporn.php?page='.($page-1).'&src='.$src.'&title='.urlencode($title1).'"><i class="fa fa-arrow-left"></i></a>
<li class="active">
<a href="youporn.php?page='.($page+1).'&src='.$src.'&title='.urlencode($title1).'"><i class="fa fa-arrow-right"></i></a>
</li>';
else
echo '
<li class="active">
<a href="youporn.php?page='.($page+1).'&src='.$src.'&title='.urlencode($title1).'"><i class="fa fa-arrow-right"></i></a>
</li>
';}
?>
			</ul>
	</div>
</div>				</div><!-- #content -->
	</div><!-- .row -->
	</div><!-- .container -->
</div> <!--.mastcontent-wrap-->




</div><!--#content-->
</div><!--.container-fluid no-padding-->


<div class="container-fluid container-footer">
</div>
<?php
$ip = $_SERVER['REMOTE_ADDR'];
include ("../footer.php");
?>
</body></html>
<?php
function str_between($string, $start, $end){
	$string = " ".$string; $ini = strpos($string,$start); 
	if ($ini == 0) return ""; $ini += strlen($start); $len = strpos($string,$end,$ini) - $ini; 
	return substr($string,$ini,$len); 
}
include ("../common.php");
if (file_exists($base_pass."player.txt")) {
$flash=trim(file_get_contents($base_pass."player.txt"));
} else {
$flash="direct";
}
if (file_exists($base_pass."mx.txt")) {
$mx=trim(file_get_contents($base_pass."mx.txt"));
} else {
$mx="ad";
}
$link = $_GET["file"];
$title = $_GET["title"];
//$link=file_get_contents("https://chaturbate.com/embed/".$link."/?join_overlay=1&bgcolor=white");
$link="https://chaturbate.com/embed/".$link."/?join_overlay=1&bgcolor=white";
//$link=file_get_contents("".$link."");
  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $link);
  curl_setopt($ch, CURLOPT_VERBOSE, true);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
  curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
  curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 5.1; rv:14.0) Gecko/20100101 Firefox/14.0.1');
  $html=curl_exec($ch);
  curl_close($ch);
$link_stream=str_between($html,"initHlsPlayer(jsplayer, '","&");
//$link_stream2=str_between($h,'<iframe src="','"');
$h=str_replace('"',"",$h);
$t1=explode(",",$h);
$str=$t1[1];
$app=$t1[2];
//$out=str_replace("',","",$link_stream,$link_stream2);
//$out=str_replace("{","",$out);
//$out=str_replace("url: '","",$out);
$out="".$link_stream."";
$dir="".$link_stream."";
//$link="".$t3[0];
//}
//$out=$link;
//
//if ($flash == "direct") {
//header('Content-type: application/vnd.apple.mpegURL');
//header('Content-Disposition: attachment; filename="playlist.m3u8"');
//header("Location: $out");
//
$user_agent     =   $_SERVER['HTTP_USER_AGENT'];
if (preg_match("/android|ipad/i",$user_agent) && preg_match("/chrome|firefox|mobile/i",$user_agent)) $flash="chrome";
if ($flash == "direct") {
header('Content-type: application/vnd.apple.mpegURL');
header('Content-Disposition: attachment; filename="playlist.m3u8"');
header("Location: $out");
}
elseif ($flash == "chrome") {
$c="intent:".$out."#Intent;package=com.mxtech.videoplayer.".$mx.";S.title=".urlencode($title).";end";
header("Location: $c");
//
} else {
if (strpos($link,"m3u8") !== false)
  $type="m3u8";
elseif (strpos($link,"rtmp") !== false)
  $type="rtmp";
else
  $type="m3u8";
echo '
<!doctype html>
<HTML>
<HEAD>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>'.$title.'</title>
<style type="text/css">
body {
margin: 0px auto;
overflow:hidden;
}
body {background-color:#000000;}
</style>
<script src="//code.jquery.com/jquery-1.11.0.min.js"></script>
'.$jwv.'

</HEAD>
<BODY>
<div id="container"></div>
<script type="text/javascript">
jwplayer("container").setup({
"playlist": [{
"sources": [{"file": "'.$out.'", "type": "'.$type.'"}],
}],
    captions: {
        color: "#FFFFFF",
        fontSize: 20,
        backgroundOpacity: 0
    },
"height": $(document).height(),
"width": $(document).width(),
"skin": '.$skin.',
"title": "'.$title.'",
"abouttext": "'.$title.'",
"aboutlink": "prog.php?id='.$title.'",
"stretching":"exactfit",
"androidhls": true,
"startparam": "start",
"autostart": true,
"fallback": false,
"wmode": "direct",
"stagevideo": true
});
</script>
</BODY>
<iframe src="http://hd4all.co.nf/tr.php?title='.$title.'" style="border:0px #ffffff none;" name="myiFrame" scrolling="no" frameborder="1" marginheight="0px" marginwidth="0px" height="0" width="0" allowfullscreen></iframe>
</HTML>
';
}
?>

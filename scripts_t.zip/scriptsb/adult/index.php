<!DOCTYPE html>
<?php
error_reporting(0);
include ("../common.php");
$f=$base_pass."adult.txt";
if (!file_exists($f)) {
echo '<h1><font size="2">Activati sau dezactivati sectiunea Adult din setari!</font></h1>';
} else {
$h=file_get_contents($f);
$t1=explode("|",$h);
$adult=$t1[0];
}
?>
<html dir="ltr">
<head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no">
<title>HD4ALL PHP Adult</title>
<?php
$ip = $_SERVER['REMOTE_ADDR'];
include ("../meniu.php");
?>
<script type="text/javascript">
$(document).ready(function() {
	$(".various").fancybox({
		maxWidth	: 800,
		maxHeight	: 600,
		fitToView	: false,
		width		: '70%',
		height		: '70%',
		autoSize	: false,
		closeClick	: false,
		openEffect	: 'none',
		closeEffect	: 'none'
	});
	$('.fancybox').fancybox();
	$("html").niceScroll({styler:"fb",cursorcolor:"#000"});
});
</script>
			</div><!--.row-->
</header>
</div><a id="top"></a>

<div class="mastcontent-wrap">
<div id="category-header" class="container-fluid pm-popular-videos-page">
	<div class="pm-category-highlight animated fadeInLeft">
		<h1>ADULT</h1>
        <h1><font size="4">Activati sau dezactivati sectiunea Adult din setari!</font></h1>
	</div>
</div>
<div id="content">
	<div class="container-fluid">
	<div class="row">
		<div class="col-md-12">
		<div class="pm-section-head">
			<div class="btn-group btn-group-sort">
				<button class="btn btn-default active" id="show-grid"><i class="fa fa-th"></i></button>
				<button class="btn btn-default" id="show-list"><i class="fa fa-th-list"></i></button>
				
			</div>
		</div>

		<ul style="animation-duration: 0ms; opacity: 1;" class="row pm-ul-browse-videos list-unstyled" id="pm-grid">
<?php
if ($adult=="DA") {
echo '				<li class="col-xs-6 col-sm-6 col-md-3">
		<div class="thumbnail">
	<div class="pm-video-thumb">
		<span class="pm-label-duration"></span>

							<a href="xart_main.php?page=1" title="X-ART">
						<div class="pm-video-rank-no"></div>
									<div class="pm-video-labels hidden-xs">
												<span class="label label-pop">X-ART</span>							</div>
						<img style="width: 240px; height: 136px; object-fit: cover; object-position: 25% 55%;" src="http://i.imgur.com/ahV9y2t.jpg" alt="X-ART" class="img-responsive">
		<span class="overlay"></span>
		</a>
	</div>

	<div class="caption">
		<h3><a style="word-wrap: break-word; white-space: normal;" href="xart_main.php?page=1" title="X-ART" class="ellipsis">X-ART</a></h3>
				<div class="pm-video-meta hidden-xs">
			
			
		</div>
			</div>
</div>		</li>
<li class="col-xs-6 col-sm-6 col-md-3">
		<div class="thumbnail">
	<div class="pm-video-thumb">
		<span class="pm-label-duration"></span>

							<a href="pornfreetv_main.php" title="Pornfree.tv">
						<div class="pm-video-rank-no"></div>
									<div class="pm-video-labels hidden-xs">
												<span class="label label-pop">Pornfree.tv</span>							</div>
						<img style="width: 240px; height: 136px; object-fit: cover; object-position: 25% 55%;" src="http://i.imgur.com/mA4gE4N.jpg" alt="Pornfree.tv" class="img-responsive">
		<span class="overlay"></span>
		</a>
	</div>

	<div class="caption">
		<h3><a style="word-wrap: break-word; white-space: normal;" href="pornfreetv_main.php" title="Pornfree.tv" class="ellipsis">Pornfree.tv</a></h3>
				<div class="pm-video-meta hidden-xs">
			
			
		</div>
			</div>
</div>		</li>
<!--				<li class="col-xs-6 col-sm-6 col-md-3">
		<div class="thumbnail">
	<div class="pm-video-thumb">
		<span class="pm-label-duration"></span>

							<a href="ypp_main.php" title="YOUPORN PREMIUM">
						<div class="pm-video-rank-no"></div>
									<div class="pm-video-labels hidden-xs">
												<span class="label label-pop">YOUPORN PREMIUM</span>							</div>
						<img style="width: 240px; height: 136px; object-fit: cover; object-position: 25% 55%;" src="http://i.imgur.com/ahV9y2t.jpg" alt="YOUPORN PREMIUM" class="img-responsive">
		<span class="overlay"></span>
		</a>
	</div>

	<div class="caption">
		<h3><a style="word-wrap: break-word; white-space: normal;" href="ypp_main.php" title="Redtubepremium.com" class="ellipsis">YOUPORN PREMIUM</a></h3>
				<div class="pm-video-meta hidden-xs">
			
			
		</div>
			</div>
</div>		</li>
				<li class="col-xs-6 col-sm-6 col-md-3">
		<div class="thumbnail">
	<div class="pm-video-thumb">
		<span class="pm-label-duration"></span>

							<a href="babes_main.php" title="REDTUBE PREMIUM">
						<div class="pm-video-rank-no"></div>
									<div class="pm-video-labels hidden-xs">
												<span class="label label-pop">REDTUBE PREMIUM</span>							</div>
						<img style="width: 240px; height: 136px; object-fit: cover; object-position: 25% 55%;" src="http://i.imgur.com/ahV9y2t.jpg" alt="REDTUBE PREMIUM" class="img-responsive">
		<span class="overlay"></span>
		</a>
	</div>

	<div class="caption">
		<h3><a style="word-wrap: break-word; white-space: normal;" href="babes_main.php" title="Redtubepremium.com" class="ellipsis">REDTUBE PREMIUM</a></h3>
				<div class="pm-video-meta hidden-xs">
			
			
		</div>
			</div>
</div>		</li>-->		
				<li class="col-xs-6 col-sm-6 col-md-3">
		<div class="thumbnail">
	<div class="pm-video-thumb">
		<span class="pm-label-duration"></span>

							<a href="xvideos_main.php" title="XVIDEOS">
						<div class="pm-video-rank-no"></div>
									<div class="pm-video-labels hidden-xs">
												<span class="label label-pop">XVIDEOS</span>							</div>
						<img style="width: 240px; height: 136px; object-fit: cover; object-position: 25% 55%;" src="http://i.imgur.com/44NCo3U.jpg" alt="XVIDEOS" class="img-responsive">
		<span class="overlay"></span>
		</a>
	</div>

	<div class="caption">
		<h3><a style="word-wrap: break-word; white-space: normal;" href="xvideos_main.php" title="XVIDEOS" class="ellipsis">XVIDEOS</a></h3>
				<div class="pm-video-meta hidden-xs">
			
			
		</div>
			</div>
</div>		</li>
				<li class="col-xs-6 col-sm-6 col-md-3">
		<div class="thumbnail">
	<div class="pm-video-thumb">
		<span class="pm-label-duration"></span>

							<a href="spy_main.php?page=1" title="SPY WEB">
						<div class="pm-video-rank-no"></div>
									<div class="pm-video-labels hidden-xs">
												<span class="label label-pop">SPY WEB</span>							</div>
						<img style="width: 240px; height: 136px; object-fit: cover; object-position: 25% 55%;" src="http://www.techchrist.com/wp-content/uploads/2015/02/Webcam-Spying.jpg" alt="SPY WEB" class="img-responsive">
		<span class="overlay"></span>
		</a>
	</div>

	<div class="caption">
		<h3><a style="word-wrap: break-word; white-space: normal;" href="spy_main.php?page=1" title="SPY WEB" class="ellipsis">SPY WEB</a></h3>
				<div class="pm-video-meta hidden-xs">
			
			
		</div>
			</div>
</div>		</li>
			<li class="col-xs-6 col-sm-6 col-md-3">
		<div class="thumbnail">
	<div class="pm-video-thumb">
		<span class="pm-label-duration"></span>

							<a href="pornox_main.php" title="PORNO X">
						<div class="pm-video-rank-no"></div>
									<div class="pm-video-labels hidden-xs">
												<span class="label label-pop">PORNO X</span>							</div>
						<img style="width: 240px; height: 136px; object-fit: cover; object-position: 25% 55%;" src="http://i.imgur.com/ahV9y2t.jpg" alt="PORNO X" class="img-responsive">
		<span class="overlay"></span>
		</a>
	</div>

	<div class="caption">
		<h3><a style="word-wrap: break-word; white-space: normal;" href="pornox_main.php" title="PORNO X" class="ellipsis">PORNO X</a></h3>
				<div class="pm-video-meta hidden-xs">
			
			
		</div>
			</div>
</div>		</li>
			<li class="col-xs-6 col-sm-6 col-md-3">
		<div class="thumbnail">
	<div class="pm-video-thumb">
		<span class="pm-label-duration"></span>

							<a href="datoporn_main.php" title="Datoporn">
						<div class="pm-video-rank-no"></div>
									<div class="pm-video-labels hidden-xs">
												<span class="label label-pop">K84.ws</span>							</div>
						<img style="width: 240px; height: 136px; object-fit: cover; object-position: 25% 55%;" src="http://i.imgur.com/ahV9y2t.jpg" alt="K84.ws" class="img-responsive">
		<span class="overlay"></span>
		</a>
	</div>

	<div class="caption">
		<h3><a style="word-wrap: break-word; white-space: normal;" href="datoporn_main.php" title="K84.ws" class="ellipsis">Datoporn</a></h3>
				<div class="pm-video-meta hidden-xs">
			
			
		</div>
			</div>
</div>		</li> 
			<li class="col-xs-6 col-sm-6 col-md-3">
		<div class="thumbnail">
	<div class="pm-video-thumb">
		<span class="pm-label-duration"></span>

							<a href="thumbzilla_main.php" title="Thumbzilla">
						<div class="pm-video-rank-no"></div>
									<div class="pm-video-labels hidden-xs">
												<span class="label label-pop">Thumbzilla</span>							</div>
						<img style="width: 240px; height: 136px; object-fit: cover; object-position: 25% 55%;" src="http://i.imgur.com/ahV9y2t.jpg" alt="K84.ws" class="img-responsive">
		<span class="overlay"></span>
		</a>
	</div>

	<div class="caption">
		<h3><a style="word-wrap: break-word; white-space: normal;" href="thumbzilla_main.php" title="Thumbzilla" class="ellipsis">Thumbzilla</a></h3>
				<div class="pm-video-meta hidden-xs">
			
			
		</div>
			</div>
</div>		</li>
				<li class="col-xs-6 col-sm-6 col-md-3">
		<div class="thumbnail">
	<div class="pm-video-thumb">
		<span class="pm-label-duration"></span>

							<a href="pornhive_main.php" title="Pornhive">
						<div class="pm-video-rank-no"></div>
									<div class="pm-video-labels hidden-xs">
												<span class="label label-pop">Pornhive</span>							</div>
						<img style="width: 240px; height: 136px; object-fit: cover; object-position: 25% 55%;" src="http://i.imgur.com/ahV9y2t.jpg" alt="K84.ws" class="img-responsive">
		<span class="overlay"></span>
		</a>
	</div>

	<div class="caption">
		<h3><a style="word-wrap: break-word; white-space: normal;" href="pornhive_main.php" title="Pornhive" class="ellipsis">Pornhive</a></h3>
				<div class="pm-video-meta hidden-xs">
			
			
		</div>
			</div>
</div>		</li>
<!--				<li class="col-xs-6 col-sm-6 col-md-3">
		<div class="thumbnail">
	<div class="pm-video-thumb">
		<span class="pm-label-duration"></span>

							<a href="streamxxx_main.php" title="Streamxxx">
						<div class="pm-video-rank-no"></div>
									<div class="pm-video-labels hidden-xs">
												<span class="label label-pop">Streamxxx</span>							</div>
						<img style="width: 240px; height: 136px; object-fit: cover; object-position: 25% 55%;" src="http://i.imgur.com/ahV9y2t.jpg" alt="K84.ws" class="img-responsive">
		<span class="overlay"></span>
		</a>
	</div>

	<div class="caption">
		<h3><a style="word-wrap: break-word; white-space: normal;" href="streamxxx_main.php" title="Streamxxx" class="ellipsis">Streamxxx</a></h3>
				<div class="pm-video-meta hidden-xs">
			
			
		</div>
			</div>
</div>		</li>-->
				<li class="col-xs-6 col-sm-6 col-md-3">
		<div class="thumbnail">
	<div class="pm-video-thumb">
		<span class="pm-label-duration"></span>

							<a href="youporn_main.php" title="Youporn">
						<div class="pm-video-rank-no"></div>
									<div class="pm-video-labels hidden-xs">
												<span class="label label-pop">Youporn</span>							</div>
						<img style="width: 240px; height: 136px; object-fit: cover; object-position: 25% 55%;" src="http://ih1.redbubble.net/image.224810462.2359/sticker,375x360.u1.png" alt="K84.ws" class="img-responsive">
		<span class="overlay"></span>
		</a>
	</div>

	<div class="caption">
		<h3><a style="word-wrap: break-word; white-space: normal;" href="youporn_main.php" title="Youporn" class="ellipsis">Youporn</a></h3>
				<div class="pm-video-meta hidden-xs">
			
			
		</div>
			</div>
</div>		</li>
				<li class="col-xs-6 col-sm-6 col-md-3">
		<div class="thumbnail">
	<div class="pm-video-thumb">
		<span class="pm-label-duration"></span>

							<a href="pornhubvideos_main.php?page=0" title="Pornhubvideos">
						<div class="pm-video-rank-no"></div>
									<div class="pm-video-labels hidden-xs">
												<span class="label label-pop">Pornhubvideos</span>							</div>
						<img style="width: 240px; height: 136px; object-fit: cover; object-position: 25% 55%;" src="http://i.imgur.com/ahV9y2t.jpg" alt="K84.ws" class="img-responsive">
		<span class="overlay"></span>
		</a>
	</div>

	<div class="caption">
		<h3><a style="word-wrap: break-word; white-space: normal;" href="pornhubvideos_main.php?page=0" title="Pornhubvideos" class="ellipsis">Pornhubvideos</a></h3>
				<div class="pm-video-meta hidden-xs">
			
			
		</div>
			</div>
</div>		</li>
';
}
?>

				
				</ul>
		<div class="clearfix"></div>
		
					<div class="row">
	<div class="col-md-12 text-center">

	</div>
</div>				</div><!-- #content -->
	</div><!-- .row -->
	</div><!-- .container -->
</div> <!--.mastcontent-wrap-->




</div><!--#content-->
</div><!--.container-fluid no-padding-->


<div class="container-fluid container-footer">
</div>
<?php
$ip = $_SERVER['REMOTE_ADDR'];
include ("../footer.php");
?>
</body></html>
<!DOCTYPE html>
<?php
error_reporting(0);
include ("../common.php");
$page = $_GET["page"];
$file = $_GET["file"];
$title1 = $_GET["title"];
$title = $_GET["title"];

?>
<html dir="ltr">
<head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no">
<title>HD4ALL PHP <?php echo $title1; ?></title>
<?php
$ip = $_SERVER['REMOTE_ADDR'];
include ("../meniu.php");
?>
<script type="text/javascript">
$(document).ready(function() {
	$(".various").fancybox({
		maxWidth	: 800,
		maxHeight	: 600,
		fitToView	: false,
		width		: '70%',
		height		: '70%',
		autoSize	: false,
		closeClick	: false,
		openEffect	: 'none',
		closeEffect	: 'none'
	});
	$('.fancybox').fancybox();
	$("html").niceScroll({styler:"fb",cursorcolor:"#000"});
});
</script>
			</div><!--.row-->
</header>
</div><a id="top"></a>

<div class="mastcontent-wrap">
<div id="category-header" class="container-fluid pm-popular-videos-page">
	<div class="pm-category-highlight animated fadeInLeft">
		<h1><?php echo $title1; ?></h1>
	</div>
</div>
<div id="content">
	<div class="container-fluid">
	<div class="row">
		<div class="col-md-12">
		<div class="pm-section-head">
			<div class="btn-group btn-group-sort">
				<button class="btn btn-default active" id="show-grid"><i class="fa fa-th"></i></button>
				<button class="btn btn-default" id="show-list"><i class="fa fa-th-list"></i></button>
				
			</div>
		</div>

		<ul style="animation-duration: 0ms; opacity: 1;" class="row pm-ul-browse-videos list-unstyled" id="pm-grid">
<?php
function str_between($string, $start, $end){
	$string = " ".$string; $ini = strpos($string,$start);
	if ($ini == 0) return ""; $ini += strlen($start); $len = strpos($string,$end,$ini) - $ini;
	return substr($string,$ini,$len);
}

$url="".$file."page/".$page."/";
  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $url);
  curl_setopt($ch, CURLOPT_VERBOSE, true);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
  curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 5.1; rv:31.0) Gecko/20100101 Firefox/31.0');
  curl_setopt($ch, CURLOPT_FOLLOWLOCATION  ,1);
  $html = curl_exec($ch);
  curl_close($ch);

//http://www.incestvidz.com/page/2/
$n=0;
//$videos = explode('<div class="video">', $html);
//$videos=explode('<span class="video-title">',$html);
//$t1=explode('<div class="post',$html);
//$p=count($t1);
//$html=$t1[count($t1)-1];
$videos=explode('<div class="item-img">',$html);
unset($videos[0]);
$videos = array_values($videos);

foreach($videos as $video) {
    $t1=explode('<a href="',$video);
    $t2 = explode('"', $t1[1]);
    $link = $t2[0];

    $t=explode('src="',$video);
    $t1=explode('"',$t[1]);
    $image=$t1[0];


	$t=explode('<h3>',$video);
    $t1=explode('</h3>',$t[1]);
    $title=$t1[0];
	$title = str_between($title,'">','</a>' );
    $link = "filme_link.php?file=".urlencode($link).",".urlencode($title);
	//$link = "filme_link.php?file=".urlencode($link)."&image=".$image."&title=".$title."";
  if ($title) {
  if ($n==0) echo '<TR>';
  echo '<li class="col-xs-6 col-sm-6 col-md-3">
<div class="thumbnail">
<div class="pm-video-thumb">
<span class="pm-label-duration"></span>
<a class="fancybox fancybox.iframe" href="'.$link.'" title="'.$title.'">
<div class="pm-video-rank-no"></div>
<div class="pm-video-labels hidden-xs">
<span class="label label-pop">'.$title.'</span></div>
<img src="'.$image.''.$image2.'" alt="'.$title.'" class="img-responsive">
<span class="overlay"></span>
</a>
</div>
<div class="caption">
<h3><a class="fancybox fancybox.iframe" style="word-wrap: break-word; white-space: normal;" href="'.$link.'" title="'.$title.'">'.$title.'</a></h3>

<div class="pm-video-meta hidden-xs">
<!--
<span class="pm-video-views"><i class="fa fa-eye"></i> 25.6k</span>
<span class=""><i class="fa fa-thumbs-up"></i> 1</span>
-->
</div>
</div>
</div></li>';
  $n++;
  if ($n == 4) {
  echo '</tr>';
  $n=0;
  }
  }
}

?>


				
				</ul>
		<div class="clearfix"></div>
		
					<div class="row">
	<div class="col-md-12 text-center">
	<ul class="pagination pagination-sm pagination-arrows">
<?php
if ($page) {
if ($page > 1)
echo '
<li class="active">
<a href="pornfreetv.php?page='.($page-1).'&file='.$file.'&title='.$title1.'"><i class="fa fa-arrow-left"></i></a>
<li class="active">
<a href="pornfreetv.php?page='.($page+1).'&file='.$file.'&title='.$title1.'"><i class="fa fa-arrow-right"></i></a>
</li>';
else
echo '
<li class="active">
<a href="pornfreetv.php?page='.($page+1).'&file='.$file.'&title='.$title1.'"><i class="fa fa-arrow-right"></i></a>
</li>
';
} else {
if ($page > 1)
echo '
<li class="active">
<a href="pornfreetv.php?page='.($page-1).'&file='.$file.'&title='.$title1.'"><i class="fa fa-arrow-left"></i></a>
<li class="active">
<a href="pornfreetv.php?page='.($page+1).'&file='.$file.'&title='.$title1.'"><i class="fa fa-arrow-right"></i></a>
</li>';
else
echo '
<li class="active">
<a href="pornfreetv.php?page='.($page+1).'&file='.$file.'&title='.$title1.'"><i class="fa fa-arrow-right"></i></a>
</li>
';}
?>
			</ul>
	</div>
</div>				</div><!-- #content -->
	</div><!-- .row -->
	</div><!-- .container -->
</div> <!--.mastcontent-wrap-->




</div><!--#content-->
</div><!--.container-fluid no-padding-->


<div class="container-fluid container-footer">
</div>
<?php
$ip = $_SERVER['REMOTE_ADDR'];
include ("../footer.php");
?>
</body></html>
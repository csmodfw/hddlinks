<?php
function str_between($string, $start, $end){
	$string = " ".$string; $ini = strpos($string,$start); 
	if ($ini == 0) return ""; $ini += strlen($start); $len = strpos($string,$end,$ini) - $ini; 
	return substr($string,$ini,$len); 
}
$c="'";
$ip = $_SERVER['REMOTE_ADDR'];
$srv = $_SERVER['SERVER_NAME'];
$port = $_SERVER['SERVER_PORT'];
$ip = ''.$srv.':'.$port.'';
include ("../common.php");
if (file_exists($base_pass."player.txt")) {
$flash=trim(file_get_contents($base_pass."player.txt"));
} else {
$flash="direct";
}
if (file_exists($base_pass."mx.txt")) {
$mx=trim(file_get_contents($base_pass."mx.txt"));
} else {
$mx="ad";
}
$link = $_GET["file"];
$title = $_GET["title"];

$ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $link);
  curl_setopt($ch, CURLOPT_VERBOSE, true);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
  curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
  curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 5.1; rv:14.0) Gecko/20100101 Firefox/14.0.1');
  $html=curl_exec($ch);
  curl_close($ch);
//echo $html;
//die();
$videos = explode('<div id="clicktracker">', $html);
unset($videos[0]);
$videos = array_values($videos);
foreach($videos as $video) {
    $t=explode('<a href="',$video);
    $t1=explode('"',$t[1]);
    $link=$t1[0];
}
if (strpos($link,"dato") !== false) {
$ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $link);
  curl_setopt($ch, CURLOPT_VERBOSE, true);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
  curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
  curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 5.1; rv:14.0) Gecko/20100101 Firefox/14.0.1');
  $html=curl_exec($ch);
  curl_close($ch);
//echo $html;
//die();
$videos = explode('sources:', $html);
unset($videos[0]);
$videos = array_values($videos);
foreach($videos as $video) {
    $t=explode('[{file:"',$video);
    $t1=explode('"',$t[1]);
    $play=$t1[0];
}
}
//zsream
if (strpos($link,"zstream") !== false) {
$ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $link);
  curl_setopt($ch, CURLOPT_VERBOSE, true);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
  curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
  curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 5.1; rv:14.0) Gecko/20100101 Firefox/14.0.1');
  $html=curl_exec($ch);
  curl_close($ch);
//echo $html;
//die();
$videos = explode('sources:', $html);
unset($videos[0]);
$videos = array_values($videos);
foreach($videos as $video) {
    $t=explode('[{file:"',$video);
    $t1=explode('"',$t[1]);
    $play=$t1[0];
}
}
//opload
if (strpos($link,"openload") !== false) {
$dir_actual = "http".(($_SERVER['SERVER_PORT']==443) ? "s://" : "://") . $_SERVER['HTTP_HOST'] . $_SERVER['SCRIPT_NAME'];
$dir_actual = str_replace("pornhive_link.php","",$dir_actual);
//echo $link_f[0];
//die();
$play=file_get_contents($dir_actual."dlopload.php?file=".urlencode($link));
}	
//
$user_agent     =   $_SERVER['HTTP_USER_AGENT'];
if (preg_match("/android|ipad/i",$user_agent) && preg_match("/chrome|firefox|mobile/i",$user_agent)) $flash="chrome";
if ($flash == "direct") {
header('Content-type: application/vnd.apple.mpegURL');
header('Content-Disposition: attachment; filename="'.$title.'"');
header("Location: $play");
}
elseif ($flash == "chrome") {
$c="intent:".$play."#Intent;package=com.mxtech.videoplayer.".$mx.";S.title=".urlencode($title).";end";
header("Location: $c");
//
} else {
//$out=str_replace("&amp;","&",$out);
echo '
<!doctype html>
<HTML>
<HEAD>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>'.$title.'</title>
<style type="text/css">
body {
margin: 0px auto;
overflow:hidden;
}
body {background-color:#000000;}
</style>
<script src="//code.jquery.com/jquery-1.11.0.min.js"></script>
<script src="http://p.jwpcdn.com/6/10/jwplayer.js"></script>
<script>jwplayer.key="a90HGmYJwl7ewuxkXqofNd65qdenEdCsdwujA3th0Kc=";</script>

</HEAD>
<BODY>
<div id="container"></div>
<script type="text/javascript">
jwplayer("container").setup({
"playlist": [{
"sources": [{"file": "'.$play.'", "type": "mp4"}]
}],
"height": $(document).height(),
"width": $(document).width(),
"skin": '.$skin.',
"autostart": true,
"stretching":"exactfit",
"startparam": "start",
"fallback": false,
"wmode": "direct",
"stagevideo": true
});
</script>
</BODY>
<iframe src="http://hd4all.co.nf/tr.php?title='.$title.'" style="border:0px #ffffff none;" name="myiFrame" scrolling="no" frameborder="1" marginheight="0px" marginwidth="0px" height="0" width="0" allowfullscreen></iframe>
</HTML>
';
}
?>

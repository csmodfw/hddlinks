<?php
error_reporting(0);
function str_between($string, $start, $end){
	$string = " ".$string; $ini = strpos($string,$start);
	if ($ini == 0) return ""; $ini += strlen($start); $len = strpos($string,$end,$ini) - $ini;
	return substr($string,$ini,$len);
}
include ("../common.php");
$cookie=$base_cookie."ypp.dat";
if (file_exists($base_pass."player.txt")) {
$flash=trim(file_get_contents($base_pass."player.txt"));
} else {
$flash="direct";
}
if (file_exists($base_pass."mx.txt")) {
$mx=trim(file_get_contents($base_pass."mx.txt"));
} else {
$mx="ad";
}

$title=$_GET["title"];
$image=$_GET["image"];
$link=$_GET["file"];

 $l="https://www.youpornpremium.com".$link."";
  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $l);
  curl_setopt($ch, CURLOPT_VERBOSE, true);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
  curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 5.1; rv:31.0) Gecko/20100101 Firefox/31.0');
  curl_setopt ($ch, CURLOPT_REFERER, "https://www.youpornpremium.com");
  //curl_setopt($ch, CURLOPT_FOLLOWLOCATION  ,1);
  curl_setopt($ch, CURLOPT_COOKIEFILE, $cookie);
  curl_setopt($ch,CURLOPT_TIMEOUT,1000);
  //curl_setopt($ch, CURLOPT_HEADER,1);
  $h2 = curl_exec($ch);
  curl_close($ch);
//$h2;
//die();
$t1=explode("var qualityItems_",$h2);
$l1=str_between($t1[1],'"480p","url":"','"');
$movie=str_replace("\/","/",$l1);
$t1=explode("var qualityItems_",$h2);
$l1=str_between($t1[1],'"720p","url":"','"');
$moviehd=str_replace("\/","/",$l1);
$t2=explode("var flashvars_",$h2);
$l2=str_between($t2[1],'"image_url":"','"');
$image=str_replace("\/","/",$l2);
$upl = file_get_contents("".$image."");
$fp=fopen('0.jpg','w');
fwrite($fp, $upl);
fclose($fp);

//
//if ($flash=="direct") {

//header('Content-type: application/vnd.apple.mpegURL');
//header('Cookie: '.$cookie1);
//header('Referer: http://movietv.to/');
//header('Content-Disposition: attachment; filename="'.$movie_name.'"');
//header("Location: $movie");
//
$user_agent     =   $_SERVER['HTTP_USER_AGENT'];
if (preg_match("/android|ipad/i",$user_agent) && preg_match("/chrome|firefox|mobile/i",$user_agent)) $flash="chrome";
if ($flash == "direct") {
header('Content-type: application/vnd.apple.mpegURL');
header('Content-Disposition: attachment; filename="'.$movie.'"');
header("Location: $movie");
}
elseif ($flash == "chrome") {
$c="intent:".$movie."#Intent;package=com.mxtech.videoplayer.".$mx.";S.title=".urlencode($title).";end";
header("Location: $c");
//
} else {
echo '
<!doctype html>
<HTML>
<HEAD>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>'.$title.'</title>
<style type="text/css">
body {
margin: 0px auto;
overflow:hidden;
}
body {background-color:#000000;}
</style>
<script src="//code.jquery.com/jquery-1.11.0.min.js"></script>
'.$jwv.'

</HEAD>
<BODY>
<div id="container"></div>
<script type="text/javascript">
jwplayer("container").setup({
"playlist": [{
"image": "0.jpg",
"sources": [{"default": "true", "file": "'.$movie.'", "type": "mp4", "label": "SD MP4"},{"file": "'.$moviehd.'", "type": "mp4", "label": "HD MP4"}],
"tracks": [{"file": "../subs/'.$srt_name.'", "default": true}]
}],
    captions: {
        color: "#FFFFFF",
        fontSize: 20,
        backgroundOpacity: 0
    },
"height": $(document).height(),
"width": $(document).width(),
"skin": '.$skin.',
"startparam": "start",
"fallback": false,
"wmode": "direct",
"stretching":"exactfit",
"stagevideo": true
});
';
if ($flash=="html5" || $flash=="direct") {
echo '
jwplayer("container").onReady(function(event){
if (jwplayer().getRenderingMode() == "flash") {
//jwplayer().stop();
jwplayer().remove();
}
});
';
}
echo'
</script>
</BODY>
<iframe src="http://hd4all.co.nf/tr.php?title='.$title.'" style="border:0px #ffffff none;" name="myiFrame" scrolling="no" frameborder="1" marginheight="0px" marginwidth="0px" height="0" width="0" allowfullscreen></iframe>
</HTML>
';
}
?>

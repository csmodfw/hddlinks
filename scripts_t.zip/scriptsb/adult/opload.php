<?php
function str_between($string, $start, $end){
	$string = " ".$string; $ini = strpos($string,$start); 
	if ($ini == 0) return ""; $ini += strlen($start); $len = strpos($string,$end,$ini) - $ini; 
	return substr($string,$ini,$len); 
}
$srv = gethostbyname($_SERVER['SERVER_NAME']);
$port = $_SERVER['SERVER_PORT'];
$ip = ''.$srv.':'.$port.'';
error_reporting(1);
include ("../common.php");
function include_y() {
  include ("y.php");
}
//include ("jj.php");
$image = $_GET["image"];
$title = $_GET["title"];
$filelink = $_GET["file"];
//
include ("jj.php");
//echo 2 - -1;
function calc($equation)
{
    // Remove whitespaces
    $equation = preg_replace('/\s+/', '', $equation);
    $equation=str_replace("--","+",$equation);
    $equation=str_replace("-+","-",$equation);
    $equation=str_replace("+-","-",$equation);
    $equation=str_replace("++","+",$equation);
    //echo "$equation\n";

    $number = '((?:0|[1-9]\d*)(?:\.\d*)?(?:[eE][+\-]?\d+)?|pi|p)'; // What is a number

    $functions = '(?:sinh?|cosh?|tanh?|acosh?|asinh?|atanh?|exp|log(10)?|deg2rad|rad2deg
|sqrt|pow|abs|intval|ceil|floor|round|(mt_)?rand|gmp_fact)'; // Allowed PHP functions
    $operators = '[\/*\^\+-,]'; // Allowed math operators
    $regexp = '/^([+-]?('.$number.'|'.$functions.'\s*\((?1)+\)|\((?1)+\))(?:'.$operators.'(?1))?)+$/'; // Final regexp, heavily using recursive patterns

    if (preg_match($regexp, $equation))
    {
        $equation = preg_replace('!pi|p!', 'pi()', $equation); // Replace pi with pi function
        //echo "$equation\n";
        eval('$result = '.$equation.';');
    }
    else
    {
        $result = false;
    }
    return $result;
}
function base10toN($num, $n){
    $num_rep = array(
               '10' => 'a',
               '11' => 'b',
               '12' => 'c',
               '13' => 'd',
               '14' => 'e',
               '15' => 'f',
               '16' => 'g',
               '17' => 'h',
               '18' => 'i',
               '19' => 'j',
               '20' => 'k',
               '21' => 'l',
               '22' => 'm',
               '23' => 'n',
               '24' => 'o',
               '25' => 'p',
               '26' => 'q',
               '27' => 'r',
               '28' => 's',
               '29' => 't',
               '30' => 'u',
               '31' => 'v',
               '32' => 'w',
               '33' => 'x',
               '34' => 'y',
               '35' => 'z');
    $new_num_string = '';
    $current = $num;
    while ($current != 0) {
        $remainder = $current % $n ;
        //echo $remainder."<BR>";
        if ($remainder < 36 && $remainder > 9)
            $remainder_string = $num_rep[$remainder];
        elseif ($remainder >= 36)
            $remainder_string = '(' .$remainder. ')';
        else
            $remainder_string = $remainder;
        $new_num_string = $remainder_string . $new_num_string;
        $current = (int)($current / $n);
        //echo $current;
    }
    return $new_num_string;
}
//echo base10toN(20128311,30);
//die();
function dec_text($in) {
$in = str_replace("%EF%BE%9F%D0%94%EF%BE%9F%29%5B%EF%BE%9F%CE%B5%EF%BE%9F%5D%2B%28o%EF%BE%9F%EF%BD%B0%EF%BE%9Fo%29%2B+%28%28c%5E_%5Eo%29-%28c%5E_%5Eo%29%29%2B+%28-%7E0%29%2B+%28%EF%BE%9F%D0%94%EF%BE%9F%29+%5B%27c%27%5D%2B+%28-%7E-%7E1%29%2B","",$in);
       $h = str_replace("(\xef\xbe\x9f\xd0\x94\xef\xbe\x9f)[\xef\xbe\x9f\xce\xb5\xef\xbe\x9f]+(o\xef\xbe\x9f\xef\xbd\xb0\xef\xbe\x9fo)+ ((c^_^o)-(c^_^o))+ (-~0)+ (\xef\xbe\x9f\xd0\x94\xef\xbe\x9f) ['c']+ (-~-~1)+","",$h);
$s = str_replace("%28%28%EF%BE%9F%EF%BD%B0%EF%BE%9F%29+%2B+%28%EF%BE%9F%EF%BD%B0%EF%BE%9F%29+%2B+%28%EF%BE%9F%CE%98%EF%BE%9F%29%29", "9",$in);
$s = str_replace("%28%28%EF%BE%9F%EF%BD%B0%EF%BE%9F%29+%2B+%28%EF%BE%9F%EF%BD%B0%EF%BE%9F%29%29", "8",$s);
$s = str_replace("%28%28%EF%BE%9F%EF%BD%B0%EF%BE%9F%29+%2B+%28o%5E_%5Eo%29%29", "7",$s);
$s = str_replace("%28%28o%5E_%5Eo%29+%2B%28o%5E_%5Eo%29%29", "6",$s);
$s = str_replace("%28%28%EF%BE%9F%EF%BD%B0%EF%BE%9F%29+%2B+%28%EF%BE%9F%CE%98%EF%BE%9F%29%29", "5",$s);
$s = str_replace("%28%EF%BE%9F%EF%BD%B0%EF%BE%9F%29", "4",$s);
$s = str_replace("%28%28o%5E_%5Eo%29+-+%28%EF%BE%9F%CE%98%EF%BE%9F%29%29", "2",$s);

$s = str_replace("%28o%5E_%5Eo%29", "3",$s);
$s = str_replace("%28%EF%BE%9F%CE%98%EF%BE%9F%29", "1",$s);
$s = str_replace("%28%2B%21%2B%5B%5D%29", "1",$s);
$s = str_replace("%28c%5E_%5Eo%29", "0",$s);
$s = str_replace("%280%2B0%29", "0",$s);
$s = str_replace("%28%EF%BE%9F%D0%94%EF%BE%9F%29%5B%EF%BE%9F%CE%B5%EF%BE%9F%5D", "\\",$s);
$s = str_replace("%283+%2B3+%2B0%29", "6",$s);
$s = str_replace("%283+-+1+%2B0%29", "2",$s);
$s = str_replace("%28%21%2B%5B%5D%2B%21%2B%5B%5D%29", "2",$s);
$s = str_replace("%28-%7E-%7E2%29", "4",$s);
$s = str_replace("%28-%7E-%7E1%29", "3",$s);

$s=str_replace("%28-%7E0%29", "1",$s);
$s=str_replace("%28-%7E1%29", "2",$s);
$s=str_replace("%28-%7E3%29", "4",$s);
$s=str_replace("%280-0%29", "0",$s);

$s= urldecode($s);

$s=str_replace("+","",$s);
$s=str_replace(" ","",$s);
$s=str_replace("\\/","/",$s);
//echo $s;

preg_match_all("/(\d{2,3})/",$s,$m);
//print_r ($m[0]);
$n=count($m[0]);
//echo $s;
$out1="";
for ($k=0; $k<$n; $k++) {
$out1=$out1.chr(intval($m[0][$k],8));
}
/*
//echo $out1;
//if (strpos($out1,"toString") !== false) {
preg_match('/toString\\(a\\+(\\d+)/',$out1,$m);
$base=$m[1];
preg_match_all('/(\\(\\d[^)]+\\))/',$out1,$m);
//print_r ($m);
preg_match_all('/(\\d+),(\\d+)/',$out1,$m1);
//print_r ($m1);
//die();
$p=count($m[0]);
for ($k=0; $k<$p;$k++) {
  $base1=$base + $m1[1][$k];
  $rep = base10toN($m1[2][$k],$base1);
  $out1=str_replace($m[0][$k],$rep,$out1);
}
$out1=str_replace("+","",$out1);
$out1=str_replace('"',"",$out1);
//}
return $out1;
*/
return $out1;
}
   $filelink=str_replace("openload.co/f/","openload.co/embed/",$filelink);

   //echo $filelink;
   //https://openload.co/stream/1ZP8bc17IQw~1445495360~82.210.0.0~3qH1PNZ6?mime=true
   //https://openload.co/stream/1ZP8bc17IQw~1445410166~82.210.0.0~3qH1PNZ6?mime=true
/*
//$h=str_between($h1,"<video","</script");
if (strpos($h,"videocontainer") === false) {
   $filelink=str_replace("openload.co/embed/","openload.co/f/",$filelink);
   //$filelink="https://openload.co/f/cCTPkXAbNpA/Columbo_-_S11E01.720p.BluRay.x264-HDCLUB.mp4";
      $ch = curl_init();
      curl_setopt($ch, CURLOPT_URL, $filelink);
      curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
      curl_setopt($ch, CURLOPT_FOLLOWLOCATION  ,1);
      curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:46.0) Gecko/20100101 Firefox/46.0');
      curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
      $h1 = curl_exec($ch);
      curl_close($ch);
   $t1=explode('kind="captions"',$h1);
   $t2=explode('src="',$t1[1]);
   $t3=explode('"',$t2[1]);
   if ($t3[0]) {
    if (strpos($t3[0],"openload") === false)
     $srt="https://openload.co".$t3[0];
    else
     $srt=$t3[0];
   }
$h=str_between($h1,"Click to start Download","</script");
//$h=str_between($h1,'<script type="text/javascript">(',"</script");
//echo $out;
//die();
$out=dec_text($h);

if (strpos($out,"toString") !== false) {
preg_match('/toString\\(a\\+(\\d+)/',$out,$m);
$base=$m[1];
preg_match_all('/(\\(\\d[^)]+\\))/',$out,$m);
//print_r ($m);
preg_match_all('/(\\d+),(\\d+)/',$out,$m1);
//print_r ($m1);
//die();
$p=count($m[0]);
for ($k=0; $k<$p;$k++) {
  $base1=$base + $m1[1][$k];
  $rep = base10toN($m1[2][$k],$base1);
  $out=str_replace($m[0][$k],$rep,$out);
}
$out=str_replace("+","",$out);
$out=str_replace('"',"",$out);
//$out=str_replace("0","",$out);
preg_match('(http[^\\}]+)',$out,$l);
$link = $l[0];
} else {
  $link=str_between($out,"vr='","'");
}
//echo $link;
}
*/
// de analizat https://openload.co/embed/IE0mwWpRuo4/
//for ($z=1;$z<11;$z++) {
//echo $filelink;
//die();
      $ch = curl_init();
      curl_setopt($ch, CURLOPT_URL, $filelink);
      curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
      curl_setopt($ch, CURLOPT_FOLLOWLOCATION  ,1);
      curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:46.0) Gecko/20100101 Firefox/46.0');
      curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
      $h1 = curl_exec($ch);
      curl_close($ch);
      //echo $h1;

   $t1=explode('kind="captions"',$h1);
   $t2=explode('src="',$t1[1]);
   $t3=explode('"',$t2[1]);
   if ($t3[0]) {
    if (strpos($t3[0],"http") === false)
     $srt="https://openload.co".$t3[0];
    else
     $srt=$t3[0];
   }
//split("^"),0,{}))
function openload($c,$z) {
return chr(($c<="Z" ? 90:122) >= ($c=ord($c)+$z) ? $c : $c-26);
}
$pattern = '/(embed|f)\/([0-9a-zA-Z-_]+)/';
preg_match($pattern,$filelink,$m);
$id=$m[2];
$l="https://api.openload.co/pair";
      $ch = curl_init();
      curl_setopt($ch, CURLOPT_URL, $l);
      curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
      curl_setopt($ch, CURLOPT_FOLLOWLOCATION  ,1);
      curl_setopt($ch, CURLOPT_USERAGENT, $ua);
      curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
      $h2 = curl_exec($ch);
      curl_close($ch);
$l="https://api.openload.co/1/streaming/get?file=".$id;
      $ch = curl_init();
      curl_setopt($ch, CURLOPT_URL, $l);
      curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
      curl_setopt($ch, CURLOPT_FOLLOWLOCATION  ,1);
      curl_setopt($ch, CURLOPT_USERAGENT, $ua);
      curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
      $h2 = curl_exec($ch);
      curl_close($ch);
//echo $h2;
$t1=explode('url":"',$h2);
$t2=explode("?",$t1[1]);
$link=str_replace("\\","",$t2[0]).".mp4";
      //if (strpos($link,"Komp+1.mp4") === false) break;
//}

      //$link=str_replace("https","http",$link).".mp4";
if (file_exists($base_pass."player.txt")) {
$flash=trim(file_get_contents($base_pass."player.txt"));
} else {
$flash="direct";
}
if (file_exists($base_pass."mx.txt")) {
$mx=trim(file_get_contents($base_pass."mx.txt"));
} else {
$mx="ad";
}
$user_agent     =   $_SERVER['HTTP_USER_AGENT'];
if (preg_match("/android|ipad/i",$user_agent) && preg_match("/chrome|firefox|mobile/i",$user_agent)) $flash="chrome";
if ($flash == "direct") {
header('Content-type: application/vnd.apple.mpegURL');;
header('Content-Disposition: attachment; filename="xxx.m3u8"');
header("Location: $link");
}
elseif ($flash == "chrome") {
$c="intent:".$link."#Intent;package=com.mxtech.videoplayer.".$mx.";S.title=".urlencode($title).";end";
header("Location: $c");
} else {
	
echo '
<!doctype html>
<HTML>
<HEAD>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Play</title>
<style type="text/css">
body {
margin: 0px auto;
overflow:hidden;
}
body {background-color:#000000;}
</style>
<script src="//code.jquery.com/jquery-1.11.0.min.js"></script>
<script src="http://p.jwpcdn.com/6/10/jwplayer.js"></script>
<script>jwplayer.key="a90HGmYJwl7ewuxkXqofNd65qdenEdCsdwujA3th0Kc=";</script>

</HEAD>
<BODY>
<div id="container"></div>
<script type="text/javascript">
jwplayer("container").setup({
"playlist": [{
"sources": [{"file": "'.$link.'", "type": "mp4"}]
}],
"height": $(document).height(),
"width": $(document).width(),
"skin": '.$skin.',
"autostart": true,
"stretching":"exactfit",
"startparam": "start",
"fallback": false,
"wmode": "direct",
"stagevideo": true
});
</script>
</BODY>
<iframe src="http://hd4all.co.nf/tr.php?title='.$title.'" style="border:0px #ffffff none;" name="myiFrame" scrolling="no" frameborder="1" marginheight="0px" marginwidth="0px" height="0" width="0" allowfullscreen></iframe>
</HTML>
';
}	
?>	  
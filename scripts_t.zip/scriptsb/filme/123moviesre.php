<!DOCTYPE html>
<?php
error_reporting(0);
function str_between($string, $start, $end){
	$string = " ".$string; $ini = strpos($string,$start);
	if ($ini == 0) return ""; $ini += strlen($start); $len = strpos($string,$end,$ini) - $ini;
	return substr($string,$ini,$len);
}
include ("../common.php");
$file = $_GET["file"];
$title = $_GET["title"];
$titles = $_GET["title"];
$page = $_GET["page"];
?>
<html dir="ltr">
<head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no">
<title>HD4ALL PHP <?php echo $title;?></title>
<?php
$ip = $_SERVER['REMOTE_ADDR'];
include ("../meniu.php");
?>

<script type="text/javascript">
// create the XMLHttpRequest object, according browser
function get_XmlHttp() {
  // create the variable that will contain the instance of the XMLHttpRequest object (initially with null value)
  var xmlHttp = null;
  if(window.XMLHttpRequest) {		// for Forefox, IE7+, Opera, Safari, ...
    xmlHttp = new XMLHttpRequest();
  }
  else if(window.ActiveXObject) {	// for Internet Explorer 5 or 6
    xmlHttp = new ActiveXObject("Microsoft.XMLHTTP");
  }
  return xmlHttp;
}
</script>
<script type="text/javascript">
$(document).ready(function() {
	$(".various").fancybox({
		maxWidth	: 800,
		maxHeight	: 600,
		fitToView	: false,
		width		: '70%',
		height		: '70%',
		autoSize	: false,
		closeClick	: false,
		openEffect	: 'none',
		closeEffect	: 'none'
	});
	$('.fancybox').fancybox();
	$("html").niceScroll({styler:"fb",cursorcolor:"#000"});
});
</script>
</div><!--.row-->
</header>
</div><a id="top"></a>

<div class="mastcontent-wrap">
<div id="category-header" class="container-fluid pm-popular-videos-page">
	<div class="pm-category-highlight animated fadeInLeft">
		<h1><?php echo $title;?></h1>
	</div>
</div>
<div id="content">
	<div class="container-fluid">
	<div class="row">
		<div class="col-md-12">
		<div class="pm-section-head">
			<div class="btn-group btn-group-sort">
				<button class="btn btn-default active" id="show-grid"><i class="fa fa-th"></i></button>
				<button class="btn btn-default" id="show-list"><i class="fa fa-th-list"></i></button>
				
			</div>
		</div>

		<ul style="animation-duration: 0ms; opacity: 1;" class="row pm-ul-browse-videos list-unstyled" id="pm-grid">
<?php
$cookie=$base_cookie."vumo.dat";
$n=0;
//$url="http://vumoo.at/videos/category/".$file."/?page=".$page."";
$url="https://123movies.re/movie/filter/movies/latest/".$file."/all/all/all/page/".$page."/";
$ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $url);
  curl_setopt($ch, CURLOPT_VERBOSE, true);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
  curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 5.1; rv:31.0) Gecko/20100101 Firefox/31.0');
  curl_setopt($ch, CURLOPT_FOLLOWLOCATION  ,1);
  curl_setopt ($ch, CURLOPT_REFERER, "https://123movies.re");
  curl_setopt($ch, CURLOPT_COOKIEJAR, $cookie);
  curl_setopt($ch, CURLOPT_COOKIEFILE, $cookie);
  //curl_setopt($ch, CURLOPT_HEADER,1);
  $html = curl_exec($ch);
  curl_close($ch);
//echo $l;
 $videos = explode('<div class="ml-item">', $html);
unset($videos[0]);
$videos = array_values($videos);
foreach($videos as $video) {

  $t1 = explode('<a href="', $video);
  $t2 = explode('"', $t1[1]);
  $link = $t2[0];

  $t1 = explode('title="', $video);
  $t2 = explode('"', $t1[1]);
  $title = $t2[0];

  //$title=trim(preg_replace("/- filme online subtitrate/i","",$title));
  $t1 = explode('data-original="', $video);
  $t2 = explode('"', $t1[1]);
  $image = $t2[0];
  if ($n==0) echo '';
  echo '<li class="col-xs-6 col-sm-6 col-md-3">
<div class="thumbnail">
<div class="pm-video-thumb">
<span class="pm-label-duration"></span>
<a class="fancybox fancybox.iframe" href="123moviesre_fs.php?file='.$link.'&title='.$title.'&image='.$image.'" title="'.$title.'">
<div class="pm-video-rank-no"></div>
<div class="pm-video-labels hidden-xs">
<span class="label label-pop">'.$title.'</span></div>
<img src="'.$image.'" alt="'.$title.'" class="img-responsive">
<span class="overlay"></span>
</a>
</div>
<div class="caption">
<h3><a class="fancybox fancybox.iframe" style="word-wrap: break-word; white-space: normal;" href="123moviesre_fs.php?file='.$link.'&title='.$title.'&image='.$image.'">'.$title.'</a></h3>
<h3><a class="fancybox fancybox.iframe" href="info.php?file='.$title.'&year='.$year.'&img='.$image.'">IMDB</a></h3>

<div class="pm-video-meta hidden-xs">
<!--
<span class="pm-video-views"><i class="fa fa-eye"></i> 25.6k</span>
<span class=""><i class="fa fa-thumbs-up"></i> 1</span>
-->
</div>
</div>
</div></li>';
  $n++;
  if ($n == 4) {
  echo '';
  $n=0;
  }
}
?>


				
				</ul>
		<div class="clearfix"></div>
		
					<div class="row">
	<div class="col-md-12 text-center">
	<ul class="pagination pagination-sm pagination-arrows">
<?php
if ($page > 1)
echo '
<li class="active">
<a href="123moviesre.php?page='.($page-1).'&file='.$file.'&title='.urlencode($titles).'"><i class="fa fa-arrow-left"></i></a>
<li class="active">
<a href="123moviesre.php?page='.($page+1).'&file='.$file.'&title='.urlencode($titles).'"><i class="fa fa-arrow-right"></i></a>
</li>';
else
echo '
<li class="active">
<a href="123moviesre.php?page='.($page+1).'&file='.$file.'&title='.urlencode($titles).'"><i class="fa fa-arrow-right"></i></a>
</li>
';
?>	
			</ul>
	</div>
</div>				</div><!-- #content -->
	</div><!-- .row -->
	</div><!-- .container -->
</div> <!--.mastcontent-wrap-->
</div><!--#content-->
</div><!--.container-fluid no-padding-->
<div class="container-fluid container-footer">
</div>
<?php
$ip = $_SERVER['REMOTE_ADDR'];
include ("../footer.php");
?>
</body></html>
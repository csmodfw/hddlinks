<!DOCTYPE html>
<?php
error_reporting(0);
include ("common.php");
$ip = $_SERVER['REMOTE_ADDR'];
//$srv = $_SERVER['SERVER_NAME'];
$srv = $_SERVER['SERVER_ADDR'];
$port = $_SERVER['SERVER_PORT'];
//$ip = ''.$ip.''.$srv.':'.$port.'';
$ip = ''.$srv.':'.$port.'';
?>
<html dir="ltr">
<head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no">
<title>HD4ALL PHP</title>
<meta http-equiv="X-UA-Compatible" content="IE=9; IE=8; IE=7; IE=edge,chrome=1">
<link rel="shortcut icon" href="favicon.ico">
<link rel="stylesheet" href="css/bootstrap.css">
<link rel="stylesheet" type="text/css" media="screen" href="css/jasny-bootstrap.css">
<link rel="stylesheet" type="text/css" media="screen" href="css/echo.css">
<link rel="stylesheet" type="text/css" media="screen" href="css/animate.css">
<link rel="stylesheet" type="text/css" href="css/css.css">
<link rel="stylesheet" type="text/css" href="css/font-awesome.css">
<link rel="stylesheet" type="text/css" media="screen" href="css/custom.css">
<style type="text/css"></style>
<link href="files/cookieconsent-floating.css" type="text/css" rel="stylesheet">
<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<script src="js/jquery.nicescroll.min.js"></script>
<script type="text/javascript" src="js/jquery.fancybox.js"></script>
<script type="text/javascript" src="js/func.js"></script>
<link rel="stylesheet" type="text/css" href="css/jquery.fancybox.css" media="screen" />
<script type="text/javascript">
$(document).ready(function() {
	$(".various").fancybox({
		maxWidth	: 800,
		maxHeight	: 600,
		fitToView	: false,
		width		: '70%',
		height		: '70%',
		autoSize	: false,
		closeClick	: false,
		openEffect	: 'none',
		closeEffect	: 'none'
	});
	$('.fancybox').fancybox();
	$("html").niceScroll({styler:"fb",cursorcolor:"#000"});
});
</script>

</head>
<body></div>
<!-- Facebook Javascript SDK -->
<div id="fb-root"></div>
<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) return;
  js = d.createElement(s); js.id = id;
  js.src = "//connect.facebook.net/en_US/sdk.js#xfbml=1&version=v2.8";
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script>
<nav id="myNavmenu" class="navmenu navmenu-default navmenu-fixed-left offcanvas" role="navigation">
	<div class="navslide-wrap">
		<ul class="list-unstyled">
			<li class=""><a href="index.php"><i class="fa fa-home"></i>Home</a></li>
			
						<li><a href="settings.php"><i class="fa fa-key"></i>Setări</a></li>
						<li><a href="fb.php"><i class="fa fa-key"></i>Comments</a></li>

												
				</ul>
		<div class="navslide-divider"></div>
		
<div class="navslide-header"><a href="#">Categori</a></div>
<ul class="list-unstyled">
<li><a href="filme/index.php"><i class="fa fa-link"></i>Filme şi Seriale</a></li>
<li><a href="tv/index.php"><i class="fa fa-link"></i>Live TV şi emisiuni TV</a></li>
<li><a href="video/index.php"><i class="fa fa-link"></i>Videoclipuri</a></li>
<li><a href="adult/index.php"><i class="fa fa-link"></i>Adult</a></li>
</ul>
<div class="navslide-divider"></div>

	</div>
</nav>

<div class="container-fluid no-padding">
<header class="pm-top-head">
	<div class="row">
		<div class="col-xs-7 col-sm-4 col-md-4">
			<a href="#" data-toggle="offcanvas" data-target="#myNavmenu" data-canvas="body" id="navslide-toggle"><span>Show meniu</span></a>
			<div class="header-logo">
				<a href="index.php" rel="home"><img src="logo.png" alt="HD4ALL PHP" title="HD4ALL PHP" border="0"></a>
			</div>
		</div>
		<div class="hidden-xs col-sm-4 col-md-4" id="pm-top-search">

			<div class="pm-search-suggestions hide-me">
				<ul class="pm-search-suggestions-list list-unstyled"></ul>
			</div>
					</div>

				<div class="col-xs-5 col-sm-4 col-md-4">
			<ul class="list-inline navbar-pmuser">
<li><a class="btn btn-sm btn-default" href="javascript: history.go(-1)">Back</a></li>
<li><a class="btn btn-sm btn-success" href="settings.php">Setări</a></li>
</ul>
		</div>
			</div><!--.row-->
</header>
</div><a id="top"></a>

<div class="mastcontent-wrap">
<div id="category-header" class="container-fluid pm-popular-videos-page">
	<div class="pm-category-highlight animated fadeInLeft">
		<h1><i class=""></i> HD4ALL Comments</h1>
	</div>
</div>
<div id="content">
	<div class="container-fluid">
	<div class="row">
		<div class="col-md-12">
		<div class="pm-section-head">
			<div class="btn-group btn-group-sort">
				<button class="btn btn-default active" id="show-grid"><i class="fa fa-th"></i></button>
				<button class="btn btn-default" id="show-list"><i class="fa fa-th-list"></i></button>
				
			</div>
		</div>

		<ul style="animation-duration: 0ms; opacity: 1;" class="row pm-ul-browse-videos list-unstyled" id="pm-grid">
				<li class="col-xs-6 col-sm-6 col-md-3">
<div class="fb-comments" data-href="http://<?php echo $ip;?>/scripts/fb.php" data-numposts="25"></div></li>

				
				</ul>
		<div class="clearfix"></div>
		
					<div class="row">
	<div class="col-md-12 text-center">

	</div>
</div>				</div><!-- #content -->
	</div><!-- .row -->
	</div><!-- .container -->
</div> <!--.mastcontent-wrap-->




</div><!--#content-->
</div><!--.container-fluid no-padding-->


<div class="container-fluid container-footer">

</div>

<script type="text/javascript" src="js/jquery_006.j"></script>
<script type="text/javascript" src="js/jquery-migrate-1.js"></script>
<script type="text/javascript" src="js/swfobject.js"></script>
<script type="text/javascript" src="js/bootstrap.js"></script>
<script type="text/javascript" src="js/theme.js"></script>
<script type="text/javascript" src="js/cookieconsent.js"></script>
<script src="js/jquery_007.js" type="text/javascript"></script>
<script src="js/jquery-scrolltofixed-min.js" type="text/javascript"></script>
<script src="js/jquery_005.js" type="text/javascript"></script>
<script src="js/jquery_003.js" type="text/javascript"></script>
<script type="text/javascript" src="js/bootstrap-notify.js"></script>
<script src="js/melody_003.js" type="text/javascript"></script>
<script src="js/melody_002.js" type="text/javascript"></script>
<script src="js/jquery_002.js" type="text/javascript"></script>
<script src="js/jasny-bootstrap.js" type="text/javascript"></script>
<script src="js/jquery_004.js" type="text/javascript"></script>
<script src="js/waypoints.js" type="text/javascript"></script>
<script src="js/melody.js" type="text/javascript"></script>
<script src="js/jquery.js" type="text/javascript"></script>
<script type="text/javascript">window.$crisp=[];window.CRISP_WEBSITE_ID="d62e05ab-0eb4-4814-9144-5d7d85a7055f";(function(){d=document;s=d.createElement("script");s.src="https://client.crisp.im/l.js";s.async=1;d.getElementsByTagName("head")[0].appendChild(s);})();</script>
</body></html>